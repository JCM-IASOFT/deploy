"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TerminalModel = void 0;
const typeorm_1 = require("typeorm");
const store_1 = require("../inventory/store");
const priceGroup_1 = require("./priceGroup");
const currency_1 = require("../company/currency");
const bankAccount_1 = require("../company/bankAccount");
const terminalType_1 = require("./terminalType");
const campus_1 = require("../company/campus");
const company_1 = require("../company/company");
const shift_1 = require("./shift");
const cashBoxDetail_1 = require("../accounting/cashBoxDetail");
const employe_1 = require("../humanResource/employe");
const paymentTypeTerminal_1 = require("../company/paymentTypeTerminal");
let TerminalModel = class TerminalModel extends typeorm_1.BaseEntity {
};
exports.TerminalModel = TerminalModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], TerminalModel.prototype, "terminalId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], TerminalModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], TerminalModel.prototype, "maxShift", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], TerminalModel.prototype, "isCashCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], TerminalModel.prototype, "warehouseId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], TerminalModel.prototype, "showOutOfStock", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], TerminalModel.prototype, "sellOutOfStock", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], TerminalModel.prototype, "priceGroupId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], TerminalModel.prototype, "currencyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], TerminalModel.prototype, "bankAccountId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], TerminalModel.prototype, "terminalTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], TerminalModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], TerminalModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], TerminalModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], TerminalModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], TerminalModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => store_1.StoreModel, (store) => store.terminals),
    (0, typeorm_1.JoinColumn)({ name: 'warehouseId', referencedColumnName: 'storeId' }),
    __metadata("design:type", store_1.StoreModel)
], TerminalModel.prototype, "warehouse", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => priceGroup_1.PriceGroupModel, (priceGroup) => priceGroup.terminals),
    (0, typeorm_1.JoinColumn)({ name: 'priceGroupId', referencedColumnName: 'priceGroupId' }),
    __metadata("design:type", priceGroup_1.PriceGroupModel)
], TerminalModel.prototype, "priceGroup", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => currency_1.CurrencyModel, (currency) => currency.terminals),
    (0, typeorm_1.JoinColumn)({ name: 'currencyId', referencedColumnName: 'currencyId' }),
    __metadata("design:type", currency_1.CurrencyModel)
], TerminalModel.prototype, "currency", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => bankAccount_1.BankAccountModel, (bankAccount) => bankAccount.terminals),
    (0, typeorm_1.JoinColumn)({ name: 'bankAccountId', referencedColumnName: 'bankAccountId' }),
    __metadata("design:type", bankAccount_1.BankAccountModel)
], TerminalModel.prototype, "bankAccount", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => terminalType_1.TerminalTypeModel, (terminalType) => terminalType.terminals),
    (0, typeorm_1.JoinColumn)({ name: 'terminalTypeId', referencedColumnName: 'terminalTypeId' }),
    __metadata("design:type", terminalType_1.TerminalTypeModel)
], TerminalModel.prototype, "terminalType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, (campus) => campus.terminals),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], TerminalModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.terminals),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], TerminalModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.ManyToMany)(() => shift_1.ShiftModel, (shift) => shift.terminals),
    (0, typeorm_1.JoinTable)({
        name: "terminal_shift",
        schema: "sales",
        joinColumn: {
            name: "terminalId",
            referencedColumnName: "terminalId"
        },
        inverseJoinColumn: {
            name: "shiftId",
            referencedColumnName: "shiftId"
        }
    }),
    __metadata("design:type", Array)
], TerminalModel.prototype, "shifts", void 0);
__decorate([
    (0, typeorm_1.ManyToMany)(() => employe_1.EmployeModel, (employe) => employe.terminals),
    (0, typeorm_1.JoinTable)({
        name: "terminal_employe",
        schema: "sales",
        joinColumn: {
            name: "terminalId",
            referencedColumnName: "terminalId"
        },
        inverseJoinColumn: {
            name: "employeId",
            referencedColumnName: "employeId"
        }
    }),
    __metadata("design:type", Array)
], TerminalModel.prototype, "employes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => cashBoxDetail_1.CashBoxDetailModel, (details) => details.terminal),
    __metadata("design:type", Array)
], TerminalModel.prototype, "cashBoxDetails", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => paymentTypeTerminal_1.PaymentTypeTerminalModel, (paymentTypeTerminal) => paymentTypeTerminal.terminal),
    __metadata("design:type", Array)
], TerminalModel.prototype, "paymentTypeTerminals", void 0);
exports.TerminalModel = TerminalModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'terminal' })
], TerminalModel);
//# sourceMappingURL=terminal.js.map