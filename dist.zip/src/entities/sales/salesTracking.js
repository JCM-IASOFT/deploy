"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesTrackingModel = void 0;
const typeorm_1 = require("typeorm");
const sales_1 = require("./sales");
const client_1 = require("./client");
const campus_1 = require("../company/campus");
let SalesTrackingModel = class SalesTrackingModel extends typeorm_1.BaseEntity {
};
exports.SalesTrackingModel = SalesTrackingModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "salesTrackingId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 150, nullable: true }),
    __metadata("design:type", String)
], SalesTrackingModel.prototype, "comment", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], SalesTrackingModel.prototype, "estado", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], SalesTrackingModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], SalesTrackingModel.prototype, "lastTraking", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "clientId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "salesId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sales_1.SalesModel, sales => sales.salesTracking),
    (0, typeorm_1.JoinColumn)({ name: 'salesId', referencedColumnName: 'salesId' }),
    __metadata("design:type", sales_1.SalesModel
    /**
    * Relacion ManyToOne con clientes
    */
    )
], SalesTrackingModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => client_1.ClientModel, client => client.salesTracking),
    (0, typeorm_1.JoinColumn)({ name: 'clientId', referencedColumnName: 'clientId' }),
    __metadata("design:type", client_1.ClientModel
    /**
    * Relacion ManyToOne con clientes
    */
    )
], SalesTrackingModel.prototype, "client", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.salesTracking),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel
    /**
     * Indicador de eliminación lógica del registro ('0' = no eliminado).
     */
    )
], SalesTrackingModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], SalesTrackingModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], SalesTrackingModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], SalesTrackingModel.prototype, "updatedAt", void 0);
exports.SalesTrackingModel = SalesTrackingModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'sales_tracking' })
], SalesTrackingModel);
//# sourceMappingURL=salesTracking.js.map