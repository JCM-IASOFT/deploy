"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CashClosingDetailModel = void 0;
const typeorm_1 = require("typeorm");
const cashClosing_1 = require("./cashClosing");
/**
 * * Cierre de caja
 */
let CashClosingDetailModel = class CashClosingDetailModel extends typeorm_1.BaseEntity {
};
exports.CashClosingDetailModel = CashClosingDetailModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CashClosingDetailModel.prototype, "cashClosingDetailId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashClosingDetailModel.prototype, "cashClosingId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 60, default: 'SIN/NUMERO' }),
    __metadata("design:type", String)
], CashClosingDetailModel.prototype, "invoiceNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], CashClosingDetailModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "decimal", precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CashClosingDetailModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "decimal", precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CashClosingDetailModel.prototype, "inputAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "decimal", precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CashClosingDetailModel.prototype, "outputAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashClosingDetailModel.prototype, "inOut", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], CashClosingDetailModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashClosingDetailModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashClosingDetailModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => cashClosing_1.CashClosingModel, cashClosing => cashClosing.cashClosingDetails),
    (0, typeorm_1.JoinColumn)({ name: 'cashClosingId', referencedColumnName: 'cashClosingId' }),
    __metadata("design:type", cashClosing_1.CashClosingModel)
], CashClosingDetailModel.prototype, "cashClosing", void 0);
exports.CashClosingDetailModel = CashClosingDetailModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'cash_closing_detail', comment: 'Detalle de cierre de caja' })
], CashClosingDetailModel);
//# sourceMappingURL=cashClosingDetail.js.map