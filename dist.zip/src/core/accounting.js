"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MonetaryUnit = void 0;
var MonetaryUnit;
(function (MonetaryUnit) {
    MonetaryUnit["BILLETE"] = "billete";
    MonetaryUnit["MONEDA"] = "moneda";
})(MonetaryUnit || (exports.MonetaryUnit = MonetaryUnit = {}));
//# sourceMappingURL=accounting.js.map