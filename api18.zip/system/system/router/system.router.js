"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.systemRoute = void 0;
const express_1 = require("express");
const system_controller_1 = require("../controller/system.controller");
exports.systemRoute = (0, express_1.Router)();
exports.systemRoute.get('/', system_controller_1.systemController.findAllSystem);
exports.systemRoute.post('/', system_controller_1.systemController.createSystems);
exports.systemRoute.put('/', system_controller_1.systemController.updateSystem);
//# sourceMappingURL=system.router.js.map