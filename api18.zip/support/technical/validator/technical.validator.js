"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateEfficiencyTechnical = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateEfficiencyTechnical = [
    (0, express_validator_1.check)('startDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('endDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('userId').exists().isNumeric().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=technical.validator.js.map