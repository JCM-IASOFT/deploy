"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteSector = exports.validateUpdateSector = exports.validateCreateSector = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateSector = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateSector = [
    (0, express_validator_1.check)('sectorId').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteSector = [
    (0, express_validator_1.check)('sectorId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=sector.validator.js.map