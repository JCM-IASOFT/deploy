"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeTransaction = void 0;
exports.typeTransaction = {
    INGRESO: 'ingreso',
    EGRESO: 'egreso'
};
//# sourceMappingURL=typeOperation.constant.js.map