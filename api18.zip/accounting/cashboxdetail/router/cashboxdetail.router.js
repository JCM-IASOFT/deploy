"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashboxdetailRoute = void 0;
const express_1 = require("express");
const cashboxdetail_validator_1 = require("../validator/cashboxdetail.validator");
const cashboxdetail_controller_1 = require("../controller/cashboxdetail.controller");
exports.cashboxdetailRoute = (0, express_1.Router)();
exports.cashboxdetailRoute.get('/', cashboxdetail_controller_1.cashboxdetailController.findCashBoxDetail);
exports.cashboxdetailRoute.post('/dataTable', cashboxdetail_controller_1.cashboxdetailController.findCashBoxDetailDataTable);
exports.cashboxdetailRoute.get('/one', cashboxdetail_controller_1.cashboxdetailController.findOneCashBoxDetail);
exports.cashboxdetailRoute.get('/open_box', cashboxdetail_controller_1.cashboxdetailController.isTheBoxOpened);
exports.cashboxdetailRoute.post('/', cashboxdetail_validator_1.validateCreateCashBoxDetail, cashboxdetail_controller_1.cashboxdetailController.createCashBoxDetails);
exports.cashboxdetailRoute.post('/close_petty_cash', cashboxdetail_validator_1.validateClosePettyCash, cashboxdetail_controller_1.cashboxdetailController.closePettyCash);
exports.cashboxdetailRoute.delete('/', cashboxdetail_validator_1.validateDeleteCashBoxDetail, cashboxdetail_controller_1.cashboxdetailController.deleteCashBoxDetail);
//# sourceMappingURL=cashboxdetail.router.js.map