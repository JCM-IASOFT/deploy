"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.priceRoute = void 0;
const express_1 = require("express");
const price_controller_1 = require("../controller/price.controller");
exports.priceRoute = (0, express_1.Router)();
exports.priceRoute.post('/', price_controller_1.priceController.createPrices);
//# sourceMappingURL=price.router.js.map