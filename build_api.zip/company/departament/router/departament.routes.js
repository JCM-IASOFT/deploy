"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.departamentRoute = void 0;
const express_1 = require("express");
const departament_controller_1 = require("../controller/departament.controller");
exports.departamentRoute = (0, express_1.Router)();
exports.departamentRoute.get('/findAllD', departament_controller_1.departamentController.findDepartamentDatatable);
exports.departamentRoute.get('/findAll', departament_controller_1.departamentController.findDepartament);
exports.departamentRoute.get('/country', departament_controller_1.departamentController.findDepartamentByCountry);
//# sourceMappingURL=departament.routes.js.map