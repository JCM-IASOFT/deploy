"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.typechangemoneyRoute = void 0;
const express_1 = require("express");
const typechangemoney_controller_1 = require("../controller/typechangemoney.controller");
const typechangemoney_validator_1 = require("../validator/typechangemoney.validator");
exports.typechangemoneyRoute = (0, express_1.Router)();
exports.typechangemoneyRoute.get('/', typechangemoney_controller_1.typechangemoneyController.findTypeChangeMoney);
exports.typechangemoneyRoute.post('/', typechangemoney_validator_1.validateCreateTypeChangeMoney, typechangemoney_controller_1.typechangemoneyController.createTypeChangeMoneys);
//# sourceMappingURL=typechangemoney.router.js.map