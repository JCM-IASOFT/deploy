"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateFindTax = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateTaxId = (0, express_validator_1.query)('companyId')
    .exists().withMessage('El parámetro companyId es requerido')
    .isNumeric().withMessage('El parámetro companyId debe ser numérico');
// * Validación para la actualización de una categoria
exports.validateFindTax = [
    validateTaxId,
    handleValidationResult
];
//# sourceMappingURL=tax.validator.js.map