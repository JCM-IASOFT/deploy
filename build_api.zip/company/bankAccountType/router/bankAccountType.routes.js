"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bankAccountTypeRoute = void 0;
const express_1 = require("express");
const bankAccountType_1 = require("../controller/bankAccountType");
exports.bankAccountTypeRoute = (0, express_1.Router)();
exports.bankAccountTypeRoute.get('/allD', bankAccountType_1.bankAccountTypeController.findBankAccountTypeDataTable);
exports.bankAccountTypeRoute.get('/all', bankAccountType_1.bankAccountTypeController.findBankAccountType);
exports.bankAccountTypeRoute.post('/create', bankAccountType_1.bankAccountTypeController.createBankAccountType);
exports.bankAccountTypeRoute.put('/update', bankAccountType_1.bankAccountTypeController.updateBankAccountType);
exports.bankAccountTypeRoute.put('/delete/:id', bankAccountType_1.bankAccountTypeController.deleteBankAccountType);
//# sourceMappingURL=bankAccountType.routes.js.map