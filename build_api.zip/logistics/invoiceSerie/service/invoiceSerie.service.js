"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoiceSerieService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class InvoiceSerieService {
    static getInstance() {
        if (!this.instance)
            this.instance = new InvoiceSerieService();
        return this.instance;
    }
    findInvoiceSerie(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const invoiceSeries = yield modelslibrary_1.InvoiceSerieModel.createQueryBuilder('invoiceSerie')
                    .leftJoinAndSelect('invoiceSerie.subInvoiceSeries', 'subInvoiceSeries', 'subInvoiceSeries.deletedAt = :subDeletedAt', { subDeletedAt: '0' })
                    .where('invoiceSerie.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('invoiceSerie.companyId = :companyId', { companyId: companyId })
                    .select([
                    'invoiceSerie.invoiceSerieId',
                    'invoiceSerie.name',
                    'subInvoiceSeries.subInvoiceSerieId',
                    'subInvoiceSeries.name',
                    'subInvoiceSeries.invoiceSerieId'
                ])
                    .getMany();
                return invoiceSeries;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createInvoiceSerie(invoiceSeries) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.InvoiceSerieModel.save(invoiceSeries);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    incrementNumberInvoiceSerie(invoiceSerieId, number, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.InvoiceSerieModel, { invoiceSerieId }, {
                    number: number + 1
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateInvoiceSerie(invoiceSerieId, invoiceSerie) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.InvoiceSerieModel.update({ invoiceSerieId }, {
                    prefix: invoiceSerie.prefix,
                    number: invoiceSerie.number,
                    distance: invoiceSerie.distance,
                    state: invoiceSerie.state,
                    invoiceId: invoiceSerie.invoiceId,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteInvoiceSerie(invoiceSerieId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.InvoiceSerieModel.update({ invoiceSerieId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.invoiceSerieService = InvoiceSerieService.getInstance();
//# sourceMappingURL=invoiceSerie.service.js.map