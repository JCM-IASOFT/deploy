"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.storeRoute = void 0;
const express_1 = require("express");
const store_controller_1 = require("../controller/store.controller");
exports.storeRoute = (0, express_1.Router)();
exports.storeRoute.get('/', store_controller_1.storeController.findStore);
exports.storeRoute.post('/create', store_controller_1.storeController.createStore);
exports.storeRoute.put('/update', store_controller_1.storeController.updateStore);
exports.storeRoute.put('/delete/:storeId', store_controller_1.storeController.deleteStore);
//# sourceMappingURL=store.router.js.map