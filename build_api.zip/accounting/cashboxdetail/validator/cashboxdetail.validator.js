"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteCashBoxDetail = exports.validateClosePettyCash = exports.validateUpdateCashBoxDetail = exports.validateCreateCashBoxDetail = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateCashBoxDetail = [
    (0, express_validator_1.check)('cashBoxId').exists().not().isEmpty(),
    (0, express_validator_1.check)('openingAmount').exists().not().isEmpty(),
    (0, express_validator_1.check)('openingDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('openingDate').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateCashBoxDetail = [
    (0, express_validator_1.check)('cashBoxDetailId').exists().not().isEmpty(),
    (0, express_validator_1.check)('closingAmount').exists().not().isEmpty(),
    (0, express_validator_1.check)('closeDate').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateClosePettyCash = [
    (0, express_validator_1.check)('cashBoxDetailId').exists().not().isEmpty(),
    (0, express_validator_1.check)('closingAmount').exists().not().isEmpty(),
    (0, express_validator_1.check)('cashBalance').exists().not().isEmpty(),
    (0, express_validator_1.check)('closeDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('leftoverBalance').exists().not().isEmpty(),
    (0, express_validator_1.check)('missingBalance').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteCashBoxDetail = [
    (0, express_validator_1.check)('cashboxdetailId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=cashboxdetail.validator.js.map