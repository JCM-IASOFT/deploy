"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashboxRoute = void 0;
const express_1 = require("express");
const cashbox_controller_1 = require("../controller/cashbox.controller");
const cashbox_validator_1 = require("../validator/cashbox.validator");
exports.cashboxRoute = (0, express_1.Router)();
exports.cashboxRoute.get('/', cashbox_controller_1.cashboxController.findCashBox);
exports.cashboxRoute.post('/', cashbox_validator_1.validateCreateCashBox, cashbox_controller_1.cashboxController.createCashBoxs);
exports.cashboxRoute.put('/', cashbox_validator_1.validateUpdateCashBox, cashbox_controller_1.cashboxController.updateCashBox);
exports.cashboxRoute.delete('/', cashbox_validator_1.validateDeleteCashBox, cashbox_controller_1.cashboxController.deleteCashBox);
//# sourceMappingURL=cashbox.router.js.map