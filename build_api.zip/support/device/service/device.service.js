"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deviceService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
class DeviceService {
    static getInstance() {
        if (!this.instance)
            this.instance = new DeviceService();
        return this.instance;
    }
    findAllDevice(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const devices = yield modelslibrary_1.DeviceModel.find({
                    where: { deletedAt: '0', campusId: campusId },
                    select: {
                        deviceId: true,
                        description: true,
                    }
                });
                return devices;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                return [];
            }
        });
    }
    findDevice(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const devices = yield modelslibrary_1.DeviceModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0',
                    },
                });
                return devices;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                return error;
            }
        });
    }
    createDevice(devices) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.DeviceModel.save(devices);
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    updateDevice(devices) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.DeviceModel.update({ deviceId: devices.deviceId }, {
                    description: devices.description,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    deleteDevice(devices) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.DeviceModel.update({ deviceId: devices.deviceId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    getErrorMessage(error) {
        return error instanceof Error ? error.message : 'Se produjo un error desconocido';
    }
}
exports.deviceService = DeviceService.getInstance();
//# sourceMappingURL=device.service.js.map