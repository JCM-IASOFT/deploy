"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicestatushistoryRoute = void 0;
const express_1 = require("express");
const servicestatushistory_controller_1 = require("../controller/servicestatushistory.controller");
const servicestatushistory_validator_1 = require("../validator/servicestatushistory.validator");
exports.servicestatushistoryRoute = (0, express_1.Router)();
exports.servicestatushistoryRoute.get('/', servicestatushistory_validator_1.validateFindServiceStatusHistory, servicestatushistory_controller_1.servicestatushistoryController.findServiceStatusHistory);
//# sourceMappingURL=servicestatushistory.router.js.map