"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class ServiceService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceService();
        return this.instance;
    }
    findServiceTransaction(search, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const serviceRepository = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.ServiceModel);
                const services = yield serviceRepository
                    .createQueryBuilder('service')
                    .select([
                    'service.serviceId',
                    'service.registrationDate',
                    'service.deliverDate',
                    'service.totalAmount',
                    'service.state',
                    'service.comment',
                    'service.priority',
                    'service.clientId',
                    'service.campusId',
                    'service.userReceptionId',
                    'service.userTechnicalId'
                ])
                    .leftJoinAndSelect('service.payments', 'payments')
                    .leftJoinAndSelect('service.serviceDevices', 'serviceDevices')
                    .leftJoinAndSelect('serviceDevices.device', 'device')
                    .where('service.campusId = :campusId', { campusId: campusId })
                    .andWhere('cast(service.serviceId as varchar) ILIKE :search', { search: `%${search}%` })
                    .andWhere('service.deletedAt = :deletedAt', { deletedAt: '0' })
                    .orderBy('service.serviceId', 'ASC')
                    .getMany();
                return services;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    getExpiringService(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const serviceRepository = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.ServiceModel);
                const excludedStates = [parameter_constant_1.StatusService.ENTREGADO, parameter_constant_1.StatusService.RECHAZADO];
                const services = yield serviceRepository
                    .createQueryBuilder('service')
                    .select([
                    'service.serviceId',
                    'service.registrationDate',
                    'service.deliverDate',
                    'service.totalAmount',
                    'service.state',
                    'service.comment',
                    'serviceDevices.reason'
                ])
                    .innerJoinAndSelect('service.payments', 'payments')
                    .innerJoinAndSelect('service.serviceDevices', 'serviceDevices')
                    .innerJoinAndSelect('serviceDevices.device', 'device')
                    .where('service.campusId = :campusId', { campusId: campusId })
                    .andWhere('(service.deliverDate <= NOW() OR service.deliverDate <= (NOW() + interval \'1 hour\'))')
                    .andWhere('service.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('service.state NOT IN (:...excludedStates)', { excludedStates })
                    .orderBy('service.serviceId', 'ASC')
                    .getMany();
                return services;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findService(servicefilter, page, sizePage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const serviceQueryBuilder = modelslibrary_1.ServiceModel.createQueryBuilder("service")
                    .leftJoin("service.userReception", "userReception")
                    .leftJoin("service.userTechnical", "userTechnical")
                    .leftJoin("service.client", "client")
                    .leftJoin("service.differences", "differences")
                    .leftJoin("differences.differencePayments", "differencePayments")
                    .leftJoin("differencePayments.paymentType", "differencePaymentType")
                    .leftJoin("service.payments", "payments")
                    .leftJoin("payments.paymentType", "paymentType")
                    .leftJoin("service.serviceDevices", "serviceDevices")
                    .leftJoin("service.servicePauseHistorys", "servicePauseHistorys")
                    .where("service.campusId = :campusId", { campusId: servicefilter.campusId })
                    .andWhere("service.deletedAt = :deletedAt", { deletedAt: '0' });
                if (servicefilter.startDate && servicefilter.endDate) {
                    serviceQueryBuilder.andWhere("(DATE(service.registrationDate) BETWEEN :startDate AND :endDate OR DATE(service.endDate) BETWEEN :startDate AND :endDate)", { startDate: servicefilter.startDate, endDate: servicefilter.endDate });
                }
                if (servicefilter.userTechnicalId && servicefilter.userTechnicalId > 0) {
                    serviceQueryBuilder.andWhere("service.userTechnicalId = :userTechnicalId", { userTechnicalId: servicefilter.userTechnicalId });
                }
                if (servicefilter.documentNumber && servicefilter.documentNumber !== '') {
                    serviceQueryBuilder.andWhere("client.documentNumber = :documentNumber", { documentNumber: servicefilter.documentNumber });
                }
                if (servicefilter.serviceId && servicefilter.serviceId > 0) {
                    serviceQueryBuilder.andWhere("service.serviceId = :serviceId", { serviceId: servicefilter.serviceId });
                }
                if (servicefilter.state && servicefilter.state !== '') {
                    serviceQueryBuilder.andWhere("service.state = :state", { state: servicefilter.state });
                }
                if (servicefilter.like) {
                    serviceQueryBuilder.andWhere(builder => {
                        builder.where("client.documentNumber LIKE :documentNumber", { documentNumber: `%${servicefilter.like}%` })
                            .orWhere("LOWER(client.fullname) LIKE :fullname", { fullname: `%${servicefilter.like.toLowerCase()}%` })
                            .orWhere("serviceDevices.serial LIKE :serial", { serial: `%${servicefilter.like}%` });
                    });
                }
                serviceQueryBuilder
                    .select([
                    "service.serviceId",
                    "service.registrationDate",
                    "service.endDate",
                    "service.deliverDate",
                    "service.totalAmount",
                    "service.state",
                    "service.pause",
                    "service.type",
                    "service.serviceLocation",
                    "service.comment",
                    "service.priority",
                    "service.detailedReception",
                    "service.clientId",
                    "service.campusId",
                    "userReception",
                    "userTechnical",
                    "client",
                    "differences",
                    "differencePaymentType",
                    "differencePayments",
                    "payments",
                    "paymentType",
                    "serviceDevices",
                    "servicePauseHistorys",
                ]);
                const [services, total] = yield serviceQueryBuilder.orderBy("service.serviceId", "DESC").addOrderBy('payments.date', 'ASC')
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { services, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findOneService(serviceId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const services = yield modelslibrary_1.ServiceModel.findOne({
                    where: {
                        serviceId: serviceId, serviceDevices: {
                            deletedAt: '0',
                        },
                        deletedAt: '0'
                    },
                    relations: ["userReception", "userTechnical", "campus",
                        "client", "differences", "differences.differencePayments", "differences.differencePayments.paymentType", "payments", "payments.paymentType", "serviceStatusHistorys",
                        "serviceDevices", "serviceDevices.deviceProducts", "serviceDevices.device",
                        "serviceDevices.deviceBrand",
                        "serviceDevices.serviceTypeDevices", "serviceDevices.serviceTypeDevices.serviceType",
                        "serviceDevices.deviceProducts.product"],
                    select: {
                        serviceId: true,
                        registrationDate: true,
                        deliverDate: true,
                        totalAmount: true,
                        state: true,
                        type: true,
                        serviceLocation: true,
                        comment: true,
                        priority: true,
                        clientId: true,
                        campusId: true,
                        campus: {
                            campusId: true,
                            name: true,
                            address: true,
                            phone: true,
                        },
                        userReception: {
                            userId: true,
                            name: true,
                            fullname: true,
                            email: true,
                            phone: true,
                        },
                        client: {
                            clientId: true,
                            fullname: true,
                            documentNumber: true,
                            email: true,
                            phone: true,
                            referencePhone: true
                        },
                        differences: {
                            differenceId: true,
                            description: true,
                            serviceDeviceId: true,
                            differencePayments: {
                                differencePaymentId: true,
                                amount: true,
                                paymentType: {
                                    paymentTypeId: true,
                                    description: true,
                                }
                            }
                        },
                        payments: {
                            paymentId: true,
                            paymentTypeId: true,
                            amount: true,
                            type: true,
                            paymentType: {
                                paymentTypeId: true,
                                description: true,
                            }
                        },
                        serviceStatusHistorys: {
                            statusHistoryId: true,
                            serviceId: true,
                            status: true,
                            dateChanged: true,
                            userId: true,
                            coments: true,
                            complete: true,
                        },
                        serviceDevices: {
                            serviceDeviceId: true,
                            accessories: true,
                            reason: true,
                            serial: true,
                            model: true,
                            observations: true,
                            estimatedAmount: true,
                            workCycle: true,
                            observationsInternal: true,
                            serviceId: true,
                            inWarranty: true,
                            campusId: true,
                            deviceId: true,
                            deviceBrandId: true,
                            serviceTypeDevices: {
                                serviceTypeDeviceId: true,
                                serviceType: {
                                    description: true
                                }
                            },
                            device: {
                                deviceId: true,
                                description: true,
                            },
                            deviceBrand: {
                                deviceBrandId: true,
                                description: true,
                            },
                            deviceProducts: {
                                deviceProductId: true,
                                serviceDeviceId: true,
                                productId: true,
                                deletedAt: true,
                                amount: true,
                                price: true,
                                product: {
                                    productId: true,
                                    description: true,
                                    brand: {
                                        brandId: true,
                                        name: true
                                    }
                                }
                            },
                            externalComponents: {
                                externalComponentId: true,
                                description: true,
                                price: true,
                                amount: true,
                                serviceDeviceId: true,
                                voucher: true
                            },
                            serviceDeviceHistorys: {
                                serviceDeviceHistoryId: true,
                                serviceDeviceId: true,
                                estimatedAmount: true,
                                coments: true,
                            }
                        }
                    },
                    order: {
                        serviceDevices: {
                            serviceDeviceHistorys: {
                                serviceDeviceHistoryId: 'ASC'
                            }
                        }
                    }
                });
                services.serviceDevices.forEach(element => {
                    element.deviceProducts = element.deviceProducts.filter(p => p.deletedAt === '0');
                });
                return services;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findServiceByPhone(phone) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield modelslibrary_1.ServiceModel.findOne({
                where: {
                    client: {
                        phone: phone
                    }
                },
                relations: {
                    client: true,
                    userTechnical: true
                }
            });
            return response;
        });
    }
    createService(services, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const serviceEntity = modelslibrary_1.ServiceModel.create(services);
                return yield queryRunner.manager.save(serviceEntity);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    /**
     * - Actualiamos el estado de servicio y agregamos su respectivo historial
     * @param service
     * @param servicestatushistory
     * @param statusHistoryId - Nos permite identificar cual fue el estado anteriror para cambiar la propiedad [complete]
     * @returns
     */
    changeState(service, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // ** Actualizar el estado del servicio
                const updateParams = {
                    state: service.state
                };
                // ** Si el estado es EN_PROCESO, también actualizamos el técnico asignado
                if (service.state === parameter_constant_1.StatusService.EN_PROCESO) {
                    updateParams.userTechnicalId = service.userTechnicalId;
                }
                return yield queryRunner.manager.update(modelslibrary_1.ServiceModel, service.serviceId, updateParams);
                ;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateService(services, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceModel, services.serviceId, {
                    registrationDate: services.registrationDate,
                    deliverDate: services.deliverDate,
                    totalAmount: services.totalAmount,
                    state: services.state,
                    userDeliveryId: services.userDeliveryId,
                    comment: services.comment,
                    priority: services.priority,
                    clientId: services.clientId,
                    endDate: services.endDate
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateServiceTransaction(service, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceModel, service.serviceId, {
                    comment: service.comment
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    changeTechnical(service, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceModel, { serviceId: service.serviceId }, {
                    userTechnicalId: service.userTechnicalId,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    rollBackStatus(service, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceModel, service.serviceId, {
                    state: service.state,
                    comment: service.comment,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateTotalAmount(service, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceModel, { serviceId: service.serviceId }, {
                    totalAmount: service.totalAmount,
                    comment: service.comment,
                    detailedReception: service.detailedReception,
                    deliverDate: service.deliverDate,
                    endDate: service.endDate
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteService(services) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.ServiceModel.update({ serviceId: services.serviceId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updatePauseService(services, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceModel, { serviceId: services.serviceId }, {
                    pause: services.pause
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.serviceService = ServiceService.getInstance();
//# sourceMappingURL=service.service.js.map