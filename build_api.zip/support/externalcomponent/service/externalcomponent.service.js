"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.externalcomponentService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class ExternalComponentService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ExternalComponentService();
        return this.instance;
    }
    createExternalComponent(externalcomponent, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const externalcomponentEntity = modelslibrary_1.ExternalComponentModel.create(externalcomponent);
                const response = yield queryRunner.manager.save(externalcomponentEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteExternalComponent(serviceDeviceId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager
                    .createQueryBuilder()
                    .update(modelslibrary_1.ExternalComponentModel)
                    .set({ deletedAt: '1' })
                    .where('serviceDeviceId = :serviceDeviceId', { serviceDeviceId })
                    .execute();
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.externalcomponentService = ExternalComponentService.getInstance();
//# sourceMappingURL=externalcomponent.service.js.map