"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteDeviceBrand = exports.validateUpdateDeviceBrand = exports.validateCreateDeviceBrand = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateDeviceBrand = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateDeviceBrand = [
    (0, express_validator_1.check)('deviceBrandId').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteDeviceBrand = [
    (0, express_validator_1.check)('deviceBrandId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=devicebrand.validator.js.map