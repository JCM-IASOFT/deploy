"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deviceproductController = void 0;
const response_handler_1 = require("../../../common/handler/response.handler");
const http_status_codes_1 = require("http-status-codes");
const deviceproduct_service_1 = require("../service/deviceproduct.service");
const message_api_1 = require("../../../common/constant/message.api");
const externalcomponent_service_1 = require("../../externalcomponent/service/externalcomponent.service");
const request_handler_1 = require("../../../common/handler/request.handler");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
class DeviceProductController {
    constructor() {
        this.createDeviceProducts = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { deviceProducts, externalComponents } = req.body;
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const response = yield deviceproduct_service_1.deviceproductService.createDeviceProduct(deviceProducts, queryRunner);
                        const responseExternal = yield externalcomponent_service_1.externalcomponentService.createExternalComponent(externalComponents, queryRunner);
                        if (!response || !responseExternal) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_DEVICE_PRODUCT };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err.message,
                    };
                }
            }));
        });
        this.updateDeviceProduct = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { serviceDevices } = req.body;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const servicedevicesParse = Array.isArray(serviceDevices) ? serviceDevices : [];
                        const deviceproductsParse = servicedevicesParse.flatMap(element => element.deviceProducts);
                        const externalcomponentsParse = servicedevicesParse.flatMap(element => element.externalComponents);
                        yield this.handleExternalComponents(queryRunner, externalcomponentsParse);
                        yield this.handleDeviceProducts(queryRunner, deviceproductsParse);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_DEVICE_PRODUCT };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.deleteDeviceProduct = (req, res) => __awaiter(this, void 0, void 0, function* () {
            // ** Aun no impelementado
            res.status(http_status_codes_1.StatusCodes.OK).json((0, response_handler_1.ResponseHandler)({ code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_DEVICE }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new DeviceProductController();
        return this.instance;
    }
    handleExternalComponents(queryRunner, externalcomponentsParse) {
        return __awaiter(this, void 0, void 0, function* () {
            for (const external of externalcomponentsParse) {
                const resCreateExternal = yield externalcomponent_service_1.externalcomponentService.createExternalComponent(external, queryRunner);
                const resDeleteExternal = yield externalcomponent_service_1.externalcomponentService.deleteExternalComponent(external.serviceDeviceId, queryRunner);
                if (!resCreateExternal || !resDeleteExternal) {
                    throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                }
            }
        });
    }
    handleDeviceProducts(queryRunner, deviceproductsParse) {
        return __awaiter(this, void 0, void 0, function* () {
            const idsUnicos = [...new Set(deviceproductsParse.map(item => item.serviceDeviceId))];
            for (const id of idsUnicos) {
                const resDeleteProduct = yield deviceproduct_service_1.deviceproductService.deleteDeviceProduct(id, queryRunner);
                if (!resDeleteProduct) {
                    throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                }
            }
            for (const deviceproduct of deviceproductsParse) {
                const resCreateProduct = yield deviceproduct_service_1.deviceproductService.createDeviceProduct(deviceproduct, queryRunner);
                if (!resCreateProduct) {
                    throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                }
            }
        });
    }
}
exports.deviceproductController = DeviceProductController.getInstance();
//# sourceMappingURL=deviceproduct.controller.js.map