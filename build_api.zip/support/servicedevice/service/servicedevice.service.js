"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicedeviceService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class ServiceDeviceService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceDeviceService();
        return this.instance;
    }
    createServiceDevice(serviceDevice, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const ServiceDeviceEntity = modelslibrary_1.ServiceDeviceModel.create(serviceDevice);
                const response = yield queryRunner.manager.save(modelslibrary_1.ServiceDeviceModel, ServiceDeviceEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteServiceDevice(differences, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceDeviceModel, { serviceId: differences.serviceId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateEstimatedAmount(serviceDevice, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceDeviceModel, { serviceDeviceId: serviceDevice.serviceDeviceId }, {
                    estimatedAmount: serviceDevice.estimatedAmount,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    update(serviceDevice, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceDeviceModel, { serviceDeviceId: serviceDevice.serviceDeviceId }, {
                    estimatedAmount: serviceDevice.estimatedAmount,
                    reason: serviceDevice.reason,
                    model: serviceDevice.model,
                    serial: serviceDevice.serial,
                    observationsInternal: serviceDevice.observationsInternal,
                    observations: serviceDevice.observations
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.servicedeviceService = ServiceDeviceService.getInstance();
//# sourceMappingURL=servicedevice.service.js.map