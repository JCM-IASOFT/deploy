"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentRoute = void 0;
const express_1 = require("express");
const payment_controller_1 = require("../controller/payment.controller");
exports.paymentRoute = (0, express_1.Router)();
exports.paymentRoute.get('/', payment_controller_1.paymentController.findPayments);
//# sourceMappingURL=payment.router.js.map