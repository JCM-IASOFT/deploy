"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientTypeRoute = void 0;
const express_1 = require("express");
const clientType_controller_1 = require("../controller/clientType.controller");
exports.clientTypeRoute = (0, express_1.Router)();
exports.clientTypeRoute.get('/findAll', clientType_controller_1.clientTypeController.findClientType);
exports.clientTypeRoute.post('/create', clientType_controller_1.clientTypeController.createClientType);
exports.clientTypeRoute.put('/update', clientType_controller_1.clientTypeController.updateClientType);
exports.clientTypeRoute.put('/delete/:clientTypeId', clientType_controller_1.clientTypeController.deleteClientType);
//# sourceMappingURL=clientType.routes.js.map