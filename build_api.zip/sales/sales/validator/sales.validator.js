"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteSales = exports.validateUpdateSales = exports.validateCreateSales = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateSales = [
    (0, express_validator_1.check)('sales.date').exists().withMessage('El campo date es obligatorio').isISO8601().withMessage('El campo date debe ser una fecha válida en formato ISO8601'),
    (0, express_validator_1.check)('sales.sellerId').exists().withMessage('El campo sellerId es obligatorio').isInt().withMessage('El campo sellerId debe ser un número entero'),
    (0, express_validator_1.check)('sales.campusId').exists().withMessage('El campo campusId es obligatorio').isInt().withMessage('El campo campusId debe ser un número entero'),
    (0, express_validator_1.check)('sales.totalPayment').exists().withMessage('El campo totalPayment es obligatorio').isNumeric().withMessage('El campo totalPayment debe ser un número'),
    (0, express_validator_1.check)('sales.invoiceId').exists().withMessage('El campo documentTypeId es obligatorio').isInt().withMessage('El campo documentTypeId debe ser un número entero'),
    (0, express_validator_1.check)('sales.correlative').exists().withMessage('El campo correlative es obligatorio'),
    (0, express_validator_1.check)('salesDetails.*.amount').exists().withMessage('amount es obligatorio').isNumeric().withMessage('amount debe ser un número entero'),
    (0, express_validator_1.check)('salesDetails.*.price').exists().withMessage('price es obligatorio').isNumeric().withMessage('price debe ser un número entero'),
    (0, express_validator_1.check)('salesDetails.*.productId').exists().withMessage('productId es obligatorio').isNumeric().withMessage('productId debe ser un número entero'),
    (0, express_validator_1.check)('paymentSales.*.paymentTypeId').exists().withMessage('paymentTypeId es obligatorio').isNumeric().withMessage('paymentTypeId debe ser un número entero'),
    (0, express_validator_1.check)('paymentSales.*.amount').exists().withMessage('amount es obligatorio').isNumeric().withMessage('amount debe ser un número entero'),
    (0, express_validator_1.check)('paymentSales.*.campusId').exists().withMessage('campusId es obligatorio').isNumeric().withMessage('campusId debe ser un número entero'),
    (0, express_validator_1.check)('invoiceSerie').exists().withMessage('invoiceSerie es obligatorio'),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateSales = [
    (0, express_validator_1.check)('salesId').exists().not().isEmpty(),
    (0, express_validator_1.check)('brand').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('serial').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteSales = [
    (0, express_validator_1.check)('salesId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=sales.validator.js.map