"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dashboardService = void 0;
const errormessage_handler_1 = require("../../common/handler/errormessage.handler");
const save_error_1 = require("../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
class DashboardService {
    static getInstance() {
        if (!this.instance)
            this.instance = new DashboardService();
        return this.instance;
    }
    findMarginGainSales(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT  COALESCE(SUM(sd.price) - SUM(p."priceDistributor"), 0) AS margin FROM sales.sales s
      JOIN sales.sales_detail sd ON s."salesId" = sd."salesId"
      JOIN inventory.product p ON sd."productId" = p."productId"
      WHERE DATE(s."date") BETWEEN $2 AND $3
      AND s."campusId" = $1
      AND s."deletedAt" = '0'
      
        `, [campusId, startDate, endDate]);
                return servicesAll.length > 0 ? servicesAll[0].margin : 0;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * Formas de pago de cada uno de las ventas
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    paymentsSales(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      COUNT(*) AS cant,
      paytype.description,
      paytype.type,
      SUM(pay.amount) - SUM(s.change) AS amount
      FROM sales.sales s
      JOIN sales.payment_sales pay ON s."salesId" = pay."salesId"
      JOIN company.payment_type paytype ON pay."paymentTypeId" = paytype."paymentTypeId"
      WHERE DATE(s."date") BETWEEN $2 AND $3
      AND s."campusId" = $1
      AND s."deletedAt" = '0'
      GROUP BY paytype."paymentTypeId"
        `, [campusId, startDate, endDate]);
                return servicesAll;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * Chart de ventas por fecha
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    chartSales(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      (SELECT SUM(pay.amount)-SUM(s.change)
        FROM sales.sales s
        JOIN sales.payment_sales pay ON s."salesId" = pay."salesId"
        WHERE s."campusId" = $1
        AND s."deletedAt" = '0'
        AND DATE(s."date") BETWEEN $2 AND $3
      ) AS "totals",
    
      (
        SELECT ARRAY_AGG(date) as categories 
          FROM (
            SELECT 
              DATE_TRUNC('day', s."date") AS date
            FROM 
      sales.sales s
           JOIN sales.payment_sales pay ON s."salesId" = pay."salesId"			
            WHERE 
              s."campusId" = $1		
              AND DATE(s."date") BETWEEN $2 AND $3
            GROUP BY 
              DATE_TRUNC('day', s."date")
          ) as categories 
      ),
      
      (SELECT ARRAY_AGG(total_amount) as series FROM (
        SELECT SUM(pay.amount) - SUM(s.change) AS total_amount
         FROM
    sales.sales s
       JOIN sales.payment_sales pay ON s."salesId" = pay."salesId"			
        WHERE pay."campusId" = $1    
        AND DATE(s."date") BETWEEN $2 AND $3
        GROUP BY DATE_TRUNC('day', s."date")
      ) as series )
      `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * Chart de recepciones incluidos con sus respectivos tecnicos
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     */
    chartReceptionWithTechnical(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      WITH filtered_services AS (
        SELECT s."userReceptionId", ur."name", ur."fullname",
               COUNT(*) AS total_amount
        FROM support.service s
      JOIN support.service_status_history ssh ON s."serviceId" = ssh."serviceId"
        JOIN system.user ur ON s."userReceptionId" = ur."userId"
        WHERE s."campusId" = $1
          AND (ssh.status = '1' OR (ssh.status = '4' AND s.type = '2'))
          AND s."deletedAt" = '0'
          AND DATE(s."registrationDate") BETWEEN $2 AND $3
        GROUP BY s."userReceptionId", ur."name", ur."fullname"
    )
    SELECT 
        (SELECT SUM(f.total_amount) FROM filtered_services f) AS "totals",
        (SELECT ARRAY_AGG(f.name || ' ' || LEFT(f."fullname", 1) || '.') FROM filtered_services f) AS categories,
        (SELECT ARRAY_AGG(f.total_amount) FROM filtered_services f) AS series;
    
      `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * Chart de reparaciones incluidos con sus respectivos tecnicos
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     */
    chartRepairWithTechnical(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      WITH filtered_services AS (
        SELECT s."userTechnicalId", ur."name", ur."fullname",
               COUNT(*) AS total_amount
        FROM support.service s
      JOIN support.service_status_history ssh ON s."serviceId" = ssh."serviceId"
        JOIN system.user ur ON s."userTechnicalId" = ur."userId"
        WHERE s."campusId" = $1
          AND (ssh.status IN ('3') OR (ssh.status = '3' AND s.type = '2'))
          AND s."deletedAt" = '0'
          AND DATE(s."registrationDate") BETWEEN $2 AND $3
        GROUP BY s."userTechnicalId", ur."name", ur."fullname"
    )
    SELECT 
        (SELECT SUM(f.total_amount) FROM filtered_services f) AS "totals",
        (SELECT ARRAY_AGG(f.name || ' ' || LEFT(f."fullname", 1) || '.') FROM filtered_services f) AS categories,
        (SELECT ARRAY_AGG(f.total_amount) FROM filtered_services f) AS series;
      `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
    * * Chart de entregados incluidos con sus respectivos tecnicos
    * @param campusId
    * @param startDate
    * @param endDate
    * @param zone
    */
    chartDeliveredWithTechnical(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      WITH filtered_services AS (
        SELECT s."userDeliveryId", ur."name", ur."fullname",
               COUNT(*) AS total_amount
        FROM support.service s
      JOIN support.service_status_history ssh ON s."serviceId" = ssh."serviceId"
        JOIN system.user ur ON s."userDeliveryId" = ur."userId"
        WHERE s."campusId" = $1
          AND ssh.status = '4'
          AND s."deletedAt" = '0'
          AND DATE(s."registrationDate") BETWEEN $2 AND $3
        GROUP BY s."userDeliveryId", ur."name", ur."fullname"
    )
    SELECT 
        (SELECT SUM(f.total_amount) FROM filtered_services f) AS "totals",
        (SELECT ARRAY_AGG(f.name || ' ' || LEFT(f."fullname", 1) || '.') FROM filtered_services f) AS categories,
        (SELECT ARRAY_AGG(f.total_amount) FROM filtered_services f) AS series;
      `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * Chart de servicios no concluidos
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     */
    chartUnfinishedServices(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      WITH service_data AS (
        SELECT s."userTechnicalId", u."name", LEFT(u."fullname", 1) AS "fullname_initial",
               COUNT(*) AS total_amount
        FROM support.service s
        JOIN system.user u ON s."userTechnicalId" = u."userId"
        WHERE s."campusId" = $1
          AND s.state IN ('2', '3', '5', '6')
          AND s."deletedAt" = '0'
          AND DATE(s."registrationDate") BETWEEN $2 AND $3
        GROUP BY s."userTechnicalId", u."name", u."fullname"
    )
    SELECT 
        (SELECT COUNT(*) FROM service_data) AS totals,
        (SELECT ARRAY_AGG(sd.name || ' ' || sd."fullname_initial" || '.') FROM service_data sd) AS categories,
        (SELECT ARRAY_AGG(sd.total_amount) FROM service_data sd) AS series;
      `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * Chart de servicios rapidos por tecnico
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    chartFastOrderByTechnical(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
            (
                SELECT COUNT(*) 
                FROM support.service s
                WHERE s."campusId" = $1
                  AND s.type = 2
                  AND s."deletedAt" = '0'
                  AND DATE(s."registrationDate") BETWEEN $2 AND $3
            ) AS "totals",

            (
                SELECT ARRAY_AGG(name) AS categories 
                FROM (
                    SELECT (u."name" || ' ' || LEFT(u."fullname", 1) || '.') AS name
                    FROM support.service s
                    JOIN system.user u ON s."userTechnicalId" = u."userId"
                    WHERE s."campusId" = $1
                      AND s.type = 2
                      AND s."deletedAt" = '0'
                      AND DATE(s."registrationDate") BETWEEN $2 AND $3
                    GROUP BY u."name", u."fullname"
                ) AS categories
            ),

            (
                SELECT ARRAY_AGG(total_amount) AS series 
                FROM (
                    SELECT COUNT(*) AS total_amount
                    FROM support.service s
                    JOIN system.user u ON s."userTechnicalId" = u."userId"
                    WHERE s."campusId" = $1
                      AND s.type = 2
                      AND s."deletedAt" = '0'
                      AND DATE(s."registrationDate") BETWEEN $2 AND $3
                    GROUP BY u."name", u."fullname"
                ) AS series
            );

      `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * Chart de los servicios por prioridades
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    chartPriority(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`SELECT 
      (
          SELECT COUNT(*) 
          FROM support.service s
          WHERE s."campusId" = $1
            AND s."deletedAt" = '0'
            AND DATE(s."registrationDate") BETWEEN $2 AND $3
      ) AS "totals",
  
      (
          SELECT ARRAY_AGG(priority) AS categories 
          FROM (
              SELECT s."priority" AS priority
              FROM support.service s
              WHERE s."campusId" = $1
                AND s."deletedAt" = '0'
                AND DATE(s."registrationDate") BETWEEN $2 AND $3
              GROUP BY s."priority"
          ) AS categories
      ),
      
      (
          SELECT ARRAY_AGG(total_amount) AS series 
          FROM (
              SELECT COUNT(*) AS total_amount
              FROM support.service s
              WHERE s."campusId" = $1
                AND s."deletedAt" = '0'
                AND DATE(s."registrationDate") BETWEEN $2 AND $3
              GROUP BY s."priority"
          ) AS series
      )`, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * Se obtiene en formato preparado de chart: las horas trabajadas de un tecnico considerando solo loes reparados
     * @param campusId - identidicador de sede
     * @param startDate - fecha de incio
     * @param endDate - fecha fin
     * @param zone - zona horaria
     * @returns
     */
    chartTechnicalHoursWorkerd(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      (
          SELECT         
              COALESCE(SUM(ROUND(EXTRACT(EPOCH FROM (ssh."completeDate" - ssh."dateChanged")) / 3600.0, 2)), 0) +
              COALESCE(SUM(ROUND(EXTRACT(EPOCH FROM (sph."endDate" - sph."registrationDate")) / 3600.0, 2)), 0) AS tiempo_trabajo
          FROM support.service s
          LEFT JOIN support.service_status_history ssh ON s."serviceId" = ssh."serviceId" 
          LEFT JOIN support.service_pause_history sph ON s."serviceId" = sph."serviceId"
          WHERE ssh.status = '2'
            AND s."deletedAt" = '0'
            AND s."campusId" = $1
            AND DATE(s."registrationDate") BETWEEN $2 AND $3
      ) AS "totals",

      (
          SELECT ARRAY_AGG(name) as categories 
          FROM (
              SELECT u.name as name
              FROM support.service s
              LEFT JOIN support.service_status_history ssh ON s."serviceId" = ssh."serviceId" 
              LEFT JOIN support.service_pause_history sph ON s."serviceId" = sph."serviceId"
              LEFT JOIN system.user u ON s."userTechnicalId" = u."userId"
              WHERE ssh.status = '2'
                AND s."campusId" = $1
                AND s."deletedAt" = '0'
                AND DATE(s."registrationDate") BETWEEN $2 AND $3
              GROUP BY u.name
          ) AS categories
      ),

      (
          SELECT ARRAY_AGG(tiempo_trabajo) as series 
          FROM (
              SELECT
                  GREATEST(
                      COALESCE(SUM(ROUND(EXTRACT(EPOCH FROM (ssh."completeDate" - ssh."dateChanged")) / 3600.0, 2)), 0) -
                      COALESCE(SUM(ROUND(EXTRACT(EPOCH FROM (sph."endDate" - sph."registrationDate")) / 3600.0, 2)), 0),
                      0
                  ) AS tiempo_trabajo
              FROM support.service s
              LEFT JOIN support.service_status_history ssh ON s."serviceId" = ssh."serviceId" 
              LEFT JOIN support.service_pause_history sph ON s."serviceId" = sph."serviceId"
              WHERE ssh.status = '2'
                AND s."campusId" = $1
                AND s."deletedAt" = '0'
                AND DATE(s."registrationDate") BETWEEN $2 AND $3
              GROUP BY s."userTechnicalId"
          ) AS series
      )

      `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * Total de servicios por mes
     * @param campusId - Identificador de sede
     * @returns
     */
    totalsServiceMonth(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      WITH sales_data AS (
        SELECT
            p."amount" AS amount,
            s."createdBy"::date AS day
        FROM
            support.service s
        JOIN support.payment p ON s."serviceId" = p."serviceId"
        WHERE
            s."campusId" = $1 AND
            s."deletedAt" = '0' AND
            s."registrationDate" >= DATE_TRUNC('month', CURRENT_DATE) AND
            s."registrationDate" < DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month'
      ),
      daily_totals AS (
          SELECT
              day,
              SUM(amount) AS total_amount
          FROM
              sales_data
          GROUP BY
              day
      )

      SELECT
          (SELECT SUM(amount) FROM sales_data) AS "totals",
          ARRAY_AGG(day) AS "categories",
          ARRAY_AGG(total_amount) AS "series"
      FROM
          daily_totals;
      `, [campusId]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * Total de ventas por mes
     * @param campusId - Identificador de sede
     * @returns
     */
    totalsSalesMonth(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
        WITH sales_data AS (
        SELECT
            s."totalPayment" AS amount,
            s."date"::date AS day
        FROM
            sales.sales s
        WHERE
            s."campusId" = $1 AND
            s."deletedAt" = '0' AND
            s."date" >= DATE_TRUNC('month', CURRENT_DATE) AND
            s."date" < DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month'
      ),
      daily_totals AS (
          SELECT
              day,
              SUM(amount) AS total_amount
          FROM
              sales_data
          GROUP BY
              day
      )

      SELECT
          (SELECT SUM(amount) FROM sales_data) AS "totals",
          ARRAY_AGG(day) AS "categories",
          ARRAY_AGG(total_amount) AS "series"
      FROM
          daily_totals;
      `, [campusId]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    totalPending(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const pending = yield modelslibrary_1.AppDataSource.query(`
      SELECT * FROM (
          SELECT '1' AS description, COUNT(*) AS amount FROM support.service s 
        WHERE s."state" = '1' AND s."deletedAt" = '0' AND s."campusId" = $1 AND DATE(s."registrationDate") BETWEEN $2 AND $3
          UNION ALL
          SELECT '2' AS description, COUNT(*) AS amount FROM support.service s 
        WHERE s."state" = '2' AND s."deletedAt" = '0' AND s."campusId" = $1 AND DATE(s."registrationDate") BETWEEN $2 AND $3
          UNION ALL
          SELECT '3' AS description, COUNT(*) AS amount FROM support.service s 
        WHERE s."state" = '3' AND s."deletedAt" = '0' AND s."campusId" = $1 AND DATE(s."registrationDate") BETWEEN $2 AND $3
          UNION ALL
          SELECT '7' AS description, COUNT(*) AS amount FROM support.service s 
        WHERE s."state" = '7' AND s."deletedAt" = '0' AND s."campusId" = $1 AND DATE(s."registrationDate") BETWEEN $2 AND $3
      ) AS pending;  
      `, [campusId, startDate, endDate]);
                return yield pending;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    totalsTransaction(campusId, type, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`SELECT 
      (SELECT SUM(pt.amount) FROM accounting.payment_transaction pt
        JOIN accounting.finance f ON f."financeId" = pt."financeId"
        WHERE f."campusId" = $1        
        AND  f."deletedAt" = '0'
        AND DATE(f."deliverDate" ) BETWEEN $2 AND $3
        AND f."typeOperation" = $4
      ) AS "totals",
    
      (
        SELECT ARRAY_AGG(createdBy) as categories 
          FROM (
            SELECT 
              DATE_TRUNC('day', pt."createdBy") AS createdBy
            FROM 
              accounting.payment_transaction pt
              JOIN accounting.finance f ON f."financeId" = pt."financeId"
            WHERE 
              f."campusId" = $1		 
              AND  f."deletedAt" = '0'             
              AND DATE(f."deliverDate" ) BETWEEN $2 AND $3
              AND f."typeOperation" = $4
            GROUP BY 
              DATE_TRUNC('day', pt."createdBy")
          ) as categories
      ),
      
      (SELECT ARRAY_AGG(total_amount) as series FROM (
        SELECT SUM(pt.amount) AS total_amount
        FROM accounting.payment_transaction pt
        JOIN accounting.finance f ON f."financeId" = pt."financeId"
        WHERE f."campusId" = $1	  
        AND  f."deletedAt" = '0'      
        AND DATE(f."deliverDate" ) BETWEEN $2 AND $3
        AND f."typeOperation" = $4
        GROUP BY DATE_TRUNC('day', pt."createdBy")
      ) as series )
      `, [campusId, startDate, endDate, type]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    totalsServices(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
        SELECT 
        (SELECT SUM(pay.amount)
          FROM support.service serv
          JOIN support.payment pay ON serv."serviceId" = pay."serviceId"
          WHERE serv."campusId" = $1
          AND serv."deletedAt" = '0'
          AND DATE(pay."date") BETWEEN $2 AND $3
        ) AS "totals",
      
        (
          SELECT ARRAY_AGG(createdBy) as categories 
            FROM (
              SELECT 
                DATE_TRUNC('day', pay."date") AS createdBy
              FROM 
                support.payment pay			
              JOIN support.service serv ON pay."serviceId" = serv."serviceId"
              WHERE 
                pay."campusId" = $1		
                AND serv."deletedAt" = '0'
                AND DATE(pay."date") BETWEEN $2 AND $3
              GROUP BY 
                DATE_TRUNC('day', pay."date")
            ) as categories 
        ),
        
        (SELECT ARRAY_AGG(total_amount) as series FROM (
          SELECT SUM(pay.amount) AS total_amount
          FROM support.payment pay		
          JOIN support.service serv ON pay."serviceId" = serv."serviceId"
          WHERE pay."campusId" = $1	          
          AND serv."deletedAt" = '0'
          AND DATE(pay."date") BETWEEN $2 AND $3
          GROUP BY DATE_TRUNC('day', pay."date")
        ) as series )
        `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    totalsTechnical(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      (
          SELECT COUNT(*) 
          FROM support.service s
          WHERE s."campusId" = $1       
          AND s."deletedAt" = '0'
          AND DATE(s."registrationDate") BETWEEN $2 AND $3
      ) AS "totals",
  
      (
          SELECT ARRAY_AGG(technical) as categories
          FROM (
              SELECT 
                  u.name AS technical
              FROM 
                  system.user u 
              WHERE 
                  u."userId" IN (SELECT DISTINCT "userTechnicalId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
                           UNION 
                           SELECT DISTINCT "userReceptionId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
                           UNION 
                           SELECT DISTINCT "userDeliveryId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
                          )
              ORDER BY u.name	
          ) as categories
      ),
  
      (
          SELECT ARRAY_AGG(repair+reception+delivery+fast_service) as series 
          FROM (            
              SELECT 
                  (SELECT COUNT(*) 
                  FROM support.service s 
                  WHERE "userTechnicalId" = u."userId"
                  AND s."deletedAt" = '0'
                  AND s."campusId" = $1
                  AND DATE(s."registrationDate") BETWEEN $2 AND $3
                  ) AS repair,
                  (SELECT COUNT(*) 
                  FROM support.service s 
                  WHERE "userReceptionId" = u."userId"
                  AND s."deletedAt" = '0'
                  AND s."campusId" = $1
                  AND DATE(s."registrationDate") BETWEEN $2 AND $3
                  ) AS reception,
                  (SELECT COUNT(*) 
                  FROM support.service s 
                  WHERE "userDeliveryId" = u."userId"
                  AND s."deletedAt" = '0'
                  AND s."campusId" = $1
                  AND DATE(s."registrationDate") BETWEEN $2 AND $3
                  ) AS delivery,
                  (SELECT COUNT(*) 
                  FROM support.service s 
                  WHERE "userTechnicalId" = u."userId" 
                  AND s."deletedAt" = '0'
                  AND s."campusId" = $1
                  AND s.type = 2 
                  AND DATE(s."registrationDate") BETWEEN $2 AND $3
                  ) AS fast_service
              FROM 
                  system.user u 
              WHERE 
                  u."userId" IN (SELECT DISTINCT "userTechnicalId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
                           UNION 
                           SELECT DISTINCT "userReceptionId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
                           UNION  
                           SELECT DISTINCT "userDeliveryId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
                          )
              ORDER BY u.name	
          ) as series
      );  
        `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    totalsDifferences(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      (SELECT SUM(diffpay.amount) FROM support.difference diff		
        JOIN support.difference_payment diffpay ON diff."differenceId" = diffpay."differenceId"
        WHERE diff."campusId" = $1        
        AND DATE(diff."createdBy") BETWEEN $2 AND $3
      ) AS "totals",
    
      (
        SELECT ARRAY_AGG(createdBy) as categories 
          FROM (
            SELECT 
              DATE_TRUNC('day', diff."createdBy") AS createdBy
            FROM 
              support.difference diff		
              JOIN support.difference_payment diffpay ON diff."differenceId" = diffpay."differenceId"			
            WHERE 
              diff."campusId" = $1		              
              AND DATE(diff."createdBy") BETWEEN $2 AND $3
            GROUP BY 
              DATE_TRUNC('day', diff."createdBy")
          ) as categories
      ),
      
      (SELECT ARRAY_AGG(total_amount) as series FROM (
        SELECT SUM(diffpay.amount) AS total_amount
        FROM support.difference diff		
        JOIN support.difference_payment diffpay ON diff."differenceId" = diffpay."differenceId"			
        WHERE diff."campusId" = $1	        
        AND DATE(diff."createdBy") BETWEEN $2 AND $3
        GROUP BY DATE_TRUNC('day', diff."createdBy")
      ) as series )
      `, [campusId, startDate, endDate]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    mostRepairedEquipment(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
        SELECT 
        (SELECT SUM(pay.amount) FROM support.payment pay		
          WHERE pay."campusId" = $1
          AND DATE_TRUNC('month', pay."createdBy") = DATE_TRUNC('month', CURRENT_DATE)	 	
        ) AS "totals",
      
        (
          SELECT ARRAY_AGG(createdBy) as categories 
            FROM (
              SELECT 
                DATE_TRUNC('day', pay."createdBy") AS createdBy
              FROM 
                support.payment pay					
              WHERE 
                pay."campusId" = $1		
                AND DATE_TRUNC('month', pay."createdBy") = DATE_TRUNC('month', CURRENT_DATE)					
              GROUP BY 
                DATE_TRUNC('day', pay."createdBy")
            )
        ),
        
        (SELECT ARRAY_AGG(total_amount) as series FROM (
          SELECT SUM(pay.amount) AS total_amount
          FROM support.payment pay		
          WHERE pay."campusId" = $1	
          AND DATE_TRUNC('month', pay."createdBy") = DATE_TRUNC('month', CURRENT_DATE)		
          GROUP BY DATE_TRUNC('day', pay."createdBy")
        ))
        `, [campusId]);
                return yield this.chartEmptyValidate(servicesAll);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * Obtiene resultado de las ganacias netas de los servicio descontando los gastos diarios
     *
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    findNetProfitService(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
     SELECT 
    (SELECT SUM(pay.amount) 
     FROM support.service serv
     JOIN support.payment pay ON serv."serviceId" = pay."serviceId"
     WHERE DATE(serv."registrationDate") BETWEEN $2 AND $3
     AND serv."campusId" = $1
     AND serv."deletedAt" = '0') 
    -
    (SELECT SUM(fe."dailyPayment") 
     FROM accounting.fixed_expenses fe) AS profit;
        `, [campusId, startDate, endDate]);
                if (servicesAll.length > 0) {
                    return servicesAll[0].profit;
                }
                else {
                    return 0;
                }
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findTotalServicePayments(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      COUNT(*) AS cant,
      paytype.description,
      paytype.type,
      SUM(pay.amount) AS amount
      FROM support.service serv
      JOIN support.payment pay ON serv."serviceId" = pay."serviceId" 
      JOIN company.payment_type paytype ON pay."paymentTypeId" = paytype."paymentTypeId"
      WHERE  DATE(pay."date") BETWEEN $2 AND $3
      AND serv."campusId" = $1
      AND serv."deletedAt" = '0'
      GROUP BY paytype."paymentTypeId", paytype.description, paytype.type;
        `, [campusId, startDate, endDate]);
                return servicesAll;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findTotalSalesPayments(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const salesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      COUNT(*) AS cant,
      paytype.description,
      paytype.type,
      SUM(pay.amount) AS amount
      FROM support.service serv
      JOIN support.payment pay ON serv."serviceId" = pay."serviceId"
      JOIN company.payment_type paytype ON pay."paymentTypeId" = paytype."paymentTypeId"
      WHERE DATE(serv."registrationDate") BETWEEN $2 AND $3
      AND serv."campusId" = $1
      AND serv."deletedAt" = '0'
      GROUP BY paytype."paymentTypeId"
        `, [campusId, startDate, endDate]);
                return salesAll;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findTransactionPayments(campusId, typeOperation, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      COUNT(*) AS cant,
      paytype.description,
      paytype.type,
      SUM(pay.amount) AS amount
      FROM accounting.finance fnce
      JOIN accounting.payment_transaction pay ON fnce."financeId" = pay."financeId"
      JOIN company.payment_type paytype ON pay."paymentTypeId" = paytype."paymentTypeId"
      WHERE DATE(fnce."deliverDate" ) BETWEEN $1 AND $2
      AND fnce."campusId" = $3
      AND fnce."typeOperation" = $4
      AND fnce."deletedAt" = '0'
      GROUP BY paytype."paymentTypeId"
        `, [startDate, endDate, campusId, typeOperation]);
                return servicesAll;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findDifferencePayments(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const servicesAll = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
      COUNT(*) AS cant,
      paytype.description,
      paytype.type,
      SUM(diffpay.amount) AS amount
      FROM support.service serv
      JOIN support.difference diff ON serv."serviceId" = diff."serviceId"
      JOIN support.difference_payment diffpay ON diff."differenceId" = diffpay."differenceId"      
      JOIN company.payment_type paytype ON diffpay."paymentTypeId" = paytype."paymentTypeId"
      WHERE DATE(serv."registrationDate") BETWEEN $1 AND $2
      AND serv."campusId" = $3
      AND serv."deletedAt" = '0'
      GROUP BY paytype."paymentTypeId"
        `, [startDate, endDate, campusId]);
                return servicesAll;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    technicalRecors(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const techincalRecors = yield modelslibrary_1.AppDataSource.query(`
      SELECT 
          u.name AS technical,
          (SELECT COUNT(*) FROM support.service s WHERE "userTechnicalId" = u."userId"
          AND s."deletedAt" = '0'
          AND s."campusId" = $1
          AND DATE(s."registrationDate") BETWEEN $2 AND $3
        ) AS repair,	
          (SELECT COUNT(*) FROM support.service s WHERE "userReceptionId" = u."userId"
          AND s."deletedAt" = '0'
          AND s."campusId" = $1
          AND DATE(s."registrationDate") BETWEEN $2 AND $3
        ) AS reception,	
          (SELECT COUNT(*) FROM support.service s WHERE "userDeliveryId" = u."userId"
          AND s."deletedAt" = '0'
          AND s."campusId" = $1
          AND DATE(s."registrationDate") BETWEEN $2 AND $3
        ) AS delivery,
        (SELECT COUNT(*) FROM support.service s WHERE "userTechnicalId" = u."userId" 
          AND s."deletedAt" = '0'
          AND s."campusId" = $1
          AND s.type = 2 AND DATE(s."registrationDate") BETWEEN $2 AND $3
        ) AS fast_service
      FROM 
          system.user u 
      WHERE 
          u."userId" IN (SELECT DISTINCT "userTechnicalId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
                  UNION 
                  SELECT DISTINCT "userReceptionId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
                  UNION 
                  SELECT DISTINCT "userDeliveryId" FROM support.service s WHERE s."campusId" = $1 AND s."deletedAt" = '0' AND DATE(s."registrationDate") BETWEEN $2 AND $3
            )
      ORDER BY u.name			
        `, [campusId, startDate, endDate]);
                return techincalRecors;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * * OBTENER MONTO DE RETIROS EN EFECTIVO
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    chartWithdrawals(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const expensesRecordsArray = yield modelslibrary_1.AppDataSource.query(`     
        WITH totals AS (
          SELECT 
              (SELECT COALESCE(SUM(p.amount), 0)
              FROM support.service s
              JOIN support.payment p ON p."serviceId" = s."serviceId"
          JOIN company.payment_type pt ON pt."paymentTypeId" = p."paymentTypeId"
          WHERE pt.type = 'cash'
            AND s."campusId" = $1          
                AND s."deletedAt" = '0'          
          ) AS service,
              
              (SELECT COALESCE(SUM(ps.amount), 0)
              FROM sales.sales s
              JOIN sales.payment_sales ps ON ps."salesId" = s."salesId"
            JOIN company.payment_type pt ON pt."paymentTypeId" = ps."paymentTypeId"
          WHERE pt.type = 'cash'
            AND s."campusId" = $1        
                AND s."deletedAt" = '0'          
          ) AS sales,
              
              (SELECT COALESCE(SUM(pt.amount), 0)
              FROM accounting.finance f
              JOIN accounting.payment_transaction pt ON pt."financeId" = f."financeId"
          JOIN company.payment_type pat ON pat."paymentTypeId" = pt."paymentTypeId"
          WHERE pat.type = 'cash'
            AND f."campusId" = $1          
                AND f."deletedAt" = '0'          
          ) AS finance,
              
          (SELECT COALESCE(SUM(cbd."openingAmount"), 0) 
          FROM accounting.cash_box_detail cbd
          JOIN accounting.cash_box cb ON cbd."cashBoxId" = cb."cashBoxId"
            WHERE cb."campusId" = $1          
                AND cbd."deletedAt" = '0'
                AND DATE(cbd."openingDate") BETWEEN $2 AND $3
          ) AS cashBox,
        
              (SELECT COALESCE(SUM(cw.amount), 0)
              FROM accounting.cash_withdrawals cw
            WHERE cw."campusId" = $1           
                AND cw."deletedAt" = '0'
                AND DATE(cw."date") BETWEEN $2 AND $3
          ) AS withdrawals
      )
      SELECT 
          service,
          sales,
          finance,
          withdrawals,
        cashBox,
          (service + sales + finance) - withdrawals AS saldo
      FROM totals;	
        `, [campusId, startDate, endDate]);
                const expensesRecords = expensesRecordsArray.length > 0 ? expensesRecordsArray[0] : null;
                return expensesRecords;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    chartEmptyValidate(charts) {
        return __awaiter(this, void 0, void 0, function* () {
            if (charts.length > 0) {
                if (charts[0].totals === null) {
                    charts[0].totals = 0;
                }
                if (charts[0].series === null) {
                    charts[0].series = [];
                }
                if (charts[0].categories === null) {
                    charts[0].categories = [];
                }
            }
            return charts[0];
        });
    }
    /**
     * Devuelve el total de ganancias en efectivo
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    findTotalCashBalance(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalInCash = yield modelslibrary_1.AppDataSource.query(`     
        WITH totals AS (
          SELECT 
              (SELECT COALESCE(SUM(p.amount), 0)
              FROM support.service s
              JOIN support.payment p ON p."serviceId" = s."serviceId"
              JOIN company.payment_type pt ON pt."paymentTypeId" = p."paymentTypeId"
              WHERE pt.type = 'cash'
                AND s."campusId" = $1          
                AND s."deletedAt" = '0'
                AND DATE(s."registrationDate") BETWEEN $2 AND $3  
          ) AS service,
              
              (SELECT COALESCE(SUM(ps.amount), 0)
              FROM sales.sales s
              JOIN sales.payment_sales ps ON ps."salesId" = s."salesId"
              JOIN company.payment_type pt ON pt."paymentTypeId" = ps."paymentTypeId"
              WHERE pt.type = 'cash'
                AND s."campusId" = $1        
                AND s."deletedAt" = '0'
                AND DATE(s."date") BETWEEN $2 AND $3            
          ) AS sales,
              
              (SELECT COALESCE(SUM(pt.amount), 0)
              FROM accounting.finance f
              JOIN accounting.payment_transaction pt ON pt."financeId" = f."financeId"
              JOIN company.payment_type pat ON pat."paymentTypeId" = pt."paymentTypeId"
              WHERE pat.type = 'cash'
                AND f."campusId" = $1          
                AND f."deletedAt" = '0'          
                AND DATE(f."deliverDate") BETWEEN $2 AND $3
          ) AS finance,
              
          (SELECT COALESCE(SUM(cbd."openingAmount"), 0) 
          FROM accounting.cash_box_detail cbd
          JOIN accounting.cash_box cb ON cbd."cashBoxId" = cb."cashBoxId"
            WHERE cb."campusId" = $1          
                AND cbd."deletedAt" = '0'
                AND DATE(cbd."openingDate") BETWEEN $2 AND $3
          ) AS cashBox,
        
              (SELECT COALESCE(SUM(cw.amount), 0)
              FROM accounting.cash_withdrawals cw
            WHERE cw."campusId" = $1           
                AND cw."deletedAt" = '0'
                AND DATE(cw."date") BETWEEN $2 AND $3
          ) AS withdrawals
      )
      SELECT 
          service,
          sales,
          finance,
          withdrawals,
        cashBox,
          (service + sales + finance) - withdrawals AS total
      FROM totals;	
        `, [campusId, startDate, endDate]);
                const totalCash = totalInCash.length > 0 ? totalInCash[0] : 0;
                return totalCash;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * Devuelve el total de ganancias en otros medios de pago
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    findTotalCashInBank(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalCashInBank = yield modelslibrary_1.AppDataSource.query(`     
        WITH totals AS (
          SELECT 
              (SELECT COALESCE(SUM(p.amount), 0)
              FROM support.service s
              JOIN support.payment p ON p."serviceId" = s."serviceId"
              JOIN company.payment_type pt ON pt."paymentTypeId" = p."paymentTypeId"
              WHERE pt.type = 'transfer'
                AND s."campusId" = $1          
                AND s."deletedAt" = '0'
                AND DATE(s."registrationDate") BETWEEN $2 AND $3            
          ) AS service,
              
              (SELECT COALESCE(SUM(ps.amount), 0)
              FROM sales.sales s
              JOIN sales.payment_sales ps ON ps."salesId" = s."salesId"
              JOIN company.payment_type pt ON pt."paymentTypeId" = ps."paymentTypeId"
              WHERE pt.type = 'transfer'
                AND s."campusId" = $1        
                AND s."deletedAt" = '0'
                AND DATE(s."date") BETWEEN $2 AND $3         
          ) AS sales,
              
              (SELECT COALESCE(SUM(pt.amount), 0)
              FROM accounting.finance f
              JOIN accounting.payment_transaction pt ON pt."financeId" = f."financeId"
              JOIN company.payment_type pat ON pat."paymentTypeId" = pt."paymentTypeId"
              WHERE pat.type = 'transfer'
                AND f."campusId" = $1          
                AND f."deletedAt" = '0'
                AND DATE(f."deliverDate") BETWEEN $2 AND $3        
          ) AS finance,
              
          (SELECT COALESCE(SUM(cbd."openingAmount"), 0) 
          FROM accounting.cash_box_detail cbd
          JOIN accounting.cash_box cb ON cbd."cashBoxId" = cb."cashBoxId"
            WHERE cb."campusId" = $1          
                AND cbd."deletedAt" = '0'
                AND DATE(cbd."openingDate") BETWEEN $2 AND $3
          ) AS cashBox,
        
              (SELECT COALESCE(SUM(cw.amount), 0)
              FROM accounting.cash_withdrawals cw
            WHERE cw."campusId" = $1           
                AND cw."deletedAt" = '0'
                AND DATE(cw."date") BETWEEN $2 AND $3
          ) AS withdrawals
      )
      SELECT 
          service,
          sales,
          finance,
          cashBox,
          (service + sales + finance) AS total
      FROM totals;	
        `, [campusId, startDate, endDate]);
                const totalCashBank = totalCashInBank.length > 0 ? totalCashInBank[0] : null;
                return totalCashBank;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * Devuelve el total de ganancias general
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    findTotalgeneralBalance(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalGeneral = yield modelslibrary_1.AppDataSource.query(`     
        WITH totals AS (
          SELECT 
              (SELECT COALESCE(SUM(p.amount), 0)
              FROM support.service s
              JOIN support.payment p ON p."serviceId" = s."serviceId"
              JOIN company.payment_type pt ON pt."paymentTypeId" = p."paymentTypeId"
              WHERE s."campusId" = $1          
                    AND s."deletedAt" = '0'
                    AND DATE(s."registrationDate") BETWEEN $2 AND $3          
              ) AS service,
              
              (SELECT COALESCE(SUM(ps.amount), 0)
              FROM sales.sales s
              JOIN sales.payment_sales ps ON ps."salesId" = s."salesId"
              JOIN company.payment_type pt ON pt."paymentTypeId" = ps."paymentTypeId"
              WHERE s."campusId" = $1        
                    AND s."deletedAt" = '0'
                    AND DATE(s."date") BETWEEN $2 AND $3          
              ) AS sales,
              
              (SELECT COALESCE(SUM(pt.amount), 0)
              FROM accounting.finance f
              JOIN accounting.payment_transaction pt ON pt."financeId" = f."financeId"
              JOIN company.payment_type pat ON pat."paymentTypeId" = pt."paymentTypeId"
              WHERE f."campusId" = $1          
                    AND f."deletedAt" = '0'
                    AND DATE(f."deliverDate") BETWEEN $2 AND $3          
              ) AS finance,
              
              (SELECT COALESCE(SUM(cbd."openingAmount"), 0) 
              FROM accounting.cash_box_detail cbd
              JOIN accounting.cash_box cb ON cbd."cashBoxId" = cb."cashBoxId"
                WHERE cb."campusId" = $1          
                    AND cbd."deletedAt" = '0'
                    AND DATE(cbd."openingDate") BETWEEN $2 AND $3
              ) AS cashBox,
        
              (SELECT COALESCE(SUM(cw.amount), 0)
              FROM accounting.cash_withdrawals cw
              WHERE cw."campusId" = $1           
                  AND cw."deletedAt" = '0'
                  AND DATE(cw."date") BETWEEN $2 AND $3
              ) AS withdrawals
      )
      SELECT 
          service,
          sales,
          finance,
          withdrawals,
        cashBox,
          (service + sales + finance) - withdrawals AS total
      FROM totals;	
        `, [campusId, startDate, endDate]);
                const totalGeneralBalance = totalGeneral.length > 0 ? totalGeneral[0] : null;
                return totalGeneralBalance;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * Devuelve el total de operaciones hechas (pagos)
     * @param campusId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    findTotalOperations(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalOperations = yield modelslibrary_1.AppDataSource.query(`     
        WITH totals AS (
        SELECT 
          (SELECT COALESCE(COUNT(*), 0)
           FROM support.service s
           JOIN support.payment p ON p."serviceId" = s."serviceId"
           JOIN company.payment_type pt ON pt."paymentTypeId" = p."paymentTypeId"
           WHERE s."campusId" = $1          
            AND s."deletedAt" = '0'
            AND DATE(s."registrationDate") BETWEEN $2 AND $3
          ) AS service,
              
          (SELECT COALESCE(COUNT(*), 0)
           FROM sales.sales s
           JOIN sales.payment_sales ps ON ps."salesId" = s."salesId"
           JOIN company.payment_type pt ON pt."paymentTypeId" = ps."paymentTypeId"
           WHERE s."campusId" = $1        
            AND s."deletedAt" = '0'
            AND DATE(s."date") BETWEEN $2 AND $3
          ) AS sales,
              
          (SELECT COALESCE(COUNT(*), 0)
           FROM accounting.finance f
           JOIN accounting.payment_transaction pt ON pt."financeId" = f."financeId"
           JOIN company.payment_type pat ON pat."paymentTypeId" = pt."paymentTypeId"
           WHERE f."campusId" = $1          
            AND f."deletedAt" = '0'
            AND DATE(f."deliverDate") BETWEEN $2 AND $3
          ) AS finance
      )
      SELECT 
        service,
        sales,
        finance,
        (service + sales + finance) AS total
      FROM totals;
    `, [campusId, startDate, endDate]);
                const totalOperation = totalOperations.length > 0 ? totalOperations[0] : null;
                return totalOperation;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    /**
     * Devuelve el total de pagos a creditos que estan por pagar
     * @param companyId
     * @param startDate
     * @param endDate
     * @param zone
     * @returns
     */
    findTotalPriceAdjustment(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalService = yield modelslibrary_1.AppDataSource.query(`
        WITH totals AS (

        SELECT

          (SELECT 
                SUM(sdh.adjustment) as "discount"
                FROM support.service service
				        JOIN support.service_device sd on sd."serviceId" = service."serviceId"
              	JOIN support.service_device_history sdh on sdh."serviceDeviceId" = sd."serviceDeviceId"
              	WHERE service."campusId" = $1 
                  AND sdh."type" = 'discount'
                  AND service."deletedAt" = '0'
                  AND DATE(sdh."createdBy") BETWEEN $2 AND $3
          ) as discount, 

          (SELECT 
                SUM(sdh.adjustment) as "repayment"
                FROM support.service service
                JOIN support.service_device sd on sd."serviceId" = service."serviceId"
              	JOIN support.service_device_history sdh on sdh."serviceDeviceId" = sd."serviceDeviceId"
                WHERE service."campusId" = $1
                  AND sdh."type" = 'repayment'          
                  AND service."deletedAt" = '0'
                  AND DATE(sdh."createdBy") BETWEEN $2 AND $3
          ) as repayment,
          
          (SELECT 
                SUM(sdh.adjustment) as "increase"
                FROM support.service service
                JOIN support.service_device sd on sd."serviceId" = service."serviceId"
              	JOIN support.service_device_history sdh on sdh."serviceDeviceId" = sd."serviceDeviceId"
                WHERE service."campusId" = $1
                  AND sdh."type" = 'increase'          
                  AND service."deletedAt" = '0'
                  AND DATE(sdh."createdBy") BETWEEN $2 AND $3
          ) as increase,
          
          (SELECT 
                SUM(cw.amount) as "cash_withdrawals"
                FROM accounting.cash_withdrawals cw
                WHERE cw."campusId" = $1          
                  AND cw."deletedAt" = '0'
                  AND DATE(cw."date") BETWEEN $2 AND $3
          ) as cash_withdrawals
        )

        SELECT 
          discount,
          repayment,
          increase,
          cash_withdrawals
          FROM totals
      `, [campusId, startDate, endDate]);
                const totalPriceAdjustment = totalService.length > 0 ? totalService[0] : null;
                return totalPriceAdjustment;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findTotalCreditPayment(companyId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalCredit = yield modelslibrary_1.AppDataSource.query(`
        WITH totals AS (
        SELECT 
          SUM(cs.amount) as "credit"  
        FROM credit.credit c
        JOIN credit.credit_schedule cs ON cs."creditId" = c."creditId"
        WHERE c."companyId" = $1
          AND c."deletedAt" = '0'
          AND cs."isPaid" = false
          AND cs."paymentDate" IS NULL
          AND DATE(c."date") BETWEEN $2 AND $3
      )

      SELECT 
        credit as total
      FROM totals;  
      `, [companyId, startDate, endDate]);
                const totalCredits = totalCredit.length > 0 ? totalCredit[0] : null;
                return totalCredits;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
}
exports.dashboardService = DashboardService.getInstance();
//# sourceMappingURL=dashboard.service.js.map