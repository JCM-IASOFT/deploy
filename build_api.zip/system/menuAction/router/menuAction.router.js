"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.menuActionRoute = void 0;
const express_1 = require("express");
const menuAction_controller_1 = require("../controller/menuAction.controller");
const menuAction_validator_1 = require("../validator/menuAction.validator");
exports.menuActionRoute = (0, express_1.Router)();
exports.menuActionRoute.get('/', menuAction_controller_1.menuActionController.findMenuAction);
exports.menuActionRoute.post('/', menuAction_validator_1.validateCreateMenuAction, menuAction_controller_1.menuActionController.createMenuActions);
exports.menuActionRoute.put('/:menuActionId', menuAction_validator_1.validateUpdateMenuAction, menuAction_controller_1.menuActionController.updateMenuAction);
exports.menuActionRoute.delete('/:menuActionId', menuAction_validator_1.validateDeleteMenuAction, menuAction_controller_1.menuActionController.deleteMenuAction);
//# sourceMappingURL=menuAction.router.js.map