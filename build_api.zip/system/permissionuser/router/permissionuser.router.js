"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionuserRoute = void 0;
const express_1 = require("express");
const permissionuser_controller_1 = require("../controller/permissionuser.controller");
exports.permissionuserRoute = (0, express_1.Router)();
exports.permissionuserRoute.get('/', permissionuser_controller_1.permissionuserController.findAllPermissionUser);
exports.permissionuserRoute.post('/', permissionuser_controller_1.permissionuserController.createPermissionUsers);
exports.permissionuserRoute.delete('/', permissionuser_controller_1.permissionuserController.deletePermissionUser);
//# sourceMappingURL=permissionuser.router.js.map