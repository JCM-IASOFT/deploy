"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateUpdateParameter = exports.validateCreateParameter = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateParameter = [
    (0, express_validator_1.check)('parameters').custom((value) => {
        if (Array.isArray(value)) {
            throw new Error('El campo debe ser un array');
        }
        return true;
    }),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateParameter = [
    (0, express_validator_1.check)('parameters').custom((value) => {
        if (Array.isArray(value)) {
            throw new Error('El campo debe ser un array');
        }
        return true;
    }),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=parameter.validator.js.map