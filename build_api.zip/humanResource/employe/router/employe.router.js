"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.employeRoute = void 0;
const express_1 = require("express");
const employe_controller_1 = require("../controller/employe.controller");
const employe_validator_1 = require("../validator/employe.validator");
exports.employeRoute = (0, express_1.Router)();
exports.employeRoute.get('/', employe_controller_1.employeController.findEmploye);
exports.employeRoute.post('/', employe_validator_1.validateCreateEmploye, employe_controller_1.employeController.createEmployes);
exports.employeRoute.put('/:employeId', employe_validator_1.validateUpdateEmploye, employe_controller_1.employeController.updateEmploye);
exports.employeRoute.delete('/:employeId', employe_validator_1.validateDeleteEmploye, employe_controller_1.employeController.deleteEmploye);
//# sourceMappingURL=employe.router.js.map