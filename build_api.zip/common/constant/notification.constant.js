"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageNotification = void 0;
exports.MessageNotification = {
    EXPIRADO: 'Este servicio esta vencido',
    POR_EXPIRAR: 'Este servicio esta por vencer!',
    REVISAR: 'Tiene algunos servicios proximos a entregar!',
    EN_ESPERA: 'Este servicio aun esta en espera!'
};
//# sourceMappingURL=notification.constant.js.map