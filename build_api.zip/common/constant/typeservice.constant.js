"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypeService = void 0;
exports.TypeService = {
    detail: 1,
    fast: 2
};
//# sourceMappingURL=typeservice.constant.js.map