"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reniecRoute = void 0;
const express_1 = require("express");
const reniec_controller_1 = require("../controller/reniec.controller");
const reniec_validator_1 = require("../validator/reniec.validator");
exports.reniecRoute = (0, express_1.Router)();
exports.reniecRoute.get('/documentNumber', reniec_validator_1.validateSearchDniReniec, reniec_controller_1.reniecController.searchPersonForDni);
exports.reniecRoute.get('/ruc', reniec_validator_1.validateSearchDniReniec, reniec_controller_1.reniecController.searchPersonForRuc);
exports.reniecRoute.get('/exchange', reniec_controller_1.reniecController.exchangeCurrency);
//# sourceMappingURL=reniec.router.js.map