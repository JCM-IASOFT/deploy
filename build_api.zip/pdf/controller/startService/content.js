"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentPdf = exports.fetchAndConvertToBase64 = void 0;
const axios_1 = __importDefault(require("axios"));
const moment_1 = __importDefault(require("moment"));
const fetchAndConvertToBase64 = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axios_1.default.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 5000
        });
        const base64Image = Buffer.from(response.data, 'binary').toString('base64');
        return base64Image;
    }
    catch (error) {
        return null;
    }
});
exports.fetchAndConvertToBase64 = fetchAndConvertToBase64;
const ContentPdf = (service, campus, company) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let data = [];
        const tableData = [];
        tableData.push([
            { text: 'SERVICIO:', style: 'tHeaderLabel' },
            { text: `${service.serviceId.toString().padStart(5, '0').toUpperCase()}`, style: 'tHeaderLabel', colSpan: 3 },
            {},
            {},
        ], [
            { text: 'TIPO DE OPERACION:', style: 'tHeaderLabel' },
            { text: `INICIO DE REPARACIÓN`, style: 'tHeaderLabel', colSpan: 3 },
            {},
            {}
        ]);
        tableData.push([
            { text: 'EQUIPO(S):', style: 'tHeaderLabel', colSpan: 4 },
            {},
            {},
            {}
        ]);
        service.serviceDevices.forEach(item => {
            tableData.push([
                { text: `${item.device.description.toUpperCase()}`, style: 'tHeaderLabel', colSpan: 4 },
                {},
                {},
                {}
            ]);
        });
        tableData.push([
            { text: 'MARCA - SERIAL - MODELO:', style: 'tHeaderLabel', colSpan: 4 },
            {},
            {},
            {}
        ]);
        service.serviceDevices.forEach(item => {
            tableData.push([
                { text: `${item.deviceBrand.description.toUpperCase()} - ${item.serial.toUpperCase()} - ${item.model.toUpperCase()}`, style: 'tHeaderLabel', colSpan: 4 },
                {},
                {},
                {}
            ]);
        });
        tableData.push([
            { text: 'RESPONSABLE:', style: 'tHeaderLabel' },
            { text: `${service.userTechnical.name.toUpperCase() + ' ' + service.userTechnical.fullname.toUpperCase()}`, style: 'tHeaderLabel', colSpan: 3, margin: [5, 0, 0, 0] },
            {},
            {}
        ]);
        data = [
            { text: company.name.toUpperCase(), style: 'tHeaderValue', margin: [0, 5, 0, 0], alignment: 'center' },
            { text: 'TICKET SERVICIO', style: 'tHeaderValue', margin: [0, 5, 0, 2], alignment: 'center' },
            { text: service.serviceId.toString().padStart(5, '0'), style: 'tHeaderValue', margin: [0, 2, 0, 0], alignment: 'center' },
            { text: `SEDE: ${campus.name.toUpperCase()}`, style: 'tHeaderValue', margin: [0, 8, 0, 0], alignment: 'left' },
            { text: `DIRECCIÓN: ${campus.address.toUpperCase()}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0] },
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['25%', '30%', '20%', '25%'],
                    body: [
                        [
                            { text: 'FECHA:', style: 'tHeaderLabel' },
                            { text: service.deliverDate ? (0, moment_1.default)(service.deliverDate).format('L') : 'Sin fecha', style: 'tHeaderValue' },
                            { text: 'HORA:', style: 'tHeaderLabel' },
                            { text: service.deliverDate ? (0, moment_1.default)(service.deliverDate).format('HH:mm:ss') : 'Sin fecha', style: 'tHeaderValue' },
                        ],
                    ],
                },
                layout: {
                    hLineWidth: (i, node) => {
                        return (i === 0) ? 1 : 0;
                    },
                    vLineWidth: (i, node) => {
                        return 0;
                    },
                    hLineColor: (i, node) => {
                        return '#000000';
                    },
                },
            },
            // ** TABLA TRANSACCION
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['35%', '30%', '15%', '20%'],
                    body: tableData
                },
                layout: {
                    hLineWidth: (i, node) => {
                        return (i === 0 || i === node.table.body.length) ? 1 : 0;
                    },
                    vLineWidth: (i, node) => {
                        return 0;
                    },
                    hLineColor: (i, node) => {
                        return '#000000';
                    },
                },
            },
            // //TABLE PAYMENT
            // {
            //     margin: [0, 5, 0, 0],
            //     table: {
            //         widths: ['50%', '*'],
            //         body: tableData
            //     },
            //     layout: 'noBorders'
            // },
            { text: '--------------------', style: 'header', margin: [0, 15, 0, 0], alignment: 'center' },
            { text: 'FIRMA', style: 'header', margin: [0, 0, 0, 0], alignment: 'center' },
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentPdf = ContentPdf;
//# sourceMappingURL=content.js.map