"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentPdf = exports.fetchAndConvertToBase64 = void 0;
const axios_1 = __importDefault(require("axios"));
const moment_1 = __importDefault(require("moment"));
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
const canvas_1 = require("canvas");
const jsbarcode_1 = __importDefault(require("jsbarcode"));
const enum_1 = require("modelslibrary/src/core/enum/enum");
const fetchAndConvertToBase64 = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axios_1.default.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 5000
        });
        const base64Image = Buffer.from(response.data, 'binary').toString('base64');
        return base64Image;
    }
    catch (error) {
        return null;
    }
});
exports.fetchAndConvertToBase64 = fetchAndConvertToBase64;
const generateBarcodeAsBase64 = (text, width, height) => {
    const canvas = (0, canvas_1.createCanvas)(width, height);
    const context = canvas.getContext('2d');
    (0, jsbarcode_1.default)(canvas, text, {
        format: 'CODE128', displayValue: false, width: 7,
        height: 200,
    });
    const barcodeBase64 = context.canvas.toDataURL();
    return barcodeBase64;
};
const ContentPdf = (campus, company, service) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let data = [];
        const serviceStatusService = service.serviceStatusHistorys.find(p => p.status === parameter_constant_1.StatusService.SIN_SOLUCION_ENTREGADO
            || p.status === parameter_constant_1.StatusService.ENTREGADO || p.status === parameter_constant_1.StatusService.RECHAZADO);
        const amountAdvance = service.payments.reduce((total, element) => total + (+element.amount), 0);
        const tableData = [];
        if (service.serviceDevices.length > 0) {
            service.serviceDevices.forEach(element => {
                tableData.push([{ text: element.device.description, style: 'titleTable', margin: [0, 0, 0, 0] }, { text: element.deviceBrand.description, style: 'titleTable', }]);
                tableData.push([{ text: 'falla/problema:', style: 'tProductsBody', margin: [0, 0, 0, 0] }, { text: element.reason, style: 'tProductsBody', margin: [0, 0, 0, 0] }]);
                tableData.push([{ text: 'Accesorio:', style: 'tProductsBody', margin: [0, 0, 0, 0] }, { text: element.accessories, style: 'tProductsBody', margin: [0, 0, 0, 0] }]);
                tableData.push([{ text: 'Observaciones:', style: 'tProductsBody', margin: [0, 0, 0, 0] }, { text: element.observations, style: 'tProductsBody', margin: [0, 0, 0, 0] }]);
                if (element.model) {
                    tableData.push([{ text: 'Modelo:', style: 'tProductsBody', margin: [0, 0, 0, 0] }, { text: element.model, style: 'tProductsBody', margin: [0, 0, 0, 0] }]);
                }
                if (element.workCycle !== '') {
                    tableData.push([{ text: 'Siclo de trabajo:', style: 'tProductsBody', margin: [0, 0, 0, 0] }, { text: element.workCycle, style: 'tProductsBody', margin: [0, 0, 0, 0] }]);
                }
                if (element.inWarranty) {
                    tableData.push([{ text: 'GRARANTIA', style: 'textGaranty', margin: [0, 0, 0, 5] }, {}]);
                }
                tableData.push([{ text: "Tipo de Servicios:", style: 'titleTable', margin: [0, 0, 0, 0] }, {}]);
                element.serviceTypeDevices.forEach(item => {
                    tableData.push([{ text: item.serviceType.description, style: 'tProductsBody', margin: [0, 0, 0, 0] }, {}]);
                });
                // tableData.push([{ text: "Observaciones:", style: 'titleTable', margin: [0, 10, 0, 0] }, {}])
                // tableData.push([{ text: element.observations, style: 'tProductsBody', margin: [0, 0, 0, 0] }, {}])
                tableData.push([{ text: 'Monto Referencial:', style: 'tProductsBody', margin: [0, 10, 0, 0] }, { text: element.estimatedAmount.toString(), style: 'tProductsBody', margin: [0, 10, 0, 0] }]);
            });
        }
        else {
            tableData.push([{}, {}]);
        }
        const tablePaymentTypes = [];
        if (service.payments.length > 0) {
            service.payments.forEach(element => {
                tablePaymentTypes.push([
                    { text: element.paymentType.description + ": S/", style: 'tTotals', colSpan: 2 },
                    {},
                    { text: element.amount.toString(), style: 'tTotals', colSpan: 2 },
                    {}
                ]);
            });
        }
        let differences = 0;
        service.differences.forEach(element => {
            differences += 0; // parseFloat(element.amount.toString())
        });
        const statusCanChange = ![parameter_constant_1.StatusService.ENTREGADO, parameter_constant_1.StatusService.RECHAZADO].includes(service.state);
        const infoTicket = [];
        if (statusCanChange) {
            infoTicket.push([
                { text: 'MUY IMPORTANTE', style: 'important', margin: [0, 5, 0, 3] },
                { text: '-Evite cobros adicionales por concepto de almacenaje', style: 'message', },
                { text: '-Evite daños de componentes por tiempos guardados ', style: 'message' },
                { text: '-Evite que las tintas se dañen (solo aplica para Impresoras)', style: 'message' },
                { text: '-Evite daños fisicos por no recoger su producto ', style: 'message' },
                { text: 'Suportecc no se resonsabiliza por daños ocacionados despues de su reparacion o informe final.', style: 'important', margin: [0, 4, 0, 4] },
                { text: 'ACEPTO LAS CONDICONES MENCIONADAS', style: 'important', margin: [0, 3, 0, 30] },
                { text: '------------------------------------', style: 'text', margin: [0, 5, 0, 0] },
                { text: 'FIRMA', style: 'text', },
            ]);
        }
        //anticipo
        const tablePaymentTypesAdvance = [];
        let totalAdvance = 0;
        const advance = service.payments.filter(payment => payment.type === enum_1.TypeOperationPaymentService.Advance);
        if (service.payments.length > 0) {
            advance.forEach(element => {
                tablePaymentTypesAdvance.push([
                    { text: element.paymentType.description + ": S/", style: 'tTotals', colSpan: 2 },
                    {},
                    { text: element.amount.toString(), style: 'tTotals', colSpan: 2 },
                    {}
                ]);
                totalAdvance = Number(element.amount) + totalAdvance;
            });
        }
        // aumento
        const tablePaymentTypesIncrease = [];
        let totalIncrease = 0;
        const increase = service.serviceDevices.flatMap(device => device.serviceDeviceHistorys.filter(deviceHistory => deviceHistory.type === enum_1.TypeOperationDeviceHistory.Increase));
        totalIncrease = increase.reduce((current, total) => current + Number(total.adjustment), 0);
        //descuento
        let totalDiscount = 0;
        const discount = service.serviceDevices.flatMap(device => device.serviceDeviceHistorys.filter(deviceHistory => deviceHistory.type === enum_1.TypeOperationDeviceHistory.Discount));
        totalDiscount = discount.reduce((current, total) => current + Number(total.adjustment), 0);
        //devolucion
        let totalRepayment = 0;
        const repayment = service.serviceDevices.flatMap(device => device.serviceDeviceHistorys.filter(deviceHistory => deviceHistory.type === enum_1.TypeOperationDeviceHistory.Repayment));
        totalRepayment = repayment.reduce((current, total) => current + Number(total.adjustment), 0);
        // aumento
        if (increase.length > 0) {
            tablePaymentTypesIncrease.push([
                { text: 'SUBTOTAL' + ": S/", style: 'tTotals', colSpan: 2 },
                {},
                { text: `${((Number(service.totalAmount) + totalDiscount) - totalIncrease).toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
            tablePaymentTypesIncrease.push([
                { text: 'ADICIONAL' + ": S/", style: 'tTotals', colSpan: 2 },
                {},
                { text: `${totalIncrease.toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
            tablePaymentTypesIncrease.push([
                { text: '', style: 'tTotals', colSpan: 2 },
                {},
                { text: `${(Number(service.totalAmount) + totalDiscount).toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
        }
        // descuento
        const tablePaymentTypesDiscount = [];
        if (discount.length > 0) {
            tablePaymentTypesDiscount.push([
                { text: 'SUBTOTAL' + ": S/", style: 'tTotals', colSpan: 2 },
                {},
                { text: `${(Number(service.totalAmount) + totalDiscount).toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
            tablePaymentTypesDiscount.push([
                { text: 'DESCUENTO' + ": S/", style: 'tTotals', colSpan: 2 },
                {},
                { text: `-${totalDiscount.toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
            tablePaymentTypesDiscount.push([
                { text: 'Monto a pagar' + ": S/", style: 'tTotals', colSpan: 2 },
                {},
                { text: `${service.totalAmount}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
        }
        //repayment
        const tablePaymentTypesRepayment = [];
        if (repayment.length > 0) {
            tablePaymentTypesRepayment.push([
                { text: 'SUBTOTAL' + ": S/", style: 'tTotals', colSpan: 2 },
                {},
                { text: `${(totalAdvance).toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
            tablePaymentTypesRepayment.push([
                { text: 'DEVOLUCION' + ": S/", style: 'tTotals', colSpan: 2 },
                {},
                { text: `-${totalRepayment.toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
            tablePaymentTypesRepayment.push([
                { text: '', style: 'tTotals', colSpan: 2 },
                {},
                { text: `${(totalAdvance - totalRepayment).toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
        }
        //payment completion total
        const tablePaymentTypesCompletion = [];
        const completion = service.payments.filter(payment => payment.type === enum_1.TypeOperationPaymentService.completion);
        const totalCompletion = completion.reduce((total, payment) => total + Number(payment.amount), 0);
        if (completion.length > 0) {
            completion.forEach(element => {
                tablePaymentTypesCompletion.push([
                    { text: element.paymentType.description + ": S/", style: 'tTotals', colSpan: 2 },
                    {},
                    { text: element.amount.toString(), style: 'tTotals', colSpan: 2 },
                    {}
                ]);
            });
            tablePaymentTypesCompletion.push([
                { text: 'PAGO ACTUAL' + ": S/", style: 'tTotals', colSpan: 2 },
                {},
                { text: `${totalCompletion.toFixed(2)}`, style: 'tTotals', colSpan: 2 },
                {}
            ]);
        }
        const totalPaymentService = (totalCompletion + totalAdvance);
        data = [
            { text: campus.name, style: 'header', margin: [0, 5, 0, 0] },
            { text: campus.address, style: 'header' },
            { text: 'RUC: ' + company.ruc, style: 'header' },
            { text: 'CEL: ' + campus.phone, style: 'header' },
            //TIPO Y NUMERO DOCUMENTO
            { text: 'TIKET SERVICIO', style: 'header', margin: [0, 5, 0, 2] },
            { text: service.serviceId.toString().padStart(5, '0'), style: 'header', margin: [0, 2, 0, 0] },
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['25%', '35%', '15%', '25%'],
                    body: [
                        [
                            { text: 'FECHA:', style: 'tHeaderLabel' },
                            { text: (0, moment_1.default)(service.registrationDate).format('L'), style: 'tHeaderValue' },
                            { text: 'HORA:', style: 'tHeaderLabel' },
                            { text: (0, moment_1.default)(service.registrationDate).format('HH:mm:ss'), style: 'tHeaderValue' },
                        ],
                        [
                            { text: 'SERVICIO:', style: 'tHeaderLabel' },
                            { text: service.serviceId.toString().padStart(5, '0'), style: 'tHeaderValue', colSpan: 3 },
                            {},
                            {},
                        ],
                        [
                            { text: 'CEL:', style: 'tHeaderLabel' },
                            { text: service.client ? service.client.phone : '999999999', style: 'tHeaderValue', colSpan: 3 },
                            {},
                            {},
                        ],
                        [
                            { text: 'RECEPCIÓN:', style: 'tHeaderLabel' },
                            { text: service.userReception.name + ' ' + service.userReception.fullname, style: 'tHeaderValue', colSpan: 3 },
                            {},
                            {},
                        ],
                        [
                            { text: 'TECNICO:', style: 'tHeaderLabel' },
                            { text: service.userTechnical ? service.userTechnical.name + ' ' + service.userTechnical.fullname : 'No Aplica', style: 'tHeaderValue', colSpan: 3 },
                            {},
                            {},
                        ],
                        [
                            { text: 'CLIENTE:', style: 'tHeaderLabel' },
                            { text: service.client ? service.client.fullname : 'No aplica', style: 'tHeaderValue' },
                            { text: 'DNI:', style: 'tHeaderLabel' },
                            { text: service.client ? service.client.documentNumber : 'No aplica', style: 'tHeaderValue' },
                        ],
                    ],
                },
                layout: 'noBorders',
            },
            { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0] },
            // ** TABLA PRODUCTOS            
            {
                margin: [0, 0, 0, 0],
                table: {
                    widths: ['40%', '60%'],
                    body: tableData,
                },
                layout: 'noBorders',
            },
            { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0] },
            {
                margin: [0, 0, 0, 0],
                table: {
                    widths: ['25%', '35%', '15%', '25%'],
                    body: [
                        //ANTICIPO O ADELANTO
                        advance.length > 0 ?
                            [
                                { text: 'ADELANTO', style: 'tTotals', colSpan: 2 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        advance.length > 0 ?
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: tablePaymentTypesAdvance
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ] : [{}, {}, {}, {}],
                        advance.length > 0 ?
                            [
                                { text: 'Adelanto o Anticipo: S/', style: 'tTotals', colSpan: 2 },
                                {},
                                { text: totalAdvance.toFixed(2), style: 'tTotals', colSpan: 2 },
                                {},
                            ] : [{}, {}, {}, {}],
                        advance.length > 0 ?
                            [
                                { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0], colSpan: 4 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        //AUMENTO
                        increase.length > 0 ?
                            [
                                { text: 'AUMENTO', style: 'tTotals', colSpan: 2 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        increase.length > 0 ?
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: tablePaymentTypesIncrease
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ] : [{}, {}, {}, {}],
                        increase.length > 0 ?
                            [
                                { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0], colSpan: 4 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        //DESCUENTO
                        discount.length > 0 ?
                            [
                                { text: 'DESCUENTO', style: 'tTotals', colSpan: 2 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        discount.length > 0 ?
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: tablePaymentTypesDiscount
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ] : [{}, {}, {}, {}],
                        discount.length > 0 ?
                            [
                                { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0], colSpan: 4 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        //DEVOLUCION
                        repayment.length > 0 ?
                            [
                                { text: 'DEVOLUCION', style: 'tTotals', colSpan: 2 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        repayment.length > 0 ?
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: tablePaymentTypesRepayment
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ] : [{}, {}, {}, {}],
                        repayment.length > 0 ?
                            [
                                { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0], colSpan: 4 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        //completion
                        completion.length > 0 ?
                            [
                                { text: 'PAGO ACTUAL', style: 'tTotals', colSpan: 2 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        completion.length > 0 ?
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: tablePaymentTypesCompletion
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ] : [{}, {}, {}, {}],
                        completion.length > 0 ?
                            [
                                { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0], colSpan: 4 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        totalPaymentService > 0 ?
                            [
                                { text: 'TOTAL PAGADO', style: 'tTotals', colSpan: 2 },
                                {},
                                { text: `${totalPaymentService - totalRepayment}`, style: 'tTotals', colSpan: 2 },
                                {}
                            ] : [{}, {}, {}, {}],
                        totalPaymentService > 0 ?
                            [
                                { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0], colSpan: 4 },
                                {},
                                {},
                                {}
                            ] : [{}, {}, {}, {}],
                        //TOTALES
                        // [
                        //     { text: 'SUBTOTAL: S/', style: 'tTotals', colSpan: 2 },
                        //     {},
                        //     { text: service.totalAmount, style: 'tTotals', colSpan: 2 },
                        //     {},
                        // ],
                        // [
                        //     { text: 'DEVOLUCION: S/', style: 'tTotals', colSpan: 2 },
                        //     {},
                        //     { text: totalRepayment.toFixed(2), style: 'tTotals', colSpan: 2 },
                        //     {},
                        // ],
                        // service.type === TypeService.detail ?
                        //     [
                        //         { text: 'ANTICIPO: S/', style: 'tTotals', colSpan: 2 },
                        //         {},
                        //         { text: totalAdvance.toFixed(2), style: 'tTotals', colSpan: 2 },
                        //         {},
                        //     ] : [{}, {}, {}, {}],
                        // service.type === TypeService.detail ?
                        //     [
                        //         { text: 'DEBE: S/', style: 'tTotals', colSpan: 2 },
                        //         {},
                        //         { text: (service.totalAmount - amountAdvance - totalRepayment).toFixed(2), style: 'tTotals', colSpan: 2 },
                        //         {},
                        //     ] : [{}, {}, {}, {}],
                        // [
                        //     { text: 'TOTAL A PAGAR: S/', style: 'tTotals', colSpan: 2 },
                        //     {},
                        //     { text: (service.totalAmount - differences).toFixed(2), style: 'tTotals', colSpan: 2 },
                        //     {},
                        // ],
                        // service.type === TypeService.detail ?
                        //     [
                        //         { text: 'TOTAL A PAGAR: S/', style: 'tTotals', colSpan: 2 },
                        //         {},
                        //         { text: (service.totalAmount - amountAdvance - totalRepayment).toFixed(2), style: 'tTotals', colSpan: 2 },
                        //         {},
                        //     ] :
                        //     [
                        //         { text: 'TOTAL A PAGAR: S/', style: 'tTotals', colSpan: 2 },
                        //         {},
                        //         { text: parseFloat(service.totalAmount.toString()).toFixed(2), style: 'tTotals', colSpan: 2 },
                        //         {},
                        //     ]
                    ],
                },
                layout: 'noBorders',
            },
            // // ** FORMAS DE PAGO
            // { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0] },
            // { text: 'FORMAS DE PAGO', style: 'header', margin: [0, 0, 0, 0] },
            // {
            //     margin: [0, 0, 0, 0],
            //     table: {
            //         widths: ['25%', '35%', '15%', '25%'],
            //         body: tablePaymentTypes
            //     },
            //     layout: 'noBorders',
            // },
            // {
            //     margin: [4, 0, 0, 0],
            //     table: {
            //         widths: ['25%', '35%', '15%', '25%'],
            //         body: [[
            //             { text: 'TOTAL A PAGAR: S/', style: 'tTotals', colSpan: 2 },
            //             {},
            //             { text: (service.totalAmount - amountAdvance - differences).toFixed(2), style: 'tTotals', colSpan: 2 },
            //             {},
            //         ]]
            //     }
            // },
            //NOTA DE PIE
            serviceStatusService ?
                {
                    text: `Fecha de Entrega: ${(0, moment_1.default)(serviceStatusService.dateChanged).format("L")} Hora: ${(0, moment_1.default)(serviceStatusService.dateChanged).format("LT")}`,
                    style: 'tHeaderValue',
                    alignment: 'justify',
                    margin: [0, 5],
                } : {},
            {
                text: 'Gracias por elegir nuestro soporte técnico. Estamos aquí para ayudarte en lo que necesites.',
                style: 'text',
                alignment: 'justify',
                margin: [0, 5],
            },
            //QR FACTURA
            {
                stack: [
                    {
                        qr: company.ruc,
                        fit: 115,
                        alignment: 'center',
                        eccLevel: 'Q',
                        margin: [0, 10, 0, 3],
                    },
                    {
                        text: 'Representación impresa del comprobante original. Consulta tu comprobante aquí:',
                        style: 'text',
                    },
                ],
            },
            {
                stack: [
                    {
                        image: generateBarcodeAsBase64(service.serviceId.toString(), 100, 80),
                        width: 70, // Ancho deseado
                        height: 25, // Mantenemos la altura original
                        alignment: 'center',
                        margin: [3, 14, 0, 3],
                    },
                ],
                width: '30%',
                margin: [3, 0, 0, 3]
            },
            ...infoTicket,
            // { text: 'MUY IMPORTANTE', style: 'important', margin: [0, 5, 0, 3] },
            // { text: '-Evite cobros adicionales por concepto de almacenaje', style: 'message', },
            // { text: '-Evite daños de componentes por tiempos guardados ', style: 'message' },
            // { text: '-Evite que las tintas se dañen (solo aplica para Impresoras)', style: 'message' },
            // { text: '-Evite daños fisicos por no recoger su producto ', style: 'message' },
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentPdf = ContentPdf;
//# sourceMappingURL=content.js.map