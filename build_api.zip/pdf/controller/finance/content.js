"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentPdf = exports.fetchAndConvertToBase64 = void 0;
const axios_1 = __importDefault(require("axios"));
const moment_1 = __importDefault(require("moment"));
const convertdata_utils_1 = require("../../utils/convertdata.utils");
const fetchAndConvertToBase64 = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axios_1.default.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 5000
        });
        const base64Image = Buffer.from(response.data, 'binary').toString('base64');
        return base64Image;
    }
    catch (error) {
        return null;
    }
});
exports.fetchAndConvertToBase64 = fetchAndConvertToBase64;
const ContentPdf = (finance, campus, company) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let data = [];
        const tableData = [
            [
                {},
                { text: 'TIPOS DE PAGO: ', style: 'tHeaderValue', alignment: 'left' }
            ],
        ];
        if (finance.paymentTransaction.length > 0) {
            finance.paymentTransaction.forEach(item => {
                tableData.push([
                    {},
                    { text: `${item.paymentType.description.toUpperCase()}: S/.${item.amount}`, style: 'tHeaderValue', alignment: 'right' }
                ]);
            });
        }
        tableData.push([
            {},
            { text: `TOTAL: S/.${(0, convertdata_utils_1.getPayments)(finance.paymentTransaction).toFixed(2)}`, style: 'tHeaderValue', alignment: 'right' }
        ]);
        const date = new Date(finance.deliverDate.toString());
        data = [
            { text: company.name.toUpperCase(), style: 'tHeaderValue', margin: [0, 5, 0, 0], alignment: 'center' },
            { text: 'TICKET TRANSACCIÓN', style: 'tHeaderValue', margin: [0, 5, 0, 2], alignment: 'center' },
            { text: finance.financeId.toString().padStart(5, '0'), style: 'tHeaderValue', margin: [0, 2, 0, 0], alignment: 'center' },
            { text: `SEDE: ${campus.name.toUpperCase()}`, style: 'tHeaderValue', margin: [0, 8, 0, 0], alignment: 'left' },
            { text: `DIRECCIÓN: ${campus.address.toUpperCase()}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0] },
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['25%', '30%', '20%', '25%'],
                    body: [
                        [
                            { text: 'FECHA:', style: 'tHeaderLabel' },
                            { text: (0, moment_1.default)(date).format('L'), style: 'tHeaderValue' },
                            { text: 'HORA:', style: 'tHeaderLabel' },
                            { text: (0, moment_1.default)(date).format('HH:mm:ss'), style: 'tHeaderValue' },
                        ],
                    ],
                },
                layout: {
                    hLineWidth: (i, node) => {
                        return (i === 0) ? 1 : 0;
                    },
                    vLineWidth: (i, node) => {
                        return 0;
                    },
                    hLineColor: (i, node) => {
                        return '#000000';
                    },
                },
            },
            // ** TABLA TRANSACCION
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['35%', '30%', '15%', '20%'],
                    body: [
                        [
                            { text: 'TRANSACCIÓN:', style: 'tHeaderLabel' },
                            { text: `${finance.financeId.toString().padStart(5, '0').toUpperCase()}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {},
                        ],
                        [
                            { text: 'TIPO DE OPERACION:', style: 'tHeaderLabel' },
                            { text: `${finance.typeOperation.toUpperCase()}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {}
                        ],
                        [
                            { text: 'TIPO DE TRANSACCIÓN:', style: 'tHeaderLabel' },
                            { text: `${finance.typeTransaction.description.toUpperCase()}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {}
                        ],
                        [
                            { text: 'DETALLES:', style: 'tHeaderLabel' },
                            { text: `${finance.details.toUpperCase()}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {}
                        ],
                        [
                            { text: 'RESPONSABLE:', style: 'tHeaderLabel' },
                            { text: `${finance.user.name.toUpperCase() + ' ' + finance.user.fullname.toUpperCase()}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {}
                        ]
                    ],
                },
                layout: {
                    hLineWidth: (i, node) => {
                        return (i === 0 || i === 5) ? 1 : 0;
                    },
                    vLineWidth: (i, node) => {
                        return 0;
                    },
                    hLineColor: (i, node) => {
                        return '#000000';
                    },
                },
            },
            //TABLE PAYMENT
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['50%', '*'],
                    body: tableData
                },
                layout: 'noBorders'
            },
            { text: '--------------------', style: 'header', margin: [0, 15, 0, 0], alignment: 'center' },
            { text: 'FIRMA', style: 'header', margin: [0, 0, 0, 0], alignment: 'center' },
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentPdf = ContentPdf;
//# sourceMappingURL=content.js.map