"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LatoFont = exports.FontAwesome = exports.Roboto = void 0;
const path_1 = __importDefault(require("path"));
const fs = __importStar(require("fs"));
const vfsFonts = __importStar(require("pdfmake/build/vfs_fonts"));
exports.Roboto = {
    normal: Buffer.from(vfsFonts.pdfMake.vfs['Roboto-Regular.ttf'], 'base64'),
    bold: Buffer.from(vfsFonts.pdfMake.vfs['Roboto-Medium.ttf'], 'base64'),
    italics: Buffer.from(vfsFonts.pdfMake.vfs['Roboto-Italic.ttf'], 'base64'),
    bolditalics: Buffer.from(vfsFonts.pdfMake.vfs['Roboto-MediumItalic.ttf'], 'base64'),
};
const fontAwesomePath = path_1.default.join(__dirname, 'font', 'fontawesome-webfont.ttf');
const fontAwesomeBuffer = fs.readFileSync(fontAwesomePath);
exports.FontAwesome = {
    normal: fontAwesomeBuffer
};
const rutaNormal = path_1.default.join(__dirname, 'font', 'lato', 'Lato-Regular.ttf');
const rutaNegrita = path_1.default.join(__dirname, 'font', 'lato', 'Lato-Bold.ttf');
const rutaCursiva = path_1.default.join(__dirname, 'font', 'lato', 'Lato-Italic.ttf');
const rutaNegritaCursiva = path_1.default.join(__dirname, 'font', 'lato', 'Lato-BoldItalic.ttf');
const normalBuffer = fs.readFileSync(rutaNormal);
const boldBuffer = fs.readFileSync(rutaNegrita);
const italicBuffer = fs.readFileSync(rutaCursiva);
const boldItalicBuffer = fs.readFileSync(rutaNegritaCursiva);
exports.LatoFont = {
    normal: normalBuffer,
    bold: boldBuffer,
    italics: italicBuffer,
    bolditalics: boldItalicBuffer
};
//# sourceMappingURL=roboto.js.map