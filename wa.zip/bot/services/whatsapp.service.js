"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.whatsappService = void 0;
const whatsapp_web_js_1 = require("whatsapp-web.js");
const store_service_1 = require("../../session/services/store.service");
const log_helper_1 = require("../../core/helpers/log.helper");
const webSocketService_1 = __importDefault(require("../../socket/webSocketService"));
/**
 * Extendemos los super poderes de whatsapp-web
 */
class WhatsappService {
    static getInstance() {
        if (!this.instance)
            this.instance = new WhatsappService();
        return this.instance;
    }
    constructor() {
        this.clients = new Map();
        this.generateImage = (base64, clietId) => __awaiter(this, void 0, void 0, function* () {
            // const path = `${process.cwd()}/tmp`;
            // let qr_svg = imageQr(base64, { type: "svg", margin: 4 });
            // qr_svg.pipe(require("fs").createWriteStream(`${path}/${clietId}.svg`));
            // const qrSvg = await toString(base64, { type: 'svg', margin: 4 });
            this.webSocketService.waGenerateQR(clietId, base64);
        });
        this.webSocketService = new webSocketService_1.default();
    }
    connect(clientId) {
        return __awaiter(this, void 0, void 0, function* () {
            const store = new store_service_1.Store();
            const client = new whatsapp_web_js_1.Client({
                authStrategy: new whatsapp_web_js_1.RemoteAuth({
                    store: store,
                    clientId: clientId,
                    dataPath: 'session',
                    backupSyncIntervalMs: 300000
                }),
                puppeteer: {
                    headless: true,
                    args: ['--no-sandbox']
                },
                // webVersionCache:
                // {
                //     remotePath: 'https://raw.githubusercontent.com/wppconnect-team/wa-version/main/html/2.2402.5-beta.html',
                //     type: 'remote'
                // }
                webVersionCache: {
                    type: 'remote',
                    remotePath: 'https://raw.githubusercontent.com/wppconnect-team/wa-version/main/html/2.2410.1.html',
                }
            });
            client.on('ready', () => {
                log_helper_1.logger.info(`Client ${clientId} is ready!`);
                this.webSocketService.waReady(clientId);
            });
            client.on('authenticated', () => {
                log_helper_1.logger.info(`Client ${clientId} is authenticated!`);
                this.webSocketService.waAuthenticated(clientId);
            });
            client.on('loading_screen', (percent, message) => {
                this.webSocketService.waLoadingScreen(clientId);
                log_helper_1.logger.info(`porcent: ${percent} message: ${message}`);
            });
            client.on('qr', qr => {
                this.generateImage(qr, clientId);
                log_helper_1.logger.info(`Generating QR for ${clientId}`);
            });
            client.on('disconnected', qr => {
                this.webSocketService.waDisconnected(clientId);
                this.clients.delete(clientId);
                log_helper_1.logger.info(`Disconnected ${clientId}`);
            });
            client.on('remote_session_saved', () => {
                log_helper_1.logger.info(`Remote saved to ${clientId}!`);
                this.webSocketService.waRemoteSessionSaved(clientId);
            });
            try {
                yield client.initialize();
                this.clients.set(clientId, client);
                return ({ success: true, message: `${clientId} is authenticated!` });
            }
            catch (error) {
                log_helper_1.logger.error(`Error connecting client ${clientId}: ${error.message}`);
                return ({ success: false, message: error.message });
            }
        });
    }
    getSessionClient(clientId) {
        const client = this.clients.get(clientId);
        if (!client) {
            log_helper_1.logger.error(`Client not found: ${clientId}`);
            return null;
        }
        return client;
    }
    logout(clientId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = this.getSessionClient(clientId);
            if (!client)
                return false;
            try {
                yield client.logout();
                this.clients.delete(clientId);
                log_helper_1.logger.info(`Session closed successfully for client: ${clientId}`);
                return true;
            }
            catch (error) {
                log_helper_1.logger.error(`Error closing session for client ${clientId}: ${error.message}`);
                return false;
            }
        });
    }
    sendMsgText(message) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const client = this.getSessionClient(message.clientId);
                if (!client) {
                    return { message: "Client not found", success: false };
                }
                const isUserExist = yield client.isRegisteredUser(message.phone);
                if (!isUserExist) {
                    return { message: "Unregistered customer", success: false };
                }
                const response = yield client.sendMessage(`${message.phone}@c.us`, message.message);
                return { waId: response.id, success: true };
            }
            catch (error) {
                log_helper_1.logger.error(`Error getting session for client ${message.clientId}: ${error.message}`);
                return { message: error.message, success: false };
            }
        });
    }
    sendMsgFile(message) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const client = this.getSessionClient(message.clientId);
                if (!client) {
                    return { message: "Client not found", success: false };
                }
                const media = new whatsapp_web_js_1.MessageMedia(message.mimetype, message.file, "document");
                const messageOption = {
                    media
                };
                const isUserExist = yield client.isRegisteredUser(message.phone);
                if (!isUserExist) {
                    return { message: "Unregistered customer", success: false };
                }
                const response = yield client.sendMessage(`${message.phone}@c.us`, message.message, messageOption);
                return { waId: response.id, success: true };
            }
            catch (error) {
                log_helper_1.logger.error(`Error getting session for client ${message.clientId}: ${error.message}`);
                return { message: error.message, success: false };
            }
        });
    }
}
exports.whatsappService = WhatsappService.getInstance();
//# sourceMappingURL=whatsapp.service.js.map