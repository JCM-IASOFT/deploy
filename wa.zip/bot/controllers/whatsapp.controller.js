"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.whatsappController = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const path = __importStar(require("path"));
const http_status_codes_1 = require("http-status-codes");
const log_helper_1 = require("../../core/helpers/log.helper");
const whatsapp_service_1 = require("../services/whatsapp.service");
class WhatsappController {
    constructor() {
        this.sendMsgFileCtrl = (_a, res_1) => __awaiter(this, [_a, res_1], void 0, function* ({ body, file }, res) {
            try {
                const { message, phone, clientId } = body;
                const uploadedFile = file;
                const fileBuffer = uploadedFile.path;
                const imageBuffer = fs_extra_1.default.readFileSync(fileBuffer);
                const base64Image = imageBuffer.toString('base64');
                const messageModel = {
                    clientId: clientId,
                    message: message,
                    phone: phone,
                    file: base64Image,
                    mimetype: file.mimetype
                };
                const response = yield whatsapp_service_1.whatsappService.sendMsgFile(messageModel);
                if (response.success) {
                    res.status(http_status_codes_1.StatusCodes.OK).json(response);
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json(response);
                }
            }
            catch (error) {
                log_helper_1.logger.error(`Error in sendMsgFileCtrl: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ message: 'Internal Server Error', success: false });
            }
        });
        this.connect = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { clientId } = req.body;
            try {
                const response = yield whatsapp_service_1.whatsappService.connect(clientId);
                const status = response.success ? http_status_codes_1.StatusCodes.OK : http_status_codes_1.StatusCodes.BAD_REQUEST;
                return res.status(status).json(response);
            }
            catch (error) {
                log_helper_1.logger.error(`Error in connect: ${error.message}`);
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ message: 'Internal Server Error', success: false });
            }
        });
        this.sendMsgTextCtrl = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const message = req.body;
            try {
                const response = yield whatsapp_service_1.whatsappService.sendMsgText(message);
                if (response.success) {
                    res.status(http_status_codes_1.StatusCodes.OK).json(response);
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json(response);
                }
            }
            catch (error) {
                log_helper_1.logger.error(`Error in sendMsgTextCtrl: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ message: 'Internal Server Error', success: false });
            }
        });
        this.getSessionClient = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { clientId } = req.query;
            try {
                const response = whatsapp_service_1.whatsappService.getSessionClient(clientId);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json(response.info);
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json(response);
                }
            }
            catch (error) {
                log_helper_1.logger.error(`Error in getSessionClient: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ message: 'Internal Server Error', success: false });
            }
        });
        this.logout = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { clientId } = req.body;
                const response = yield whatsapp_service_1.whatsappService.logout(clientId);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json(response);
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.NOT_FOUND).json(response);
                }
            }
            catch (error) {
                log_helper_1.logger.error(`Error in logout: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ message: 'Internal Server Error', success: false });
            }
        });
        // public getStatus = async (req: Request, res: Response) => {
        //     const whatsappServices = new WhatsappService('juan');
        //     const response = whatsappServices.getStatus()
        //     res.send(response);
        // };
        this.qrCtrl = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { clientId } = req.query;
            const filePath = path.resolve(process.cwd(), 'tmp', `${clientId}.svg`);
            if (!fs_extra_1.default.existsSync(filePath)) {
                return res.status(404).send('File not found');
            }
            res.setHeader('Content-Type', 'image/svg+xml');
            res.sendFile(filePath, (err) => {
                if (err) {
                    res.status(500).send('Error while sending the file');
                }
            });
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new WhatsappController();
        return this.instance;
    }
}
exports.whatsappController = WhatsappController.getInstance();
//# sourceMappingURL=whatsapp.controller.js.map