"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.whatsappRoute = void 0;
const express_1 = require("express");
const whatsapp_controller_1 = require("../controllers/whatsapp.controller");
const multer_helper_1 = require("../../core/helpers/multer.helper");
exports.whatsappRoute = (0, express_1.Router)();
exports.whatsappRoute.post('/text', whatsapp_controller_1.whatsappController.sendMsgTextCtrl);
exports.whatsappRoute.post('/connect', whatsapp_controller_1.whatsappController.connect);
exports.whatsappRoute.post('/file', multer_helper_1.upload.single('file'), whatsapp_controller_1.whatsappController.sendMsgFileCtrl);
exports.whatsappRoute.get('/client', whatsapp_controller_1.whatsappController.getSessionClient);
exports.whatsappRoute.post('/logout', whatsapp_controller_1.whatsappController.logout);
exports.whatsappRoute.get('/qr', whatsapp_controller_1.whatsappController.qrCtrl);
//# sourceMappingURL=whatsapp.router.js.map