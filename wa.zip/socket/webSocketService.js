"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const connection_1 = require("./connection"); // Importa la instancia de Socket.IO
class WebSocketService {
    emitToClient(clientId, eventName, data) {
        const client = connection_1.clientConnections.find(client => client.clientId === clientId);
        if (client) {
            const socket = connection_1.io.sockets.sockets.get(client.socketId);
            if (socket) {
                socket.emit(eventName, data);
            }
        }
    }
    waClientSession(clientId, client) {
        this.emitToClient(clientId, "WAClientSessionResponse", client ? client.info : null);
    }
    waReady(clientId) {
        this.emitToClient(clientId, "WAReady", `Ready by ${clientId}`);
    }
    waAuthenticated(clientId) {
        this.emitToClient(clientId, "WAAuthenticated", `Authenticated by ${clientId}`);
    }
    waLoadingScreen(clientId) {
        this.emitToClient(clientId, "WALoadingScreen", `Loading screen by ${clientId}`);
    }
    waDisconnected(clientId) {
        this.emitToClient(clientId, "WADisconnected", `Disconnected ${clientId}`);
    }
    waRemoteSessionSaved(clientId) {
        this.emitToClient(clientId, "WARemoteSessionSaved", `Remote session save ${clientId}`);
    }
    waGenerateQR(clientId, qr) {
        this.emitToClient(clientId, "WAGenerateQR", qr);
    }
    DEMO(eventName, message) {
        connection_1.io.emit(eventName, message);
    }
    sendMessage(clientId) {
        this.emitToClient(clientId, "WAMessage", clientId);
    }
    emitCustomEvent(eventName, data) {
        connection_1.io.emit(eventName, data);
    }
    // Emitir un mensaje a un socket específico usando su socketId
    emitToSocket(socketId, eventName, data) {
        const socket = connection_1.io.sockets.sockets.get(socketId);
        if (socket) {
            socket.emit(eventName, data);
        }
    }
}
exports.default = WebSocketService;
//# sourceMappingURL=webSocketService.js.map