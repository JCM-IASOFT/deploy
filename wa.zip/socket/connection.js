"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientConnections = exports.io = exports.initializeSocketServer = void 0;
// sockets/socketServer.ts
const socket_io_1 = require("socket.io");
const webSocketHandler_1 = __importDefault(require("./webSocketHandler"));
let io;
const clientConnections = [];
exports.clientConnections = clientConnections;
const webEvent = new webSocketHandler_1.default();
const initializeSocketServer = (server) => {
    exports.io = io = new socket_io_1.Server(server, { cors: { origin: "*" } });
    io.on('connection', (socket) => {
        socket.on("authenticate", (data) => __awaiter(void 0, void 0, void 0, function* () {
            const { clientId, authToken } = data;
            clientConnections.push({
                clientId: clientId,
                socketId: socket.id
            });
            const userAuthenticated = authToken;
            if (!userAuthenticated) {
                socket.emit("authenticationFailed", { error: "Authentication failed" });
                return;
            }
            socket.emit("IOAuthentication");
        }));
        webEvent.handleSocketEvents(socket);
        socket.on('disconnect', () => {
            const index = clientConnections.findIndex(client => client.socketId === socket.id);
            if (index !== -1) {
                clientConnections.splice(index, 1);
            }
        });
    });
};
exports.initializeSocketServer = initializeSocketServer;
//# sourceMappingURL=connection.js.map