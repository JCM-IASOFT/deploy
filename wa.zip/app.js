"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createApp = void 0;
// app.ts
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const whatsapp_router_1 = require("./bot/routes/whatsapp.router");
const session_router_1 = require("./session/routes/session.router");
const createApp = () => {
    const app = (0, express_1.default)();
    app.use((0, cors_1.default)());
    app.use(express_1.default.json());
    app.use('/tmp', express_1.default.static('tmp'));
    app.use(`/whatsApp`, whatsapp_router_1.whatsappRoute);
    app.use(`/session`, session_router_1.sessionRoute);
    return app;
};
exports.createApp = createApp;
//# sourceMappingURL=app.js.map