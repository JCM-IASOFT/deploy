"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionRoute = void 0;
const express_1 = require("express");
const session_controller_1 = require("../controllers/session.controller");
exports.sessionRoute = (0, express_1.Router)();
exports.sessionRoute.get('/', session_controller_1.sessionController.getSessionCtrl);
//# sourceMappingURL=session.router.js.map