"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Store = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const models_1 = require("models");
class Store {
    sessionExists(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const existingSession = yield models_1.SessionModel.findOne({ where: { session: options.session } });
            console.log(existingSession);
            return !!existingSession;
        });
    }
    streamToBuffer(stream) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                const chunks = [];
                stream.on('data', (chunk) => chunks.push(chunk)); // Asegúrate de que chunk sea Buffer
                stream.on('error', reject);
                stream.on('end', () => resolve(Buffer.concat(chunks)));
            });
        });
    }
    save(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const fileStream = fs_extra_1.default.createReadStream(`${options.session}.zip`);
            const fileData = yield this.streamToBuffer(fileStream);
            const sessionModel = {
                session: options.session,
                data: fileData,
            };
            const response = yield models_1.SessionModel.save(sessionModel);
            if (response) {
                yield this.deletePrevious(options);
            }
        });
    }
    extract(options) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const existingSession = yield models_1.SessionModel.findOne({ where: { session: options.session } });
                if (existingSession) {
                    fs_extra_1.default.writeFileSync(options.path, existingSession.data);
                    console.log(`Archivo extraído y guardado en ${options.path}`);
                }
            }
            catch (error) {
                console.error('Error al extraer la sesión:', error);
                throw error;
            }
        });
    }
    delete(options) {
        return __awaiter(this, void 0, void 0, function* () {
            yield models_1.SessionModel.delete({ session: options.session });
        });
    }
    deletePrevious(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const sessions = yield models_1.SessionModel.find({ where: { session: options.session } });
            if (sessions.length > 1) {
                const oldSession = sessions.reduce((a, b) => a.createdBy < b.createdBy ? a : b);
                yield models_1.SessionModel.delete({ session: oldSession.session });
            }
        });
    }
}
exports.Store = Store;
//# sourceMappingURL=store.service.js.map