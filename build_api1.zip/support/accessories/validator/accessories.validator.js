"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteAccessory = exports.validateUpdateAccessory = exports.validateCreateAccessory = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateAccessory = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateAccessory = [
    (0, express_validator_1.check)('accessoryId').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteAccessory = [
    (0, express_validator_1.check)('accessoryId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=accessories.validator.js.map