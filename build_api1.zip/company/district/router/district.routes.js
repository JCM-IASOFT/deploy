"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.districtRoute = void 0;
const express_1 = require("express");
const district_controller_1 = require("../controller/district.controller");
exports.districtRoute = (0, express_1.Router)();
exports.districtRoute.get('/findAllD', district_controller_1.districtController.findDistrictDatatable);
exports.districtRoute.get('/findAll', district_controller_1.districtController.findDistrict);
exports.districtRoute.get('/province', district_controller_1.districtController.findDistrictByProvince);
//# sourceMappingURL=district.routes.js.map