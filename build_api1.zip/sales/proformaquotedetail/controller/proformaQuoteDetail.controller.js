"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaQuoteDetailController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const proformaQuoteDetail_service_1 = require("../service/proformaQuoteDetail.service");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
class ProformaQuoteDetailController {
    constructor() {
        this.findProformaQuoteDetail = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { proformaQuoteId } = req.query;
            const proformaQuoteDetails = yield proformaQuoteDetail_service_1.proformaQuoteDetailService.findProformaQuoteDetail(Number(proformaQuoteId));
            res.status(http_status_codes_1.StatusCodes.OK).json(proformaQuoteDetails);
        });
        this.updateProformaQuoteDetail = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { proformeQuoteDetails } = req.body;
                    if (!Array.isArray(proformeQuoteDetails) || !Array.isArray(proformeQuoteDetails)) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        yield Promise.all(proformeQuoteDetails.map((proforma) => proformaQuoteDetail_service_1.proformaQuoteDetailService.createProformaQuoteDetail(proforma, queryRunner)));
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.SALES_SUCCESS };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ProformaQuoteDetailController();
        return this.instance;
    }
}
exports.proformaQuoteDetailController = ProformaQuoteDetailController.getInstance();
//# sourceMappingURL=proformaQuoteDetail.controller.js.map