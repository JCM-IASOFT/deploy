"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesFreeService = void 0;
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
class SalesFreeService {
    static getInstance() {
        if (!this.instance)
            this.instance = new SalesFreeService();
        return this.instance;
    }
    findSalesFrees(salesId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const salesDetails = yield modelslibrary_1.SalesFreeModel.find({ where: { salesId: salesId, deletedAt: '0' } });
                return salesDetails;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    createSalesFree(salesFree, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const salesFreeEntity = modelslibrary_1.SalesFreeModel.create(salesFree);
                const response = yield queryRunner.manager.save(salesFreeEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.salesFreeService = SalesFreeService.getInstance();
//# sourceMappingURL=salesdetail.service.js.map