"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesController = void 0;
const http_status_codes_1 = require("http-status-codes");
const sales_service_1 = require("../service/sales.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const salesdetail_service_1 = require("../../salesdetail/service/salesdetail.service");
const paymentsales_service_1 = require("../../paymentsales/service/paymentsales.service");
const modelslibrary_1 = require("modelslibrary");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const credit_service_1 = require("../../../credit/credit/service/credit.service");
const creditSchedule_service_1 = require("../../../credit/creditSchedule/service/creditSchedule.service");
const creditAdvance_service_1 = require("../../../credit/creditAdvance/service/creditAdvance.service");
const proformaquote_service_1 = require("../../proformaquote/service/proformaquote.service");
const stateproforma_enum_1 = require("../../../common/enum/stateproforma.enum");
const invoiceSerie_service_1 = require("../../../logistics/invoiceSerie/service/invoiceSerie.service");
const salesdetail_service_2 = require("../../salesFree/service/salesdetail.service");
class SalesController {
    constructor() {
        this.findSales = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const saless = yield sales_service_1.salesService.findSales(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(saless);
        });
        this.findAllSales = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { salesfilter, page, sizePage } = req.body;
            const findSales = yield sales_service_1.salesService.findAllSales(salesfilter, Number(page), Number(sizePage));
            const sales = findSales ? findSales.sales : [];
            const total = findSales ? findSales.total : 0;
            res.status(http_status_codes_1.StatusCodes.OK).json({
                data: sales,
                draw: Math.random(),
                recordsFiltered: sales.length,
                recordsTotal: total,
            });
        });
        this.findOneSales = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { salesId } = req.query;
            const saless = yield sales_service_1.salesService.findOneSales(Number(salesId));
            res.status(http_status_codes_1.StatusCodes.OK).json(saless);
        });
        /**
       * Crea un crédito de ventas basado en la información proporcionada en la solicitud.
       *
       * @param req - La solicitud HTTP, que contiene los datos necesarios para crear el crédito de ventas.
       * @param res - La respuesta HTTP, que se utilizará para enviar de vuelta el resultado de la operación.
       */
        this.createSalesCredit = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { sales, salesDetails, salesFrees, credit, creditAdvances, creditSchedules, invoiceSerie } = req.body;
                    let salesId = 0;
                    if (!sales || !Array.isArray(salesDetails) || !Array.isArray(creditSchedules)) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const savedSales = yield sales_service_1.salesService.createSales(sales, queryRunner);
                        if (!savedSales && savedSales.salesId === 0) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        salesId = savedSales.salesId;
                        // Guarda los detalles de la venta de acuerdo con la modalidad
                        if (sales.modality === modelslibrary_1.SaleModality.Product) {
                            const salesDetailsWithSalesId = salesDetails.map(detail => (Object.assign(Object.assign({}, detail), { salesId })));
                            yield Promise.all(salesDetailsWithSalesId.map(detail => salesdetail_service_1.salesdetailService.createSalesDetail(detail, queryRunner)));
                        }
                        // Guarda las ventas libres si la modalidad es "Free"
                        if (sales.modality === modelslibrary_1.SaleModality.Free) {
                            const salesFreesWithSalesId = salesFrees.map(free => (Object.assign(Object.assign({}, free), { salesId })));
                            yield Promise.all(salesFreesWithSalesId.map(free => salesdetail_service_2.salesFreeService.createSalesFree(free, queryRunner)));
                        }
                        // Crea credito
                        credit.salesId = savedSales.salesId;
                        const savedCredit = yield credit_service_1.creditService.createCredit(credit, queryRunner);
                        const creditScheduleWithCreditId = creditSchedules.map(schedule => (Object.assign(Object.assign({}, schedule), { creditId: savedCredit.creditId })));
                        yield Promise.all(creditScheduleWithCreditId.map(schedule => creditSchedule_service_1.creditScheduleService.createCreditSchedule(schedule, queryRunner)));
                        if (creditAdvances && creditAdvances.length) {
                            const creditAdvanceWhithCreditId = creditAdvances.map(advance => (Object.assign(Object.assign({}, advance), { creditId: savedCredit.creditId })));
                            yield Promise.all(creditAdvanceWhithCreditId.map(advance => creditAdvance_service_1.creditAdvanceService.createCreditAdvance(advance, queryRunner)));
                        }
                        yield invoiceSerie_service_1.invoiceSerieService.incrementNumberInvoiceSerie(invoiceSerie.invoiceSerieId, invoiceSerie.number, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.SALES_SUCCESS, data: { salesId: salesId } };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.createSales = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    // Destructuring de los datos necesarios del cuerpo de la solicitud
                    const { sales, salesDetails, salesFrees, paymentSales, invoiceSerie } = req.body;
                    // Validación inicial de los datos requeridos
                    if (!sales || !Array.isArray(salesDetails) || !Array.isArray(paymentSales)) {
                        return {
                            code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                            success: false,
                            message: message_api_1.MessageCustomApi.ERROR_SERVER
                        };
                    }
                    // Variable para almacenar el ID de la venta
                    let salesId = 0;
                    // Ejecuta la transacción con un queryRunner para asegurar consistencia en la base de datos
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        // Crea la venta principal
                        const savedSales = yield sales_service_1.salesService.createSales(sales, queryRunner);
                        // Verifica si la venta fue creada correctamente
                        if (!savedSales || savedSales.salesId === 0) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        // Actualiza el estado de la proforma si existe
                        if (savedSales.proformaQuoteId) {
                            const proforma = {
                                proformaQuoteId: savedSales.proformaQuoteId,
                                state: stateproforma_enum_1.ProformaState.FINALIZADO
                            };
                            yield proformaquote_service_1.proformaQuoteService.updateStateProformaQuote(proforma, queryRunner);
                        }
                        // Almacena el ID de la venta para su uso posterior
                        salesId = savedSales.salesId;
                        // Guarda los detalles de la venta de acuerdo con la modalidad
                        if (sales.modality === modelslibrary_1.SaleModality.Product) {
                            const salesDetailsWithSalesId = salesDetails.map(detail => (Object.assign(Object.assign({}, detail), { salesId })));
                            yield Promise.all(salesDetailsWithSalesId.map(detail => salesdetail_service_1.salesdetailService.createSalesDetail(detail, queryRunner)));
                        }
                        // Guarda las ventas libres si la modalidad es "Free"
                        if (sales.modality === modelslibrary_1.SaleModality.Free) {
                            const salesFreesWithSalesId = salesFrees.map(free => (Object.assign(Object.assign({}, free), { salesId })));
                            yield Promise.all(salesFreesWithSalesId.map(free => salesdetail_service_2.salesFreeService.createSalesFree(free, queryRunner)));
                        }
                        // Guarda los pagos asociados a la venta
                        const paymentSalesWithSalesId = paymentSales.map(detail => (Object.assign(Object.assign({}, detail), { salesId })));
                        yield Promise.all(paymentSalesWithSalesId.map(detail => paymentsales_service_1.paymentsalesService.createPaymentSales(detail, queryRunner)));
                        // Incrementa el número de la serie de la factura
                        yield invoiceSerie_service_1.invoiceSerieService.incrementNumberInvoiceSerie(invoiceSerie.invoiceSerieId, invoiceSerie.number, queryRunner);
                        // Retorna un mensaje de éxito junto con el ID de la venta
                        return {
                            code: http_status_codes_1.StatusCodes.OK,
                            success: true,
                            message: message_api_1.MessageCustomApi.SALES_SUCCESS,
                            data: { salesId }
                        };
                    }));
                    return result;
                }
                catch (err) {
                    // Manejo de errores con mensaje genérico
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.updateSales = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield sales_service_1.salesService.updateSales(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_DEVICE, data: response };
            }));
        });
        this.deleteSales = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield sales_service_1.salesService.deleteSales(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_DEVICE, data: response };
            }));
        });
        this.changeStatus = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield sales_service_1.salesService.changeStatus(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATE_STATE_SERVICE_SUCCESS, data: response };
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new SalesController();
        return this.instance;
    }
}
exports.salesController = SalesController.getInstance();
//# sourceMappingURL=sales.controller.js.map