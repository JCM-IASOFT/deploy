"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.documentTypeRoute = void 0;
const express_1 = require("express");
const documentType_1 = require("../controller/documentType");
exports.documentTypeRoute = (0, express_1.Router)();
exports.documentTypeRoute.get('/findAllD', documentType_1.documentTypeController.findDocumentTypeDataTable);
exports.documentTypeRoute.get('/findAll', documentType_1.documentTypeController.findDocumentType);
exports.documentTypeRoute.post('/create', documentType_1.documentTypeController.createDocumentType);
exports.documentTypeRoute.patch('/update', documentType_1.documentTypeController.updateDocumentType);
exports.documentTypeRoute.put('/delete/:id', documentType_1.documentTypeController.deleteDocumentType);
//# sourceMappingURL=documentType.routes.js.map