"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authController = void 0;
const http_status_codes_1 = require("http-status-codes");
const auth_service_1 = require("../service/auth.service");
const message_api_1 = require("../../common/constant/message.api");
const request_handler_1 = require("../../common/handler/request.handler");
const bycrypt_handler_1 = require("../../common/handler/bycrypt.handler");
const token_handler_1 = require("../../common/handler/token.handler");
const membershipPayment_service_1 = require("../../membership/membershipPayment/service/membershipPayment.service");
const terminal_service_1 = require("../../sales/terminal/service/terminal.service");
class AuthController {
    constructor() {
        this.loginAuth = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { email, password } = req.body;
                    const user = yield auth_service_1.authService.login(email);
                    if (!user) {
                        return { code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: message_api_1.MessageCustomApi.ERROR_LOGIN };
                    }
                    const correctPassword = yield (0, bycrypt_handler_1.compare)(password, user.password);
                    if (!correctPassword) {
                        return { code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: message_api_1.MessageCustomApi.ERROR_LOGIN };
                    }
                    const userMembership = yield membershipPayment_service_1.membershipPaymentService.existMembershipPayment(user.userId);
                    if (!userMembership) {
                        const campus = user === null || user === void 0 ? void 0 : user.permissionCampus;
                        const terminal = yield terminal_service_1.terminalService.findTerminalByEmploye(user.employeId);
                        const existTerminal = campus.some(p => p.campusId === terminal.campusId);
                        if (campus || campus.length < 1 || !existTerminal) {
                            return { code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: message_api_1.MessageCustomApi.ERROR_PERMISSION_CAMPUS };
                        }
                    }
                    const token = yield (0, token_handler_1.tokenSign)(user, token_handler_1.TypeToken.secret);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.LOGIN_SUCCESS, data: { token } };
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: message_api_1.MessageCustomApi.ERROR_LOGIN, data: error };
                }
            }));
        });
        this.registerAuth = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const user = req.body;
                    const passwordHash = yield (0, bycrypt_handler_1.encrypt)(user.password);
                    user.password = yield passwordHash;
                    const response = yield auth_service_1.authService.register(user);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.LOGIN_SUCCESS, data: response };
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER, data: error };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new AuthController();
        return this.instance;
    }
}
exports.authController = AuthController.getInstance();
//# sourceMappingURL=auth.controller.js.map