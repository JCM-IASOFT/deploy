"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentProformaPdf = void 0;
const axios_1 = __importDefault(require("axios"));
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const convertdata_utils_1 = require("../../utils/convertdata.utils");
const util_1 = require("util");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
const save_error_1 = require("../../../common/handler/save.error");
const getProductsProformaPDF = (proformadetails) => {
    const products = proformadetails.map((details) => [
        { text: `${details.amount}`, style: 'rowValue', alignment: 'center' },
        { text: `${details.product.code}`, style: 'rowValue', alignment: 'left' },
        { text: `${details.product.unitMeasurement.name}`, style: 'rowValue', alignment: 'left' },
        { text: `${details.product.description}`, style: 'rowValue', alignment: 'left' },
        { text: `${details.price}`, style: 'rowValue', alignment: 'right', margin: [0, 0, 3, 0] },
        { text: `${details.total}`, style: 'rowValue', alignment: 'right', margin: [0, 0, 3, 0] },
    ]);
    return products;
};
const getBanckAccountsPDF = (bankAccouns) => {
    const accounts = bankAccouns.map((account) => [
        {
            text: [
                { text: `${account.bank.name} - ${account.currency.code}: `, style: 'rowValue', bold: true },
                { text: `${account.accountNumber} `, style: 'rowValue' },
                { text: `CCI: `, style: 'rowValue', bold: true },
                { text: `${account.CCI}`, style: 'rowValue' },
            ]
        },
    ]);
    return accounts;
};
const total = (proformadetails) => {
    let totals = 0;
    proformadetails.forEach(element => {
        totals += element.amount * element.price;
    });
    return totals;
};
const downloadImage = (url) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield (0, axios_1.default)({
            url,
            method: 'GET',
            responseType: 'arraybuffer',
        });
        return response.data;
    }
    catch (error) {
        save_error_1.logger.error(`downloadImage ${error.message}`);
    }
});
const convertImageToBase64 = (imageBuffer) => {
    try {
        return imageBuffer.toString('base64');
    }
    catch (error) {
        save_error_1.logger.error(`convertImageToBase64 ${error.message}`);
        return null;
    }
};
const getPaymentImage = () => __awaiter(void 0, void 0, void 0, function* () {
    const rutaImagenPNG = path_1.default.resolve(__dirname, '../../../public/upload/image/payment.png');
    const readFileAsync = (0, util_1.promisify)(fs_1.default.readFile);
    try {
        const data = yield readFileAsync(rutaImagenPNG);
        const base64Image = Buffer.from(data).toString('base64');
        return base64Image;
    }
    catch (err) {
        console.error(err);
        return null;
    }
});
const ContentProformaPdf = (company, proforma, backAccounts, parameters) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const imageBuffer = yield downloadImage(company.image);
        const logoCompany = convertImageToBase64(imageBuffer);
        const base64Image = logoCompany;
        const base64ImagePayment = yield getPaymentImage();
        const roundedBorder = {
            canvas: [
                {
                    type: 'rect',
                    x: 0,
                    y: 0,
                    w: 150,
                    h: 80,
                    r: 10,
                    lineWidth: 1,
                    lineColor: 'black',
                    color: 'gainsboro',
                }
            ]
        };
        let data = [
            // ** INFORMACION DE PROFORMA Y DE EMPRESA
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['50%', '5%', '45%'],
                    body: [
                        [
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    columns: [
                                        {
                                            width: 'auto',
                                            image: 'data:image/jpg;base64,' + base64Image,
                                            fit: [50, 50],
                                            alignment: 'left',
                                            margin: [0, 0, 10, 0]
                                        },
                                        {
                                            width: 'auto',
                                            text: `${company.name.toUpperCase()}`, style: 'titleLeft', alignment: 'left',
                                            margin: [0, 0, 0, 0]
                                        }
                                    ]
                                },
                                {
                                    stack: [
                                        {
                                            margin: [0, 5, 0, 0],
                                            text: [
                                                // { text: '\uf041  ', style: 'iconFont' },
                                                { text: `Direccion: ${company.address.toUpperCase()}`, style: 'text' }
                                            ]
                                        },
                                        {
                                            margin: [0, 5, 0, 0],
                                            text: [
                                                // { text: '  ', style: 'iconFont' },
                                                { text: `Ciudad: ${company.district.province.name}`, style: 'text' }
                                            ]
                                        },
                                        {
                                            margin: [0, 5, 0, 0],
                                            text: [
                                                // { text: '\uf003  ', style: 'iconFont' },
                                                { text: `Sitio web: ${company.web}`, style: 'text' }
                                            ]
                                        },
                                        {
                                            margin: [0, 5, 0, 0],
                                            text: [
                                                // { text: '\uf232  ', style: 'iconFont' },
                                                { text: `Telefono: ${proforma.campus.phone}`, style: 'text' }
                                            ]
                                        }, //f268
                                        {
                                            margin: [0, 5, 0, 0],
                                            text: [
                                                // { text: '\uf0ac  ', style: 'iconFont' },
                                                { text: `E-mail: ${company.email}`, style: 'text' }
                                            ]
                                        },
                                    ],
                                },
                            ],
                            {},
                            [
                                {
                                    text: "COTIZACIÓN", style: 'serieDocument', margin: [20, 3, 0, 3], alignment: 'right', color: '#152235'
                                },
                                {
                                    margin: [0, 10, 0, 0],
                                    columns: [
                                        // roundedBorder,
                                        {
                                            margin: [0, 0, 5, 0],
                                            stack: [
                                                { text: 'FECHA:', style: 'documentNumber', alignment: 'right', margin: [0, 2, 0, 4] },
                                                { text: 'SERIE:', style: 'documentNumber', alignment: 'right', margin: [0, 2, 0, 4] },
                                                { text: 'MONEDA:', style: 'documentNumber', alignment: 'right', margin: [0, 2, 0, 4] },
                                                { text: 'FECHA V.:', style: 'documentNumber', alignment: 'right', margin: [0, 2, 0, 4] }
                                            ]
                                        },
                                        {
                                            // width: 'auto', 
                                            // absolutePosition: { x: 430, y: 34 },
                                            margin: [0, 0, 0, 0],
                                            table: {
                                                widths: ['auto'],
                                                body: [
                                                    [
                                                        { text: `${(0, moment_timezone_1.default)().format('DD/MM/YYYY')}`, style: 'documentNumber' },
                                                    ],
                                                    [
                                                        { text: proforma.correlative.toString().padStart(5, '0') + "-" + (0, moment_timezone_1.default)(proforma.registrationDate).format("yyyy"), style: 'documentNumber' },
                                                    ],
                                                    [
                                                        { text: `${proforma.currency.currencyName.toUpperCase()}`, style: 'documentNumber' }
                                                    ],
                                                    [
                                                        { text: `${(0, moment_timezone_1.default)(proforma.expirationDate).format('DD/MM/YYYY')}`, style: 'documentNumber' }
                                                    ]
                                                ],
                                            },
                                            layout: {
                                                hLineWidth: function (i, node) {
                                                    return 1; // Define el grosor de las líneas horizontales
                                                },
                                                vLineWidth: function (i, node) {
                                                    return 1; // Define el grosor de las líneas verticales
                                                },
                                                hLineColor: function (i, node) {
                                                    return 'black'; // Define el color de las líneas horizontales
                                                },
                                                vLineColor: function (i, node) {
                                                    return 'black'; // Define el color de las líneas verticales
                                                },
                                            },
                                            alignment: 'left'
                                        }
                                    ]
                                }
                            ]
                        ],
                    ],
                },
                layout: 'noBorders',
            },
            // ** INFORMACION DE CLIENTE
            {
                table: {
                    widths: ['60%', '40%'],
                    body: [
                        [
                            {
                                margin: [0, 3, 0, 3],
                                stack: [{
                                    table: {
                                        widths: ['60%', '40%'],
                                        body: [
                                            [
                                                { text: ' CLIENTE', style: 'rowCaption', fillColor: '#152235', color: 'white', margin: [5, 0, 0, 0] },
                                                {},
                                            ],
                                            [
                                                { text: `RUC/DNI/DOCUMENTO: ${proforma.client ? proforma.client.documentNumber : '999999999'}`, style: 'rowCaption' },
                                                {},
                                            ],
                                            [
                                                { text: `Nombre: ${proforma.client ? proforma.client.fullname : 'No Aplica'}`, style: 'rowCaption' },
                                                {},
                                            ],
                                            [
                                                { text: `E-mail: ${proforma.client ? proforma.client.email : '-'}`, style: 'rowCaption' },
                                                {},
                                            ],
                                            [
                                                { text: `Dirección: ${proforma.client ? proforma.client.address : '-'}`, style: 'rowCaption' },
                                                {},
                                            ],
                                            [
                                                { text: `Ciudad: ${proforma.client ? proforma.client.district.province.name : '-'}`, style: 'rowCaption' },
                                                {},
                                            ],
                                            [
                                                { text: `Teléfono: ${proforma.client ? proforma.client.address : '-'}`, style: 'rowCaption' },
                                                {},
                                            ]
                                        ],
                                    },
                                    layout: 'noBorders',
                                }]
                            },
                            {
                                margin: [0, 3, 0, 3],
                                stack: [{
                                    table: {
                                        widths: ['80%', '20%'],
                                        body: [
                                            [
                                                { text: 'VENDEDOR(A)', style: 'rowCaption', fillColor: '#152235', color: 'white', margin: [5, 0, 0, 0] },
                                                {},
                                            ],
                                            [
                                                { text: `Nombre: ${proforma.employe.name + ' ' + proforma.employe.fullname}`, style: 'rowCaption' },
                                                {},
                                            ],
                                            [
                                                { text: `Telefono: ${proforma.employe ? proforma.employe.phone : '999999999'}`, style: 'rowCaption' },
                                                {},
                                            ],
                                            [
                                                { text: `E-mail: ${proforma.employe.email}`, style: 'rowCaption' },
                                                {},
                                            ]
                                        ],
                                    },
                                    layout: 'noBorders',
                                }]
                            },
                        ]
                    ]
                },
                layout: 'noBorders'
            },
            {
                table: {
                    widths: ['30%', '70%'],
                    body: [
                        [
                            {
                                text: 'OBSERVACIONES', style: 'rowCaption', fillColor: '#152235', color: 'white', margin: [5, 0, 0, 0]
                            },
                            {
                                table: {
                                    widths: ['100%'],
                                    body: [
                                        [
                                            {
                                                text: proforma.observation ? proforma.observation : 'Sin observaciones', style: 'rowCaption'
                                            }
                                        ]
                                    ],
                                },
                                layout: {
                                    hLineWidth: function (i, node) {
                                        return (i === 0 || i === node.table.body.length) ? 1 : 0;
                                    },
                                    vLineWidth: function (i, node) {
                                        return (i === 0 || i === node.table.widths.length) ? 1 : 0;
                                    },
                                    hLineColor: function () {
                                        return 'black';
                                    },
                                    vLineColor: function () {
                                        return 'black';
                                    }
                                }
                            }
                        ]
                    ]
                },
                layout: 'noBorders'
            },
            // ** PRODUCTOS
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['10%', '15%', '10%', '40%', '15%', '10%'],
                    body: [
                        [
                            { text: 'CANT', style: 'rowCaption', borderRight: 'none' },
                            { text: 'CÓDIGO', style: 'rowCaption' },
                            { text: 'U.M', style: 'rowCaption' },
                            { text: 'DESCRIPCIÓN', style: 'rowCaption' },
                            { text: 'PREC. UNIT.', style: 'rowCaption' },
                            { text: 'IMPORTE', style: 'rowCaption' },
                        ],
                    ]
                },
                layout: {
                    hLineColor: function (i, node) {
                        return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                    },
                    vLineColor: function (i, node) {
                        return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                    }
                }
            },
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['10%', '15%', '10%', '40%', '15%', '10%'],
                    body: [
                        ...getProductsProformaPDF(proforma.proformaQuoteDetails)
                    ]
                },
                layout: 'noBorders'
            },
            {
                margin: [0, 150, 0, 0],
                text: [
                    { text: 'Contacto :', style: 'rowCaption' },
                    { text: '', style: 'rowValue' }
                ]
            },
            {
                margin: [0, 2, 0, 0],
                text: [
                    { text: 'Teléfono :', style: 'rowCaption' },
                    { text: '', style: 'rowValue' }
                ]
            },
            {
                margin: [0, 2, 0, 0],
                table: {
                    widths: ['50%', '50%'],
                    body: [[
                        {
                            stack: [{
                                text: [
                                    { text: 'Correo :', style: 'rowCaption' },
                                    { text: '', style: 'rowValue' }
                                ]
                            }]
                        },
                        {
                            stack: [{
                                alignment: 'right',
                                text: [
                                    { text: `TOTAL: `, style: 'rowCaption' },
                                    { text: `${proforma.currency.symbol} ${total(proforma.proformaQuoteDetails).toFixed(2)}`, style: 'rowCaption' }
                                ]
                            }]
                        },
                    ]
                    ]
                },
                layout: 'noBorders'
            },
            // ** PAGO
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['100%'],
                    body: [
                        [
                            {
                                text: [
                                    { text: `SON :`, style: 'rowCaption' },
                                    {
                                        text: `${(0, convertdata_utils_1.convertNumberToTextSUNAT)(total(proforma.proformaQuoteDetails)).toUpperCase()} ${proforma.currency.currencyName}`, style: 'rowValue'
                                    }
                                ]
                            },
                        ],
                    ]
                },
                layout: {
                    hLineColor: function (i, node) {
                        return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                    },
                    vLineColor: function (i, node) {
                        return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                    }
                }
            },
            // ** CONDICIONES
            {
                margin: [0, 5, 0, 0],
                table: {
                    margin: [0, 0, 0, 0],
                    widths: ['50%', '50%'],
                    body: [
                        [
                            // ** TERMINOS Y CONDICIONES
                            {
                                stack: [
                                    {
                                        table: {
                                            widths: ['100%'],
                                            body: [
                                                [
                                                    {
                                                        stack: [
                                                            { text: 'Terminos y Condiciones:', margin: [0, 0, 0, 4], style: 'textMin', bold: true, },
                                                            {
                                                                text: parameters.find(p => p.name === parameter_constant_1.GroupConstant.PROFORMA.NAMES.TERMS_CONDITIONS).value, style: 'textMin'
                                                            }
                                                        ]
                                                    }
                                                ],
                                            ]
                                        },
                                        layout: {
                                            hLineColor: function (i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                            },
                                            vLineColor: function (i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                                            }
                                        },
                                    },
                                    { text: 'ADICIONALES PARA ENTIDADES PÚBLICAS', margin: [0, 5, 0, 0], style: 'rowCaption', bold: true, alignment: 'center', },
                                    {
                                        text: parameters.find(p => p.name === parameter_constant_1.GroupConstant.PROFORMA.NAMES.ADDITIONAL).value, margin: [0, 3, 0, 0], style: 'textMin'
                                    },
                                    { text: '________________________________________', margin: [0, 14, 0, 0], style: 'rowCaption', bold: true, alignment: 'center', },
                                    { text: 'Firma del cliente', margin: [0, 0, 0, 0], style: 'rowCaption', bold: true, alignment: 'center', },
                                ],
                            },
                            // ** CEUNTAS BANCARIAS
                            {
                                stack: [
                                    {
                                        table: {
                                            widths: ['100%'],
                                            body: [
                                                [
                                                    {
                                                        stack: [
                                                            {
                                                                table: {
                                                                    widths: '*',
                                                                    body: [
                                                                        [
                                                                            {
                                                                                alignment: 'center',
                                                                                bold: true,
                                                                                border: [false, false, false, false],
                                                                                fillColor: '#0B75FF',
                                                                                color: 'white',
                                                                                text: 'CUENTAS BANCARIAS'
                                                                            }
                                                                        ]
                                                                    ]
                                                                }
                                                            },
                                                            { text: company.name, style: 'textLog', margin: [0, 0, 0, 4], alignment: 'center', },
                                                            ...getBanckAccountsPDF(backAccounts),
                                                            {
                                                                stack: [{
                                                                    image: 'data:image/jpg;base64,' + base64ImagePayment,
                                                                    fit: [200, 100],
                                                                    alignment: 'center',
                                                                }]
                                                            },
                                                        ]
                                                    }
                                                ],
                                            ]
                                        },
                                        layout: {
                                            hLineColor: function (i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                            },
                                            vLineColor: function (i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                                            }
                                        }
                                    },
                                    {
                                        margin: [0, 4, 0, 0],
                                        table: {
                                            widths: ['100%'],
                                            body: [
                                                [
                                                    {
                                                        stack: [
                                                            { text: parameters.find(p => p.name === parameter_constant_1.GroupConstant.PROFORMA.NAMES.FAREWELL_MESSAGE).value, style: 'textMin' },
                                                            { text: '¡Gracias por hacer negocios con nosotros!', margin: [0, 4, 0, 0], style: 'rowCaption', alignment: 'center', }
                                                        ]
                                                    }
                                                ],
                                            ]
                                        },
                                        layout: {
                                            hLineColor: function (i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                            },
                                            vLineColor: function (i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                                            }
                                        }
                                    },
                                ]
                            }
                        ]
                    ]
                },
                layout: 'noBorders'
            }
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentProformaPdf = ContentProformaPdf;
// nvm install 20.11.0
//# sourceMappingURL=content.js.map