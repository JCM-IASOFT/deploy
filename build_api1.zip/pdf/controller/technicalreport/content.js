"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentTechnicalReportPdf = void 0;
const moment_1 = __importDefault(require("moment"));
const downloadLogo_utils_1 = require("../../utils/downloadLogo.utils");
const getDevices = (serviceDevices) => {
    const tableDevices = [];
    serviceDevices.forEach(elemet => {
        if (!elemet.device)
            return;
        tableDevices.push([
            { text: '1.1', style: 'rowValue' },
            { text: "EQUIPO", style: 'rowValue' },
            { text: elemet.device.description, style: 'rowValue' }
        ]);
        tableDevices.push([
            { text: '1.2', style: 'rowValue' },
            { text: "MODELO", style: 'rowValue' },
            { text: elemet.model, style: 'rowValue' }
        ]);
        tableDevices.push([
            { text: '1.3', style: 'rowValue' },
            { text: "SERIE", style: 'rowValue' },
            { text: elemet.serial, style: 'rowValue' }
        ]);
    });
    if (tableDevices.length === 0) {
        tableDevices.push([
            {},
            {},
            {}
        ]);
    }
    return tableDevices;
};
const getCampus = (campus) => {
    const tableDevices = [];
    tableDevices.push([
        { text: '2.1', style: 'rowValue' },
        { text: "UBICACIÓN", style: 'rowValue' },
        { text: campus.address, style: 'rowValue' }
    ]);
    tableDevices.push([
        { text: '2.2', style: 'rowValue' },
        { text: "TIPO DE TRABAJO", style: 'rowValue' },
        { text: 'Servvicio Tecnico', style: 'rowValue' }
    ]);
    return tableDevices;
};
const getObjetives = (serviceDevices) => {
    const obtives = [];
    serviceDevices.forEach(element => {
        const elementData = [];
        if (element.reason) {
            elementData.push({
                margin: [20, 10, 0, 0],
                text: 'Falla/Problema: ' + element.reason,
                style: 'rowValue'
            });
        }
        if (element.accessories) {
            elementData.push({
                margin: [20, 10, 0, 0],
                text: 'Accesorios: ' + element.accessories,
                style: 'rowValue'
            });
        }
        if (element.estimatedAmount !== undefined && element.estimatedAmount !== null) {
            elementData.push({
                margin: [20, 10, 0, 0],
                text: 'Monto Estimado: ' + parseFloat(element.estimatedAmount.toString()).toFixed(2),
                style: 'rowValue'
            });
        }
        if (element.serial) {
            elementData.push({
                margin: [20, 10, 0, 0],
                text: 'Serial: ' + element.serial,
                style: 'rowValue'
            });
        }
        if (element.observations) {
            elementData.push({
                margin: [20, 10, 0, 0],
                text: 'Observaciones: ' + element.observations,
                style: 'rowValue'
            });
        }
        if (element.observations) {
            elementData.push({
                margin: [20, 10, 0, 0],
                text: 'Modelo: ' + element.model,
                style: 'rowValue'
            });
        }
        if (elementData.length > 0) {
            obtives.push(elementData);
        }
    });
    return obtives;
};
const ContentTechnicalReportPdf = (company, service, dateoOfIssue, technical, affair, finalReport) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const imageBuffer = yield (0, downloadLogo_utils_1.downloadImage)(company.image);
        const logoCompany = (0, downloadLogo_utils_1.convertImageToBase64)(imageBuffer);
        let data = [
            // ** INFORMACION TECNICO
            {
                stack: [{
                        image: 'data:image/jpg;base64,' + logoCompany,
                        fit: [100, 100],
                        alignment: 'center',
                    }]
            },
            {
                margin: [0, 20, 0, 0],
                text: 'INFORME TECNICO', style: 'titleCenter'
            },
            {
                text: 'CONSTANCIA ' + (0, moment_1.default)(dateoOfIssue).format("LL").toUpperCase(), style: 'rowCaption', alignment: 'right',
            },
            {
                margin: [0, 8, 0, 0],
                table: {
                    widths: ['20%', '80%'],
                    body: [
                        [
                            { text: 'PARA', style: 'rowCaption' },
                            { text: ': ' + service.client.fullname.toUpperCase(), style: 'rowValue' }
                        ],
                        [
                            { text: 'DE', style: 'rowCaption' },
                            { text: ': ' + technical.toUpperCase(), style: 'rowValue' }
                        ],
                        [
                            { text: 'ASUNTO', style: 'rowCaption' },
                            { text: ': ' + affair.toUpperCase(), style: 'rowValue' }
                        ]
                    ]
                },
                layout: 'noBorders',
            },
            {
                canvas: [{ type: 'line', x1: 0, y1: 10, x2: 520, y2: 10, lineWidth: 2 }]
            },
            {
                margin: [0, 25, 0, 0],
                text: '1. DATOS DEL EQUIPO', style: 'rowCaption'
            },
            {
                margin: [0, 8, 0, 0],
                table: {
                    widths: ['10%', '20%', '70%'],
                    body: getDevices(service.serviceDevices)
                },
            },
            {
                margin: [0, 25, 0, 0],
                text: '2. DATOS DEL LUGAR Y DEL TIPO DE TRABAJO ', style: 'rowCaption'
            },
            {
                margin: [0, 8, 0, 0],
                table: {
                    widths: ['10%', '20%', '70%'],
                    body: getCampus(service.campus)
                },
            },
            {
                margin: [0, 30, 0, 0],
                text: 'ANTECEDENTES', style: 'rowCaption'
            },
            ...getObjetives(service.serviceDevices),
            {
                margin: [0, 10, 0, 0],
                table: {
                    widths: ['100%'],
                    body: [
                        [
                            {
                                text: finalReport, style: 'rowCaption'
                            }
                        ]
                    ]
                },
            },
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentTechnicalReportPdf = ContentTechnicalReportPdf;
// nvm install 20.11.0
//# sourceMappingURL=content.js.map