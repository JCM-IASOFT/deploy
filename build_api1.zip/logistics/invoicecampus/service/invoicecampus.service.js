"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoicecampusService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const modelslibrary_1 = require("modelslibrary");
class InvoiceCampusService {
    static getInstance() {
        if (!this.instance)
            this.instance = new InvoiceCampusService();
        return this.instance;
    }
    findInvoiceCampus(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const devices = yield modelslibrary_1.InvoiceCampusModel.find({
                    where: { campusId: campusId },
                    relations: ["invoice", "invoice.invoiceSeries"],
                    select: {
                        invoiceCampusId: true,
                        invoiceId: true,
                        campusId: true,
                        isDefault: true,
                        state: true,
                        invoice: {
                            invoiceId: true,
                            code: true,
                            name: true,
                            type: true,
                            invoiceSeries: {
                                invoiceSerieId: true,
                                prefix: true,
                                number: true,
                                distance: true,
                                state: true,
                                isDefault: true,
                                invoiceId: true
                            }
                        }
                    },
                    order: {
                        isDefault: 'DESC'
                    }
                });
                return devices;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
}
exports.invoicecampusService = InvoiceCampusService.getInstance();
//# sourceMappingURL=invoicecampus.service.js.map