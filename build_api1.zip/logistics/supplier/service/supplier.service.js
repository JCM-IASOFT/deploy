"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.supplierService = exports.SupplierService = void 0;
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
class SupplierService {
    static getInstance() {
        if (!this.instance)
            this.instance = new SupplierService();
        return this.instance;
    }
    findSupplier(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const supplierFind = yield modelslibrary_1.SupplierModel.find({
                    where: {
                        companyId: companyId,
                        deletedAt: '0'
                    }
                });
                return supplierFind;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createSupplier(supplier) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const supplierCreate = modelslibrary_1.SupplierModel.create(supplier);
                return yield modelslibrary_1.SupplierModel.save(supplierCreate);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateSupplier(supplier) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const supplierUpdate = yield modelslibrary_1.SupplierModel.update({ supplierId: supplier.supplierId }, {
                    name: supplier.name,
                    ruc: supplier.ruc,
                    address: supplier.address,
                    phone: supplier.phone,
                    companyId: supplier.companyId,
                    status: supplier.status
                });
                return supplierUpdate;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteSupplier(supplierId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const supplierDelete = yield modelslibrary_1.SupplierModel.update({ supplierId: supplierId }, {
                    deletedAt: '1'
                });
                return supplierDelete;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.SupplierService = SupplierService;
exports.supplierService = SupplierService.getInstance();
//# sourceMappingURL=supplier.service.js.map