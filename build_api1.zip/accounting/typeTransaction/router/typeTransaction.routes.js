"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeTransactionRoute = void 0;
const express_1 = require("express");
const typeTransaction_1 = require("../controller/typeTransaction");
exports.typeTransactionRoute = (0, express_1.Router)();
exports.typeTransactionRoute.get('/', typeTransaction_1.typeTransactioncontroller.findTypeTransaction);
exports.typeTransactionRoute.post('/all/:campusId', typeTransaction_1.typeTransactioncontroller.findAllTypeTransaction);
exports.typeTransactionRoute.post('/add', typeTransaction_1.typeTransactioncontroller.createTypeTransaction);
exports.typeTransactionRoute.put('/edit', typeTransaction_1.typeTransactioncontroller.updateTypeTransaction);
exports.typeTransactionRoute.put('/delete', typeTransaction_1.typeTransactioncontroller.deleteTypeTransaction);
//# sourceMappingURL=typeTransaction.routes.js.map