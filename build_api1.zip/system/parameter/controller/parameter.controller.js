"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parameterController = void 0;
const http_status_codes_1 = require("http-status-codes");
const parameter_service_1 = require("../service/parameter.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
class ParameterController {
    constructor() {
        this.findParameter = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { group, campusId } = req.query;
            if (group) {
                const parameters = yield parameter_service_1.parameterService.findParameter(group.toString(), Number(campusId));
                res.status(http_status_codes_1.StatusCodes.OK).json(parameters);
            }
            else {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ message: 'Falta argumento group' });
            }
        });
        this.createParameters = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield parameter_service_1.parameterService.createParameter(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_DEVICE, data: response };
            }));
        });
        this.updateParameter = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield parameter_service_1.parameterService.updateParameter(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_DEVICE, data: response };
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ParameterController();
        return this.instance;
    }
}
exports.parameterController = ParameterController.getInstance();
//# sourceMappingURL=parameter.controller.js.map