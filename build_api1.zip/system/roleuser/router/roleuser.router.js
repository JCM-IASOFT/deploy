"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.roleuserRoute = void 0;
const express_1 = require("express");
const roleuser_controller_1 = require("../controller/roleuser.controller");
exports.roleuserRoute = (0, express_1.Router)();
exports.roleuserRoute.get('/', roleuser_controller_1.roleuserController.findAllRoleUser);
exports.roleuserRoute.post('/', roleuser_controller_1.roleuserController.createRoleUsers);
exports.roleuserRoute.delete('/', roleuser_controller_1.roleuserController.deleteRoleUser);
//# sourceMappingURL=roleuser.router.js.map