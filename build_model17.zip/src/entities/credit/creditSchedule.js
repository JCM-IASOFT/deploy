"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditScheduleModel = void 0;
const typeorm_1 = require("typeorm");
const credit_1 = require("./credit"); // Asegúrate de importar correctamente el modelo CreditModel si aún no está importado
const creditPayment_1 = require("./creditPayment"); // Asegúrate de importar correctamente el modelo CreditPaymentModel si aún no está importado
/**
 * Modelo de entidad para representar el cronograma de pago de crédito.
 * Esta clase mapea a la tabla 'credit_schedule' en el esquema 'finance'.
 */
let CreditScheduleModel = class CreditScheduleModel extends typeorm_1.BaseEntity {
};
exports.CreditScheduleModel = CreditScheduleModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CreditScheduleModel.prototype, "creditScheduleId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditScheduleModel.prototype, "creditId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], CreditScheduleModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], CreditScheduleModel.prototype, "dueDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], CreditScheduleModel.prototype, "isPaid", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], CreditScheduleModel.prototype, "paymentDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', nullable: true, default: 0, scale: 2, precision: 15 }),
    __metadata("design:type", Number)
], CreditScheduleModel.prototype, "change", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], CreditScheduleModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], CreditScheduleModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => credit_1.CreditModel, credit => credit.creditSchedules),
    (0, typeorm_1.JoinColumn)({ name: 'creditId', referencedColumnName: 'creditId' }),
    __metadata("design:type", credit_1.CreditModel)
], CreditScheduleModel.prototype, "credit", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => creditPayment_1.CreditPaymentModel, creditPayment => creditPayment.creditSchedule),
    __metadata("design:type", Array)
], CreditScheduleModel.prototype, "creditPayments", void 0);
exports.CreditScheduleModel = CreditScheduleModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'credit', name: 'credit_schedule' })
], CreditScheduleModel);
//# sourceMappingURL=creditSchedule.js.map