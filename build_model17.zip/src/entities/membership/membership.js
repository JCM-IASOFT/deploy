"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MembershipModel = void 0;
const typeorm_1 = require("typeorm");
const benefit_1 = require("./benefit");
const membershipPayment_1 = require("./membershipPayment");
/**
 * * MEMBRESIAS
 */
let MembershipModel = class MembershipModel extends typeorm_1.BaseEntity {
};
exports.MembershipModel = MembershipModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)(),
    __metadata("design:type", Number)
], MembershipModel.prototype, "membershipId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", default: '', length: 200 }),
    __metadata("design:type", String)
], MembershipModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], MembershipModel.prototype, "price", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], MembershipModel.prototype, "duration", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => membershipPayment_1.MembershipPaymentModel, membershipPayment => membershipPayment.membership),
    __metadata("design:type", Array)
], MembershipModel.prototype, "membershipPayments", void 0);
__decorate([
    (0, typeorm_1.ManyToMany)(() => benefit_1.BenefitModel, benefit => benefit.memberships),
    (0, typeorm_1.JoinTable)({
        name: 'membership_benefit',
        joinColumn: {
            name: 'membershipId',
            referencedColumnName: 'membershipId'
        },
        inverseJoinColumn: {
            name: 'benefitId',
            referencedColumnName: 'benefitId'
        }
    }),
    __metadata("design:type", Array)
], MembershipModel.prototype, "benefits", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP', }),
    __metadata("design:type", Date)
], MembershipModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP', }),
    __metadata("design:type", Date)
], MembershipModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 1, default: () => '0' }),
    __metadata("design:type", String)
], MembershipModel.prototype, "deletedAt", void 0);
exports.MembershipModel = MembershipModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'membership', name: 'membership' })
], MembershipModel);
//# sourceMappingURL=membership.js.map