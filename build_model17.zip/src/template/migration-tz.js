"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChangeAlltimestamptzsTotimestamptztz1689264000000 = void 0;
class ChangeAlltimestamptzsTotimestamptztz1689264000000 {
    up(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            const tablesAndColumns = yield queryRunner.query(`
            SELECT table_schema, table_name, column_name
            FROM information_schema.columns
            WHERE data_type = 'timestamptz without time zone';
        `);
            for (const row of tablesAndColumns) {
                yield queryRunner.query(`
                ALTER TABLE "${row.table_schema}"."${row.table_name}"
                ALTER COLUMN "${row.column_name}"
                SET DATA TYPE timestamptztz
                USING "${row.column_name}"::timestamptztz;
            `);
            }
        });
    }
    down(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            const tablesAndColumns = yield queryRunner.query(`
            SELECT table_schema, table_name, column_name
            FROM information_schema.columns
            WHERE data_type = 'timestamptztz';
        `);
            for (const row of tablesAndColumns) {
                yield queryRunner.query(`
                ALTER TABLE "${row.table_schema}"."${row.table_name}"
                ALTER COLUMN "${row.column_name}"
                SET DATA TYPE timestamptz
                USING "${row.column_name}"::timestamptz;
            `);
            }
        });
    }
}
exports.ChangeAlltimestamptzsTotimestamptztz1689264000000 = ChangeAlltimestamptzsTotimestamptztz1689264000000;
//# sourceMappingURL=migration-tz.js.map