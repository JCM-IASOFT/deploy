"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomMigrationTemplate1721145285695 = void 0;
class CustomMigrationTemplate1721145285695 {
    up(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS accounting`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS company`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS credit`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS human_resource`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS inventory`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS logistics`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS membership`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS sales`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS support`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS system`);
        });
    }
    down(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            // Aquí podrías definir la lógica de reversión si es necesario
        });
    }
}
exports.CustomMigrationTemplate1721145285695 = CustomMigrationTemplate1721145285695;
//# sourceMappingURL=schema.js.map