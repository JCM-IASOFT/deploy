"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.upload = void 0;
const multer_1 = __importDefault(require("multer"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const normalizeFileName = (fileName) => {
    const sanitizedFileName = fileName
        .replace(/[^a-zA-Z0-9\s]/g, '')
        .replace(/\s+/g, '_')
        .toLowerCase();
    return sanitizedFileName;
};
const storage = multer_1.default.diskStorage({
    destination: function (req, file, cb) {
        const uuid = req.body.uuid;
        const uploadPath = `uploads/${uuid}`;
        fs_1.default.mkdir(uploadPath, { recursive: true }, (err) => {
            if (err) {
                return cb(err, uploadPath);
            }
            cb(null, uploadPath);
        });
    },
    filename: function (req, file, cb) {
        // Obtener la extensión del archivo
        const extname = path_1.default.extname(file.originalname);
        // Obtener el nombre del archivo sin la extensión
        const baseName = path_1.default.basename(file.originalname, extname);
        // Normalizar el nombre del archivo
        const normalizedFileName = normalizeFileName(baseName);
        // Crear el nuevo nombre de archivo con la extensión
        const filename = `${normalizedFileName}${extname}`;
        // Pasar el nombre de archivo final al callback
        cb(null, filename);
    }
});
exports.upload = (0, multer_1.default)({ storage });
//# sourceMappingURL=multer.middleware.js.map