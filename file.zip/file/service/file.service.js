"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileService = void 0;
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
class FileService {
    static getInstance() {
        if (!this.instance)
            this.instance = new FileService();
        return this.instance;
    }
    findFiles(dir) {
        try {
            let results = [];
            const list = node_fs_1.default.readdirSync(dir);
            list.forEach(file => {
                const filePath = node_path_1.default.join(dir, file);
                const stat = node_fs_1.default.statSync(filePath);
                if (stat && stat.isDirectory()) {
                    // Si es un directorio, realiza la lectura recursiva
                    results = results.concat(this.findFiles(filePath));
                }
                else {
                    // Si es un archivo, lee su contenido
                    const content = node_fs_1.default.readFileSync(filePath).toString('base64');
                    results.push({ fileName: file, filePath: filePath, content: content });
                }
            });
            return results;
        }
        catch (error) {
            return [];
        }
    }
    findOneFile(rawPath) {
        try {
            let result;
            const normalizedPath = node_path_1.default.normalize(rawPath);
            const filePath = node_path_1.default.join('./', normalizedPath);
            if (this.existFile(rawPath)) {
                const image = node_fs_1.default.readFileSync(filePath).toString('base64');
                result = image;
            }
            return result;
        }
        catch (error) {
            return '';
        }
    }
    existFile(rawPath) {
        let exist = false;
        if (node_fs_1.default.existsSync(rawPath)) {
            exist = true;
        }
        return exist;
    }
}
exports.fileService = FileService.getInstance();
//# sourceMappingURL=file.service.js.map