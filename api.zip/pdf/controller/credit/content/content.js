"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentPdf = exports.fetchAndConvertToBase64 = void 0;
const axios_1 = __importDefault(require("axios"));
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const convertdata_utils_1 = require("../../../utils/convertdata.utils");
const fetchAndConvertToBase64 = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axios_1.default.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 5000
        });
        const base64Image = Buffer.from(response.data, 'binary').toString('base64');
        return base64Image;
    }
    catch (error) {
        return null;
    }
});
exports.fetchAndConvertToBase64 = fetchAndConvertToBase64;
const getTotalAdvance = (creditAdvance) => {
    const advances = creditAdvance.reduce((total, payment) => total + Number(payment.amount), 0);
    return advances;
};
const getTotalPayments = (creditPayments) => {
    const payments = creditPayments.reduce((total, payment) => total + Number(payment.amount), 0);
    return payments;
};
const ContentPdf = (credit, campus, company) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let data = [];
        const tableData = [
            [
                { text: 'CUOTAS: ', style: 'tHeaderValue', alignment: 'left' },
                {},
                {},
                {}
            ],
            [
                { text: 'Monto: ', style: 'tHeaderValue', alignment: 'left' },
                { text: 'F. venc. ', style: 'tHeaderValue', alignment: 'left' },
                { text: 'Monto p. ', style: 'tHeaderValue', alignment: 'left' },
                { text: 'F. pago ', style: 'tHeaderValue', alignment: 'left' },
            ],
        ];
        if (credit.creditSchedules.length > 0) {
            credit.creditSchedules.forEach(item => {
                tableData.push([
                    { text: `${credit.currency.symbol + '' + item.amount}`, style: 'tHeaderValue', alignment: 'left' },
                    { text: `${(0, convertdata_utils_1.dateFormat)(item.dueDate)}`, style: 'tHeaderValue', alignment: 'left' },
                    { text: `${credit.currency.symbol + '' + getTotalPayments(item.creditPayments)}`, style: 'tHeaderValue', alignment: 'left' },
                    { text: `${item.paymentDate ? (0, convertdata_utils_1.dateFormat)(item.paymentDate) : 'Sin fecha'}`, style: 'tHeaderValue', alignment: 'left' },
                ]);
            });
        }
        data = [
            { text: company.name.toUpperCase(), style: 'tHeaderValue', margin: [0, 5, 0, 0], alignment: 'center' },
            { text: 'TICKET CREDITO', style: 'tHeaderValue', margin: [0, 5, 0, 2], alignment: 'center' },
            { text: credit.creditId.toString().padStart(5, '0'), style: 'tHeaderValue', margin: [0, 2, 0, 0], alignment: 'center' },
            { text: `SEDE: ${campus.name.toUpperCase()}`, style: 'tHeaderValue', margin: [0, 8, 0, 0], alignment: 'left' },
            { text: `DIRECCIÓN: ${campus.address.toUpperCase()}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0] },
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['25%', '30%', '20%', '25%'],
                    body: [
                        [
                            { text: 'FECHA:', style: 'tHeaderLabel' },
                            { text: (0, moment_timezone_1.default)().tz(company.timeZone).format('L'), style: 'tHeaderValue' },
                            { text: 'HORA:', style: 'tHeaderLabel' },
                            { text: (0, moment_timezone_1.default)().tz(company.timeZone).format('HH:mm:ss'), style: 'tHeaderValue' },
                        ],
                    ],
                },
                layout: {
                    hLineWidth: (i, node) => {
                        return (i === 0) ? 1 : 0;
                    },
                    vLineWidth: (i, node) => {
                        return 0;
                    },
                    hLineColor: (i, node) => {
                        return '#000000';
                    },
                },
            },
            // ** TABLA CREDITOS
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['35%', '30%', '15%', '20%'],
                    body: [
                        [
                            { text: 'CREDITO:', style: 'tHeaderLabel' },
                            { text: `${credit.creditId.toString().padStart(5, '0').toUpperCase()}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {},
                        ],
                        [
                            { text: 'CLIENTE:', style: 'tHeaderLabel' },
                            { text: `${credit.client ? credit.client.fullname.toUpperCase() : ''}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {}
                        ],
                        [
                            { text: 'N° DOCUMENTO:', style: 'tHeaderLabel' },
                            { text: `${credit.client ? credit.client.documentNumber : '99999999'}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {}
                        ],
                        [
                            { text: 'IMPORTE:', style: 'tHeaderLabel' },
                            { text: `${credit.currency.symbol + '' + credit.amount}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {}
                        ],
                        [
                            { text: 'ANTICIPO:', style: 'tHeaderLabel' },
                            { text: `${credit.currency.symbol + '' + getTotalAdvance(credit.creditAdvances)}`, style: 'tHeaderLabel', colSpan: 3 },
                            {},
                            {}
                        ],
                    ],
                },
                layout: {
                    hLineWidth: (i, node) => {
                        return (i === 0 || i === 5) ? 1 : 0;
                    },
                    vLineWidth: (i, node) => {
                        return 0;
                    },
                    hLineColor: (i, node) => {
                        return '#000000';
                    },
                },
            },
            //TABLE CUOTAS
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['25%', '*', '25%', '25%'],
                    body: tableData
                },
                layout: {
                    hLineWidth: (i, node) => {
                        return (i === 1 || i === 2 || i == node.table.body.length) ? 1 : 0;
                    },
                    vLineWidth: (i, node) => {
                        return 0;
                    },
                    hLineColor: (i, node) => {
                        return '#000000';
                    },
                },
            },
            { text: '--------------------', style: 'header', margin: [0, 15, 0, 0], alignment: 'center' },
            { text: 'FIRMA', style: 'header', margin: [0, 0, 0, 0], alignment: 'center' },
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentPdf = ContentPdf;
//# sourceMappingURL=content.js.map