"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditTicketPdfController = void 0;
const campus_service_1 = require("../../../company/campus/service/campus.service");
const company_service_1 = require("../../../company/company/service/company.service");
const credit_service_1 = require("../../../credit/credit/service/credit.service");
const http_status_codes_1 = require("http-status-codes");
const creditTicketGeneratorPdf_1 = require("./creditTicketGeneratorPdf");
class CreditTicketPdfController {
    constructor() {
        this.findCreditTicketPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { creditId, companyId, campusId } = req.body;
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const credit = yield credit_service_1.creditService.findOneCredit(Number(creditId));
                if (!credit) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no existe credito' });
                }
                if (company && credit && campus) {
                    const binaryResult = yield creditTicketGeneratorPdf_1.creditTicketGeneratorPdf.generateCreditTicketPdf(campus, company, credit);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new CreditTicketPdfController();
        return this.instance;
    }
}
exports.creditTicketPdfController = CreditTicketPdfController.getInstance();
//# sourceMappingURL=creditTicketPdf.js.map