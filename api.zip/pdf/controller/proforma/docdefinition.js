"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docProformaDefinition = void 0;
const content_1 = require("./content");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const docProformaDefinition = (company, proforma, backAccounts, parameters) => __awaiter(void 0, void 0, void 0, function* () {
    const content = yield (0, content_1.ContentProformaPdf)(company, proforma, backAccounts, parameters);
    const data = {
        // pageSize: {
        //     width: 226.77,
        //     height: 'auto'
        // },
        pageMargins: [
            40, 20, 40, 20
        ],
        info: {
            title: `${proforma.correlative.toString().padStart(5, '0')}-${(0, moment_timezone_1.default)(proforma.registrationDate).tz(company.timeZone).format("yyyy")} `,
            author: 'angel',
            subject: `${proforma.correlative.toString().padStart(5, '0')}-${(0, moment_timezone_1.default)(proforma.registrationDate).tz(company.timeZone).format("yyyy")} `,
            keywords: 'tck, sale',
        },
        content: content,
        styles: {
            centerTable: {
                alignment: 'center',
            },
            rightTable: {
                alignment: 'right',
            },
            importantCenter: {
                fontSize: 12,
                bold: true,
                alignment: 'center',
            },
            documentNumber: {
                fontSize: 10,
                bold: true,
                font: 'Roboto',
                alignment: 'center',
            },
            serieDocument: {
                fontSize: 15,
                bold: true,
                font: 'Roboto',
                alignment: 'center',
            },
            titleLeft: {
                fontSize: 13,
                bold: true,
                font: 'Roboto',
                alignment: 'left',
            },
            titleCenter: {
                fontSize: 13,
                bold: true,
                font: 'Roboto',
                alignment: 'center',
            },
            iconFont: {
                font: 'FontAwesome',
                fontSize: 12,
            },
            info: {
                font: 'LatoFont',
                fontSize: 13
            },
            rowCaption: {
                fontSize: 9,
                bold: true,
                font: 'Roboto',
            },
            textMin: {
                fontSize: 7,
                bold: false,
                font: 'Roboto',
            },
            textLog: {
                fontSize: 12,
                bold: true,
                font: 'Roboto',
            },
            rowValue: {
                fontSize: 8,
                bold: false,
                font: 'Roboto',
            },
            rowValue2: {
                fontSize: 7,
                bold: false,
                font: 'Roboto',
            },
            text: {
                fontSize: 10,
                bold: false,
                font: 'Roboto'
            },
            link: {
                fontSize: 8,
                bold: true,
                margin: [0, 0, 0, 4],
                alignment: 'center',
            },
        },
    };
    return data;
});
exports.docProformaDefinition = docProformaDefinition;
//# sourceMappingURL=docdefinition.js.map