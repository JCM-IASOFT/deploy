"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentPdf = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const convertdata_utils_1 = require("../../../utils/convertdata.utils");
const ContentPdf = (company, campus, proforma, title) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let data = [];
        const tableData = [
            [{ text: `#`, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                { text: `Codigo`, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                { text: `Fecha`, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                { text: `Nombre / Razon social`, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                { text: `Direccion`, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                { text: `Cant`, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                { text: `Moneda`, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                { text: `Estado `, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                { text: `Total`, style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },]
        ];
        const tableProduct = [
            {},
            { text: 'Nombre', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF', colSpan: 2 },
            {},
            { text: 'Categoria', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF', colSpan: 2 },
            {},
            { text: 'Marca', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF', colSpan: 2 },
            {},
            { text: 'Precio U.', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
            { text: 'Cantidad', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
        ];
        if (proforma.length > 0) {
            proforma.forEach((element, index) => {
                tableData.push([
                    { text: `${index + 1}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                    { text: `${element.correlative}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                    { text: `${(0, moment_timezone_1.default)(element.registrationDate).tz(company.timeZone).format('YYYY-MM-DD')}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                    { text: `${element.client ? element.client.fullname : '---'}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0] },
                    { text: `${element.client ? element.client.address : '---'}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                    { text: `${element.totalAmount}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                    { text: `${element.currency.code}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                    { text: `${(0, convertdata_utils_1.getTextStatus)(element.state)}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                    { text: `${element.totalPrice}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] }
                ]);
                tableData.push([
                    { text: 'PRODUCTOS ASOCIADOS', style: 'header', margin: [0, 5, 0, 5], colSpan: 9, alignment: 'left', border: [false, false, false, false] },
                    {},
                    {},
                    {},
                    {},
                    {},
                    {},
                    {},
                    {},
                ]);
                tableData.push([
                    { text: '', border: [false, false, false, false] },
                    { text: 'Nombre', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF', colSpan: 2 },
                    {},
                    { text: 'Categoria', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF', colSpan: 2 },
                    {},
                    { text: 'Marca', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF', colSpan: 2 },
                    {},
                    { text: 'Precio U.', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                    { text: 'Cantidad', style: 'header', margin: [0, 0, 0, 0], fillColor: '#152235', color: '#FFFFFF' },
                ]);
                element.proformaQuoteDetails.forEach(item => {
                    tableData.push([
                        { text: '', border: [false, false, false, false] },
                        { text: `${item.product.description}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0], colSpan: 2 },
                        {},
                        { text: `${item.product.category.name}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0], colSpan: 2 },
                        {},
                        { text: `${item.product.brand.name}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0], colSpan: 2 },
                        {},
                        { text: `${item.product.priceProduct}`, style: 'tHeaderValue', alignment: 'right', margin: [0, 0, 0, 0] },
                        { text: `${element.totalAmount}`, style: 'tHeaderValue', alignment: 'right', margin: [0, 0, 0, 0] }
                    ]);
                });
                tableData.push([
                    { text: '', colSpan: 9, border: [false, false, false, false] },
                    {},
                    {},
                    {},
                    {},
                    {},
                    {},
                    {},
                    {},
                ]);
            });
        }
        else {
            tableData.push([]);
        }
        data = [
            {
                table: {
                    widths: ['45%', '*', '*', '45%'],
                    body: [
                        [
                            // Primera fila
                            { text: `${company.name.toUpperCase()}`, style: 'tHeaderValue', alignment: 'left', margin: [10, 10, 0, 0] },
                            {},
                            {},
                            { text: `Fecha emision: ${(0, moment_timezone_1.default)().tz(company.timeZone).format('YYYY-MM-DD')}`, style: 'tHeaderValue', alignment: 'right', margin: [0, 10, 10, 0] },
                        ],
                        [
                            // Segunda fila
                            { text: `${campus.address.toUpperCase()}`, style: 'tHeaderValue', alignment: 'left', margin: [10, 0, 0, 0] },
                            {},
                            {},
                            { text: `Hora emision: ${(0, moment_timezone_1.default)().tz(company.timeZone).format('HH:mm:ss')}`, style: 'tHeaderValue', alignment: 'right', margin: [0, 0, 10, 0] },
                        ]
                    ]
                },
                layout: 'noBorders'
            },
            [
                {
                    text: 'REPORTE DE PROFORMA', alignment: 'center', style: 'tHeaderValue'
                },
                {
                    text: `${title}`, alignment: 'center', style: 'tHeaderValue'
                },
            ],
            { text: `SEDE: ${campus.name.toUpperCase()}`, style: 'tHeaderValue', alignment: 'left', margin: [10, 0, 0, 0] },
            {
                margin: [10, 0, 10, 0],
                table: {
                    widths: ['6.5%', '13.5%', '11%', '19%', '11.5%', '7.3%', '10%', '11.2%', '10%'],
                    body: tableData,
                },
                layout: {
                    hLineWidth: function (i, node) {
                        return (i === 0) ? 0 : 1;
                    },
                    vLineWidth: function (i, node) {
                        return 1;
                    },
                    hLineColor: function (i, node) {
                        return '#000000';
                    },
                    vLineColor: function (i, node) {
                        return '#000000';
                    }
                }
            },
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentPdf = ContentPdf;
//# sourceMappingURL=content.js.map