"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentPdf = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const report_constant_1 = require("../../../../common/constant/report.constant");
const convertdata_utils_1 = require("../../../utils/convertdata.utils");
const typeOperation_constant_1 = require("../../../../common/constant/typeOperation.constant");
const ContentPdf = (company, campus, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let data = [];
        const tableData = [
            [{ text: `Codigo`, style: 'header', margin: [0, 0, 0, 0] },
                { text: `Nro Transacción`, style: 'header', margin: [0, 0, 0, 0] },
                { text: `Fecha`, style: 'header', margin: [0, 0, 0, 0] },
                { text: `Concepto`, style: 'header', margin: [0, 0, 0, 0] },
                { text: `Tipo Pago`, style: 'header', margin: [0, 0, 0, 0] },
                { text: `Moneda`, style: 'header', margin: [0, 0, 0, 0] },
                { text: `Ingreso`, style: 'header', margin: [0, 0, 0, 0] },
                { text: `Salida`, style: 'header', margin: [0, 0, 0, 0] },
                { text: `Total`, style: 'header', margin: [0, 0, 0, 0] },]
        ];
        if (report.typeReportId == report_constant_1.typeReportConst.TYPES_TRANSACTION) {
            if (keys && keys.length > 0) {
                keys.forEach(key => {
                    tableData.push([
                        { text: `Tipo de transaccion: ${key.toUpperCase()}`, style: 'header', margin: [-10, 5, 0, 10], colSpan: 3 },
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                    ]);
                    group[key].forEach((element, index) => {
                        let valueIncome = '';
                        let valueExpenses = '';
                        switch (report.typeReportId) {
                            case report_constant_1.typeReportConst.TYPES_TRANSACTION:
                                if (element.typeOperation == typeOperation_constant_1.typeTransaction.INGRESO) {
                                    valueIncome = element.totalAmount.toString();
                                    valueExpenses = '-';
                                }
                                else {
                                    valueIncome = '-';
                                    valueExpenses = element.totalAmount.toString();
                                }
                                break;
                            default:
                                valueIncome = '-';
                                valueExpenses = '-';
                        }
                        const details = (0, convertdata_utils_1.wrapText)(element.details, 30);
                        const detailText = details.map(line => line).join('\n');
                        tableData.push([
                            { text: `${index + 1}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${element.financeId.toString().padStart(5, '0')}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${element.deliverDate}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${detailText}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0] },
                            { text: `${element.typePayment}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `PEN`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${valueIncome}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${valueExpenses}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `---`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] }
                        ]);
                    });
                    tableData.push([
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                        { text: `TOTAL ${key.toLocaleUpperCase()}: ${totalGroup[key]}`, style: 'header', margin: [0, 5, 10, 10], alignment: 'right', colSpan: 3 },
                        {},
                        {},
                    ]);
                });
            }
            else {
                tableData.push([]);
            }
        }
        else if (report.typeReportId == report_constant_1.typeReportConst.USERS) {
            if (keys && keys.length > 0) {
                keys.forEach(key => {
                    tableData.push([
                        { text: `Usuario: ${key.toUpperCase()}`, style: 'header', margin: [-10, 5, 0, 10], colSpan: 3 },
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                    ]);
                    group[key].forEach((element, index) => {
                        let valueIncome = '';
                        let valueExpenses = '';
                        switch (report.typeReportId) {
                            case report_constant_1.typeReportConst.USERS:
                                if (element.typeOperation == typeOperation_constant_1.typeTransaction.INGRESO) {
                                    valueIncome = element.totalAmount.toString();
                                    valueExpenses = '-';
                                }
                                else {
                                    valueIncome = '-';
                                    valueExpenses = element.totalAmount.toString();
                                }
                                break;
                            default:
                                valueIncome = '-';
                                valueExpenses = '-';
                        }
                        const details = (0, convertdata_utils_1.wrapText)(element.details, 30);
                        const detailText = details.map(line => line).join('\n');
                        tableData.push([
                            { text: `${index + 1}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${element.financeId.toString().padStart(5, '0')}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${element.deliverDate}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${detailText}`, style: 'tHeaderValue', alignment: 'left', margin: [0, 0, 0, 0] },
                            { text: `${element.typePayment}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `PEN`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${valueIncome}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `${valueExpenses}`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] },
                            { text: `---`, style: 'tHeaderValue', alignment: 'center', margin: [0, 0, 0, 0] }
                        ]);
                    });
                    tableData.push([
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                        { text: `TOTAL ${key.toLocaleUpperCase()}: ${totalGroup[key]}`, style: 'header', margin: [0, 5, 10, 10], alignment: 'right', colSpan: 3 },
                        {},
                        {},
                    ]);
                });
            }
            else {
                tableData.push([]);
            }
        }
        const tablePaymentIngreso = [
            [
                { text: 'Ingresos', style: 'tHeaderValue', margin: [0, 0, 10, 0], alignment: 'right' }
            ]
        ];
        const tablePaymentEgreso = [
            [
                { text: 'Egresos', style: 'tHeaderValue', margin: [0, 0, 10, 0], alignment: 'right' }
            ]
        ];
        if (paymentTypeSums.length > 0) {
            //pagos ingresos
            if (paymentTypeSums[0].length > 0) {
                paymentTypeSums[0].forEach((element) => {
                    let amount = '';
                    let description = '';
                    let count = 0;
                    switch (report.typeReportId) {
                        case report_constant_1.typeReportConst.TYPES_TRANSACTION:
                            amount = element.totalAmount.toString();
                            description = element.description.toString();
                            count = element.count;
                            break;
                        case report_constant_1.typeReportConst.USERS:
                            amount = element.totalAmount.toString();
                            description = element.description.toString();
                            count = element.count;
                            break;
                        default:
                            amount = '-';
                            description = '';
                            count = 0;
                    }
                    tablePaymentIngreso.push([{ text: `${description + '(' + count + ')'}: ${amount}`, style: 'tHeaderValue', margin: [0, 0, 10, 0], alignment: 'right' }]);
                });
            }
            else {
                tablePaymentIngreso.push([{ text: '', margin: [0, 0, 10, 0], alignment: 'right' }]);
            }
            if (paymentTypeSums[1].length > 0) {
                paymentTypeSums[1].forEach((element) => {
                    let amount = '';
                    let description = '';
                    let count = 0;
                    switch (report.typeReportId) {
                        case report_constant_1.typeReportConst.TYPES_TRANSACTION:
                            amount = element.totalAmount.toString();
                            description = element.description.toString();
                            count = element.count;
                            break;
                        case report_constant_1.typeReportConst.USERS:
                            amount = element.totalAmount.toString();
                            description = element.description.toString();
                            count = element.count;
                            break;
                        default:
                            amount = '-';
                            description = '';
                            count = 0;
                    }
                    tablePaymentEgreso.push([{ text: `${description + '(' + count + ')'}: ${amount}`, style: 'tHeaderValue', margin: [0, 0, 10, 0], alignment: 'right' }]);
                });
            }
            else {
                tablePaymentEgreso.push([{ text: '', margin: [0, 0, 10, 0], alignment: 'right' }]);
            }
        }
        else {
            tablePaymentIngreso.push([{ text: '', margin: [0, 0, 10, 0], alignment: 'right' }]);
            tablePaymentEgreso.push([{ text: '', margin: [0, 0, 10, 0], alignment: 'right' }]);
        }
        const tableTotalPayment = [];
        if (typeof totalAmount == 'number') {
            tableTotalPayment.push([{ text: `Total: ${totalAmount}`, style: 'tHeaderValue', margin: [0, 0, 10, 0], alignment: 'right' },]);
        }
        else if (Array.isArray(totalAmount)) {
            tableTotalPayment.push([
                {},
                { text: `Total Ingresos: ${totalAmount[0]}`, style: 'tHeaderValue', margin: [0, 0, 10, 0], alignment: 'right' },
                { text: `Total Egresos: ${totalAmount[1]}`, style: 'tHeaderValue', margin: [0, 0, 10, 0], alignment: 'right' },
            ]);
            tableTotalPayment.push([
                {},
                {},
                { text: `Total: ${totalAmount[2]}`, style: 'tHeaderValue', margin: [0, 0, 10, 0], alignment: 'right' }
            ]);
        }
        let reportTitle = '';
        if (Number(report.period) === report_constant_1.periodConst.DAILY) {
            reportTitle = report_constant_1.periodTitle.DAILY;
        }
        else if (Number(report.period) === report_constant_1.periodConst.MONTHLY) {
            reportTitle = report_constant_1.periodTitle.MONTHLY;
        }
        data = [
            {
                table: {
                    widths: ['45%', '*', '*', '45%'],
                    body: [
                        [
                            // Primera fila
                            { text: `${company.name}`, style: 'tHeaderValue', alignment: 'left', margin: [10, 10, 0, 0] },
                            {},
                            {},
                            { text: `Fecha emision: ${(0, moment_timezone_1.default)().tz(company.timeZone).format('YYYY-MM-DD')}`, style: 'tHeaderValue', alignment: 'right', margin: [0, 10, 10, 0] },
                        ],
                        [
                            // Segunda fila
                            { text: `${campus.address.toUpperCase()}`, style: 'tHeaderValue', alignment: 'left', margin: [10, 0, 0, 0] },
                            {},
                            {},
                            { text: `Hora emision: ${(0, moment_timezone_1.default)().tz(company.timeZone).format('HH:mm:ss')}`, style: 'tHeaderValue', alignment: 'right', margin: [0, 0, 10, 0] },
                        ]
                    ]
                },
                layout: 'noBorders'
            },
            {
                text: `REPORTE DE ${report.typeReport.toUpperCase()} VARIOS`,
                alignment: 'center',
                margin: [0, 10],
                style: 'header'
            },
            {
                text: `INFORME ${reportTitle.toUpperCase()}`,
                alignment: 'center',
                margin: [0, -10, 0, 20],
                style: 'header'
            },
            { text: `Sede: ${campus.name.toUpperCase()}`, style: 'tHeaderValue', alignment: 'left', margin: [10, 0, 0, 0] },
            {
                margin: [0, 0, 0, 0],
                table: {
                    widths: ['6.5%', '13.5%', '11%', '19%', '12.7%', '7.3%', '10%', '10%', '10%'],
                    body: tableData,
                },
                layout: {
                    hLineWidth: (i, node) => {
                        return (i === 0 || i === 1) ? 1 : 0;
                    },
                    vLineWidth: (i, node) => {
                        return 0;
                    },
                    hLineColor: (i, node) => {
                        return '#000000';
                    },
                },
            },
            {
                text: 'TIPOS DE PAGO',
                alignment: 'right',
                style: 'tHeaderValue',
                margin: [0, 0, 10, 0]
            },
            {
                table: {
                    widths: ['50%', '25%', '25%'], // Establece el ancho relativo de cada tabla
                    body: [
                        [
                            {},
                            {
                                margin: [0, 0, 0, 0],
                                table: {
                                    widths: ['*'],
                                    body: tablePaymentIngreso,
                                },
                                layout: {
                                    // fillColor: function (rowIndex: number, node: any, columnIndex: number) {
                                    //     return (rowIndex % 2 === 0) ? '#f2f2f2' : null; // Alternar colores de fondo para filas pares e impares
                                    // },
                                    hLineColor: function (rowIndex, node) {
                                        return '#CCCCCC'; // Color de línea horizontal
                                    },
                                    vLineColor: function (columnIndex, node) {
                                        return '#CCCCCC'; // Color de línea vertical
                                    },
                                    hLineWidth: function (i, node) {
                                        return (i === 0 || i === node.table.body.length) ? 2 : 1; // Grosor de la línea horizontal
                                    },
                                    vLineWidth: function (i, node) {
                                        return (i === 0 || i === node.table.widths.length) ? 2 : 1; // Grosor de la línea vertical
                                    },
                                },
                            },
                            {
                                margin: [0, 0, 0, 0],
                                table: {
                                    widths: ['*'],
                                    body: tablePaymentEgreso,
                                },
                                layout: {
                                    // fillColor: function (rowIndex: number, node: any, columnIndex: number) {
                                    //     return (rowIndex % 2 === 0) ? '#f2f2f2' : null; // Alternar colores de fondo para filas pares e impares
                                    // },
                                    hLineColor: function (rowIndex, node) {
                                        return '#CCCCCC'; // Color de línea horizontal
                                    },
                                    vLineColor: function (columnIndex, node) {
                                        return '#CCCCCC'; // Color de línea vertical
                                    },
                                    hLineWidth: function (i, node) {
                                        return (i === 0 || i === node.table.body.length) ? 2 : 1; // Grosor de la línea horizontal
                                    },
                                    vLineWidth: function (i, node) {
                                        return (i === 0 || i === node.table.widths.length) ? 2 : 1; // Grosor de la línea vertical
                                    },
                                },
                            },
                        ]
                    ],
                },
                alignment: 'right',
                layout: 'noBorders'
            },
            {
                style: 'tableContainer',
                table: {
                    widths: ['50%', '25%', '25%'], // Establece el ancho relativo de cada columna
                    body: tableTotalPayment,
                },
                alignment: 'right',
                layout: 'noBorders'
            },
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentPdf = ContentPdf;
//# sourceMappingURL=content.js.map