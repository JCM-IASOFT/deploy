"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentClosingPdf = void 0;
const getTotalsTransactions = (finances, typeOperation) => __awaiter(void 0, void 0, void 0, function* () {
    let sumAll = 0;
    finances.forEach(element => {
        if (element.typeOperation === typeOperation) {
            element.paymentTransaction.forEach(item => {
                sumAll += parseFloat(item.amount.toString());
            });
        }
    });
    return sumAll;
});
const getTotalsServices = (services) => __awaiter(void 0, void 0, void 0, function* () {
    let sumAll = 0;
    services.forEach(element => {
        element.payments.forEach(item => {
            sumAll += parseFloat(item.amount.toString());
        });
    });
    return sumAll;
});
const getFinances = (finances, typeOperation) => __awaiter(void 0, void 0, void 0, function* () {
    const tableData = [];
    let sumAll = 0;
    finances.forEach(element => {
        if (element.typeOperation === typeOperation) {
            element.paymentTransaction.forEach(item => {
                tableData.push([
                    { text: element.typeTransaction.description, style: 'important', margin: [0, 0, 0, 0] },
                    { text: item.paymentType.description, style: 'important', margin: [0, 0, 0, 0] },
                    { text: parseFloat(item.amount.toString()).toFixed(2), style: 'important', margin: [0, 0, 0, 0] }
                ]);
                sumAll += parseFloat(item.amount.toString());
            });
        }
    });
    tableData.push([{}, { text: 'TOTAL: ', style: 'important', margin: [0, 0, 0, 0] }, { text: sumAll.toFixed(2), style: 'important', margin: [0, 0, 0, 0] }]);
    return tableData;
});
const getServices = (services) => __awaiter(void 0, void 0, void 0, function* () {
    const tableData = [];
    let sumAll = 0;
    services.forEach(element => {
        element.payments.forEach(item => {
            tableData.push([
                { text: item.paymentType.description, style: 'important', margin: [0, 0, 0, 0] },
                { text: parseFloat(item.amount.toString()).toFixed(2), style: 'important', margin: [0, 0, 0, 0] }
            ]);
            sumAll += parseFloat(item.amount.toString());
        });
    });
    tableData.push([{ text: 'TOTAL: ', style: 'important', margin: [0, 0, 0, 0] }, { text: sumAll.toFixed(2), style: 'important', margin: [0, 0, 0, 0] }]);
    return tableData;
});
const ContentClosingPdf = (cashboxdetails, user, campus) => __awaiter(void 0, void 0, void 0, function* () {
    // try {
    //     let data: any[] = []
    //     const servicesData: TableDataType[][] = await getServices(cashboxdetails.services)
    //     const financesIngresoData: TableDataType[][] = await getFinances(cashboxdetails.finances, typeOperation.ingreso)
    //     const financesEgresoData: TableDataType[][] = await getFinances(cashboxdetails.finances, typeOperation.egreso)
    //     const totalIngresos = await getTotalsTransactions(cashboxdetails.finances, typeOperation.ingreso)
    //     const totalSalidas = await getTotalsTransactions(cashboxdetails.finances, typeOperation.egreso)
    //     const totalServices = await getTotalsServices(cashboxdetails.services)
    //     const currentDate = new Date()
    //     data = [
    //         { text: campus.name, style: 'header', margin: [0, 5, 0, 0] },
    //         { text: campus.address, style: 'header' },
    //         { text: 'CIERRE DE CAJA', style: 'header', margin: [0, 5, 0, 2] },
    //         {
    //             margin: [0, 5, 0, 0],
    //             table: {
    //                 widths: ['40%', '60%'],
    //                 body: [
    //                     [
    //                         { text: 'FECHA:', style: 'tHeaderLabel' },
    //                         { text: moment(currentDate).tz(campus.company.timeZone).format('LLL'), style: 'tHeaderValue' },
    //                     ],
    //                     [
    //                         { text: 'RESPONSABLE:', style: 'tHeaderLabel' },
    //                         { text: user.name + ' ' + user.fullname, style: 'tHeaderValue' },
    //                     ],
    //                 ]
    //             },
    //             layout: 'noBorders',
    //         },
    //         { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0] },
    //         { text: '****** SERVICIOS *******', style: 'header', margin: [0, 0, 0, 0] },
    //         // ** TABLA PRODUCTOS            
    //         {
    //             margin: [0, 0, 0, 0],
    //             table: {
    //                 widths: ['60%', '40%'],
    //                 body: servicesData,
    //             },
    //             layout: 'noBorders',
    //         },
    //         { text: '************ TRANSACCIONES ***************', style: 'header', margin: [0, 0, 0, 0] },
    //         { text: '****** INGRESO *******', style: 'header', margin: [0, 0, 0, 0] },
    //         // ** TABLA PRODUCTOS            
    //         {
    //             margin: [0, 0, 0, 0],
    //             table: {
    //                 widths: ['50%', '30%', '20%'],
    //                 body: financesIngresoData,
    //             },
    //             layout: 'noBorders',
    //         },
    //         { text: '****** SALIDAS *******', style: 'header', margin: [0, 0, 0, 0] },
    //         // ** TABLA PRODUCTOS            
    //         {
    //             margin: [0, 0, 0, 0],
    //             table: {
    //                 widths: ['50%', '30%', '20%'],
    //                 body: financesEgresoData,
    //             },
    //             layout: 'noBorders',
    //         },
    //         { text: '*****************************************************', style: 'header', margin: [0, 0, 0, 0] },
    //         // ** TABLA PRODUCTOS            
    //         {
    //             margin: [0, 0, 0, 0],
    //             table: {
    //                 widths: ['50%', '50%'],
    //                 body: [
    //                     [
    //                         { text: 'MONTO APERTURA: ', style: 'important', margin: [0, 0, 0, 0] },
    //                         { text: cashboxdetails.openingAmount, style: 'important', margin: [0, 0, 0, 0] }
    //                     ],
    //                     [
    //                         { text: 'TOTAL SERVICIOS: ', style: 'important', margin: [0, 0, 0, 0] },
    //                         { text: totalServices, style: 'important', margin: [0, 0, 0, 0] }
    //                     ],
    //                     [
    //                         { text: 'TOTAL INGRESOS: ', style: 'important', margin: [0, 0, 0, 0] },
    //                         { text: totalIngresos, style: 'important', margin: [0, 0, 0, 0] }
    //                     ],
    //                     [
    //                         { text: 'TOTAL EGRESOS: ', style: 'important', margin: [0, 0, 0, 0] },
    //                         { text: totalSalidas, style: 'important', margin: [0, 0, 0, 0] }
    //                     ],
    //                     [
    //                         { text: 'SALDO: ', style: 'important', margin: [0, 0, 0, 0] },
    //                         { text: ((totalIngresos.valueOf() + totalServices.valueOf() + parseFloat(cashboxdetails.openingAmount.toString())) - totalSalidas.valueOf()), style: 'important', margin: [0, 0, 0, 0] }
    //                     ]
    //                 ],
    //             },
    //             layout: 'noBorders',
    //         },
    //     ];
    //     return data;
    // } catch (error) {
    //     return []
    // }
    return [];
});
exports.ContentClosingPdf = ContentClosingPdf;
//# sourceMappingURL=content.js.map