"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentStikerPdf = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const canvas_1 = require("canvas");
const jsbarcode_1 = __importDefault(require("jsbarcode"));
require("moment/locale/es");
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
const downloadLogo_utils_1 = require("../../utils/downloadLogo.utils");
const rotate = (original, degrees) => {
    const width = original.canvas.width;
    const height = original.canvas.height;
    const rotatedWidth = Math.abs(Math.cos(degrees)) * width + Math.abs(Math.sin(degrees)) * height;
    const rotatedHeight = Math.abs(Math.sin(degrees)) * width + Math.abs(Math.cos(degrees)) * height;
    const rotatedCanvas = (0, canvas_1.createCanvas)(rotatedWidth, rotatedHeight);
    const context = rotatedCanvas.getContext('2d');
    const angle = degrees * Math.PI / 180;
    context.save();
    context.translate(rotatedWidth / 2, rotatedHeight / 2);
    context.rotate(angle);
    context.drawImage(original.canvas, -width / 2, -height / 2, width, height);
    context.restore();
    return context;
};
const generateBarcodeAsBase64 = (text, width, height) => {
    const canvas = (0, canvas_1.createCanvas)(width, height);
    const context = canvas.getContext('2d');
    (0, jsbarcode_1.default)(canvas, text, {
        format: 'CODE128', displayValue: false, width: 7,
        height: 200,
    });
    const rotatedContext = rotate(context, -90);
    const barcodeBase64 = rotatedContext.canvas.toDataURL();
    return barcodeBase64;
};
const ContentStikerPdf = (company, service, parameters) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    try {
        let data = [];
        const tableData = [];
        const imageBuffer = yield (0, downloadLogo_utils_1.downloadImage)(company.image);
        const logoCompany = (0, downloadLogo_utils_1.convertImageToBase64)(imageBuffer);
        const message = ((_a = parameters.find(element => element.name === 'message')) === null || _a === void 0 ? void 0 : _a.description) || '';
        const typeCode = ((_b = parameters.find(element => element.name === 'typecode')) === null || _b === void 0 ? void 0 : _b.description) || '';
        service.serviceDevices.forEach(element => {
            tableData.push({
                columns: [
                    {
                        stack: [
                            {
                                image: 'data:image/jpg;base64,' + logoCompany,
                                fit: [20, 20],
                                alignment: 'left',
                            },
                            { text: 'Serie: ' + element.serial, margin: [0, 4, 0, 0], style: 'tlabel' },
                            { text: 'Antecedente: ' + element.reason, style: 'tlabel' },
                            { text: 'Fecha Entrega: ' + (0, moment_timezone_1.default)(service.deliverDate).tz(company.timeZone).format('LL'), style: 'tlabel' },
                            { text: 'Observaciones: ' + element.observations, style: 'tlabel' },
                            { text: 'Siclo de trabajo: ' + element.workCycle, style: 'tlabel' },
                            { text: '-----------------------------------------------------------------------------------', style: 'tlabel' },
                            { text: message, style: 'tlabel' },
                        ],
                        width: '70%',
                        alignment: 'left',
                        margin: [5, 5, 5, 5]
                    },
                    typeCode === parameter_constant_1.TypeCode.QR ?
                        {
                            stack: [
                                {
                                    qr: company.ruc,
                                    fit: 80,
                                    alignment: 'center',
                                    eccLevel: 'Q',
                                    margin: [0, 35, 10, 3],
                                },
                                { text: `${service.serviceId.toString().padStart(5, '0')}`, style: 'tProductsBody', alignment: 'center', },
                            ],
                            width: '30%',
                            margin: [3, 0, 0, 3]
                        }
                        :
                            {
                                stack: [
                                    {
                                        image: generateBarcodeAsBase64(service.serviceId.toString().padStart(5, '0'), 100, 80),
                                        width: 80, // Ancho deseado
                                        height: 100, // Mantenemos la altura original
                                        alignment: 'center',
                                        margin: [3, 14, 0, 3],
                                    },
                                ],
                                width: '30%',
                                margin: [3, 0, 0, 3]
                            }
                ]
            });
        });
        if (logoCompany) {
            data = tableData;
        }
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentStikerPdf = ContentStikerPdf;
//# sourceMappingURL=content.js.map