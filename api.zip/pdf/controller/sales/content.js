"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentSalesPdf = void 0;
const modelslibrary_1 = require("modelslibrary");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const convertdata_utils_1 = require("../../utils/convertdata.utils");
const getProductsSalePDF = (sales) => {
    const products = sales.modality === modelslibrary_1.SaleModality.Product ? sales.salesDetails.map((product) => [
        { text: `${product.product.description}`, style: 'body', alignment: 'left' },
        { text: `${product.amount}`, style: 'body', alignment: 'center' },
        {
            text: `${Number(product.price).toFixed(2)}`,
            style: 'body',
            alignment: 'center',
        },
        {
            text: `${Number(product.total).toFixed(2)}`,
            style: 'body',
            alignment: 'right',
        },
    ]) :
        sales.salesFrees.map((product) => [
            { text: `${product.description}`, style: 'body', alignment: 'left' },
            { text: `${product.amount}`, style: 'body', alignment: 'center' },
            {
                text: `${Number(product.price).toFixed(2)}`,
                style: 'body',
                alignment: 'center',
            },
            {
                text: `${Number(product.total).toFixed(2)}`,
                style: 'body',
                alignment: 'right',
            },
        ]);
    return products;
};
const getPaymentSalesPDF = (paymentSales, sales) => {
    const tablePaymentTypes = [];
    paymentSales.forEach(element => {
        tablePaymentTypes.push([
            { text: element.paymentType.description + ": ", style: { bold: true, fontSize: 8 } },
            { text: `${sales.currency.symbol} ` + element.amount.toString(), style: { bold: true, fontSize: 8 } },
        ]);
    });
    return tablePaymentTypes;
};
const ContentSalesPdf = (company, sales) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let data = [
            {
                text: `*** ${sales.invoice.name} - ${sales.correlative} ***`,
                style: 'header',
                fontSize: 10,
            },
            { text: `${company.name}`, style: 'body' },
            { text: `${sales.campus.address}`, style: 'body' },
            {
                text: `${company.ruc.toString().startsWith('10') ? 'RUS' : 'RUC'}: ${company.ruc}`,
                style: 'body',
            },
            { text: `Telf.: ${sales.campus.phone}`, style: 'body' },
            { text: `Fecha emisión: ${(0, moment_timezone_1.default)(sales.date).tz(company.timeZone).format("DD-MM-YYYY hh:mm A")}`, style: 'body' },
            {
                text: {
                    text: `Cliente: ${sales.client ? sales.client.fullname : 'Cliente varios'}`,
                    style: 'body',
                },
            },
            {
                table: {
                    widths: ['50%', '12%', '18%', '20%'],
                    body: [
                        [
                            { text: 'Descripción', style: 'tHeaderLabel' },
                            { text: 'Cant', style: 'tHeaderLabel' },
                            { text: 'Precio', style: 'tHeaderLabel' },
                            { text: 'Pre-Total', style: 'tHeaderLabel' },
                        ],
                        ...getProductsSalePDF(sales),
                    ],
                },
                layout: {
                    hLineWidth: (i) => {
                        if (i < 2)
                            return 0.5;
                        return 0;
                    },
                    vLineWidth: () => {
                        return 0;
                    },
                },
                style: { alignment: 'center' },
            },
            {
                marginTop: 8,
                table: {
                    widths: ['80%', '20%'],
                    body: [
                        [
                            {
                                text: 'IMPORTE TOTAL',
                                style: { bold: true, fontSize: 8 },
                                alignment: 'left',
                            },
                            {
                                text: `${Number(sales.totalPayment).toFixed(2)}`,
                                style: { blod: true, fontSize: 8 },
                            },
                        ],
                    ],
                },
                layout: {
                    hLineWidth: (i) => {
                        if (i == 0)
                            return 0.5;
                        return 0;
                    },
                    vLineWidth: () => {
                        return 0;
                    },
                },
            },
            {
                text: `Son: ${(0, convertdata_utils_1.convertNumberToTextSUNAT)(sales.totalPayment).toUpperCase()} ${sales.currency.currencyName}`,
                style: 'body'
            },
            { text: '\n' },
            { text: 'FORMAS DE PAGO', style: 'body', alignment: 'left', margin: [0, 0, 0, 0] },
            {
                margin: [0, 0, 0, 0],
                table: {
                    widths: ['50%', '50%'],
                    body: getPaymentSalesPDF(sales.paymentSales, sales) ? getPaymentSalesPDF(sales.paymentSales, sales) :
                        [
                            { text: '' },
                            { text: '' }
                        ]
                },
                layout: 'noBorders',
            },
            { text: '-----------------------------' },
            {
                margin: [0, 0, 0, 0],
                table: {
                    widths: ['50%', '50%'],
                    body: [
                        [{
                                text: `Pago en total: `,
                                style: 'body',
                            },
                            {
                                text: `${sales.currency.symbol}` + parseFloat(sales.totalPayment.toString()).toFixed(2),
                                style: 'body',
                            },
                        ],
                        [
                            {
                                text: `Vuelto: `,
                                style: 'body',
                            },
                            {
                                text: `${sales.currency.symbol}` + parseFloat(sales.change.toString()).toFixed(2),
                                style: 'body',
                            },
                        ]
                    ]
                },
                layout: 'noBorders',
            },
            { text: '\n' },
            {
                text: `Cajero: ${sales.seller.name}`,
                style: { bold: true, fontSize: 8 },
                alignment: 'center',
            },
            {
                text: `Vendedor: ${sales.seller.name}`,
                style: { bold: true, fontSize: 8 },
                alignment: 'center',
            },
            /*{
                text: `${dataTicket.ticket.goodbyeMessage}`,
            },*/
            {
                marginTop: 15,
                text: '** GRACIAS POR SU COMPRA **',
                alignment: 'center',
                marginBottom: 15,
            },
        ];
        return data;
    }
    catch (error) {
        return [];
    }
});
exports.ContentSalesPdf = ContentSalesPdf;
//# sourceMappingURL=content.js.map