"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pdfController = void 0;
const pdfmake_1 = __importDefault(require("pdfmake"));
const docdefinition_1 = require("./service/content/docdefinition");
const http_status_codes_1 = require("http-status-codes");
const docdefinition_2 = require("./sales/docdefinition");
const docdefinition_3 = require("./stiker/docdefinition");
const docdefinition_4 = require("./closingboxmoney/docdefinition");
const docdefinition_5 = require("./report/period_income_expenses/docdefinition");
const docdefinition_6 = require("./report/range_types_income_expenses/docdefinition");
const docdefinition_7 = require("./waitingticket/docdefinition");
const parameter_constant_1 = require("../../common/constant/parameter.constant");
const docdefinition_8 = require("./report/period_typeTransaction_user/docdefinition");
const docdefinition_9 = require("./finance/docdefinition");
const docdefinition_10 = require("./proforma/docdefinition");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const docdefinition_11 = require("./technicalreport/docdefinition");
const docdefinition_12 = require("./cashWithdrawals/docdefinition");
const docdefinition_13 = require("./startService/docdefinition");
const cashboxdetail_service_1 = require("../../accounting/cashboxdetail/service/cashboxdetail.service");
const company_service_1 = require("../../company/company/service/company.service");
const sales_service_1 = require("../../sales/sales/service/sales.service");
const campus_service_1 = require("../../company/campus/service/campus.service");
const service_service_1 = require("../../support/service/service/service.service");
const parameter_service_1 = require("../../system/parameter/service/parameter.service");
const user_service_1 = require("../../system/user/service/user.service");
const proformaquote_service_1 = require("../../sales/proformaquote/service/proformaquote.service");
const bankAccount_service_1 = require("../../company/bankAccount/service/bankAccount.service");
const finance_service_1 = require("../../accounting/finance/service/finance.service");
const cashWithdrawals_service_1 = require("../../accounting/cashWithdrawals/service/cashWithdrawals.service");
const save_error_1 = require("../../common/handler/save.error");
const font_1 = require("./font");
class PdfController {
    constructor() {
        this.generateServicePdf = (campus, company, service) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_1.docDefinition)(campus, company, service);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        //campus, parameters, waitingticket, quantity
        this.generateWaitingTicketPdf = (campus, parameters, waitingticket, quantity) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_7.docWaitingTicketDefinition)(campus, parameters, waitingticket, quantity);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                save_error_1.logger.info(`generateWaitingTicketPdf by : ${error}`);
            }
        });
        this.generateClosingPdf = (cashboxdetails, user, campus) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_4.docClosingDefinition)(cashboxdetails, user, campus);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.generateStikerPdf = (company, service, parameters) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_3.docStikerDefinition)(company, service, parameters);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.generateProformaPdf = (company, proforma, backAccounts, parameters) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_10.docProformaDefinition)(company, proforma, backAccounts, parameters);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                save_error_1.logger.error(`generateProformaPdf by ${error.message}`);
            }
        });
        this.generateTechnicalReportPdf = (company, service, dateoOfIssue, technical, affair, finalReport) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_11.docTechnicalReportDefinition)(company, service, dateoOfIssue, technical, affair, finalReport);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.generateSalesPdf = (company, sales) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_2.docSalesDefinition)(company, sales);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                save_error_1.logger.error(`generateSalesPdf by : ${error.message}`);
            }
        });
        this.generateReportPeriodSimplePdf = (company, campus, summary, paymentTypeSums, totalAmount, report) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_5.docReportPeriodDefinition)(company, campus, summary, paymentTypeSums, totalAmount, report);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.generateReportPeriodGroupPdf = (company, campus, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_8.docReportPeriodTUDefinition)(company, campus, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.generateReportRangePdf = (company, campus, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_6.docReportRangeDefinition)(company, campus, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.generateTransactionPdf = (finance, campus, company) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_9.docFinanceDefinition)(finance, campus, company);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.generateCashWithdrawalsPdf = (cashWithdrawals, campus, company) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_12.docCashWithdrawalsDefinition)(cashWithdrawals, campus, company);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.generateStartServicePdf = (service, campus, company) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_13.docStartServiceDefinition)(service, campus, company);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
            }
        });
        this.findSalesPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { salesId, companyId, campusId } = req.body;
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                const sales = yield sales_service_1.salesService.findOneSales(Number(salesId));
                if (!sales) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no hay ventas' });
                }
                if (sales) {
                    const binaryResult = yield this.generateSalesPdf(company, sales);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findServicePdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { serviceId, companyId, campusId } = req.body;
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const service = yield service_service_1.serviceService.findOneService(Number(serviceId));
                if (!service) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no hay servico' });
                }
                if (company && service && campus) {
                    const binaryResult = yield this.generateServicePdf(campus, company, service);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findWaitingTicketPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { quantity, companyId, waitingticket } = req.body;
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                const campus = yield campus_service_1.campusService.findOneCampus(Number(waitingticket.sector.campusId));
                const parameters = yield parameter_service_1.parameterService.findParameter(parameter_constant_1.GroupConstant.WAITING_TICKET.GROUP, waitingticket.sector.campusId);
                if (!quantity) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no hay servico' });
                }
                if (company && quantity && campus) {
                    const binaryResult = yield this.generateWaitingTicketPdf(campus, parameters, waitingticket, quantity);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findClosingPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId, userId, cashBoxDetailId } = req.body;
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const user = yield user_service_1.userService.findOneUser(userId);
                const cashboxdetails = yield cashboxdetail_service_1.cashboxdetailService.findOneCashBoxDetail(cashBoxDetailId);
                if (!cashboxdetails) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no hay medios de pago' });
                }
                if (campus && user && cashboxdetails) {
                    const binaryResult = yield this.generateClosingPdf(cashboxdetails, user, campus);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findStikerPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { serviceId, companyId } = req.body;
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                const service = yield service_service_1.serviceService.findOneService(Number(serviceId));
                const parameters = yield parameter_service_1.parameterService.findParameter(parameter_constant_1.GroupConstant.STIKER_PRINTER.GROUP, service.campusId);
                if (!service || !parameters) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no hay servico' });
                }
                if (company && service && parameters) {
                    const binaryResult = yield this.generateStikerPdf(company, service, parameters);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        /**
         * - REPORT DE PROFORMAS Y COTIZACIONES
         */
        this.findProformaPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { proformaQuoteId, companyId } = req.body;
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                const proforma = yield proformaquote_service_1.proformaQuoteService.findOneProformaQuote(Number(proformaQuoteId));
                const backAccounts = yield bankAccount_service_1.bankAccountService.findBankAccount(Number(companyId));
                const parameters = yield parameter_service_1.parameterService.findSomeParameter([parameter_constant_1.GroupConstant.PROFORMA.GROUP], proforma.campusId);
                if (!proforma || !parameters) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no hay servico' });
                }
                if (company && proforma && parameters) {
                    const binaryResult = yield this.generateProformaPdf(company, proforma, backAccounts, parameters);
                    res.setHeader('Content-disposition', `attachment; filename=${proforma.correlative.toString().padStart(5, '0')}-${(0, moment_timezone_1.default)(proforma.registrationDate).tz(company.timeZone).format("yyyy")}.pdf`);
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        /**
         *  * INFORME TECNICO
         * @param req * (serviceId,compayId,fecha de emision,tecnico,razon,informe final,reporte final)
         * @param res
         */
        this.findTechnicalReportPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { serviceId, companyId, dateoOfIssue, technical, affair, finalReport } = req.body;
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                const service = yield service_service_1.serviceService.findOneService(Number(serviceId));
                if (!service) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no hay servico' });
                }
                if (company && service) {
                    const binaryResult = yield this.generateTechnicalReportPdf(company, service, dateoOfIssue, technical, affair, finalReport);
                    res.setHeader('Content-disposition', `attachment; filename=${service.serviceId.toString().padStart(5, '0')}-${(0, moment_timezone_1.default)(service.registrationDate).tz(company.timeZone).format("yyyy")}.pdf`);
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findReportPeriodSimplePdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId, companyId, summary, paymentTypeSums, totalAmount, report } = req.body;
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                if (summary && (paymentTypeSums || totalAmount) && report) {
                    const binaryResult = yield this.generateReportPeriodSimplePdf(company, campus, summary, paymentTypeSums, totalAmount, report);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findReportPeriodGroupPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId, companyId, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup } = req.body;
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                if (summary && (paymentTypeSums || totalAmount) && report) {
                    const binaryResult = yield this.generateReportPeriodGroupPdf(company, campus, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findReportRangePdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId, companyId, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup } = req.body;
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                if (summary && (paymentTypeSums || totalAmount) && report) {
                    const binaryResult = yield this.generateReportRangePdf(company, campus, summary, paymentTypeSums, totalAmount, report, keys, group, totalGroup);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findTransactionPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { financeId, campusId, companyId } = req.body;
                const finance = yield finance_service_1.financeService.findOneTransaction(financeId, campusId);
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                if (finance && campus && company) {
                    const binaryResult = yield this.generateTransactionPdf(finance, campus, company);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findCashWithdrawalsPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { cashWithdrawalsId, campusId, companyId } = req.body;
                const cashWithdrawals = yield cashWithdrawals_service_1.cashWithdrawalsService.findOneCashWithdrawals(campusId, cashWithdrawalsId);
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                if (cashWithdrawals && campus && company) {
                    const binaryResult = yield this.generateCashWithdrawalsPdf(cashWithdrawals, campus, company);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findStartServicePdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { serviceId, campusId, companyId } = req.body;
                const service = yield service_service_1.serviceService.findOneService(serviceId);
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                if (service && campus && company) {
                    const binaryResult = yield this.generateStartServicePdf(service, campus, company);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new PdfController();
        return this.instance;
    }
}
exports.pdfController = PdfController.getInstance();
//# sourceMappingURL=pdf.controller.js.map