"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generatorInventoryPdf = void 0;
const pdfmake_1 = __importDefault(require("pdfmake"));
const docdefinition_1 = require("./product/kardex/docdefinition");
const save_error_1 = require("../../../common/handler/save.error");
const font_1 = require("../font");
const docdefinition_2 = require("./product/availableStock/docdefinition");
class GeneratorInventoryPdf {
    constructor() {
        this.generateKardexPdf = (kardexDefinition) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_1.docKardexDefinition)(kardexDefinition);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                save_error_1.logger.info(`generateInventoryPdf for : ${error.message}`);
            }
        });
        this.generateAvailablePdf = (availableDefinition) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_2.docAvailableDefinition)(availableDefinition);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                save_error_1.logger.info(`generateInventoryPdf for : ${error.message}`);
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new GeneratorInventoryPdf();
        return this.instance;
    }
}
exports.generatorInventoryPdf = GeneratorInventoryPdf.getInstance();
//# sourceMappingURL=genInventoryPdf.js.map