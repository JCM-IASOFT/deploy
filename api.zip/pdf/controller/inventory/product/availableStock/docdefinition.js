"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docAvailableDefinition = void 0;
const content_1 = require("./content");
const style_1 = require("../../../styles/style");
const downloadLogo_utils_1 = require("../../../../utils/downloadLogo.utils");
const docAvailableDefinition = (availableDefinition) => __awaiter(void 0, void 0, void 0, function* () {
    const content = yield (0, content_1.contentAvailablePdf)(availableDefinition);
    const logo = yield (0, downloadLogo_utils_1.downloadImage)(availableDefinition.company.image);
    const logoBase64 = (0, downloadLogo_utils_1.convertImageToBase64)(logo);
    const data = {
        pageMargins: [20, 60, 20, 40], // Márgenes más grandes para el encabezado
        info: {
            title: 'F001-000001',
            author: 'JCM',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        header: {
            columns: [
                {
                    image: 'data:image/png;base64,' + logoBase64,
                    width: 20,
                    height: 20,
                    alignment: 'left',
                    margin: [20, 20, 0, 0],
                },
            ],
        },
        content: content,
        defaultStyle: {
            font: 'Roboto'
        },
        styles: style_1.pdfStyles,
    };
    return data;
});
exports.docAvailableDefinition = docAvailableDefinition;
//# sourceMappingURL=docdefinition.js.map