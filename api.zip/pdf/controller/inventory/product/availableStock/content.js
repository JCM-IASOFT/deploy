"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.contentAvailablePdf = exports.fetchAndConvertToBase64 = void 0;
const axios_1 = __importDefault(require("axios"));
const fetchAndConvertToBase64 = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axios_1.default.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 5000
        });
        const base64Image = Buffer.from(response.data, 'binary').toString('base64');
        return base64Image;
    }
    catch (error) {
        return null;
    }
});
exports.fetchAndConvertToBase64 = fetchAndConvertToBase64;
const generateHeaderTable = () => {
    return {
        table: {
            widths: ['*'],
            body: [
                [
                    {
                        text: 'REPORTES PRODUCTOS CON STOCK',
                        alignment: 'center',
                        style: 'header',
                        fillColor: '#17B453',
                        color: '#FFFFFF',
                        border: [true, true, true, true]
                    },
                ],
            ]
        },
        layout: 'noBorders',
    };
};
const generateMovement = (products) => {
    let availableData = [];
    // Agregamos el encabezado de la tabla
    availableData.push([
        { text: 'CODIGO', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'DESCRIPCIÓN', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'CATEGORIA', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'STK ACT', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'STK MIN', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
    ]);
    // Iteramos sobre el array kardex para rellenar las filas de la tabla
    products.forEach(element => {
        var _a;
        availableData.push([
            { text: element.code, style: 'infoItem' },
            { text: element.description.toString(), style: 'infoItem' },
            { text: (_a = element.category) === null || _a === void 0 ? void 0 : _a.name, style: 'infoItem' },
            { text: element.stock.toString(), style: 'infoItem' },
            { text: element.stockMin.toString(), style: 'infoItem' }
        ]);
    });
    // Estructura de la tabla en pdfmake
    const table = {
        table: {
            headerRows: 1,
            widths: ['10%', '40%', '30%', '10%', '10%'],
            body: availableData
        }
    };
    return table;
};
const contentAvailablePdf = (availableDefinition) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const header = generateHeaderTable();
        const movement = generateMovement(availableDefinition.products);
        const availableDoc = [
            Object.assign({}, header),
            Object.assign({}, movement),
        ];
        return availableDoc;
    }
    catch (error) {
        return [];
    }
});
exports.contentAvailablePdf = contentAvailablePdf;
//# sourceMappingURL=content.js.map