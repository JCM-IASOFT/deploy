"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docKardexDefinition = void 0;
const content_1 = require("./content");
const style_1 = require("../../../styles/style");
const downloadLogo_utils_1 = require("../../../../utils/downloadLogo.utils");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const docKardexDefinition = (kardexDefinition) => __awaiter(void 0, void 0, void 0, function* () {
    const content = yield (0, content_1.contentKardexPdf)(kardexDefinition);
    const logo = yield (0, downloadLogo_utils_1.downloadImage)(kardexDefinition.company.image);
    const logoBase64 = (0, downloadLogo_utils_1.convertImageToBase64)(logo);
    const data = {
        pageOrientation: 'landscape',
        pageMargins: [20, 60, 20, 40], // Márgenes más grandes para el encabezado
        info: {
            title: 'F001-000001',
            author: 'JCM',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        header: {
            columns: [
                {
                    image: 'data:image/png;base64,' + logoBase64,
                    width: 20,
                    height: 20,
                    alignment: 'left',
                    margin: [20, 20, 0, 0],
                },
                {
                    text: `${(0, moment_timezone_1.default)(kardexDefinition.startDate).tz(kardexDefinition.timeZone).format("L")} - ${(0, moment_timezone_1.default)(kardexDefinition.endDate).tz(kardexDefinition.timeZone).format("L")}`,
                    alignment: 'right',
                    style: 'infoLabel',
                    margin: [0, 20, 20, 0],
                },
            ],
        },
        content: content,
        defaultStyle: {
            font: 'Roboto'
        },
        styles: style_1.pdfStyles,
    };
    return data;
});
exports.docKardexDefinition = docKardexDefinition;
//# sourceMappingURL=docdefinition.js.map