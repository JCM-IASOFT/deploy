"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.contentKardexPdf = exports.fetchAndConvertToBase64 = void 0;
const axios_1 = __importDefault(require("axios"));
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const fetchAndConvertToBase64 = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axios_1.default.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 5000
        });
        const base64Image = Buffer.from(response.data, 'binary').toString('base64');
        return base64Image;
    }
    catch (error) {
        return null;
    }
});
exports.fetchAndConvertToBase64 = fetchAndConvertToBase64;
const generateHeaderTable = () => {
    return {
        table: {
            widths: ['*'],
            body: [
                [
                    {
                        text: 'REPORTE DE KARDEX',
                        alignment: 'center',
                        style: 'header',
                        fillColor: '#17B453',
                        color: '#FFFFFF',
                        border: [true, true, true, true]
                    },
                ],
            ]
        },
        layout: 'noBorders',
    };
};
const generateProductInfo = (product) => {
    var _a;
    return {
        table: {
            widths: ['*'],
            body: [
                [
                    {
                        text: `PRODUCTO:  ${product.description}`,
                        alignment: 'left',
                        style: 'infoLabel',
                        border: [true, true, true, true]
                    },
                ],
                [
                    {
                        text: `UNIDAD M.:  ${(_a = product === null || product === void 0 ? void 0 : product.unitMeasurement) === null || _a === void 0 ? void 0 : _a.name}`,
                        alignment: 'left',
                        style: 'infoLabel',
                        border: [true, true, true, true]
                    },
                ],
                [
                    {
                        text: `MINIMO:  ${product.stockMin}`,
                        alignment: 'left',
                        style: 'infoLabel',
                        border: [true, true, true, true]
                    }
                ],
                [
                    {
                        text: `MAXIMO:  ${product.stockMax}`,
                        alignment: 'left',
                        style: 'infoLabel',
                        border: [true, true, true, true]
                    },
                ]
            ]
        },
        layout: 'noBorders',
    };
};
const generateMovement = (kardex) => {
    let kardexData = [];
    kardexData.push([
        {},
        {}, // Estas celdas están vacías porque 'ENTRADA' ocupa 3 columnas
        { text: 'ENTRADA', bold: true, style: 'infoLabel', colSpan: 3, alignment: 'center', fillColor: '#17B453', color: '#FFFFFF', },
        {},
        {},
        { text: 'SALIDA', bold: true, style: 'infoLabel', colSpan: 3, alignment: 'center', fillColor: '#17B453', color: '#FFFFFF', },
        {},
        {},
        { text: 'SALDO', bold: true, style: 'infoLabel', colSpan: 3, alignment: 'center', fillColor: '#17B453', color: '#FFFFFF', },
        {},
        {},
    ]);
    // Agregamos el encabezado de la tabla
    kardexData.push([
        { text: 'FECHA', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'DESCRIPCION', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'CANTIDAD', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'VALOR UNIT.', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'VALOR TOT.', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'CANTIDAD', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'VALOR UNIT.', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'VALOR TOT.', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'CANTIDAD', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'VALOR UNIT.', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
        { text: 'VALOR TOT.', bold: true, style: 'infoLabel', fillColor: '#17B453', color: '#FFFFFF', },
    ]);
    // Iteramos sobre el array kardex para rellenar las filas de la tabla
    kardex.forEach(element => {
        kardexData.push([
            { text: (0, moment_timezone_1.default)(element.date).format('DD-MM-YYYY'), style: 'infoItem' },
            { text: element.description.toString(), style: 'infoItem' },
            { text: element.inputAmount.toString(), style: 'infoItem' },
            { text: element.inputValue.toString(), style: 'infoItem' },
            { text: (element.inputValue * element.inputAmount).toString(), style: 'infoItem' },
            { text: element.outputAmount.toString(), style: 'infoItem' },
            { text: element.outputValue.toString(), style: 'infoItem' },
            { text: (element.outputAmount * element.outputValue).toString(), style: 'infoItem' },
            { text: element.balanceQuantity.toString(), style: 'infoItem' },
            { text: element.balanceValue.toString(), style: 'infoItem' },
            { text: (element.balanceQuantity * element.balanceValue).toString(), style: 'infoItem' }
        ]);
    });
    // Estructura de la tabla en pdfmake
    const table = {
        table: {
            headerRows: 1,
            widths: ['10%', '20%', '7%', '8%', '8%', '7%', '8%', '8%', '8%', '8%', '8%'],
            body: kardexData
        }
    };
    return table;
};
const contentKardexPdf = (kardexDefinition) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const header = generateHeaderTable();
        const productInfo = generateProductInfo(kardexDefinition.product);
        const movement = generateMovement(kardexDefinition.kardex);
        const kardexDoc = [
            Object.assign({}, header),
            Object.assign({}, productInfo),
            Object.assign({}, movement),
        ];
        return kardexDoc;
    }
    catch (error) {
        return [];
    }
});
exports.contentKardexPdf = contentKardexPdf;
//# sourceMappingURL=content.js.map