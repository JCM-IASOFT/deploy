"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docDefinition = void 0;
const content_1 = require("./content");
const style_1 = require("../../styles/style");
const docDefinition = (campus, company, service) => __awaiter(void 0, void 0, void 0, function* () {
    const content = yield (0, content_1.ContentPdf)(campus, company, service);
    const data = {
        pageSize: {
            width: 226.77,
            height: 'auto',
        },
        pageMargins: [5.66, 5.66, 5.66, 5.66],
        info: {
            title: 'F001-000001',
            author: 'JCM',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        content: content,
        defaultStyle: {
            font: 'SourceCodePro'
        },
        styles: style_1.pdfStyles,
    };
    return data;
});
exports.docDefinition = docDefinition;
//# sourceMappingURL=docdefinition.js.map