"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentPdf = exports.fetchAndConvertToBase64 = void 0;
const axios_1 = __importDefault(require("axios"));
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const parameter_constant_1 = require("../../../../common/constant/parameter.constant");
const canvas_1 = require("canvas");
const jsbarcode_1 = __importDefault(require("jsbarcode"));
const enum_1 = require("modelslibrary/src/core/enum/enum");
const fetchAndConvertToBase64 = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axios_1.default.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 5000
        });
        const base64Image = Buffer.from(response.data, 'binary').toString('base64');
        return base64Image;
    }
    catch (error) {
        return null;
    }
});
exports.fetchAndConvertToBase64 = fetchAndConvertToBase64;
const generateBarcodeAsBase64 = (text, width, height) => {
    const canvas = (0, canvas_1.createCanvas)(width, height);
    const context = canvas.getContext('2d');
    (0, jsbarcode_1.default)(canvas, text, {
        format: 'CODE128', displayValue: false, width: 7,
        height: 200,
    });
    const barcodeBase64 = context.canvas.toDataURL();
    return barcodeBase64;
};
const getServiceDevice = (serviceDevices) => {
    const datServiceDevices = [];
    if (serviceDevices.length > 0) {
        serviceDevices.forEach(element => {
            datServiceDevices.push([{ text: element.device.description, style: 'infoLabel', margin: [0, 0, 0, 0] }, { text: element.deviceBrand.description, style: 'infoItem', }]);
            datServiceDevices.push([{ text: 'falla/problema:', style: 'infoItem', margin: [0, 0, 0, 0] }, { text: element.reason, style: 'infoItem', margin: [0, 0, 0, 0] }]);
            datServiceDevices.push([{ text: 'Accesorio:', style: 'infoItem', margin: [0, 0, 0, 0] }, { text: element.accessories, style: 'infoItem', margin: [0, 0, 0, 0] }]);
            datServiceDevices.push([{ text: 'Observaciones:', style: 'infoItem', margin: [0, 0, 0, 0] }, { text: element.observations, style: 'infoItem', margin: [0, 0, 0, 0] }]);
            if (element.model) {
                datServiceDevices.push([{ text: 'Modelo:', style: 'infoItem', margin: [0, 0, 0, 0] }, { text: element.model, style: 'infoItem', margin: [0, 0, 0, 0] }]);
            }
            if (element.workCycle !== '') {
                datServiceDevices.push([{ text: 'Ciclo de trab.:', style: 'infoItem', margin: [0, 0, 0, 0] }, { text: element.workCycle, style: 'infoItem', margin: [0, 0, 0, 0] }]);
            }
            if (element.inWarranty) {
                datServiceDevices.push([{ text: 'GRARANTIA', style: 'infoItem', margin: [0, 0, 0, 5] }, {}]);
            }
            datServiceDevices.push([{ text: "Tipo de Servicios:", style: 'infoLabel', margin: [0, 0, 0, 0], colSpan: 2 }, {}]);
            element.serviceTypeDevices.forEach(item => {
                datServiceDevices.push([{ text: item.serviceType.description, style: 'infoItem', margin: [0, 0, 0, 0] }, {}]);
            });
            datServiceDevices.push([{ text: 'Monto Referencial:' + element.estimatedAmount.toString(), style: 'infoLabel', margin: [0, 10, 0, 0], colSpan: 2 }, {}]);
        });
    }
    else {
        datServiceDevices.push([{}, {}]);
    }
    return datServiceDevices;
};
// ** Anticipos
const getAdvances = (payments) => {
    const dataAdvances = [];
    let totalAdvance = 0;
    const advance = payments.filter(payment => payment.type === enum_1.TypeOperationPaymentService.Advance);
    if (payments.length > 0) {
        dataAdvances.push([
            { text: "ANTICIPOS", style: 'infoLabel', colSpan: 2, alignment: 'right' },
            {}, {}, {}
        ]);
        advance.forEach(element => {
            dataAdvances.push([
                { text: element.paymentType.description + ": S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
                {},
                { text: element.amount.toString(), style: 'infoItem', colSpan: 2, alignment: 'right' },
                {}
            ]);
            totalAdvance = Number(element.amount) + totalAdvance;
        });
    }
    return dataAdvances;
};
// ** Aumentos
const getIncreases = (service) => {
    const dataIncreases = [];
    let totalIncrease = 0;
    const increase = service.serviceDevices.flatMap(device => device.serviceDeviceHistorys.filter(deviceHistory => deviceHistory.type === enum_1.TypeOperationDeviceHistory.Increase));
    totalIncrease = increase.reduce((current, total) => current + Number(total.adjustment), 0);
    if (totalIncrease > 0) {
        dataIncreases.push([
            { text: "ADICIONAL", style: 'infoLabel', colSpan: 2, alignment: 'right' },
            {}, {}, {}
        ]);
        dataIncreases.push(([
            { text: "SUBTOTAL: S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
            {},
            { text: service.totalAmount.toString(), style: 'infoItem', colSpan: 2, alignment: 'right' },
            {}
        ]));
        dataIncreases.push(([
            { text: "ADICIONAL: S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
            {},
            { text: totalIncrease.toString(), style: 'infoItem', colSpan: 2, alignment: 'right' },
            {}
        ]));
    }
    return dataIncreases;
};
// ** Descuentos
const getDiscount = (service) => {
    const dataDiscounts = [];
    let totalDiscount = 0;
    const increase = service.serviceDevices.flatMap(device => device.serviceDeviceHistorys.filter(deviceHistory => deviceHistory.type === enum_1.TypeOperationDeviceHistory.Discount));
    totalDiscount = increase.reduce((current, total) => current + Number(total.adjustment), 0);
    if (totalDiscount > 0) {
        dataDiscounts.push([
            { text: "DESCUENTO", style: 'infoLabel', colSpan: 2, alignment: 'right' },
            {}, {}, {}
        ]);
        dataDiscounts.push([
            { text: 'SUBTOTAL' + ": S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
            {},
            { text: `${(Number(service.totalAmount) + totalDiscount).toFixed(2)}`, style: 'tTotals', colSpan: 2, alignment: 'right' },
            {}
        ]);
        dataDiscounts.push([
            { text: 'DESCUENTO' + ": S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
            {},
            { text: `-${totalDiscount.toFixed(2)}`, style: 'infoItem', colSpan: 2, alignment: 'right' },
            {}
        ]);
        dataDiscounts.push([
            { text: 'MONTO A PAGAR' + ": S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
            {},
            { text: `${service.totalAmount}`, style: 'infoItem', colSpan: 2, alignment: 'right' },
            {}
        ]);
    }
    return dataDiscounts;
};
// ** Descuentos
const getRepayment = (service) => {
    const dataRepayment = [];
    let totalRepayment = 0;
    const increase = service.serviceDevices.flatMap(device => device.serviceDeviceHistorys.filter(deviceHistory => deviceHistory.type === enum_1.TypeOperationDeviceHistory.Repayment));
    totalRepayment = increase.reduce((current, total) => current + Number(total.adjustment), 0);
    if (totalRepayment > 0) {
        dataRepayment.push([
            { text: 'DEVOLUCION' + ": S/", style: 'infoLabel', colSpan: 2, alignment: 'right' },
            {},
            {},
            {}
        ]);
        dataRepayment.push([
            { text: 'SUBTOTAL' + ": S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
            {},
            { text: `${(Number(service.totalAmount) + totalRepayment).toFixed(2)}`, style: 'infoItem', colSpan: 2, alignment: 'right' },
            {}
        ]);
        dataRepayment.push([
            { text: 'DEVOLUCION' + ": S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
            {},
            { text: `-${totalRepayment.toFixed(2)}`, style: 'infoItem', colSpan: 2, alignment: 'right' },
            {}
        ]);
        dataRepayment.push([
            { text: 'MONTO A PAGAR' + ": S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
            {},
            { text: `${service.totalAmount}`, style: 'infoItem', colSpan: 2, alignment: 'right' },
            {}
        ]);
    }
    return dataRepayment;
};
// ** Pagos completados
const getCompletePayment = (service) => {
    const dataPaymentCompletions = [];
    const completion = service.payments.filter(payment => payment.type === enum_1.TypeOperationPaymentService.completion);
    const totalCompletion = completion.reduce((total, payment) => total + Number(payment.amount), 0);
    if (completion.length > 0) {
        dataPaymentCompletions.push([
            { text: "PAGO ACTUAL", style: 'infoLabel', colSpan: 2, alignment: 'right' },
            {}, {}, {}
        ]);
        completion.forEach(element => {
            dataPaymentCompletions.push([
                { text: element.paymentType.description + ": S/", style: 'infoItem', colSpan: 2, alignment: 'right' },
                {},
                { text: element.amount.toString(), style: 'infoItem', colSpan: 2, alignment: 'right' },
                {}
            ]);
        });
        dataPaymentCompletions.push([
            { text: 'PAGO ACTUAL' + ": S/", style: 'infoLabel', colSpan: 2, alignment: 'right' },
            {},
            { text: `${totalCompletion.toFixed(2)}`, style: 'infoItem', colSpan: 2, alignment: 'right' },
            {}
        ]);
    }
    return dataPaymentCompletions;
};
// ** Informacion importante para cliente
const getInfoTicket = () => {
    const infoTicket = [
        [
            { text: 'MUY IMPORTANTE', style: 'infoLabel', alignment: 'center', margin: [0, 5, 0, 3] },
            { text: '-Evite cobros adicionales por concepto de almacenaje', style: 'smallText', },
            { text: '-Evite daños de componentes por tiempos guardados ', style: 'smallText' },
            { text: '-Evite que las tintas se dañen (solo aplica para Impresoras)', style: 'smallText' },
            { text: '-Evite daños fisicos por no recoger su producto ', style: 'smallText' },
            { text: 'Suportecc no se resonsabiliza por daños ocacionados despues de su reparacion o informe final.', style: 'infoLabel', alignment: 'center', margin: [0, 4, 0, 4] },
            { text: 'ACEPTO LAS CONDICONES MENCIONADAS', style: 'infoLabel', alignment: 'center', margin: [0, 3, 0, 30] },
            { text: '------------------------------------', style: 'infoItem', alignment: 'center', margin: [0, 5, 0, 0] },
            { text: 'FIRMA', style: 'infoItem', alignment: 'center' },
        ]
    ];
    return infoTicket;
};
const totalPayment = (service) => {
    const dataTotalPayment = [];
    const totalPayments = service.payments.reduce((acc, payment) => acc + parseFloat(payment.amount.toString()), 0);
    const totalRepayment = service.differences.reduce((acc, element) => {
        return acc + element.differencePayments.reduce((subAcc, pay) => subAcc + parseFloat(pay.amount.toString()), 0);
    }, 0);
    if (totalPayments > 0) {
        dataTotalPayment.push([
            { text: "TOTAL PAGADO", style: 'header', colSpan: 4, alignment: 'center' },
            {}, {}, {}
        ]);
        dataTotalPayment.push([
            { text: `S/ ${(totalPayments - totalRepayment).toFixed(2)}`, style: 'header', colSpan: 4, alignment: 'center' },
            {},
            {},
            {}
        ]);
    }
    return dataTotalPayment;
};
const ContentPdf = (campus, company, service) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    try {
        // ** Service Devices
        const serviceDevicesData = getServiceDevice(service.serviceDevices);
        // ** Anticipos
        const advancesData = getAdvances(service.payments);
        // ** Aumentos
        const increasesData = getIncreases(service);
        // ** Descuentos
        const discountsData = getDiscount(service);
        // ** Devoluciones
        const repaymentData = getRepayment(service);
        // ** Pagos completados
        const completeData = getCompletePayment(service);
        // ** Total pagado
        const totalPaymentData = totalPayment(service);
        // ** Verificacion de estados
        const serviceStatusService = service.serviceStatusHistorys.find(p => p.status === parameter_constant_1.StatusService.SIN_SOLUCION_ENTREGADO
            || p.status === parameter_constant_1.StatusService.ENTREGADO || p.status === parameter_constant_1.StatusService.RECHAZADO);
        const statusCanChange = ![parameter_constant_1.StatusService.ENTREGADO, parameter_constant_1.StatusService.RECHAZADO].includes(service.state);
        // ** Informacion importante para cliente
        const infoTicket = getInfoTicket();
        const ticketService = [
            { text: campus.name, style: 'header', margin: [0, 5, 0, 0] },
            { text: campus.address, style: 'header' },
            { text: 'RUC: ' + company.ruc, style: 'header' },
            { text: 'CEL: ' + campus.phone, style: 'header' },
            //TIPO Y NUMERO DOCUMENTO
            { text: 'TIKET SERVICIO', style: 'header', margin: [0, 5, 0, 2] },
            { text: service.serviceId.toString().padStart(5, '0'), style: 'header', margin: [0, 2, 0, 0] },
            // ** Informacion de ticket (Numero de servicio,cliente,fecha,etc)
            {
                margin: [0, 5, 0, 0],
                table: {
                    widths: ['28%', '35%', '17%', '20%'],
                    body: [
                        [
                            {
                                text: `FECHA: ${(0, moment_timezone_1.default)(service.registrationDate).tz(company.timeZone).format('L')}  HORA: ${(0, moment_timezone_1.default)(service.registrationDate).tz(company.timeZone).format('hh:mm A')}`,
                                style: 'infoItem',
                                colSpan: 4
                            },
                            {}, {}, {}
                        ],
                        [
                            {
                                text: `SERVICIO: ${service.serviceId.toString().padStart(5, '0')}`,
                                style: 'infoItem',
                                colSpan: 4
                            },
                            {}, {}, {}
                        ],
                        [
                            {
                                text: `CEL: ${((_a = service.client) === null || _a === void 0 ? void 0 : _a.phone) || '999999999'}`,
                                style: 'infoItem',
                                colSpan: 4
                            },
                            {}, {}, {}
                        ],
                        [
                            {
                                text: `RECEPCIÓN: ${service.userReception.name} ${service.userReception.fullname}`,
                                style: 'infoItem',
                                colSpan: 4
                            },
                            {}, {}, {}
                        ],
                        [
                            {
                                text: `TECNICO: ${service.userTechnical ? `${service.userTechnical.name} ${service.userTechnical.fullname}` : 'No Aplica'}`,
                                style: 'infoItem',
                                colSpan: 4
                            },
                            {}, {}, {}
                        ],
                        [
                            {
                                text: 'CLIENTE:',
                                style: 'infoItem'
                            },
                            {
                                text: ((_b = service.client) === null || _b === void 0 ? void 0 : _b.fullname) || '',
                                style: 'infoItem'
                            },
                            {
                                text: 'DNI:',
                                style: 'infoItem'
                            },
                            {
                                text: ((_c = service.client) === null || _c === void 0 ? void 0 : _c.documentNumber) || '',
                                style: 'infoItem'
                            },
                        ],
                    ],
                },
                layout: 'noBorders',
            },
            { text: '*****************************', style: 'header', margin: [0, 0, 0, 0] },
            // ** Equipos del servicio           
            {
                margin: [0, 0, 0, 0],
                table: {
                    widths: ['40%', '60%'],
                    body: serviceDevicesData,
                },
                layout: 'noBorders',
            },
            ...(advancesData.length > 0 ? [
                { text: '*****************************', style: 'header', margin: [0, 0, 0, 0] },
                {
                    margin: [0, 0, 0, 0],
                    table: {
                        widths: ['25%', '35%', '15%', '25%'],
                        body: [
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: advancesData
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ],
                            // Otras filas que quieras agregar en caso de que haya datos en advancesData
                        ],
                    },
                    layout: 'noBorders',
                }
            ] : []),
            ...(increasesData.length > 0 ? [
                { text: '*****************************', style: 'header', margin: [0, 0, 0, 0] },
                {
                    margin: [0, 0, 0, 0],
                    table: {
                        widths: ['25%', '35%', '15%', '25%'],
                        body: [
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: increasesData
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ],
                            // discountsData,
                            // repaymentData,
                            // completeData,
                        ],
                    },
                    layout: 'noBorders',
                },
            ] : []),
            ...(discountsData.length > 0 ? [
                { text: '*****************************', style: 'header', margin: [0, 0, 0, 0] },
                {
                    margin: [0, 0, 0, 0],
                    table: {
                        widths: ['25%', '35%', '15%', '25%'],
                        body: [
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: discountsData
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ],
                            // discountsData,
                            // repaymentData,
                            // completeData,
                        ],
                    },
                    layout: 'noBorders',
                },
            ] : []),
            ...(repaymentData.length > 0 ? [
                { text: '*****************************', style: 'header', margin: [0, 0, 0, 0] },
                {
                    margin: [0, 0, 0, 0],
                    table: {
                        widths: ['25%', '35%', '15%', '25%'],
                        body: [
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: repaymentData
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ],
                            // discountsData,
                            // repaymentData,
                            // completeData,
                        ],
                    },
                    layout: 'noBorders',
                },
            ] : []),
            ...(completeData.length > 0 ? [
                { text: '*****************************', style: 'header', margin: [0, 0, 0, 0] },
                {
                    margin: [0, 0, 0, 0],
                    table: {
                        widths: ['25%', '35%', '15%', '25%'],
                        body: [
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: completeData
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ],
                            // discountsData,
                            // repaymentData,
                            // completeData,
                        ],
                    },
                    layout: 'noBorders',
                },
            ] : []),
            ...(totalPaymentData.length > 0 ? [
                { text: '*****************************', style: 'header', margin: [0, 0, 0, 0] },
                {
                    margin: [0, 0, 0, 0],
                    table: {
                        widths: ['25%', '35%', '15%', '25%'],
                        body: [
                            [
                                {
                                    margin: [0, 0, 0, 0],
                                    table: {
                                        widths: ['25%', '35%', '15%', '25%'],
                                        body: totalPaymentData
                                    },
                                    layout: 'noBorders',
                                    colSpan: 4
                                }, {}, {}, {}
                            ],
                            // discountsData,
                            // repaymentData,
                            // completeData,
                        ],
                    },
                    layout: 'noBorders',
                },
            ] : []),
            //NOTA DE PIE
            serviceStatusService ?
                {
                    text: `F. de Entrega: ${(0, moment_timezone_1.default)(serviceStatusService.dateChanged).tz(company.timeZone).format("L")} Hora: ${(0, moment_timezone_1.default)(serviceStatusService.dateChanged).tz(company.timeZone).format("LT")}`,
                    style: 'infoItem',
                    margin: [0, 5],
                } : {},
            {
                text: 'Gracias por elegir nuestro soporte técnico. Estamos aquí para ayudarte en lo que necesites.',
                style: 'infoItem',
                alignment: 'justify',
                margin: [0, 5],
            },
            //QR FACTURA
            {
                stack: [
                    {
                        qr: company.ruc,
                        fit: 115,
                        alignment: 'center',
                        eccLevel: 'Q',
                        margin: [0, 10, 0, 3],
                    },
                    {
                        text: 'Representación impresa del comprobante original. Consulta tu comprobante aquí:',
                        style: 'infoItem',
                    },
                ],
            },
            {
                stack: [
                    {
                        image: generateBarcodeAsBase64(service.serviceId.toString(), 100, 80),
                        width: 70, // Ancho deseado
                        height: 25, // Mantenemos la altura original
                        alignment: 'center',
                        margin: [3, 14, 0, 3],
                    },
                ],
                width: '30%',
                margin: [3, 0, 0, 3]
            },
            ...infoTicket,
            // { text: 'MUY IMPORTANTE', style: 'infoLabel', margin: [0, 5, 0, 3] },
            // { text: '-Evite cobros adicionales por concepto de almacenaje', style: 'message', },
            // { text: '-Evite daños de componentes por tiempos guardados ', style: 'message' },
            // { text: '-Evite que las tintas se dañen (solo aplica para Impresoras)', style: 'message' },
            // { text: '-Evite daños fisicos por no recoger su producto ', style: 'message' },
        ];
        return ticketService;
    }
    catch (error) {
        return [];
    }
});
exports.ContentPdf = ContentPdf;
//# sourceMappingURL=content.js.map