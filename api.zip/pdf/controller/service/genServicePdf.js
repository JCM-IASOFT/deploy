"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generatorServicePdf = void 0;
const pdfmake_1 = __importDefault(require("pdfmake"));
const docdefinition_1 = require("./content/docdefinition");
const save_error_1 = require("../../../common/handler/save.error");
const font_1 = require("../font");
class GeneratorServicePdf {
    constructor() {
        this.generateServicePdf = (campus, company, service) => __awaiter(this, void 0, void 0, function* () {
            try {
                (0, font_1.demos)();
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_1.docDefinition)(campus, company, service);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                save_error_1.logger.info(`generateServicePdf for : ${error.message}`);
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new GeneratorServicePdf();
        return this.instance;
    }
}
exports.generatorServicePdf = GeneratorServicePdf.getInstance();
//# sourceMappingURL=genServicePdf.js.map