"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicePdfController = void 0;
const company_service_1 = require("../../../company/company/service/company.service");
const campus_service_1 = require("../../../company/campus/service/campus.service");
const service_service_1 = require("../../../support/service/service/service.service");
const http_status_codes_1 = require("http-status-codes");
const genServicePdf_1 = require("./genServicePdf");
class ServicePdfController {
    constructor() {
        this.findServicePdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { serviceId, companyId, campusId } = req.body;
                const company = yield company_service_1.companyService.findOneCompany(Number(companyId));
                const campus = yield campus_service_1.campusService.findOneCampus(Number(campusId));
                const service = yield service_service_1.serviceService.findOneService(Number(serviceId));
                if (!service) {
                    res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: 'no hay servico' });
                }
                if (company && service && campus) {
                    const binaryResult = yield genServicePdf_1.generatorServicePdf.generateServicePdf(campus, company, service);
                    res.setHeader('Content-disposition', 'attachment; filename=report.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ServicePdfController();
        return this.instance;
    }
}
exports.servicePdfController = ServicePdfController.getInstance();
//# sourceMappingURL=servicePdf.controller.js.map