"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.styles = void 0;
exports.styles = {
    invoiceTitle: {
        fontSize: 16,
        bold: true,
        color: '#007bff'
    },
    invoiceDetails: {
        fontSize: 10,
        margin: [0, 5, 0, 5]
    },
    totalDue: {
        fontSize: 14,
        bold: true,
        color: '#333333'
    },
    tableHeader: {
        fillColor: '#0a3654',
        bold: true,
        color: '#FFFFFF'
    },
    paymentMethods: {
        fontSize: 10,
        margin: [0, 5, 0, 5],
        color: '#555555'
    },
    totals: {
        fontSize: 10,
        margin: [0, 5, 0, 5],
        alignment: 'right'
    },
    signature: {
        fontSize: 10,
        margin: [0, 20, 0, 0]
    },
    contactDetails: {
        fontSize: 10,
        alignment: 'right',
        color: '#555555'
    }
};
//# sourceMappingURL=index.js.map