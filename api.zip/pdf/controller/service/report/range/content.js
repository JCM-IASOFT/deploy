"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentRangePdf = void 0;
const save_error_1 = require("../../../../../common/handler/save.error");
const downloadLogo_utils_1 = require("../../../../utils/downloadLogo.utils");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const paymentServices = (service) => {
    let pay = '';
    let total = 0;
    let cant = 0;
    service.payments.forEach(element => {
        cant++;
        total += parseFloat(element.amount.toString());
        pay += `${element.paymentType.description}: S/ ${element.amount}\n`;
    });
    if (cant > 1) {
        pay += `total: S/ ${total.toFixed(2)}`;
    }
    return pay;
};
const totalService = (services) => {
    let total = 0;
    services.forEach(element => {
        element.payments.forEach(pay => {
            total += parseFloat(pay.amount.toString());
        });
    });
    return total;
};
const totalDifferencesService = (services) => {
    let total = 0;
    services.forEach(element => {
        element.differences.forEach(diff => {
            diff.differencePayments.forEach(pay => {
                total += parseFloat(pay.amount.toString());
            });
        });
    });
    return total;
};
const totalStimatedService = (services) => {
    let totalStimated = 0;
    services.forEach(element => {
        element.serviceDevices.forEach(sd => {
            totalStimated += parseFloat(sd.estimatedAmount.toString());
        });
    });
    return totalStimated;
};
const ContentRangePdf = (campus, company, services, startDate, endDate) => __awaiter(void 0, void 0, void 0, function* () {
    const download = yield (0, downloadLogo_utils_1.downloadImage)(company.image);
    const imageString = (0, downloadLogo_utils_1.convertImageToBase64)(download);
    try {
        const subTotal = totalService(services);
        const totalStimated = totalStimatedService(services);
        const differences = totalDifferencesService(services);
        const content = [
            // Header with logo and invoice title
            {
                columns: [
                    { image: 'data:image/jpg;base64,' + imageString, width: 80 },
                    { text: 'REPORTE', style: 'invoiceTitle', alignment: 'right' }
                ]
            },
            {
                columns: [
                    {
                        text: [
                            { text: 'fecha inicio:', bold: true },
                            `${startDate}\n`,
                            { text: 'fecha fin:', bold: true },
                            `${endDate}\n`
                        ],
                        style: 'invoiceDetails'
                    },
                ]
            },
            { text: `\nTotal de Servicios\n S/ ${(subTotal - differences).toFixed(2)}`, style: 'totalDue', alignment: 'right' },
            // Table of items
            {
                table: {
                    headerRows: 1,
                    widths: ['5%', '10%', '10%', '25%', '15%', '20%', '15%'],
                    body: [
                        [
                            { text: 'ID', style: 'tableHeader' },
                            { text: 'FECHA', style: 'tableHeader' },
                            { text: 'RECEPCION', style: 'tableHeader' },
                            { text: 'CLIENTE', style: 'tableHeader' },
                            { text: 'TECNICO', style: 'tableHeader' },
                            { text: 'TOTAL', style: 'tableHeader' },
                            { text: 'FECHA ENTREGA', style: 'tableHeader' },
                        ],
                        ...services.map(service => {
                            var _a, _b;
                            return [
                                { text: service.serviceId },
                                { text: `${(0, moment_timezone_1.default)(service === null || service === void 0 ? void 0 : service.registrationDate).format("DD-MM-YYYY")}`, alignment: 'left' },
                                { text: `${(_a = service === null || service === void 0 ? void 0 : service.userReception) === null || _a === void 0 ? void 0 : _a.name}`, alignment: 'left' },
                                { text: `${(service === null || service === void 0 ? void 0 : service.client) ? service.client.fullname : 'Cliente Varios'}`, alignment: 'left' },
                                { text: `${(_b = service === null || service === void 0 ? void 0 : service.userTechnical) === null || _b === void 0 ? void 0 : _b.name}`, alignment: 'left' },
                                { text: `${paymentServices(service)}`, alignment: 'right' },
                                { text: `${(service === null || service === void 0 ? void 0 : service.endDate) ? (0, moment_timezone_1.default)(service.endDate).format("DD-MM-YYYY") : '-'}`, alignment: 'left' },
                            ];
                        })
                    ]
                },
                layout: 'lightHorizontalLines'
            },
            // Totals and payment method section
            {
                columns: [
                    {
                        text: '',
                        style: ''
                    },
                    {
                        style: 'totals',
                        table: {
                            widths: ['*', 60],
                            body: [
                                ['Sub Total:', `${subTotal.toFixed(2)}`],
                                ['Total Estimado:', `${totalStimated.toFixed(2)}`],
                                ['Devoluciones:', `${differences.toFixed(2)}`],
                                [{ text: 'Total:', bold: true }, { text: `${(subTotal - differences).toFixed(2)}`, bold: true }]
                            ]
                        },
                        alignment: 'right'
                    }
                ]
            },
            // Signature and footer
            // { text: '\n\n', margin: [0, 20] },
            // {
            //     columns: [
            //         {
            //             text: 'Signature\n\n__________________________\nAccount Manager',
            //             style: 'signature'
            //         },
            //         {
            //             text: 'Contact details\n87, ABC Lane, NY, USA\n+1 08562 056456\nnameurl.com',
            //             alignment: 'right',
            //             style: 'contactDetails'
            //         }
            //     ]
            // }
        ];
        return content;
    }
    catch (error) {
        save_error_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.ContentRangePdf = ContentRangePdf;
//# sourceMappingURL=content.js.map