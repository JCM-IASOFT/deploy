"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docRangeDefinition = void 0;
const style_1 = require("../style");
const content_1 = require("./content");
const campus_service_1 = require("../../../../../company/campus/service/campus.service");
const company_service_1 = require("../../../../../company/company/service/company.service");
const service_service_1 = require("../../../../../support/service/service/service.service");
const docRangeDefinition = (campusId, companyId, startDate, endDate) => __awaiter(void 0, void 0, void 0, function* () {
    const campus = yield campus_service_1.campusService.findOneCampus(campusId);
    const company = yield company_service_1.companyService.findOneCompany(companyId);
    const services = yield service_service_1.serviceService.findRangeService(campusId, startDate, endDate, company.timeZone);
    const content = yield (0, content_1.ContentRangePdf)(campus, company, services, startDate, endDate);
    const data = {
        // pageSize: {
        //     width: 226.77,
        //     height: 'auto',
        // },
        pageOrientation: 'landscape',
        pageMargins: [
            40, 20, 40, 20
        ],
        info: {
            title: 'F001-000001',
            author: 'JCM',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        content: content,
        defaultStyle: {
            font: 'Roboto'
        },
        styles: style_1.styles,
    };
    return data;
});
exports.docRangeDefinition = docRangeDefinition;
//# sourceMappingURL=docdefinition.js.map