"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentWaitingPdf = void 0;
const waitingticket_service_1 = require("../../../support/waitingticket/service/waitingticket.service");
const save_error_1 = require("../../../common/handler/save.error");
const ContentWaitingPdf = (campus, parameters, waitingticket, quantity) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const message = ((_a = parameters.find(element => element.name === "message")) === null || _a === void 0 ? void 0 : _a.description) || 'Gracias por su paciencia. Valoramos mucho su tiempo y estamos trabajando para atenderlo lo antes posible. Su satisfacción es importante para nosotros.';
        let data = [];
        for (let i = 0; i < quantity; i++) {
            const response = yield waitingticket_service_1.waitingticketService.findOneWaitingTicket(waitingticket.sector.sectorId, campus.campusId);
            data.push([
                { text: campus.name, style: 'header', margin: [0, 0, 0, 0] },
                { text: campus.address, style: 'header' },
                { text: 'CEL: ' + campus.phone, style: 'header' },
                //TIPO Y NUMERO DOCUMENTO
                { text: 'Bienvenido', style: 'header', margin: [0, 0, 0, 0] },
                { text: 'Su turno es', style: 'text', margin: [0, 2, 0, 0] },
                { text: 'H-00' + (response !== null ? response.order + 1 : 1), style: 'turno', margin: [0, 4, 0, 0] },
                //NOTA DE PIE
                {
                    text: message,
                    style: 'text',
                    margin: [0, 4, 0, 0],
                },
                {
                    text: 'Tiempo de espera',
                    style: 'text',
                    margin: [0, 2, 0, 0],
                },
                {
                    text: 'Aproximado: ' + 2 * (i + 1) + ' minutos',
                    style: 'important',
                    margin: [0, 0, 0, 0],
                },
            ]);
            waitingticket.waitingTicketId = 0;
            waitingticket.order = response !== null ? response.order + 1 : 1;
            yield waitingticket_service_1.waitingticketService.createWaitingTicket(waitingticket);
        }
        return data;
    }
    catch (error) {
        save_error_1.logger.error("🚀 ~ error:" + error.message);
        return [];
    }
});
exports.ContentWaitingPdf = ContentWaitingPdf;
//# sourceMappingURL=content.js.map