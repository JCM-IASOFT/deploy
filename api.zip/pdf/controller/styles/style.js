"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pdfStyles = void 0;
exports.pdfStyles = {
    header: {
        fontSize: 12,
        bold: true,
        alignment: 'center',
    },
    subheader: {
        fontSize: 16,
        bold: true,
        margin: [0, 10, 0, 5]
    },
    infoItem: {
        fontSize: 9,
    },
    infoLabel: {
        bold: true,
        fontSize: 9
    },
    productTable: {
        margin: [0, 5, 0, 15],
    },
    productTableHeader: {
        bold: true,
        fontSize: 13,
        color: 'black'
    },
    productTableRow: {
        fontSize: 12
    },
    total: {
        fontSize: 14,
        bold: true,
        alignment: 'right',
        margin: [0, 10, 0, 0]
    },
    footer: {
        fontSize: 10,
        italics: true,
        alignment: 'center',
        margin: [0, 20, 0, 0]
    },
    centeredText: {
        alignment: 'center',
        fontSize: 12,
        margin: [0, 10, 0, 10]
    },
    dashedLine: {
        margin: [0, 10, 0, 10],
        decorationStyle: 'dashed',
        decorationColor: '#000000',
        decoration: 'lineThrough'
    },
    logo: {
        alignment: 'center',
        margin: [0, 10, 0, 10]
    },
    smallText: {
        fontSize: 7,
    }
};
//# sourceMappingURL=style.js.map