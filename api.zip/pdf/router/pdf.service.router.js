"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pdfServiceRoute = void 0;
const express_1 = require("express");
const servicePdf_controller_1 = require("../controller/service/servicePdf.controller");
exports.pdfServiceRoute = (0, express_1.Router)();
exports.pdfServiceRoute.post('/ticket', servicePdf_controller_1.servicePdfController.findServicePdf);
exports.pdfServiceRoute.post('/range', servicePdf_controller_1.servicePdfController.findRangeServicePdf);
//# sourceMappingURL=pdf.service.router.js.map