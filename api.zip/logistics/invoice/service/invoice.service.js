"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoiceService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class InvoiceService {
    static getInstance() {
        if (!this.instance)
            this.instance = new InvoiceService();
        return this.instance;
    }
    findInvoice() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const invoices = yield modelslibrary_1.InvoiceModel.find({
                    relations: {
                        invoiceSeries: true
                    }
                });
                return invoices;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
}
exports.invoiceService = InvoiceService.getInstance();
//# sourceMappingURL=invoice.service.js.map