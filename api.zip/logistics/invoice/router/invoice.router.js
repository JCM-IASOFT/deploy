"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoiceRoute = void 0;
const express_1 = require("express");
const invoice_controller_1 = require("../controller/invoice.controller");
exports.invoiceRoute = (0, express_1.Router)();
exports.invoiceRoute.get('/', invoice_controller_1.invoiceController.findInvoice);
//# sourceMappingURL=invoice.router.js.map