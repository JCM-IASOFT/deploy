"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteInvoiceSerie = exports.validateUpdateInvoiceSerie = exports.validateCreateInvoiceSerie = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateInvoiceSerieId = (0, express_validator_1.param)('invoiceSerieId')
    .exists().withMessage('El parámetro invoiceSerieId es requerido')
    .isNumeric().withMessage('El parámetro invoiceSerieId debe ser numérico');
const validatePrefix = (0, express_validator_1.check)('prefix')
    .exists().trim().not().isEmpty().withMessage('El prefijo es requerido')
    .isLength({ max: 20 }).withMessage('El prefijo no debe exceder los 20 caracteres');
const validateNumber = (0, express_validator_1.check)('number')
    .exists().withMessage('El número es requerido')
    .isNumeric().withMessage('El número debe ser numérico');
const validateDistance = (0, express_validator_1.check)('distance')
    .exists().withMessage('La distancia es requerida')
    .isNumeric().withMessage('La distancia debe ser numérica');
const validateState = (0, express_validator_1.check)('state')
    .isBoolean().withMessage('El estado debe ser booleano');
const validateInvoiceId = (0, express_validator_1.check)('invoiceId')
    .exists().withMessage('El invoiceId es requerido')
    .isNumeric().withMessage('El invoiceId debe ser numérico');
const validateDeletedAt = (0, express_validator_1.check)('deletedAt')
    .isLength({ max: 1 }).withMessage('El campo deletedAt debe ser un solo carácter');
// * Validación para la creación de una serie de facturas
exports.validateCreateInvoiceSerie = [
    validatePrefix,
    validateNumber,
    validateDistance,
    validateState,
    validateInvoiceId,
    handleValidationResult
];
// * Validación para la actualización de una serie de facturas
exports.validateUpdateInvoiceSerie = [
    validateInvoiceSerieId,
    validatePrefix,
    validateNumber,
    validateDistance,
    validateState,
    validateInvoiceId,
    validateDeletedAt,
    handleValidationResult
];
// * Validación para la eliminación de una serie de facturas
exports.validateDeleteInvoiceSerie = [
    validateInvoiceSerieId,
    handleValidationResult
];
//# sourceMappingURL=invoiceSerie.validator.js.map