"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoiceSerieRoute = void 0;
const express_1 = require("express");
const invoiceSerie_controller_1 = require("../controller/invoiceSerie.controller");
const invoiceSerie_validator_1 = require("../validator/invoiceSerie.validator");
exports.invoiceSerieRoute = (0, express_1.Router)();
exports.invoiceSerieRoute.get('/', invoiceSerie_controller_1.invoiceSerieController.findInvoiceSerie);
exports.invoiceSerieRoute.post('/', invoiceSerie_validator_1.validateCreateInvoiceSerie, invoiceSerie_controller_1.invoiceSerieController.createInvoiceSeries);
exports.invoiceSerieRoute.put('/:invoiceSerieId', invoiceSerie_validator_1.validateUpdateInvoiceSerie, invoiceSerie_controller_1.invoiceSerieController.updateInvoiceSerie);
exports.invoiceSerieRoute.delete('/:invoiceSerieId', invoiceSerie_validator_1.validateDeleteInvoiceSerie, invoiceSerie_controller_1.invoiceSerieController.deleteInvoiceSerie);
//# sourceMappingURL=invoiceSerie.router.js.map