"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateFindInvoiceCampus = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateFindInvoiceCampus = [
    (0, express_validator_1.query)('campusId').exists().isNumeric().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=invoicecampus.validator.js.map