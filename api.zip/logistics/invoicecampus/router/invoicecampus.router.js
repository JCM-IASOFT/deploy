"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoicecampusRoute = void 0;
const express_1 = require("express");
const invoicecampus_controller_1 = require("../controller/invoicecampus.controller");
const invoicecampus_validator_1 = require("../validator/invoicecampus.validator");
exports.invoicecampusRoute = (0, express_1.Router)();
exports.invoicecampusRoute.get('/', invoicecampus_validator_1.validateFindInvoiceCampus, invoicecampus_controller_1.invoicecampusController.findInvoiceCampus);
//# sourceMappingURL=invoicecampus.router.js.map