"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supplierRoute = void 0;
const express_1 = require("express");
const supplier_controller_1 = require("../controller/supplier.controller");
exports.supplierRoute = (0, express_1.Router)();
exports.supplierRoute.get('/findAll', supplier_controller_1.supplierController.findSupplier);
exports.supplierRoute.post('/create', supplier_controller_1.supplierController.createSupplier);
exports.supplierRoute.put('/update', supplier_controller_1.supplierController.updateSupplier);
exports.supplierRoute.put('/delete/:supplierId', supplier_controller_1.supplierController.deleteSupplier);
//# sourceMappingURL=supplier.routes.js.map