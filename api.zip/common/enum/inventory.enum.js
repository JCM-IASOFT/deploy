"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryMovementType = exports.TypeTransaction = void 0;
var TypeTransaction;
(function (TypeTransaction) {
    TypeTransaction["Entry"] = "E";
    TypeTransaction["Output"] = "S";
})(TypeTransaction || (exports.TypeTransaction = TypeTransaction = {}));
var InventoryMovementType;
(function (InventoryMovementType) {
    InventoryMovementType["INGRESO_INICIAL"] = "II";
    InventoryMovementType["COMPRA_O_ADQUISICION"] = "CP";
    InventoryMovementType["TRANSFERENCIA_ENTRE_ALMACENES"] = "TA";
    InventoryMovementType["DEVOLUCION_DE_CLIENTES"] = "DC";
    InventoryMovementType["PRODUCCION_O_FABRICACION"] = "PF";
    InventoryMovementType["AJUSTE_DE_INVENTARIO"] = "AJ";
    InventoryMovementType["DONACIONES_O_REGALOS"] = "DN";
    InventoryMovementType["INVENTARIO_EN_CONSIGNACION"] = "CI";
    InventoryMovementType["VENTA"] = "VN";
    InventoryMovementType["DEVOLUCION_A_PROVEEDOR"] = "DCP";
    InventoryMovementType["CONSUMO_INTERNO"] = "CO";
    InventoryMovementType["DONACION_O_TRASLADO"] = "DT";
    InventoryMovementType["BAJA_POR_CONSUMO_O_VENCIMIENTO"] = "BC";
})(InventoryMovementType || (exports.InventoryMovementType = InventoryMovementType = {}));
//# sourceMappingURL=inventory.enum.js.map