"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProformaState = void 0;
var ProformaState;
(function (ProformaState) {
    ProformaState["EN_PROCESO"] = "1";
    ProformaState["REVISADO"] = "2";
    ProformaState["APROBADO"] = "3";
    ProformaState["DENEGADO"] = "4";
    ProformaState["FINALIZADO"] = "5";
})(ProformaState || (exports.ProformaState = ProformaState = {}));
//# sourceMappingURL=stateproforma.enum.js.map