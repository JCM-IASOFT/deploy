"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleUser = exports.Permission_Campus_User = exports.Permission_Company_User = void 0;
//#region Role permission
var Permission_Company_User;
(function (Permission_Company_User) {
    Permission_Company_User["create_brand"] = "create_brand";
    Permission_Company_User["edit_brand"] = "edit_brand";
    Permission_Company_User["view_brand"] = "view_brand";
    Permission_Company_User["delete_brand"] = "delete_brand";
    Permission_Company_User["create_category"] = "create_category";
    Permission_Company_User["edit_category"] = "edit_category";
    Permission_Company_User["view_category"] = "view_category";
    Permission_Company_User["delete_category"] = "delete_category";
    Permission_Company_User["create_company"] = "create_company";
    Permission_Company_User["edit_company"] = "edit_company";
    Permission_Company_User["delete_company"] = "delete_company";
    Permission_Company_User["create_client"] = "create_client";
    Permission_Company_User["edit_client"] = "edit_client";
    Permission_Company_User["delete_client"] = "delete_client";
    Permission_Company_User["create_campus"] = "create_campus";
    Permission_Company_User["edit_campus"] = "edit_campus";
    Permission_Company_User["delete_campus"] = "delete_campus";
    //create_price = 'create_price',
    //view_price = 'view_price',
    //delete_price = 'delete_price',
    Permission_Company_User["create_product"] = "create_product";
    Permission_Company_User["edit_product"] = "edit_product";
    Permission_Company_User["view_product"] = "view_product";
    Permission_Company_User["delete_product"] = "delete_product";
    Permission_Company_User["create_supplier"] = "create_supplier";
    Permission_Company_User["edit_supplier"] = "edit_supplier";
    Permission_Company_User["view_supplier"] = "view_supplier";
    Permission_Company_User["delete_supplier"] = "delete_supplier";
    Permission_Company_User["create_type_income"] = "create_type_income";
    Permission_Company_User["edit_type_income"] = "edit_type_income";
    Permission_Company_User["view_type_income"] = "view_type_income";
    Permission_Company_User["delete_type_income"] = "delete_type_income";
    Permission_Company_User["create_payment_type"] = "create_payment_type";
    Permission_Company_User["edit_payment_type"] = "edit_payment_type";
    Permission_Company_User["view_payment_type"] = "view_payment_type";
    Permission_Company_User["delete_payment_type"] = "delete_payment_type";
})(Permission_Company_User || (exports.Permission_Company_User = Permission_Company_User = {}));
var Permission_Campus_User;
(function (Permission_Campus_User) {
    Permission_Campus_User["create_store"] = "create_store";
    Permission_Campus_User["edit_store"] = "edit_store";
    Permission_Campus_User["view_store"] = "view_store";
    Permission_Campus_User["delete_store"] = "delete_store";
    Permission_Campus_User["transfer_store"] = "transfer_store";
    Permission_Campus_User["add_item_inventory_product"] = "add_item_inventory_product";
    Permission_Campus_User["view_item_inventory_product"] = "view_item_inventory_product";
    Permission_Campus_User["edit_item_inventory_product"] = "edit_item_inventory_product";
    Permission_Campus_User["delete_item_inventory_product"] = "delete_item_inventory_product";
    Permission_Campus_User["view_product_movement_history"] = "view_product_movement_history";
    Permission_Campus_User["delete_product_movement_history"] = "delete_product_movement_history";
    Permission_Campus_User["view_income_outcome_history"] = "view_income_outcome_history";
    Permission_Campus_User["add_worker"] = "add_worker";
    Permission_Campus_User["edit_worker"] = "edit_worker";
    Permission_Campus_User["expel_worker"] = "expel_worker";
    Permission_Campus_User["create_priceGroup"] = "create_priceGroup";
    Permission_Campus_User["edit_priceGroup"] = "edit_priceGroup";
    Permission_Campus_User["view_priceGroup"] = "view_priceGroup";
    Permission_Campus_User["delete_priceGroup"] = "delete_priceGroup";
    Permission_Campus_User["edit_price"] = "edit_price";
    Permission_Campus_User["system_support"] = "system_support";
})(Permission_Campus_User || (exports.Permission_Campus_User = Permission_Campus_User = {}));
var RoleUser;
(function (RoleUser) {
    RoleUser[RoleUser["user"] = 0] = "user";
    RoleUser[RoleUser["administrator"] = 1] = "administrator";
    RoleUser[RoleUser["super_user"] = 2] = "super_user";
})(RoleUser || (exports.RoleUser = RoleUser = {}));
//# sourceMappingURL=permission.js.map