"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CorrelativeConstant = void 0;
exports.CorrelativeConstant = {
    FACTURA_VENTA: "FV",
    NPTA_VENTA: "NV",
    NOTA_CREDITO: "NC",
    FACTURA: "F",
    BOLETA: "B",
    COTIZACION_PROFORMA: "CP"
};
//# sourceMappingURL=correlative.constant.js.map