"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusCodesCashBox = void 0;
exports.StatusCodesCashBox = {
    /**
     * Parámetros faltantes: Este código se utiliza cuando no se han proporcionado los parámetros necesarios en la solicitud.
     */
    MISSING_PARAMETERS: 4001,
    /**
     * Sin permisos: Este código indica que el usuario no tiene los permisos necesarios para realizar la acción solicitada.
     */
    NO_PERMISSION: 4031,
    /**
     * Necesita abrir caja: Este código señala que es necesario abrir una caja antes de continuar con la operación.
     */
    NEED_TO_OPEN_BOX: 2001,
    /**
     * Máximo de cajas abiertas: Este código se devuelve cuando ya se ha alcanzado el número máximo de cajas abiertas permitidas.
     */
    MAX_BOXES_OPENED: 2002,
    /**
     * Caja abierta con éxito: Este código indica que la caja se ha abierto correctamente.
     */
    SUCCESS_OPEN_CASH_BOX: 2003,
    /**
     * Error interno del servidor: Este código indica que ocurrió un error inesperado en el servidor.
     */
    INTERNAL_SERVER_ERROR: 5001,
};
//# sourceMappingURL=cashBoxCode.constant.js.map