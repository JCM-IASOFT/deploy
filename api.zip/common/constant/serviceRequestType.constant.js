"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceRequestType = void 0;
exports.serviceRequestType = {
    PAUSE: 'pause',
    RESUME: 'resume'
};
//# sourceMappingURL=serviceRequestType.constant.js.map