"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.periodTitle = exports.periodConst = exports.typeReportConst = void 0;
exports.typeReportConst = {
    INCOMES: 1,
    EXPENSES: 2,
    TYPES_TRANSACTION: 3,
    USERS: 4,
    INCOMES_EXPENSES: 5,
    TYPES_INCOMES_EXPENSES: 6
};
exports.periodConst = {
    DAILY: 1,
    WEEKLY: 2,
    MONTHLY: 3
};
exports.periodTitle = {
    DAILY: 'diario',
    WEEKLY: 'semanal',
    MONTHLY: 'mensual'
};
//# sourceMappingURL=report.constant.js.map