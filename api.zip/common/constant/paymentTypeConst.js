"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentTypeConst = void 0;
exports.paymentTypeConst = {
    CASH: 'cash',
    TRANSFER: 'transfer'
};
//# sourceMappingURL=paymentTypeConst.js.map