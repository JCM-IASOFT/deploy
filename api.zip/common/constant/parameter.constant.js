"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypeCode = exports.GroupConstant = exports.StatusService = void 0;
exports.StatusService = {
    POR_ASIGNAR: "1",
    EN_PROCESO: "2",
    POR_ENTREGAR: "3",
    ENTREGADO: "4",
    RECHAZADO: "5",
    SIN_SOLUCION: "6",
    GARANTIA: "7",
    SIN_SOLUCION_ENTREGADO: "8",
};
exports.GroupConstant = {
    WHATSAPP_MESSAGE: {
        GROUP: "whatsapp_message",
        NAMES: {
            POR_ASIGNAR: "1",
            EN_PROCESO: "2",
            POR_ENTREGAR: "3",
            ENTREGADO: "4",
            RECHAZADO: "5",
            SIN_SOLUCION: "6",
            GARANTIA: "7",
        }
    },
    STIKER_PRINTER: {
        GROUP: 'stiker_printer',
        NAMES: {
            MESSAGE: "message",
            TYPE_CODE: "typecode"
        }
    },
    WAITING_TICKET: {
        GROUP: "waiting_ticket",
        NAMES: {
            MESSAGE: "message"
        }
    },
    PROFORMA: {
        GROUP: "proforma",
        NAMES: {
            TERMS_CONDITIONS: "terms_conditions",
            ADDITIONAL: "additional",
            FAREWELL_MESSAGE: "farewell_message",
        }
    },
};
exports.TypeCode = {
    BARCODE: 'barcode',
    QR: 'qr'
};
//# sourceMappingURL=parameter.constant.js.map