"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidateResult = void 0;
const express_validator_1 = require("express-validator");
const http_status_codes_1 = require("http-status-codes");
const response_handler_1 = require("./response.handler");
const ValidateResult = (req, res, next) => {
    const result = (0, express_validator_1.validationResult)(req);
    if (result.isEmpty()) {
        return next();
    }
    else {
        res.status(http_status_codes_1.StatusCodes.OK).json((0, response_handler_1.ResponseHandler)({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: "Error validacion", data: result }));
    }
};
exports.ValidateResult = ValidateResult;
//# sourceMappingURL=validate.result.js.map