"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getErrorMessage = void 0;
const getErrorMessage = (error) => {
    return error instanceof Error ? error.message : 'Se produjo un error desconocido';
};
exports.getErrorMessage = getErrorMessage;
//# sourceMappingURL=errormessage.handler.js.map