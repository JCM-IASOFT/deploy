"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventManager = void 0;
class EventManager {
    constructor(io) {
        this.io = io;
    }
    emit(event, data) {
        this.io.emit(event, data);
    }
    emitToRoom(roomId, event, data) {
        this.io.to(roomId).emit(event, data);
    }
}
exports.EventManager = EventManager;
//# sourceMappingURL=eventManager.js.map