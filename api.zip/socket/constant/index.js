"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventIo = void 0;
exports.EventIo = {
    ALERT_SALES_TRACKING: 'alert_sales_tracking'
};
//# sourceMappingURL=index.js.map