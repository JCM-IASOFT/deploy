"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventIo = void 0;
exports.EventIo = {
    ALERT_SALES_TRACKING: 'alert_sales_tracking',
    ALERT_TRACKING: 'alert_tracking',
    ALERT_PROFORMAS_TRACKING: 'alert_proformas_tracking'
};
//# sourceMappingURL=index.js.map