"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const conecction_1 = require("./conecction"); // Importa la instancia de Socket.IO
class WebSocketService {
    changePermission(roleId) {
        conecction_1.io.to(roleId.toString()).emit('permission_change', roleId);
    }
}
exports.default = WebSocketService;
//# sourceMappingURL=webSocketService.js.map