"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.webSocketService = void 0;
const conecction_1 = require("./conecction"); // Importa la instancia de Socket.IO
class WebSocketService {
    static getInstance() {
        if (!this.instance)
            this.instance = new WebSocketService();
        return this.instance;
    }
    changePermission(roleId) {
        conecction_1.io.to(roleId.toString()).emit('permission_change', roleId);
    }
    //#region -- SOPORTE TECNICO
    changePauseService(companyId, campusId) {
        conecction_1.io.to(`company_${companyId}_campus_${campusId}`).emit('pause_service', 'servicios pausados hacer accion');
    }
    changeStartService(companyId, campusId) {
        conecction_1.io.to(`company_${companyId}_campus_${campusId}`).emit('start_service', 'servicios starts hacer accion');
    }
}
exports.webSocketService = WebSocketService.getInstance();
//# sourceMappingURL=webSocketService.js.map