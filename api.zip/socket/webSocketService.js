"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.webSocketService = void 0;
const conecction_1 = require("./conecction"); // Importa la instancia de Socket.IO
const constant_1 = require("./constant");
const save_error_1 = require("../common/handler/save.error");
class WebSocketService {
    static getInstance() {
        if (!this.instance)
            this.instance = new WebSocketService();
        return this.instance;
    }
    changePermission(roleId) {
        conecction_1.io.to(roleId.toString()).emit('permission_change', roleId);
    }
    //#region -- SOPORTE TECNICO
    changePauseService(companyId, campusId) {
        conecction_1.io.to(`company_${companyId}_campus_${campusId}`).emit('pause_service', 'servicios pausados hacer accion');
    }
    changeStartService(companyId, campusId) {
        conecction_1.io.to(`company_${companyId}_campus_${campusId}`).emit('start_service', 'servicios starts hacer accion');
    }
    changeServiceStatus(companyId, campusId) {
        conecction_1.io.to(`company_${companyId}_campus_${campusId}`).emit('change_service_status', 'servicio actualizado');
    }
    //#endregion
    //#region -- VENTAS
    alertSalesTracking(companyId, campusId, salesTrackings) {
        save_error_1.logger.info("Enviado alerta");
        console.log("Enviado Alerta");
        conecction_1.io.to(`company_${companyId}_campus_${campusId}`).emit(constant_1.EventIo.ALERT_SALES_TRACKING, salesTrackings);
    }
    alertProformaTracking(companyId, campusId, proformas) {
        save_error_1.logger.info("Enviado alerta");
        console.log("Enviado Alerta PROFORMAS");
        conecction_1.io.to(`company_${companyId}_campus_${campusId}`).emit(constant_1.EventIo.ALERT_PROFORMAS_TRACKING, proformas);
    }
    alertTracking(companyId, campusId, notification) {
        save_error_1.logger.info("Enviado alerta");
        console.log("ALERT TRACKING", companyId, campusId);
        conecction_1.io.to(`company_${companyId}_campus_${campusId}`).emit(constant_1.EventIo.ALERT_TRACKING, notification);
    }
    //#endregion
    //#region -- CREDITOS
    changeCreditSchedule(companyId, creditId, creditScheduleId) {
        conecction_1.io.to(`company_${companyId}_credit_${creditId}_creditSchedule_${creditScheduleId}`).emit('scheduled_installment');
    }
}
exports.webSocketService = WebSocketService.getInstance();
//# sourceMappingURL=webSocketService.js.map