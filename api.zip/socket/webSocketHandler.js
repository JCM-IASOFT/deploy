"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class WebSocketEvents {
    constructor() {
        this.handleSocketEvents = (socket) => {
            // const webSocketService = new WebSocketService();
            // socket.on('WAConnect', async (ioClient: IOClient) => {
            //     await whatsappService.connect(ioClient.clientId)
            // });
            // socket.on('WAClientSession', async (ioClient: IOClient) => {
            //     const client = whatsappService.getSessionClient(ioClient.clientId)
            //     webSocketService.waClientSession(ioClient.clientId, client)
            // });
        };
    }
}
exports.default = WebSocketEvents;
//# sourceMappingURL=webSocketHandler.js.map