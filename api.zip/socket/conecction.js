"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.io = exports.initializeSocketServer = void 0;
// sockets/socketServer.ts
const socket_io_1 = require("socket.io");
let io;
const initializeSocketServer = (server) => {
    exports.io = io = new socket_io_1.Server(server, { cors: { origin: "*" } });
    io.on('connection', (socket) => {
        socket.on('joinCompanyAndCampus', ({ companyId, campusId }) => {
            // Crear nombre de la sala para la empresa
            const companyCampusRoom = `company_${companyId}_campus_${campusId}`;
            // Unir a la sala del campus
            socket.join(companyCampusRoom);
            console.log("🚀 ~ JOIN::::", companyCampusRoom);
            // Emitir mensaje a la sala de la empresa
            io.to(companyCampusRoom).emit('message', `Campus ${campusId} se ha unido a la empresa ${companyId}`);
        });
        socket.on('joinRoom', (room) => {
            socket.join(room);
        });
    });
};
exports.initializeSocketServer = initializeSocketServer;
//# sourceMappingURL=conecction.js.map