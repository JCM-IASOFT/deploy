"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.io = exports.initializeSocketServer = void 0;
// sockets/socketServer.ts
const socket_io_1 = require("socket.io");
const webSocketHandler_1 = __importDefault(require("./webSocketHandler"));
let io;
const webEvent = new webSocketHandler_1.default();
const initializeSocketServer = (server) => {
    exports.io = io = new socket_io_1.Server(server, { cors: { origin: "*" } });
    io.on('connection', (socket) => {
        socket.on('joinRoom', (room) => {
            socket.join(room);
        });
        webEvent.handleSocketEvents(socket);
    });
};
exports.initializeSocketServer = initializeSocketServer;
//# sourceMappingURL=conecction.js.map