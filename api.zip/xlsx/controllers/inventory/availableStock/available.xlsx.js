"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportToProductExcel = void 0;
const XLSX = __importStar(require("xlsx"));
const exportToProductExcel = (productos) => {
    // Define los encabezados personalizados
    const encabezados = [
        "CÓDIGO",
        "DESCRIPCIÓN",
        "PRECIO DISTRIBUIDOR",
        "PRECIO PRODUCTO",
        "STOCK",
        "COMISIÓN",
        "PERECIBLE",
        "CONTROLAR STOCK",
        "FACTURABLE",
        "AFECTO ICBPER",
        "SUJETO A DETRACCIÓN",
        "SERIAL",
        "STOCK MÍNIMO",
        "STOCK MÁXIMO",
        "PESO NETO",
        "PESO BRUTO",
        "ESTADO",
    ];
    // Mapea los datos del modelo para que coincidan con los encabezados personalizados
    const datosFormateados = productos.map(producto => ({
        "CÓDIGO": producto.code,
        "DESCRIPCIÓN": producto.description,
        "PRECIO DISTRIBUIDOR": producto.priceDistributor,
        "PRECIO PRODUCTO": producto.priceProduct,
        "STOCK": producto.stock,
        "COMISIÓN": producto.commission,
        "PERECIBLE": producto.perishable ? 'Sí' : 'No',
        "CONTROLAR STOCK": producto.countStock ? 'Sí' : 'No',
        "FACTURABLE": producto.isBillable ? 'Sí' : 'No',
        "AFECTO ICBPER": producto.isICBPERAffected ? 'Sí' : 'No',
        "SUJETO A DETRACCIÓN": producto.isSubjectToDetraction ? 'Sí' : 'No',
        "SERIAL": producto.hasSerialNumber ? 'Sí' : 'No',
        "STOCK MÍNIMO": producto.stockMin,
        "STOCK MÁXIMO": producto.stockMax,
        "PESO NETO": producto.netWeight,
        "PESO BRUTO": producto.grossWeight,
        "ESTADO": producto.status ? 'Activo' : 'Inactivo'
    }));
    // Crear la hoja de cálculo con los encabezados personalizados
    const hojaDeCalculo = XLSX.utils.json_to_sheet(datosFormateados, { header: encabezados });
    // Crear un nuevo libro de trabajo y agregar la hoja de cálculo
    const libroDeTrabajo = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libroDeTrabajo, hojaDeCalculo, 'Productos');
    // Generar un archivo Excel en formato buffer
    const bufferExcel = XLSX.write(libroDeTrabajo, { bookType: 'xlsx', type: 'buffer' });
    return bufferExcel;
};
exports.exportToProductExcel = exportToProductExcel;
//# sourceMappingURL=available.xlsx.js.map