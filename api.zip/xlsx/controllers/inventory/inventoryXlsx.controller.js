"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.inventoryXlsxController = void 0;
const http_status_codes_1 = require("http-status-codes");
const kardex_xlsx_1 = require("./kardex/kardex.xlsx");
const product_service_1 = require("../../../inventory/product/service/product.service");
const available_xlsx_1 = require("./availableStock/available.xlsx");
class InventoryXlsxController {
    constructor() {
        this.findKardexXlsx = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { productId, startDate, endDate, timeZone } = req.body;
                const kardex = yield product_service_1.productService.kardex(productId, startDate, endDate, timeZone);
                const buffer = (0, kardex_xlsx_1.exportToExcel)(kardex);
                res.setHeader('Content-Disposition', 'attachment; filename="data.xlsx"');
                res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                res.send(buffer);
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.findProductsXlsx = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { productId } = req.body;
                const products = yield product_service_1.productService.findProductAvailableStock(productId);
                const buffer = (0, available_xlsx_1.exportToProductExcel)(products);
                res.setHeader('Content-Disposition', 'attachment; filename="data.xlsx"');
                res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                res.send(buffer);
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new InventoryXlsxController();
        return this.instance;
    }
}
exports.inventoryXlsxController = InventoryXlsxController.getInstance();
//# sourceMappingURL=inventoryXlsx.controller.js.map