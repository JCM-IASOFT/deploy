"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportToExcel = void 0;
const XLSX = __importStar(require("xlsx"));
const exportToExcel = (data) => {
    // Define los encabezados personalizados
    const headers = [
        "FECHA",
        "DESCRIPCION",
        "CANTIDAD ENTRADA",
        "VALOR ENTRADA",
        "VALOR TOTAL ENTRADA",
        "CANTIDAD SALIDA",
        "VALOR SALIDA",
        "VALOR TOTAL SALIDA",
        "CANTIDAD SALDO",
        "VALOR SALDO",
        "VALOR TOTAL SALDO",
    ];
    // Mapea los datos para que coincidan con los encabezados personalizados
    const formattedData = data.map(item => ({
        "FECHA": item.date,
        "DESCRIPCION": item.description,
        "CANTIDAD ENTRADA": item.inputAmount,
        "VALOR ENTRADA": item.inputValue,
        "VALOR TOTAL ENTRADA": item.inputAmount * item.inputValue,
        "CANTIDAD SALIDA": item.outputAmount,
        "VALOR SALIDA": item.outputValue,
        "VALOR TOTAL SALIDA": item.outputAmount * item.outputValue,
        "CANTIDAD SALDO": item.balanceQuantity,
        "VALOR SALDO": item.balanceValue,
        "VALOR TOTAL SALDO": item.balanceQuantity * item.balanceValue,
    }));
    // Crear la hoja de cálculo con los encabezados personalizados
    const worksheet = XLSX.utils.json_to_sheet(formattedData, { header: headers });
    // Aplica estilos a los encabezados
    const headerRange = XLSX.utils.decode_range(worksheet['!ref']);
    for (let col = headerRange.s.c; col <= headerRange.e.c; col++) {
        const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
        worksheet[cellAddress].s = {
            font: {
                bold: true,
            },
            alignment: {
                horizontal: "center"
            }
        };
    }
    // Crear un nuevo libro de trabajo y agregar la hoja de cálculo
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Kardex');
    // Generar un archivo Excel en formato buffer
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });
    return excelBuffer;
};
exports.exportToExcel = exportToExcel;
//# sourceMappingURL=kardex.xlsx.js.map