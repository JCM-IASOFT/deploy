"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateReportXlsxRange = void 0;
const ExcelJS = __importStar(require("exceljs"));
const service_service_1 = require("../../../support/service/service/service.service");
const generateReportXlsxRange = (campusId, startDate, endDate, timeZone) => __awaiter(void 0, void 0, void 0, function* () {
    const services = yield service_service_1.serviceService.findRangeService(campusId, startDate, endDate, timeZone);
    // Crear un nuevo libro de trabajo
    const workbook = new ExcelJS.Workbook();
    // Añadir una nueva hoja de trabajo
    const worksheet = workbook.addWorksheet('servicios');
    // Definir los encabezados y la información
    const headers = [
        ['Registo de servicios'],
        ['Mostrando registros por rango de fecha'],
        ['ID', 'FECHA RECEPCION', 'ENCARGADO DE RECEPCION', 'CLIENTE', 'TECNICO ENCARGADO', 'TOTAL', 'FECHA ENTREGA']
    ];
    // Añadir las filas al worksheet
    headers.forEach((header) => {
        worksheet.addRow(header);
    });
    // Estilos para las celdas
    for (let i = 1; i <= 7; i++) {
        worksheet.getCell(3, i).fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: '060E2C' }
        };
        worksheet.getCell(3, i).font = {
            size: 12,
            bold: true,
            color: { argb: 'FFFFFF' }
        };
    }
    worksheet.getCell('A1').fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '382172' },
    };
    worksheet.getCell('A1').font = {
        size: 15,
        color: { argb: 'FFFFFF' }
    };
    worksheet.getCell('A2').fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '382172' },
    };
    worksheet.getCell('A2').font = {
        color: { argb: 'FFFFFF' }
    };
    // Unir celdas de las primeras dos filas
    worksheet.mergeCells('A1:G1');
    worksheet.mergeCells('A2:G2');
    // Ajustar ancho de columnas
    worksheet.columns = [
        { width: 15 }, { width: 25 }, { width: 15 }, { width: 25 }, { width: 25 },
        { width: 10 }, { width: 20 }
    ];
    // Añadir datos de servicios
    services.forEach((service) => {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        worksheet.addRow([
            (_a = service.serviceId) !== null && _a !== void 0 ? _a : ' ',
            (_b = service.registrationDate) !== null && _b !== void 0 ? _b : ' ',
            (_d = (_c = service.userReception) === null || _c === void 0 ? void 0 : _c.name) !== null && _d !== void 0 ? _d : ' ',
            (_f = (_e = service.client) === null || _e === void 0 ? void 0 : _e.fullname) !== null && _f !== void 0 ? _f : ' ',
            (_h = (_g = service.userTechnical) === null || _g === void 0 ? void 0 : _g.name) !== null && _h !== void 0 ? _h : ' ',
            (_j = service.totalAmount) !== null && _j !== void 0 ? _j : ' ',
            (_k = service.endDate) !== null && _k !== void 0 ? _k : ' '
        ]);
    });
    // Crear el archivo Excel como un blob
    const data = yield workbook.xlsx.writeBuffer();
    return data;
});
exports.generateReportXlsxRange = generateReportXlsxRange;
//# sourceMappingURL=range.generator.js.map