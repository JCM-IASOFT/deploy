"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.xlsxRoute = void 0;
const express_1 = require("express");
const inventoryXlsx_controller_1 = require("../controllers/inventory/inventoryXlsx.controller");
exports.xlsxRoute = (0, express_1.Router)();
exports.xlsxRoute.post('/inventory/kardex', inventoryXlsx_controller_1.inventoryXlsxController.findKardexXlsx);
exports.xlsxRoute.post('/inventory/available', inventoryXlsx_controller_1.inventoryXlsxController.findProductsXlsx);
//# sourceMappingURL=xlsx.routes.js.map