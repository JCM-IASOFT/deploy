"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.productService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class ProductService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProductService();
        return this.instance;
    }
    findAllProduct(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const products = yield modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin("product.prices", "prices")
                    .leftJoin("prices.priceGroup", "priceGroup")
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.currency', 'currency')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.companyId = :companyId', { companyId: companyId })
                    .select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.stock',
                    'product.currencyId',
                    'supplier',
                    'category.categoryId',
                    'category.name',
                    'subCategory.subCategoryId',
                    'subCategory.name',
                    'unitMeasurement.unitMeasurementId',
                    'unitMeasurement.name',
                    'brand.brandId',
                    'brand.name',
                    'group.groupId',
                    'group.name',
                    'presentation.presentationId',
                    'presentation.description',
                    'tax.taxId',
                    'tax.name',
                    'currency.currencyId',
                    'currency.code',
                    'currency.symbol',
                    'currency.currencyName',
                    'prices.priceId',
                    'prices.price',
                    'prices.priceGroupId',
                    'priceGroup.priceGroupId',
                    'priceGroup.name',
                ])
                    .orderBy("product.description", "ASC")
                    .getMany();
                return products;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findProductAvailableStock(companyId, negative, positive, all) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const products = yield modelslibrary_1.ProductModel.query(`
                SELECT 
                p."productId",	
                p."code",
                p.description,    
                p."priceDistributor",
                p."priceProduct",
                p."commission",
                p."perishable",
                p."countStock",
                p."isBillable",
                p."isICBPERAffected",
                p."isSubjectToDetraction",
                p."stockMin",
                p."stockMax",
                p."netWeight",
                p."grossWeight",
                p."status",
                p."brandId",
                p."unitMeasurementId",
                p."subCategoryId",
                p."categoryId",
                p."supplierId",
                p."groupId",
                p."presentationId",
                p."taxId",
                p."stock",
                p."currencyId",
                s."supplierId",
                s."name" as "supplierName",
                c."categoryId",
                c."name" as "categoryName",
                sc."subCategoryId",
                sc."name" as "subCategoryName",
                um."unitMeasurementId",
                um."name" as "unitMeasurementName",
                b."brandId",
                b."name" as "brandName",
                g."groupId",
                g."name" as "groupName",
                pr."presentationId",
                pr."description" as "presentationDescription",
                t."taxId",
                t."name" as "taxName",
                cr."currencyId",
                cr."code" as "currencyCode",
                cr."symbol" as "currencySymbol",
                cr."currencyName",
                prc."priceId",
                prc."price",
                pg."priceGroupId",
                pg."name" as "priceGroupName",
                SUM(CASE WHEN m."inOut" = 'E' THEN md.quantity ELSE 0 END) - 
                SUM(CASE WHEN m."inOut" = 'S' THEN md.quantity ELSE 0 END) AS stock_movement
            FROM 
                inventory.product p
            LEFT JOIN 
                sales.prices prc ON p."productId" = prc."productId"
            LEFT JOIN 
                sales.price_group pg ON prc."priceGroupId" = pg."priceGroupId"
            LEFT JOIN 
                logistics.supplier s ON p."supplierId" = s."supplierId"
            LEFT JOIN 
                inventory.category c ON p."categoryId" = c."categoryId"
            LEFT JOIN 
                inventory.sub_category sc ON p."subCategoryId" = sc."subCategoryId"
            LEFT JOIN 
                inventory.unit_measurement um ON p."unitMeasurementId" = um."unitMeasurementId"
            LEFT JOIN 
                inventory.brand b ON p."brandId" = b."brandId"
            LEFT JOIN 
                inventory.group g ON p."groupId" = g."groupId"
            LEFT JOIN 
                inventory.presentation pr ON p."presentationId" = pr."presentationId"
            LEFT JOIN 
                company.tax t ON p."taxId" = t."taxId"
            LEFT JOIN 
                company.currency cr ON p."currencyId" = cr."currencyId"
            JOIN 
                inventory.movement_detail md ON p."productId" = md."productId"
            JOIN 
                inventory.movement m ON md."movementId" = m."movementId"
            WHERE 
                p."deletedAt" = '0'
                AND p."companyId" = $1
            GROUP BY 
                p."productId", 
                p."code", 
                p.description, 
                p."priceDistributor",
                p."priceProduct",
                p."commission",
                p."perishable",
                p."countStock",
                p."isBillable",
                p."isICBPERAffected",
                p."isSubjectToDetraction",
                p."stockMin",
                p."stockMax",
                p."netWeight",
                p."grossWeight",
                p."status",
                p."brandId",
                p."unitMeasurementId",
                p."subCategoryId",
                p."categoryId",
                p."supplierId",
                p."groupId",
                p."presentationId",
                p."taxId",
                p."stock",
                p."currencyId",
                s."supplierId",
                c."categoryId",
                sc."subCategoryId",
                um."unitMeasurementId",
                b."brandId",
                g."groupId",
                pr."presentationId",
                t."taxId",
                cr."currencyId",
                prc."priceId",
                pg."priceGroupId"
            HAVING
                ${negative ? 'SUM(CASE WHEN m."inOut" = \'E\' THEN md.quantity ELSE 0 END) - SUM(CASE WHEN m."inOut" = \'S\' THEN md.quantity ELSE 0 END) < 0' : ''}
                ${positive ? 'SUM(CASE WHEN m."inOut" = \'E\' THEN md.quantity ELSE 0 END) - SUM(CASE WHEN m."inOut" = \'S\' THEN md.quantity ELSE 0 END) > 0' : ''}
                ${all ? '1=1' : ''};
                `, [companyId]);
                return this.mapProducto(products);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    mapProducto(products) {
        const resultadosMapeados = products.map((fila) => ({
            productId: fila.productId,
            code: fila.code,
            description: fila.description,
            priceDistributor: fila.priceDistributor,
            priceProduct: fila.priceProduct,
            commission: fila.commission,
            perishable: fila.perishable,
            countStock: fila.countStock,
            isBillable: fila.isBillable,
            isICBPERAffected: fila.isICBPERAffected,
            isSubjectToDetraction: fila.isSubjectToDetraction,
            stockMin: fila.stockMin,
            stockMax: fila.stockMax,
            netWeight: fila.netWeight,
            grossWeight: fila.grossWeight,
            status: fila.status,
            stock: fila.stock_movement,
            brand: {
                brandId: fila.brandId,
                name: fila.brandName,
            },
            unitMeasurement: {
                unitMeasurementId: fila.unitMeasurementId,
                name: fila.unitMeasurementName,
            },
            category: {
                categoryId: fila.categoryId,
                name: fila.categoryName,
            },
            subCategory: {
                subCategoryId: fila.subCategoryId,
                name: fila.subCategoryName,
            },
            supplier: {
                supplierId: fila.supplierId,
                name: fila.supplierName,
            },
            group: {
                groupId: fila.groupId,
                name: fila.groupName,
            },
            presentation: {
                presentationId: fila.presentationId,
                description: fila.presentationDescription,
            },
            tax: {
                taxId: fila.taxId,
                name: fila.taxName,
            },
            currency: {
                currencyId: fila.currencyId,
                code: fila.currencyCode,
                symbol: fila.currencySymbol,
                currencyName: fila.currencyName,
            },
            prices: [
                {
                    priceId: fila.priceId,
                    price: fila.price,
                    priceGroup: {
                        priceGroupId: fila.priceGroupId,
                        name: fila.priceGroupName,
                    },
                },
            ],
        }));
        return resultadosMapeados;
    }
    findOneProduct(productId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const products = yield modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.codes', 'codes')
                    .leftJoin('product.currency', 'currency')
                    .leftJoin('product.prices', 'prices')
                    .leftJoin('prices.priceGroup', 'priceGroup')
                    .leftJoin('product.file', 'file')
                    .leftJoin('product.stockBalances', 'stockBalances')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.productId = :productId', { productId })
                    .select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.stock',
                    'product.currencyId',
                    'supplier',
                    'category.categoryId',
                    'category.name',
                    'subCategory.subCategoryId',
                    'subCategory.name',
                    'unitMeasurement.unitMeasurementId',
                    'unitMeasurement.name',
                    'brand.brandId',
                    'brand.name',
                    'group.groupId',
                    'group.name',
                    'presentation.presentationId',
                    'presentation.description',
                    'tax.taxId',
                    'tax.name',
                    'currency.currencyId',
                    'currency.code',
                    'currency.symbol',
                    'currency.currencyName',
                    'prices',
                    'priceGroup',
                    'stockBalances'
                ])
                    .orderBy("product.description", "ASC")
                    .getOne();
                return products;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findProduct(companyId, page, sizePage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const [products, total] = yield modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.currency', 'currency')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.companyId = :companyId', { companyId: companyId })
                    .select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.currencyId',
                    'supplier',
                    'category',
                    'subCategory',
                    'unitMeasurement',
                    'brand',
                    'group',
                    'presentation',
                    'tax',
                    'currency',
                ])
                    .orderBy("product.description", "ASC")
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { products, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findDataTableProduct(page, sizePage, product) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const productBuilder = modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.codes', 'codes')
                    .leftJoin('product.currency', 'currency')
                    .leftJoin('product.prices', 'prices')
                    .leftJoin('prices.priceGroup', 'priceGroup')
                    .leftJoin('product.file', 'file')
                    .leftJoin('product.stockBalances', 'stockBalances')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.companyId = :companyId', { companyId: product.companyId });
                if (product.groupId && product.groupId > 0) {
                    productBuilder.andWhere('product.groupId = :groupId', { groupId: product.groupId });
                }
                if (product.brandId && product.brandId > 0) {
                    productBuilder.andWhere('product.brandId = :brandId', { brandId: product.brandId });
                }
                if (product.categoryId && product.categoryId > 0) {
                    productBuilder.andWhere('product.categoryId = :categoryId', { categoryId: product.categoryId });
                }
                if (product.subCategoryId && product.subCategoryId > 0) {
                    productBuilder.andWhere('product.subCategoryId = :subCategoryId', { subCategoryId: product.subCategoryId });
                }
                if (product.description && product.description !== "") {
                    productBuilder.andWhere("product.description ILIKE :description", { description: `%${product.description}%` });
                }
                if (product.code && product.code !== "") {
                    productBuilder.andWhere("product.code ILIKE :code", { code: `%${product.code}%` });
                }
                productBuilder.select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    //'product.stock',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.registerType',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.fileId',
                    //'product.currentStock',
                    'product.currencyId',
                    'supplier',
                    'category.categoryId',
                    'category.name',
                    'subCategory.subCategoryId',
                    'subCategory.name',
                    'unitMeasurement.unitMeasurementId',
                    'unitMeasurement.name',
                    'brand.brandId',
                    'brand.name',
                    'group.groupId',
                    'group.name',
                    'presentation.presentationId',
                    'presentation.description',
                    'tax.taxId',
                    'tax.name',
                    'currency.currencyId',
                    'currency.code',
                    'currency.symbol',
                    'currency.currencyName',
                    'codes',
                    'prices.priceId',
                    'prices.price',
                    'priceGroup.priceGroupId',
                    'priceGroup.name',
                    'file',
                    'stockBalances',
                ]);
                const [products, total] = yield productBuilder.orderBy("product.description", "ASC")
                    .take(sizePage)
                    .skip(omit)
                    .getManyAndCount();
                return { products, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findProductListPrice(companyId, priceGroupId, storeId, search, code) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const productQueryBuilder = modelslibrary_1.ProductModel.createQueryBuilder("product")
                    .leftJoinAndSelect("product.storeItems", "storeItems")
                    .leftJoinAndSelect("storeItems.store", "store")
                    .leftJoinAndSelect("product.prices", "prices")
                    .leftJoinAndSelect("product.brand", "brand")
                    .leftJoinAndSelect("product.currency", "currency")
                    .leftJoinAndSelect("product.file", "file")
                    .leftJoinAndSelect("product.stockBalances", "stockBalances")
                    .leftJoinAndSelect("prices.priceGroup", "priceGroup")
                    .select([
                    "product.productId",
                    "product.code",
                    "product.stock",
                    "product.description",
                    "product.brandId",
                    "product.priceDistributor",
                    "product.priceProduct",
                    "product.categoryId",
                    "product.countStock",
                    "product.subCategoryId",
                    "brand.brandId",
                    "brand.name",
                    "prices.priceId",
                    "currency.symbol",
                    "currency.code",
                    "prices.price",
                    "prices.priceGroupId",
                    "priceGroup.name",
                    "priceGroup.priceGroupId",
                    "storeItems.quantity",
                    "store.storeId",
                    "file",
                    "stockBalances"
                ])
                    .where("product.companyId = :companyId", { companyId: companyId })
                    .andWhere("product.deletedAt = :deletedAt", { deletedAt: '0' });
                if (priceGroupId && priceGroupId > 0) {
                    productQueryBuilder.andWhere("priceGroup.priceGroupId = :priceGroupId", { priceGroupId: priceGroupId });
                }
                if (search && search !== '') {
                    productQueryBuilder.andWhere("LOWER(product.description) LIKE LOWER(:description)", { description: `%${search.toLowerCase()}%` });
                }
                if (code && code !== '') {
                    productQueryBuilder.andWhere("product.code = :code", { code: code });
                }
                const products = yield productQueryBuilder.getMany();
                return products;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findByCode(code, companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const product = yield modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin("product.prices", "prices")
                    .leftJoin("prices.priceGroup", "priceGroup")
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.currency', 'currency')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.code = :code', { code })
                    .andWhere('product.companyId = :companyId', { companyId })
                    .select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.currencyId',
                    'supplier',
                    'category',
                    'subCategory',
                    'unitMeasurement',
                    'brand',
                    'group',
                    'presentation',
                    'tax',
                    'currency',
                    'prices',
                    'priceGroup'
                ])
                    .getOne();
                return product;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    kardex(productId, startDate, endDate, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const kardex = yield modelslibrary_1.ProductModel.query(`WITH DetailedMovement AS (
                SELECT 
					m."movementId",
                    m.date,
                    t."name" AS description,
                    md.price AS "unitValue",
                    md.quantity,
                    m."inOut"
                FROM 
                    inventory.movement_detail md
                JOIN 
                    inventory.movement m ON m."movementId" = md."movementId"
                JOIN 
                    inventory.transaction t ON m."transactionId" = t."transactionId"
                JOIN 
                    inventory.product p ON p."productId" = md."productId"
                WHERE 
                    p."productId" = $1
                AND DATE(m."date" AT TIME ZONE $2) BETWEEN $3 AND $4
            ),
            AverageCost AS (
                SELECT 
					"movementId",
                    date,
                    description,
                    "unitValue",
                    quantity,
                    "inOut",
                    SUM(
                        CASE 
                            WHEN "inOut" = 'E' THEN quantity * "unitValue" 
                            ELSE 0 
                        END
                    ) OVER (ORDER BY date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) 
                    / 
                    NULLIF(
                        SUM(
                            CASE 
                                WHEN "inOut" = 'E' THEN quantity 
                                ELSE 0 
                            END
                        ) OVER (ORDER BY date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW), 
                        0
                    ) AS "averageCost"
                FROM 
                    DetailedMovement
            )
            SELECT 
				"movementId",
                date,
                description,
                "unitValue",
                CASE 
                    WHEN "inOut" = 'E' THEN quantity ELSE 0
                END AS "inputAmount",
                CASE 
                    WHEN "inOut" = 'E' THEN quantity * "averageCost" ELSE 0
                END AS "inputValue",
                CASE 
                    WHEN "inOut" = 'S' THEN quantity ELSE 0
                END AS "outputAmount",
                CASE 
                    WHEN "inOut" = 'S' THEN quantity * "averageCost" ELSE 0
                END AS "outputValue",
                "inOut",
                SUM(
                        CASE 
                            WHEN "inOut" = 'E' THEN quantity
                            WHEN "inOut" = 'S' THEN -quantity
                            ELSE 0
                        END
                    ) OVER (ORDER BY date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS "balanceQuantity",
                    SUM(
                        CASE 
                            WHEN "inOut" = 'E' THEN quantity * "averageCost"
                            WHEN "inOut" = 'S' THEN -quantity * "averageCost"
                            ELSE 0
                        END
                    ) OVER (ORDER BY date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS "balanceValue"
            FROM 
                AverageCost
            ORDER BY 
                "movementId" ASC;`, [productId, timeZone, startDate, endDate]);
                return kardex;
            }
            catch (error) {
                save_error_1.logger.error(`product - kardex: ${(0, errormessage_handler_1.getErrorMessage)(error)}`);
                return null;
            }
        });
    }
    existCode(code, companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const exist = modelslibrary_1.ProductModel.exists({
                    where: {
                        code: code,
                        companyId: companyId
                    }
                });
                return exist;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createProduct(product, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const productEntity = modelslibrary_1.ProductModel.create(product);
                return yield queryRunner.manager.save(modelslibrary_1.ProductModel, productEntity);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateProduct(productId, product, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ProductModel, { productId }, {
                    description: product.description,
                    priceDistributor: product.priceDistributor,
                    priceProduct: product.priceProduct,
                    stock: product.stock,
                    commission: product.commission,
                    perishable: product.perishable,
                    countStock: product.countStock,
                    isBillable: product.isBillable,
                    isICBPERAffected: product.isICBPERAffected,
                    isSubjectToDetraction: product.isSubjectToDetraction,
                    stockMin: product.stockMin,
                    stockMax: product.stockMax,
                    netWeight: product.netWeight,
                    grossWeight: product.grossWeight,
                    status: product.status,
                    brandId: product.brandId,
                    unitMeasurementId: product.unitMeasurementId,
                    subCategoryId: product.subCategoryId,
                    categoryId: product.categoryId,
                    supplierId: product.supplierId,
                    groupId: product.groupId,
                    presentationId: product.presentationId,
                    companyId: product.companyId,
                    taxId: product.taxId,
                    currencyId: product.currencyId,
                    fileId: product.fileId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteProduct(productId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.ProductModel.update({ productId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.productService = ProductService.getInstance();
//# sourceMappingURL=product.service.js.map