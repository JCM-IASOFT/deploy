"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.productController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const product_service_1 = require("../service/product.service");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const code_service_1 = require("../../code/service/code.service");
const inventory_service_1 = require("../../inventory/service/inventory.service");
const transaction_service_1 = require("../../transaction/service/transaction.service");
const inventoryDetail_service_1 = require("../../inventoryDetail/service/inventoryDetail.service");
const file_service_1 = require("../../../company/file/service/file.service");
const price_service_1 = require("../../../sales/price/service/price.service");
const movement_service_1 = require("../../movement/services/movement.service");
const movementDetail_service_1 = require("../../movementDetail/services/movementDetail.service");
class ProductController {
    constructor() {
        this.findAllProduct = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId } = req.query;
            const products = yield product_service_1.productService.findAllProduct(Number(companyId));
            res.status(http_status_codes_1.StatusCodes.OK).json(products);
        });
        this.findByCode = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { code, companyId } = req.query;
            const products = yield product_service_1.productService.findByCode(code, companyId);
            res.status(http_status_codes_1.StatusCodes.OK).json(products);
        });
        this.findProduct = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId, page, sizePage, } = req.query;
            const response = yield product_service_1.productService.findProduct(Number(companyId), Number(page), Number(sizePage));
            const products = response ? response.products : [];
            const total = response ? response.total : 0;
            res.status(http_status_codes_1.StatusCodes.OK).json({
                data: products,
                draw: Math.random(),
                recordsFiltered: products,
                recordsTotal: total,
            });
        });
        this.findProductListPrice = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId, priceGroupId, storeId, search, code } = req.query;
                const products = yield product_service_1.productService.findProductListPrice(Number(companyId), Number(priceGroupId), Number(storeId), search.toString(), code.toString());
                res.status(http_status_codes_1.StatusCodes.OK).json(products);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json(message_api_1.MessageApi.ERROR_SERVER);
            }
        });
        this.findDataTableProduct = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { page, sizePage, product } = req.body;
            const response = yield product_service_1.productService.findDataTableProduct(page, sizePage, product);
            const products = response ? response.products : [];
            const total = response ? response.total : 0;
            res.status(http_status_codes_1.StatusCodes.OK).json({
                data: products,
                draw: Math.random(),
                recordsFiltered: products.length,
                recordsTotal: total,
            });
        });
        // createProducts = async (req: Request, res: Response) => {
        //     HandleRequest(res, async () => {
        //         const { product, codes, file, prices, movement, movementDetails } = req.body as {
        //             product: ProductModel;
        //             codes: CodeModel[];
        //             file?: FileModel,
        //             prices: PriceModel[],
        //             movement: MovementModel,
        //             movementDetails: MovementDetailModel[]
        //         }
        //         const result = await handleTransaction(async (queryRunner) => {
        //             const existCode = await productService.existCode(product.code, product.companyId)
        //             if (existCode) {
        //                 return { code: StatusCodes.OK, success: false, message: MessageCustomApi.ERROR_EXIST_CODE_PRODUCT };
        //             }
        //             if (file) {
        //                 const savedFile = await fileService.createFileTrans(file, queryRunner);
        //                 product.fileId = savedFile.fileId
        //             }
        //             const productSaved = await productService.createProduct(product, queryRunner);
        //             const updatedCodes = codes.map(code => ({ ...code, productId: productSaved.productId }));
        //             // ** guardar movimiento
        //             const savedMovement = await movementService.createMovement(movement, queryRunner)
        //             const movementDetailWhitId = movementDetails.map(m => ({ ...m, productId: productSaved.productId, movementId: savedMovement.movementId }))
        //             await Promise.all(movementDetailWhitId.map(md => movementDetailService.createMovementDetail(md, queryRunner)))
        //             await Promise.all(updatedCodes.map(code => codeService.createCode(code, queryRunner)))
        //             if (prices && prices.length > 0) {
        //                 const priceWhithProductId = prices.map(price => ({ ...price, productId: productSaved.productId }))
        //                 await Promise.all(priceWhithProductId.map(price => priceService.createPrice(price, queryRunner)))
        //             }
        //             return { code: StatusCodes.OK, success: true, message: MessageCustomApi.END_SUCCESS_SERVICE, data: productSaved };
        //         });
        //         return result;
        //     });
        // }
        //#region :: Create product
        this.createProducts = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const { product, codes, file, prices, movement, movementDetails } = req.body;
                const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    if (yield this.isProductCodeExisting(product.code, product.companyId)) {
                        return this.createErrorResponse(http_status_codes_1.StatusCodes.OK, message_api_1.MessageCustomApi.ERROR_EXIST_CODE_PRODUCT);
                    }
                    if (file) {
                        product.fileId = yield this.saveFileAndGetId(file, queryRunner);
                    }
                    const productSaved = yield product_service_1.productService.createProduct(product, queryRunner);
                    yield this.saveRelatedEntities({
                        productSaved,
                        codes,
                        movement,
                        movementDetails,
                        prices,
                        queryRunner
                    });
                    return this.createSuccessResponse(productSaved);
                }));
                return result;
            }));
        });
        this.isProductCodeExisting = (code, companyId) => __awaiter(this, void 0, void 0, function* () {
            return yield product_service_1.productService.existCode(code, companyId);
        });
        this.saveFileAndGetId = (file, queryRunner) => __awaiter(this, void 0, void 0, function* () {
            const savedFile = yield file_service_1.fileService.createFileTrans(file, queryRunner);
            return savedFile.fileId;
        });
        this.saveRelatedEntities = (_a) => __awaiter(this, [_a], void 0, function* ({ productSaved, codes, movement, movementDetails, prices, queryRunner }) {
            const updatedCodes = this.assignProductIdToCodes(codes, productSaved.productId);
            const savedMovement = yield movement_service_1.movementService.createMovement(movement, queryRunner);
            const movementDetailsWithIds = this.assignIdsToMovementDetails(movementDetails, productSaved.productId, savedMovement.movementId);
            yield Promise.all([
                ...movementDetailsWithIds.map(md => movementDetail_service_1.movementDetailService.createMovementDetail(md, queryRunner)),
                ...updatedCodes.map(code => code_service_1.codeService.createCode(code, queryRunner))
            ]);
            if (prices === null || prices === void 0 ? void 0 : prices.length) {
                const pricesWithProductId = this.assignProductIdToPrices(prices, productSaved.productId);
                yield Promise.all(pricesWithProductId.map(price => price_service_1.priceService.createPrice(price, queryRunner)));
            }
        });
        this.assignProductIdToCodes = (codes, productId) => {
            return codes.map(code => (Object.assign(Object.assign({}, code), { productId })));
        };
        this.assignIdsToMovementDetails = (movementDetails, productId, movementId) => {
            return movementDetails.map(detail => (Object.assign(Object.assign({}, detail), { productId, movementId })));
        };
        this.assignProductIdToPrices = (prices, productId) => {
            return prices.map(price => (Object.assign(Object.assign({}, price), { productId })));
        };
        this.createErrorResponse = (statusCode, message) => {
            return { code: statusCode, success: false, message };
        };
        this.createSuccessResponse = (productSaved) => {
            return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_PRODUCT, data: productSaved };
        };
        //#endregion
        /**
         * Crea un producto en el inventario.
         *
         * @param {Request} req - Solicitud de Express con los detalles del producto.
         * @param {Response} res - Respuesta de Express.
         */
        this.createProductToInventory = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const { product, codes, file, transaction, inventory, inventoryDetail } = req.body;
                const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    const existCode = yield product_service_1.productService.existCode(product.code, product.companyId);
                    if (existCode) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: false, message: message_api_1.MessageCustomApi.ERROR_EXIST_CODE_PRODUCT };
                    }
                    if (file) {
                        const savedFile = yield file_service_1.fileService.createFileTrans(file, queryRunner);
                        product.fileId = savedFile.fileId;
                    }
                    const productSaved = yield product_service_1.productService.createProduct(product, queryRunner);
                    const updatedCodes = codes.map(code => (Object.assign(Object.assign({}, code), { productId: productSaved.productId })));
                    const transactionSaved = yield transaction_service_1.transactionService.createTransaction(transaction, queryRunner);
                    inventory.transactionId = transactionSaved.transactionId;
                    const inventorySaved = yield inventory_service_1.inventoryService.createInventory(inventory, queryRunner);
                    inventoryDetail.inventoryId = inventorySaved.inventoryId;
                    inventoryDetail.productId = productSaved.productId;
                    yield inventoryDetail_service_1.inventoryDetailService.createInventoryDetail(inventoryDetail, queryRunner);
                    yield Promise.all(updatedCodes.map(code => code_service_1.codeService.createCode(code, queryRunner)));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.END_SUCCESS_SERVICE, data: productSaved };
                }));
                return result;
            }));
        });
        this.updateProduct = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const productId = req.params.productId;
                const { product, codes, prices, file } = req.body;
                const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    if (file) {
                        const savedFile = yield file_service_1.fileService.createFileTrans(file, queryRunner);
                        product.fileId = savedFile.fileId;
                    }
                    const productSaved = yield product_service_1.productService.updateProduct(Number(productId), product, queryRunner);
                    yield code_service_1.codeService.deleteCode(product.productId, queryRunner);
                    yield Promise.all(codes.map(code => code_service_1.codeService.createCode(code, queryRunner)));
                    if (prices && prices.length > 0) {
                        yield price_service_1.priceService.deletePriceByProduct(product.productId, queryRunner);
                        yield Promise.all(prices.map(price => price_service_1.priceService.createPrice(price, queryRunner)));
                    }
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.END_SUCCESS_SERVICE, data: productSaved };
                }));
                return result;
            }));
        });
        this.deleteProduct = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const productId = req.params.productId;
                const response = yield product_service_1.productService.deleteProduct(Number(productId));
                if (response.affected > 0) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_BRAND, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ProductController();
        return this.instance;
    }
}
exports.productController = ProductController.getInstance();
//# sourceMappingURL=product.controller.js.map