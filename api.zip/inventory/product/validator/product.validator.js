"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteProduct = exports.validateUpdateProduct = exports.validateCreateProduct = void 0;
const express_validator_1 = require("express-validator");
const save_error_1 = require("../../../common/handler/save.error");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        save_error_1.logger.error(`Validators: `, errors);
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateProductId = (0, express_validator_1.param)('productId')
    .exists().withMessage('El parámetro productId es requerido')
    .isNumeric().withMessage('El parámetro productId debe ser numérico');
const validateCompany = (0, express_validator_1.check)('product.companyId')
    .exists().not().isEmpty().withMessage('El companyId es requerido');
const validateCode = (0, express_validator_1.check)('product.codigo')
    .optional().trim().not().isEmpty().withMessage('El codigo del producto es requerida');
const validateDescription = (0, express_validator_1.check)('product.description')
    .optional().trim().not().isEmpty().withMessage('La descripción del producto es requerida');
const validatePriceDistributor = (0, express_validator_1.check)('priceDistributor')
    .optional().isNumeric().withMessage('El precio de distribución debe ser un valor numérico');
const validatePriceProduct = (0, express_validator_1.check)('priceProduct')
    .optional().isNumeric().withMessage('El precio base del producto debe ser un valor numérico');
const validateCommission = (0, express_validator_1.check)('commission')
    .optional().isNumeric().withMessage('La comisión debe ser un valor numérico');
const validateStockMin = (0, express_validator_1.check)('stockMin')
    .optional().isInt({ min: 0 }).withMessage('El stock mínimo debe ser un número entero mayor o igual a 0');
const validateStockMax = (0, express_validator_1.check)('stockMax')
    .optional().isInt({ min: 0 }).withMessage('El stock máximo debe ser un número entero mayor o igual a 0');
const validateNetWeight = (0, express_validator_1.check)('netWeight')
    .optional().isNumeric().withMessage('El peso neto debe ser un valor numérico');
const validateGrossWeight = (0, express_validator_1.check)('grossWeight')
    .optional().isNumeric().withMessage('El peso bruto debe ser un valor numérico');
const validateBrandId = (0, express_validator_1.check)('brandId')
    .optional().isInt({ min: 1 }).withMessage('El ID de la marca debe ser un número entero mayor a 0');
const validateUnitMeasurementId = (0, express_validator_1.check)('unitMeasurementId')
    .optional().isInt({ min: 1 }).withMessage('El ID de la unidad de medida debe ser un número entero mayor a 0');
exports.validateCreateProduct = [
    validateCompany,
    validateCode,
    validateDescription,
    //validatePriceDistributor,
    //validatePriceProduct,
    //validateCommission,
    //validateStockMin,
    //validateStockMax,
    //validateNetWeight,
    //validateGrossWeight,
    //validateBrandId,
    //validateUnitMeasurementId,
    handleValidationResult
];
exports.validateUpdateProduct = [
    validateProductId,
    validateCode,
    validateDescription,
    //validatePriceDistributor,
    //validatePriceProduct,
    //validateCommission,
    //validateStockMin,
    //validateStockMax,
    //validateNetWeight,
    //validateGrossWeight,
    //validateBrandId,
    //validateUnitMeasurementId,
    handleValidationResult
];
exports.validateDeleteProduct = [
    validateProductId,
    handleValidationResult
];
//# sourceMappingURL=product.validator.js.map