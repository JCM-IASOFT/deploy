"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productRoute = void 0;
const express_1 = require("express");
const product_controller_1 = require("../controller/product.controller");
const product_validator_1 = require("../validator/product.validator");
exports.productRoute = (0, express_1.Router)();
exports.productRoute.get('/', product_controller_1.productController.findProduct);
exports.productRoute.get('/all', product_controller_1.productController.findAllProduct);
exports.productRoute.get('/code', product_controller_1.productController.findByCode);
exports.productRoute.get('/kardex', product_controller_1.productController.kardex);
exports.productRoute.get('/price_group', product_controller_1.productController.findProductListPrice);
exports.productRoute.post('/datatable', product_controller_1.productController.findDataTableProduct);
exports.productRoute.post('/', product_validator_1.validateCreateProduct, product_controller_1.productController.createProducts);
exports.productRoute.post('/created_inventory', product_controller_1.productController.createProductToInventory);
exports.productRoute.put('/:productId', product_validator_1.validateUpdateProduct, product_controller_1.productController.updateProduct);
exports.productRoute.delete('/:productId', product_validator_1.validateDeleteProduct, product_controller_1.productController.deleteProduct);
//# sourceMappingURL=product.router.js.map