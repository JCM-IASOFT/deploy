"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.presentationRoute = void 0;
const express_1 = require("express");
const presentation_controller_1 = require("../controller/presentation.controller");
exports.presentationRoute = (0, express_1.Router)();
exports.presentationRoute.get('/', presentation_controller_1.presentationController.findPresentation);
exports.presentationRoute.post('/create', presentation_controller_1.presentationController.createPresentation);
exports.presentationRoute.put('/update', presentation_controller_1.presentationController.updatePresentation);
exports.presentationRoute.put('/delete/:presentationId', presentation_controller_1.presentationController.deletePresentation);
//# sourceMappingURL=presentation.router.js.map