"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteStore = exports.validateUpdateStore = exports.validateCreateStore = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateStore = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateStore = [
    (0, express_validator_1.check)('StoreId').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteStore = [
    (0, express_validator_1.check)('StoreId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=storeType.validator.js.map