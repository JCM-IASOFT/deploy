"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.storeTypeRoute = void 0;
const express_1 = require("express");
const storeType_controller_1 = require("../controller/storeType.controller");
exports.storeTypeRoute = (0, express_1.Router)();
exports.storeTypeRoute.get('/', storeType_controller_1.storeTypeController.findStoreType);
exports.storeTypeRoute.post('/create', storeType_controller_1.storeTypeController.createStoreType);
exports.storeTypeRoute.put('/update', storeType_controller_1.storeTypeController.updateStoreType);
exports.storeTypeRoute.put('/delete/:storeTypeId', storeType_controller_1.storeTypeController.deleteStoreType);
//# sourceMappingURL=storeType.router.js.map