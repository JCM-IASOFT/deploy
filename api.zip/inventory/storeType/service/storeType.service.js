"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.storeTypeService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class StoreTypeService {
    static getInstance() {
        if (!this.instance)
            this.instance = new StoreTypeService();
        return this.instance;
    }
    findStoreType(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const storeTypes = yield models_1.StoreTypeModel.find({
                    where: {
                        companyId,
                        deletedAt: '0'
                    },
                    select: {
                        storeTypeId: true,
                        type: true,
                        companyId: true
                    }
                });
                return storeTypes;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createStoreType(storeType) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const createResponse = models_1.StoreTypeModel.create({
                    type: storeType.type,
                    companyId: storeType.companyId,
                });
                return yield models_1.StoreTypeModel.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateStoreType(storeType) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = models_1.StoreTypeModel.update({ storeTypeId: storeType.storeTypeId }, {
                    type: storeType.type,
                    companyId: storeType.companyId,
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteStoreType(storeTypeId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = models_1.StoreTypeModel.update({ storeTypeId: storeTypeId }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.storeTypeService = StoreTypeService.getInstance();
//# sourceMappingURL=storeType.service.js.map