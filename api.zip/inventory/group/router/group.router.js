"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.groupRoute = void 0;
const express_1 = require("express");
const groupcontroller_1 = require("../controller/groupcontroller");
exports.groupRoute = (0, express_1.Router)();
exports.groupRoute.get('/', groupcontroller_1.groupController.findGroup);
exports.groupRoute.post('/create', groupcontroller_1.groupController.createGroup);
exports.groupRoute.put('/update', groupcontroller_1.groupController.updateGroup);
exports.groupRoute.put('/delete/:groupId', groupcontroller_1.groupController.deleteGroup);
//# sourceMappingURL=group.router.js.map