"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.groupService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class GroupService {
    static getInstance() {
        if (!this.instance)
            this.instance = new GroupService();
        return this.instance;
    }
    findGroup(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Groups = yield modelslibrary_1.GroupModel.find({
                    where: {
                        companyId,
                        deletedAt: '0'
                    },
                });
                return Groups;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createGroup(group) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const createResponse = modelslibrary_1.GroupModel.create(group);
                return yield modelslibrary_1.GroupModel.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateGroup(group) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = modelslibrary_1.GroupModel.update({ groupId: group.groupId }, {
                    name: group.name,
                    description: group.description,
                    productTypeId: group.productTypeId,
                    correlative: group.correlative,
                    companyId: group.companyId
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteGroup(groupId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = modelslibrary_1.GroupModel.update({ groupId: groupId }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.groupService = GroupService.getInstance();
//# sourceMappingURL=group.service.js.map