"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.groupController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const group_service_1 = require("../service/group.service");
class GroupController {
    constructor() {
        this.findGroup = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId } = req.query;
                const Groups = yield group_service_1.groupService.findGroup(Number(companyId));
                res.status(http_status_codes_1.StatusCodes.OK).json(Groups);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
        this.createGroup = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { group } = req.body;
                    const groups = yield group_service_1.groupService.createGroup(group);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_GROUP, data: groups };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
        this.updateGroup = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { group } = req.body;
                    const groups = yield group_service_1.groupService.updateGroup(group);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_GROUP, data: groups };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
        this.deleteGroup = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { groupId } = req.params;
                    const groups = yield group_service_1.groupService.deleteGroup(Number(groupId));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_GROUP, data: groups };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new GroupController();
        return this.instance;
    }
}
exports.groupController = GroupController.getInstance();
//# sourceMappingURL=groupcontroller.js.map