"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unitMeasurementService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class UnitMeasurementService {
    static getInstance() {
        if (!this.instance)
            this.instance = new UnitMeasurementService();
        return this.instance;
    }
    findUnitMeasurement(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const UnitMeasurements = yield models_1.UnitMeasurementModel.find({
                    where: {
                        companyId,
                        deletedAt: '0'
                    },
                });
                return UnitMeasurements;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createUnitMeasurement(unitMeasurement) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const createResponse = models_1.UnitMeasurementModel.create(unitMeasurement);
                return yield models_1.UnitMeasurementModel.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateUnitMeasurement(unitMeasurement) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = models_1.UnitMeasurementModel.update({ unitMeasurementId: unitMeasurement.unitMeasurementId }, {
                    name: unitMeasurement.name,
                    description: unitMeasurement.description,
                    abbreviation: unitMeasurement.abbreviation,
                    factor: unitMeasurement.factor,
                    decimal: unitMeasurement.decimal,
                    companyId: unitMeasurement.companyId,
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteUnitMeasurement(unitMeasurementId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = models_1.UnitMeasurementModel.update({ unitMeasurementId: unitMeasurementId }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.unitMeasurementService = UnitMeasurementService.getInstance();
//# sourceMappingURL=unitMeasurement.service.js.map