"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unitMeasurementController = void 0;
const http_status_codes_1 = require("http-status-codes");
const unitMeasurement_service_1 = require("../service/unitMeasurement.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
class UnitMeasurementController {
    constructor() {
        this.findUnitMeasurement = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId } = req.query;
                const unitMeasurements = yield unitMeasurement_service_1.unitMeasurementService.findUnitMeasurement(Number(companyId));
                res.status(http_status_codes_1.StatusCodes.OK).json(unitMeasurements);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
        this.createUnitMeasurement = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { unitMeasurement } = req.body;
                    const unitMeasurements = yield unitMeasurement_service_1.unitMeasurementService.createUnitMeasurement(unitMeasurement);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_UNIT_MEASUREMENT, data: unitMeasurements };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
        this.updateUnitMeasurement = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { unitMeasurement } = req.body;
                    const unitMeasurements = yield unitMeasurement_service_1.unitMeasurementService.updateUnitMeasurement(unitMeasurement);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_UNIT_MEASUREMENT, data: unitMeasurements };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
        this.deleteUnitMeasurement = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { unitMeasurementId } = req.params;
                    const unitMeasurements = yield unitMeasurement_service_1.unitMeasurementService.deleteUnitMeasurement(Number(unitMeasurementId));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_UNIT_MEASUREMENT, data: unitMeasurements };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new UnitMeasurementController();
        return this.instance;
    }
}
exports.unitMeasurementController = UnitMeasurementController.getInstance();
//# sourceMappingURL=unitMeasurement.controller.js.map