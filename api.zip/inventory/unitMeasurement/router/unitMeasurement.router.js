"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unitMeasurementRoute = void 0;
const express_1 = require("express");
const unitMeasurement_controller_1 = require("../controller/unitMeasurement.controller");
exports.unitMeasurementRoute = (0, express_1.Router)();
exports.unitMeasurementRoute.get('/', unitMeasurement_controller_1.unitMeasurementController.findUnitMeasurement);
exports.unitMeasurementRoute.post('/create', unitMeasurement_controller_1.unitMeasurementController.createUnitMeasurement);
exports.unitMeasurementRoute.put('/update', unitMeasurement_controller_1.unitMeasurementController.updateUnitMeasurement);
exports.unitMeasurementRoute.put('/delete/:unitMeasurementId', unitMeasurement_controller_1.unitMeasurementController.deleteUnitMeasurement);
//# sourceMappingURL=unitMeasurement.router.js.map