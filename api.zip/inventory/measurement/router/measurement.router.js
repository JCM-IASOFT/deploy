"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.measurementRoute = void 0;
const express_1 = require("express");
const measurement_controller_1 = require("../controller/measurement.controller");
exports.measurementRoute = (0, express_1.Router)();
exports.measurementRoute.get('/', measurement_controller_1.measurementController.findMeasurement);
exports.measurementRoute.post('/create', measurement_controller_1.measurementController.createMeasurement);
exports.measurementRoute.put('/update', measurement_controller_1.measurementController.updateMeasurement);
exports.measurementRoute.put('/delete/:measurementId', measurement_controller_1.measurementController.deleteMeasurement);
//# sourceMappingURL=measurement.router.js.map