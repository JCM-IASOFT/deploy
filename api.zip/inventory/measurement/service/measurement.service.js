"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.measurementService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class MeasurementService {
    static getInstance() {
        if (!this.instance)
            this.instance = new MeasurementService();
        return this.instance;
    }
    findMeasurement(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Measurements = yield models_1.MeasurementModel.find({
                    where: {
                        companyId,
                        deletedAt: '0'
                    },
                });
                return Measurements;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createMeasurement(measurement) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const createResponse = models_1.MeasurementModel.create(measurement);
                return yield models_1.MeasurementModel.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateMeasurement(measurement) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = models_1.MeasurementModel.update({ measurementId: measurement.measurementId }, {
                    name: measurement.name,
                    abbreviation: measurement.abbreviation,
                    description: measurement.description,
                    companyId: measurement.companyId
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteMeasurement(measurementId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = models_1.MeasurementModel.update({ measurementId: measurementId }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.measurementService = MeasurementService.getInstance();
//# sourceMappingURL=measurement.service.js.map