"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteUnitMeasureMent = exports.validateUpdateUnitMeasureMent = exports.validateCreateUnitMeasureMent = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateUnitMeasureMent = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('s').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateUnitMeasureMent = [
    (0, express_validator_1.check)('unitMeasureMentId').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteUnitMeasureMent = [
    (0, express_validator_1.check)('unitMeasureMentId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=measurement.validator.js.map