"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.movementController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const movementDetail_service_1 = require("../../movementDetail/services/movementDetail.service");
const stockBalance_service_1 = require("../../stockBalance/services/stockBalance.service");
const movement_service_1 = require("../services/movement.service");
class MovementController {
    constructor() {
        this.findMovement = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId } = req.query;
            const movements = yield movement_service_1.movementService.findMovement(Number(companyId));
            res.status(http_status_codes_1.StatusCodes.OK).json(movements);
        });
        //#region :: Create movement
        this.createMovements = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const { movement, stockBalance, movementDetails } = req.body;
                const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    const movementSaved = yield movement_service_1.movementService.createMovement(movement, queryRunner);
                    const updateMovementDetails = movementDetails.map(detail => (Object.assign(Object.assign({}, detail), { movementId: movementSaved.movementId })));
                    yield Promise.all(updateMovementDetails.map(detail => movementDetail_service_1.movementDetailService.createMovementDetail(detail, queryRunner)));
                    yield stockBalance_service_1.stockBalanceService.createStockBalance(stockBalance, queryRunner);
                    return this.createSuccessResponse(movementSaved);
                }));
                return result;
            }));
        });
        this.createSuccessResponse = (movementSaved) => {
            return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_MOVEMENT, data: movementSaved };
        };
        //#endregion
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new MovementController();
        return this.instance;
    }
}
exports.movementController = MovementController.getInstance();
//# sourceMappingURL=movement.controller.js.map