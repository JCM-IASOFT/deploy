"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.movementRoute = void 0;
const express_1 = require("express");
const movement_controller_1 = require("../controllers/movement.controller");
exports.movementRoute = (0, express_1.Router)();
exports.movementRoute.get('/', movement_controller_1.movementController.findMovement);
exports.movementRoute.post('/', movement_controller_1.movementController.createMovements);
//# sourceMappingURL=product.router.js.map