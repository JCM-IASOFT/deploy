"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transactionRoute = void 0;
const express_1 = require("express");
const transaction_controller_1 = require("../controller/transaction.controller");
exports.transactionRoute = (0, express_1.Router)();
exports.transactionRoute.get('/', transaction_controller_1.transactionController.findTransaction);
//# sourceMappingURL=transaction.router.js.map