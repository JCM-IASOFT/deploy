"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteBrand = exports.validateUpdateBrand = exports.validateCreateBrand = void 0;
const express_validator_1 = require("express-validator");
// * Función de manejo de resultados de validación
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
// * Validación común para el identificador de marca
const validateBrandId = (0, express_validator_1.param)('brandId')
    .exists().withMessage('El parámetro brandId es requerido')
    .isNumeric().withMessage('El parámetro brandId debe ser numérico');
// * Validación común para el nombre de la marca
const validateBrandName = (0, express_validator_1.check)('name')
    .exists().trim().not().isEmpty().withMessage('El nombre de la marca es requerido');
// * Validación común para el identificador de empresa
const validateCompanyId = (0, express_validator_1.check)('companyId')
    .exists().not().isEmpty().withMessage('El companyId es requerido');
// * Validación para la creación de una marca
exports.validateCreateBrand = [
    validateBrandName,
    validateCompanyId,
    handleValidationResult
];
// * Validación para la actualización de una marca
exports.validateUpdateBrand = [
    validateBrandId,
    validateBrandName,
    handleValidationResult
];
// * Validación para la eliminación de una marca
exports.validateDeleteBrand = [
    validateBrandId,
    handleValidationResult
];
//# sourceMappingURL=brand.validator.js.map