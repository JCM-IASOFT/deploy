"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.brandRoute = void 0;
const express_1 = require("express");
const brand_controller_1 = require("../controller/brand.controller");
const brand_validator_1 = require("../validator/brand.validator");
exports.brandRoute = (0, express_1.Router)();
exports.brandRoute.get('/', brand_controller_1.brandController.findBrand);
exports.brandRoute.post('/', brand_validator_1.validateCreateBrand, brand_controller_1.brandController.createBrands);
exports.brandRoute.put('/:brandId', brand_validator_1.validateUpdateBrand, brand_controller_1.brandController.updateBrand);
exports.brandRoute.delete('/:brandId', brand_validator_1.validateDeleteBrand, brand_controller_1.brandController.deleteBrand);
//# sourceMappingURL=brand.router.js.map