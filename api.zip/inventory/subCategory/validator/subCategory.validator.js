"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteSubCategory = exports.validateUpdateSubCategory = exports.validateCreateSubCategory = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateSubCategoryId = (0, express_validator_1.param)('subCategoryId')
    .exists().withMessage('El parámetro subCategoryId es requerido')
    .isNumeric().withMessage('El parámetro subCategoryId debe ser numérico');
const validateSubCategoryName = (0, express_validator_1.check)('name')
    .exists().trim().not().isEmpty().withMessage('El nombre de la categoria es requerido');
const validateCategoryId = (0, express_validator_1.check)('categoryId')
    .exists().not().isEmpty().withMessage('El categoryId es requerido');
// * Validación para la creación de una categoria
exports.validateCreateSubCategory = [
    validateSubCategoryName,
    validateCategoryId,
    handleValidationResult
];
// * Validación para la actualización de una categoria
exports.validateUpdateSubCategory = [
    validateSubCategoryId,
    validateSubCategoryName,
    validateCategoryId,
    handleValidationResult
];
// * Validación para la eliminación de una categoria
exports.validateDeleteSubCategory = [
    validateSubCategoryId,
    handleValidationResult
];
//# sourceMappingURL=subCategory.validator.js.map