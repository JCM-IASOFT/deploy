"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.subCategoryRoute = void 0;
const express_1 = require("express");
const subCategory_controller_1 = require("../controller/subCategory.controller");
const subCategory_validator_1 = require("../validator/subCategory.validator");
exports.subCategoryRoute = (0, express_1.Router)();
exports.subCategoryRoute.get('/', subCategory_controller_1.subCategoryController.findSubCategory);
exports.subCategoryRoute.post('/', subCategory_validator_1.validateCreateSubCategory, subCategory_controller_1.subCategoryController.createSubCategorys);
exports.subCategoryRoute.put('/:subCategoryId', subCategory_validator_1.validateUpdateSubCategory, subCategory_controller_1.subCategoryController.updateSubCategory);
exports.subCategoryRoute.delete('/:subCategoryId', subCategory_validator_1.validateDeleteSubCategory, subCategory_controller_1.subCategoryController.deleteSubCategory);
//# sourceMappingURL=subCategory.router.js.map