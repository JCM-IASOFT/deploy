"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.productFileService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const file_service_1 = require("../../../company/file/service/file.service");
class ProductFileService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProductFileService();
        return this.instance;
    }
    findProductFile(productId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield models_1.AppDataSource.getRepository(models_1.ProductFileModel).find({
                    where: {
                        productId,
                    },
                    relations: {
                        product: true,
                        file: true
                    }
                });
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createProductFile(files, productId) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryRunner = models_1.AppDataSource.createQueryRunner();
            yield queryRunner.startTransaction();
            try {
                // Llamamos a diferentes funciones que afectan diferentes tablas
                const savedFiles = yield file_service_1.fileService.createMasiveFile(files, queryRunner);
                const productFiles = [];
                savedFiles.forEach(item => {
                    productFiles.push({
                        productFileId: 0,
                        productId: productId,
                        fileId: item.fileId,
                    });
                });
                const productFile = yield queryRunner.manager.save(models_1.ProductFileModel, productFiles);
                // Confirma la transacción si todo sale bien
                yield queryRunner.commitTransaction();
                return productFile;
            }
            catch (error) {
                // Deshacer la transacción en caso de error
                yield queryRunner.rollbackTransaction();
                console.error('Error en la transacción:', error);
            }
            finally {
                console.log("FINALIZXAODODO");
                // Asegúrate de liberar el QueryRunner
                yield queryRunner.release();
            }
        });
    }
    deleteProductFile(productFileId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield models_1.AppDataSource.getRepository(models_1.ProductFileModel).delete({ productFileId });
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.productFileService = ProductFileService.getInstance();
//# sourceMappingURL=productFile..service.js.map