"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productFileRoute = void 0;
const express_1 = require("express");
const productFile_controller_1 = require("../controller/productFile.controller");
exports.productFileRoute = (0, express_1.Router)();
exports.productFileRoute.get('/', productFile_controller_1.productFileController.findProductFile);
exports.productFileRoute.post('/', productFile_controller_1.productFileController.createProductFile);
exports.productFileRoute.delete('/:productFileId', productFile_controller_1.productFileController.deleteProductFile);
//# sourceMappingURL=productFile..router.js.map