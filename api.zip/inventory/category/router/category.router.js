"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.categoryRoute = void 0;
const express_1 = require("express");
const category_controller_1 = require("../controller/category.controller");
const category_validator_1 = require("../validator/category.validator");
exports.categoryRoute = (0, express_1.Router)();
exports.categoryRoute.get('/', category_controller_1.categoryController.findCategory);
exports.categoryRoute.post('/', category_validator_1.validateCreateCategory, category_controller_1.categoryController.createCategorys);
exports.categoryRoute.put('/:categoryId', category_validator_1.validateUpdateCategory, category_controller_1.categoryController.updateCategory);
exports.categoryRoute.delete('/:categoryId', category_validator_1.validateDeleteCategory, category_controller_1.categoryController.deleteCategory);
//# sourceMappingURL=category.router.js.map