"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteCredit = exports.validateUpdateCredit = exports.validateCreateCredit = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateCreditId = (0, express_validator_1.param)('creditId')
    .exists().withMessage('El parámetro creditId es requerido')
    .isNumeric().withMessage('El parámetro creditId debe ser numérico');
const validateDate = (0, express_validator_1.check)('date')
    .exists().withMessage('La fecha es requerida')
    .isISO8601().toDate().withMessage('La fecha debe ser en formato ISO 8601');
const validateClientId = (0, express_validator_1.check)('clientId')
    .exists().withMessage('El clientId es requerido')
    .isInt().withMessage('El clientId debe ser un número entero');
const validateCompanyId = (0, express_validator_1.check)('companyId')
    .exists().withMessage('El companyId es requerido')
    .isInt().withMessage('El companyId debe ser un número entero');
const validateServiceId = (0, express_validator_1.check)('serviceId')
    .optional().isInt().withMessage('El serviceId debe ser un número entero');
const validateSalesId = (0, express_validator_1.check)('salesId')
    .optional().isInt().withMessage('El salesId debe ser un número entero');
const validateAmount = (0, express_validator_1.check)('amount')
    .exists().withMessage('El monto total del crédito es requerido')
    .isDecimal({ decimal_digits: '0,2' }).withMessage('El monto total del crédito debe ser un número decimal con hasta 2 decimales');
const validateBalance = (0, express_validator_1.check)('balance')
    .exists().withMessage('El saldo pendiente del crédito es requerido')
    .isDecimal({ decimal_digits: '0,2' }).withMessage('El saldo pendiente del crédito debe ser un número decimal con hasta 2 decimales');
const validateInterestRate = (0, express_validator_1.check)('interestRate')
    .exists().withMessage('La tasa de interés es requerida')
    .isDecimal({ decimal_digits: '0,2' }).withMessage('La tasa de interés debe ser un número decimal con hasta 2 decimales');
const validateDueDate = (0, express_validator_1.check)('dueDate')
    .exists().withMessage('La fecha de vencimiento es requerida')
    .isISO8601().toDate().withMessage('La fecha de vencimiento debe ser en formato ISO 8601');
const validateDescription = (0, express_validator_1.check)('description')
    .optional().isString().withMessage('La descripción debe ser un texto');
const validateCurrencyId = (0, express_validator_1.check)('currencyId')
    .optional().isInt().withMessage('El currencyId debe ser un número entero');
const validateType = (0, express_validator_1.check)('type')
    .exists().withMessage('El tipo de crédito es requerido')
    .isIn(['sales', 'service']).withMessage("El tipo de crédito debe ser 'sales' o 'service'");
const validateIsActive = (0, express_validator_1.check)('isActive')
    .exists().withMessage('El indicador de activo es requerido')
    .isBoolean().withMessage('El indicador de activo debe ser booleano');
// * Validación para la creación de un crédito
exports.validateCreateCredit = [
    validateDate,
    validateClientId,
    validateCompanyId,
    validateServiceId,
    validateSalesId,
    validateAmount,
    validateBalance,
    validateInterestRate,
    validateDueDate,
    validateDescription,
    validateCurrencyId,
    validateType,
    validateIsActive,
    handleValidationResult
];
// * Validación para la actualización de un crédito
exports.validateUpdateCredit = [
    validateCreditId,
    validateDate,
    validateClientId,
    validateCompanyId,
    validateServiceId,
    validateSalesId,
    validateAmount,
    validateBalance,
    validateInterestRate,
    validateDueDate,
    validateDescription,
    validateCurrencyId,
    validateType,
    validateIsActive,
    handleValidationResult
];
// * Validación para la eliminación de un crédito
exports.validateDeleteCredit = [
    validateCreditId,
    handleValidationResult
];
//# sourceMappingURL=credit.validator.js.map