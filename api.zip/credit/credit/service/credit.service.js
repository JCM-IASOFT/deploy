"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class CreditService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CreditService();
        return this.instance;
    }
    findCredit(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const credits = yield models_1.CreditModel.find({
                    where: {
                        companyId: companyId,
                        deletedAt: '0'
                    },
                    relations: {
                        creditModality: true,
                        creditAdvances: true,
                        creditSchedules: {
                            creditPayments: {
                                paymentType: true
                            }
                        },
                        currency: true,
                        client: {
                            documentType: true
                        },
                        service: true,
                        sales: true
                    }
                });
                return credits;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findAllCredit() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const credits = yield models_1.CreditModel.find({
                    where: {
                        deletedAt: '0'
                    },
                    relations: {
                        creditModality: true,
                        creditAdvances: true,
                        creditSchedules: {
                            creditPayments: {
                                paymentType: true
                            }
                        },
                        currency: true,
                        client: {
                            documentType: true
                        },
                        service: true,
                        sales: true
                    }
                });
                return credits;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findOneCredit(creditId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const credit = yield models_1.CreditModel.findOne({
                    where: {
                        creditId: creditId,
                        deletedAt: '0'
                    },
                    relations: {
                        creditModality: true,
                        creditAdvances: true,
                        creditSchedules: {
                            creditPayments: {
                                paymentType: true
                            }
                        },
                        currency: true,
                        client: {
                            documentType: true
                        },
                        service: true,
                        sales: true
                    }
                });
                return credit;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findDataTableCredit(page, sizePage, credit) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const creditBuilder = models_1.CreditModel.createQueryBuilder('credit')
                    .leftJoin('credit.currency', 'currency')
                    .leftJoin('credit.creditModality', 'creditModality')
                    .leftJoin('credit.creditSchedules', 'creditSchedule')
                    .leftJoin('creditSchedule.creditPayments', 'creditPayments')
                    .leftJoin('creditPayments.paymentType', 'paymentType')
                    .leftJoin('credit.creditAdvances', 'creditAdvance')
                    .leftJoin('credit.client', 'client')
                    .leftJoin('client.documentType', 'documentType')
                    .leftJoin('credit.service', 'service')
                    .leftJoin('credit.sales', 'sales')
                    .leftJoin('sales.salesDetails', 'salesDetails')
                    .leftJoin('salesDetails.product', 'product')
                    .where('credit.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('credit.companyId = :companyId', { companyId: credit.companyId });
                if (credit.startDate && credit.endDate) {
                    creditBuilder.andWhere('DATE(credit.date) BETWEEN :startDate AND :endDate', { startDate: credit.startDate, endDate: credit.endDate });
                }
                creditBuilder.select([
                    'credit.creditId',
                    'credit.date',
                    'credit.clientId',
                    'credit.companyId',
                    'credit.serviceId',
                    'credit.salesId',
                    'credit.creditModalityId',
                    'credit.amount',
                    'credit.balance',
                    'credit.interestRate',
                    'credit.exchangeRate',
                    'credit.dues',
                    'credit.description',
                    'credit.currencyId',
                    'credit.type',
                    'credit.isActive',
                    'currency',
                    'creditModality',
                    'creditSchedule',
                    'creditAdvance',
                    'client',
                    'service',
                    'sales',
                    'creditPayments',
                    'paymentType',
                    'documentType',
                    'salesDetails',
                    'product'
                ]);
                const [credits, total] = yield creditBuilder.orderBy("credit.creditId", "DESC")
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { credits, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    createCredit(credit, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const creditEntity = models_1.CreditModel.create(credit);
                const response = yield queryRunner.manager.save(creditEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateCredit(creditId, credit) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.CreditModel.update({ creditId }, {
                    date: credit.date,
                    clientId: credit.clientId,
                    companyId: credit.companyId,
                    serviceId: credit.serviceId,
                    amount: credit.amount, // El monto total del crédito.
                    balance: credit.balance, // El saldo pendiente del crédito.
                    interestRate: credit.interestRate, // La tasa de interés aplicada al crédito.                    
                    description: credit.description, // Una descripción opcional del crédito.
                    currencyId: credit.currencyId, // El tipo de moneda del crédito.                    
                    isActive: credit.isActive
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteCredit(creditId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.CreditModel, { creditId }, {
                    isActive: false
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.creditService = CreditService.getInstance();
//# sourceMappingURL=credit.service.js.map