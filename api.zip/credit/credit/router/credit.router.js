"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditRoute = void 0;
const express_1 = require("express");
const credit_controller_1 = require("../controller/credit.controller");
const credit_validator_1 = require("../validator/credit.validator");
exports.creditRoute = (0, express_1.Router)();
exports.creditRoute.get('/', credit_controller_1.creditController.findCredit);
exports.creditRoute.get('/one', credit_controller_1.creditController.findOneCredit);
exports.creditRoute.post('/dataTable', credit_controller_1.creditController.findCreditDataTable);
exports.creditRoute.put('/:creditId', credit_validator_1.validateUpdateCredit, credit_controller_1.creditController.updateCredit);
exports.creditRoute.delete('/:creditId', credit_validator_1.validateDeleteCredit, credit_controller_1.creditController.deleteCredit);
//# sourceMappingURL=credit.router.js.map