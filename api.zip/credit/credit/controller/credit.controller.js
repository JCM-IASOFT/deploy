"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const credit_service_1 = require("../service/credit.service");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const sales_service_1 = require("../../../sales/sales/service/sales.service");
class CreditController {
    constructor() {
        this.findCredit = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId } = req.query;
            const credits = yield credit_service_1.creditService.findCredit(Number(companyId));
            res.status(http_status_codes_1.StatusCodes.OK).json(credits);
        });
        this.findOneCredit = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { creditId } = req.query;
            const credits = yield credit_service_1.creditService.findOneCredit(Number(creditId));
            res.status(http_status_codes_1.StatusCodes.OK).json(credits);
        });
        this.findCreditDataTable = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { page, sizePage, credit } = req.body;
                const creditResponse = yield credit_service_1.creditService.findDataTableCredit(page, sizePage, credit);
                const credits = creditResponse ? creditResponse.credits : [];
                const total = creditResponse ? creditResponse.total : 0;
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    draw: Math.random(),
                    data: credits,
                    recordsFiltered: credits.length,
                    recordsTotal: total
                });
            }
            catch (error) {
                return {
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                };
            }
        });
        this.updateCredit = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const creditId = req.params.creditId;
                    const credit = req.body;
                    const response = yield credit_service_1.creditService.updateCredit(Number(creditId), credit);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_BRAND, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.deleteCredit = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const creditId = req.params.creditId;
                const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    const deletedCredit = yield credit_service_1.creditService.deleteCredit(Number(creditId), queryRunner);
                    const findOneCredit = yield credit_service_1.creditService.findOneCredit(Number(creditId));
                    if (!findOneCredit && deletedCredit.affected === 0) {
                        return { code: http_status_codes_1.StatusCodes.BAD_REQUEST, success: false, message: message_api_1.MessageApi.NOT_PARAMETER };
                    }
                    const deletedSales = yield sales_service_1.salesService.deleteSales(findOneCredit.salesId, queryRunner);
                    if (deletedSales.affected > 0) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_BRAND, data: deletedSales };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }));
                return result;
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new CreditController();
        return this.instance;
    }
}
exports.creditController = CreditController.getInstance();
//# sourceMappingURL=credit.controller.js.map