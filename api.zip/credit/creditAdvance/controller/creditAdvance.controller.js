"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditAdvanceController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const creditAdvance_service_1 = require("../service/creditAdvance.service");
class CreditAdvanceController {
    constructor() {
        this.findCreditAdvance = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId } = req.query;
            const creditAdvances = yield creditAdvance_service_1.creditAdvanceService.findCreditAdvance(Number(companyId));
            res.status(http_status_codes_1.StatusCodes.OK).json(creditAdvances);
        });
        this.updateCreditAdvance = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const creditAdvanceId = req.params.creditAdvanceId;
                    const creditAdvance = req.body;
                    const response = yield creditAdvance_service_1.creditAdvanceService.updateCreditAdvance(Number(creditAdvanceId), creditAdvance);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_BRAND, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.deleteCreditAdvance = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const creditAdvanceId = req.params.creditAdvanceId;
                const response = yield creditAdvance_service_1.creditAdvanceService.deleteCreditAdvance(Number(creditAdvanceId));
                if (response.affected > 0) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_BRAND, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new CreditAdvanceController();
        return this.instance;
    }
}
exports.creditAdvanceController = CreditAdvanceController.getInstance();
//# sourceMappingURL=creditAdvance.controller.js.map