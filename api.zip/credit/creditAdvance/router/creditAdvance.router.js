"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditAdvanceRoute = void 0;
const express_1 = require("express");
const creditAdvance_controller_1 = require("../controller/creditAdvance.controller");
const creditAdvance_validator_1 = require("../validator/creditAdvance.validator");
exports.creditAdvanceRoute = (0, express_1.Router)();
exports.creditAdvanceRoute.get('/', creditAdvance_controller_1.creditAdvanceController.findCreditAdvance);
exports.creditAdvanceRoute.put('/:creditAdvanceId', creditAdvance_validator_1.validateUpdateCreditAdvance, creditAdvance_controller_1.creditAdvanceController.updateCreditAdvance);
exports.creditAdvanceRoute.delete('/:creditAdvanceId', creditAdvance_validator_1.validateDeleteCreditAdvance, creditAdvance_controller_1.creditAdvanceController.deleteCreditAdvance);
//# sourceMappingURL=creditAdvance.router.js.map