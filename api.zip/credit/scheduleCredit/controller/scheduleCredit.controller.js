"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleCreditController = void 0;
const http_status_codes_1 = require("http-status-codes");
const node_cron_1 = __importDefault(require("node-cron"));
const webSocketService_1 = require("../../../socket/webSocketService");
const message_api_1 = require("../../../common/constant/message.api");
const save_error_1 = require("../../../common/handler/save.error");
const credit_service_1 = require("../../credit/service/credit.service");
const scheduleCredit_service_1 = require("../service/scheduleCredit.service");
const schedule_service_1 = require("../../../support/schedule/service/schedule.service");
const parameter_service_1 = require("../../../system/parameter/service/parameter.service");
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
const whatsapp_service_1 = require("../../../whatsapp/service/whatsapp.service");
const company_service_1 = require("../../../company/company/service/company.service");
const creditConfigTracking_service_1 = require("../../creditConfigTracking/service/creditConfigTracking.service");
class ScheduleCreditController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ScheduleCreditController();
        return this.instance;
    }
    /**
     * Programar envio de mensajes automaticos
     * @param req
     * @param res
     */
    scheduleCreditInstallments(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId, campusId } = req.body;
                const credits = yield credit_service_1.creditService.findCredit(companyId, campusId);
                const configCreditsTracking = yield creditConfigTracking_service_1.creditConfigTrackingService.findCreditConfigTracking(campusId);
                const newTasks = [];
                for (const element of credits) {
                    const key = `_credit${element.creditId}_company${companyId}`;
                    element.creditSchedules.forEach(item => {
                        const cronExpression = item.timeFormat;
                        const taskKey = key + `_installment${item.creditScheduleId}`;
                        const taskIndex = schedule_service_1.scheduleService.getTask().findIndex(task => task.key === taskKey);
                        if (taskIndex !== -1) {
                            schedule_service_1.scheduleService.getTask()[taskIndex].cronJob.stop();
                            schedule_service_1.scheduleService.getTask().splice(taskIndex, 1);
                        }
                        if (!item.isPaid) {
                            const scheduledJob = node_cron_1.default.schedule(cronExpression, () => __awaiter(this, void 0, void 0, function* () {
                                try {
                                    const phone = element.client ? element.client.phone : '';
                                    const parameter = yield parameter_service_1.parameterService.findOneParameter(parameter_constant_1.GroupConstant.WHATSAPP_MESSAGE.GROUP, parameter_constant_1.GroupConstant.WHATSAPP_MESSAGE.NAMES.CREDIT_LAST_DAY);
                                    const company = yield company_service_1.companyService.findOneCompany(companyId);
                                    yield whatsapp_service_1.whatsappService.sendMessage(phone, parameter.value, company.uuid);
                                    webSocketService_1.webSocketService.changeCreditSchedule(companyId, element.creditId, item.creditScheduleId);
                                }
                                catch (error) {
                                    console.error(`Error en la tarea programada: ${error.message}`);
                                }
                            }), {
                                timezone: "America/lima"
                            });
                            newTasks.push({ key: key + `_last_installment${item.creditScheduleId}`, cronJob: scheduledJob });
                            //config alert
                            if (configCreditsTracking.stateAlert) {
                                // await scheduleCreditService.sendAlert(companyId, campusId)
                            }
                            //config message
                            configCreditsTracking.hours.forEach(config => {
                                const [hour, minute] = config.split(':');
                                const pauseJob = node_cron_1.default.schedule(`${minute} ${hour} * * *`, () => __awaiter(this, void 0, void 0, function* () {
                                    const clientPhone = element.client.phone;
                                    const message = configCreditsTracking.message;
                                    const clientId = configCreditsTracking.campus.company.uuid;
                                    const responseWa = yield whatsapp_service_1.whatsappService.sendMessage(clientPhone, message, clientId);
                                    if (responseWa.success) {
                                        save_error_1.logger.info("enviando mensaje correctamente");
                                    }
                                }), {
                                    timezone: "America/Lima",
                                });
                                newTasks.push({ key: key + `_installment${item.creditScheduleId}`, cronJob: pauseJob });
                            });
                        }
                    });
                }
                scheduleCredit_service_1.scheduleCreditService.addTask(newTasks);
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    code: http_status_codes_1.StatusCodes.OK,
                    success: true,
                    message: message_api_1.MessageCustomApi.SCHEDULE_CREDIT_SUCCESS,
                });
            }
            catch (error) {
                save_error_1.logger.error(`Schedule Credit controller: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                });
            }
        });
    }
    loadCronJobsFromCredit() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const configCreditsTracking = yield creditConfigTracking_service_1.creditConfigTrackingService.findAllCreditConfigTracking();
                for (const config of configCreditsTracking) {
                    if (!config.state)
                        continue;
                    const allCredit = yield credit_service_1.creditService.findAllCredit();
                    for (const credit of allCredit) {
                        const key = `_credit${credit.creditId}_company${credit.companyId}`;
                        const newTasks = [];
                        credit.creditSchedules.forEach(item => {
                            const cronExpression = item.timeFormat;
                            if (!item.isPaid) {
                                const scheduledJob = node_cron_1.default.schedule(cronExpression, () => __awaiter(this, void 0, void 0, function* () {
                                    try {
                                        const phone = credit.client ? credit.client.phone : '';
                                        const parameter = yield parameter_service_1.parameterService.findOneParameter(parameter_constant_1.GroupConstant.WHATSAPP_MESSAGE.GROUP, parameter_constant_1.GroupConstant.WHATSAPP_MESSAGE.NAMES.CREDIT_LAST_DAY);
                                        const company = yield company_service_1.companyService.findOneCompany(credit.companyId);
                                        yield whatsapp_service_1.whatsappService.sendMessage(phone, parameter.value, company.uuid);
                                        webSocketService_1.webSocketService.changeCreditSchedule(credit.companyId, credit.creditId, item.creditScheduleId);
                                    }
                                    catch (error) {
                                        console.error(`Error en la tarea programada: ${error.message}`);
                                    }
                                }), {
                                    timezone: "America/lima"
                                });
                                newTasks.push({ key: key + `_last_installment${item.creditScheduleId}`, cronJob: scheduledJob });
                                if (config.stateAlert) {
                                    // await scheduleCreditService.sendAlert(companyId, campusId)
                                }
                                //config message
                                config.hours.forEach(element => {
                                    const [hour, minute] = element.split(':');
                                    const pauseJob = node_cron_1.default.schedule(`${minute} ${hour} * * *`, () => __awaiter(this, void 0, void 0, function* () {
                                        const clientPhone = credit.client.phone;
                                        const message = config.message;
                                        const clientId = config.campus.company.uuid;
                                        const responseWa = yield whatsapp_service_1.whatsappService.sendMessage(clientPhone, message, clientId);
                                        if (responseWa.success) {
                                            save_error_1.logger.info("enviando mensaje correctamente");
                                        }
                                    }), {
                                        timezone: "America/Lima",
                                    });
                                    newTasks.push({ key: key + `_installment${item.creditScheduleId}`, cronJob: pauseJob });
                                });
                            }
                        });
                        if (newTasks.length > 0) {
                            scheduleCredit_service_1.scheduleCreditService.addTask(newTasks);
                        }
                    }
                }
            }
            catch (error) {
                save_error_1.logger.error(`ScheduleCredit Controlller: ${error.message}`);
            }
        });
    }
}
exports.scheduleCreditController = ScheduleCreditController.getInstance();
//# sourceMappingURL=scheduleCredit.controller.js.map