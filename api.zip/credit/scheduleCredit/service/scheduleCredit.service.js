"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleCreditService = void 0;
class ScheduleCreditService {
    constructor() {
        this.tasks = [];
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ScheduleCreditService();
        return this.instance;
    }
    getTask() {
        return this.tasks;
    }
    addTask(tasks) {
        this.tasks.push(...tasks);
    }
}
exports.scheduleCreditService = ScheduleCreditService.getInstance();
//# sourceMappingURL=scheduleCredit.service.js.map