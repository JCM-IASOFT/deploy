"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleCreditRoute = void 0;
const express_1 = require("express");
const scheduleCredit_controller_1 = require("../controller/scheduleCredit.controller");
exports.scheduleCreditRoute = (0, express_1.Router)();
exports.scheduleCreditRoute.post('/', scheduleCredit_controller_1.scheduleCreditController.scheduleCreditInstallments);
//# sourceMappingURL=scheduleCredit.router.js.map