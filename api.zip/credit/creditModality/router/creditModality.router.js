"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditModalityRoute = void 0;
const express_1 = require("express");
const creditModality_controller_1 = require("../controller/creditModality.controller");
const creditModality_validator_1 = require("../validator/creditModality.validator");
exports.creditModalityRoute = (0, express_1.Router)();
exports.creditModalityRoute.get('/', creditModality_controller_1.creditModalityController.findCreditModality);
exports.creditModalityRoute.post('/', creditModality_validator_1.validateCreateCreditModality, creditModality_controller_1.creditModalityController.createCreditModality);
exports.creditModalityRoute.put('/:creditModalityId', creditModality_validator_1.validateUpdateCreditModality, creditModality_controller_1.creditModalityController.updateCreditModality);
exports.creditModalityRoute.delete('/:creditModalityId', creditModality_validator_1.validateDeleteCreditModality, creditModality_controller_1.creditModalityController.deleteCreditModality);
//# sourceMappingURL=creditModality.router.js.map