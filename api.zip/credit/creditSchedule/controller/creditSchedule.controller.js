"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditScheduleController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const creditSchedule_service_1 = require("../service/creditSchedule.service");
class CreditScheduleController {
    constructor() {
        this.findCreditSchedule = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId } = req.query;
            const creditSchedules = yield creditSchedule_service_1.creditScheduleService.findCreditSchedule(Number(companyId));
            res.status(http_status_codes_1.StatusCodes.OK).json(creditSchedules);
        });
        this.findOneCreditSchedule = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { creditId } = req.query;
                const creditSchedules = yield creditSchedule_service_1.creditScheduleService.findOneCreditSchedule(Number(creditId));
                res.status(http_status_codes_1.StatusCodes.OK).json(creditSchedules);
            }
            catch (error) {
                return {
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                };
            }
        });
        this.updatesCreditSchedule = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { creditSchedule } = req.body;
                    if (!Array.isArray(creditSchedule)) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                    const response = yield Promise.all(creditSchedule.map((schedule) => __awaiter(this, void 0, void 0, function* () { return yield creditSchedule_service_1.creditScheduleService.updatesCreditSchedule(schedule); })));
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_CREDIT_SCHEDULE, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.updateCreditSchedule = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { creditScheduleId } = req.params;
                    const { creditSchedule } = req.body;
                    const response = yield creditSchedule_service_1.creditScheduleService.updateCreditSchedule(Number(creditScheduleId), creditSchedule);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_BRAND, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.deleteCreditSchedule = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const creditScheduleId = req.params.creditScheduleId;
                const response = yield creditSchedule_service_1.creditScheduleService.deleteCreditSchedule(Number(creditScheduleId));
                if (response.affected > 0) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_BRAND, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new CreditScheduleController();
        return this.instance;
    }
}
exports.creditScheduleController = CreditScheduleController.getInstance();
//# sourceMappingURL=creditSchedule.controller.js.map