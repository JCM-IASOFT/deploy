"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditScheduleRoute = void 0;
const express_1 = require("express");
const creditSchedule_controller_1 = require("../controller/creditSchedule.controller");
const creditSchedule_validator_1 = require("../validator/creditSchedule.validator");
exports.creditScheduleRoute = (0, express_1.Router)();
exports.creditScheduleRoute.get('/', creditSchedule_controller_1.creditScheduleController.findCreditSchedule);
exports.creditScheduleRoute.get('/one', creditSchedule_controller_1.creditScheduleController.findOneCreditSchedule);
exports.creditScheduleRoute.put('/update/:creditScheduleId', creditSchedule_controller_1.creditScheduleController.updateCreditSchedule);
exports.creditScheduleRoute.put('/updateAll', creditSchedule_controller_1.creditScheduleController.updatesCreditSchedule);
exports.creditScheduleRoute.delete('/delete/:creditScheduleId', creditSchedule_validator_1.validateDeleteCreditSchedule, creditSchedule_controller_1.creditScheduleController.deleteCreditSchedule);
//# sourceMappingURL=creditSchedule.router.js.map