"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteCreditSchedule = exports.validateUpdateCreditSchedule = exports.validateCreateCreditSchedule = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateCreditScheduleId = (0, express_validator_1.check)('creditScheduleId')
    .exists().withMessage('El campo creditScheduleId es requerido')
    .isNumeric().withMessage('El campo creditScheduleId debe ser numérico');
const validateCreditId = (0, express_validator_1.check)('creditId')
    .exists().withMessage('El campo creditId es requerido')
    .isInt().withMessage('El campo creditId debe ser un número entero');
const validateAmount = (0, express_validator_1.check)('amount')
    .exists().withMessage('El campo amount es requerido')
    .isDecimal({ decimal_digits: '0,2' }).withMessage('El campo amount debe ser un número decimal con hasta 2 decimales');
const validateDueDate = (0, express_validator_1.check)('dueDate')
    .exists().withMessage('El campo dueDate es requerido')
    .isISO8601().toDate().withMessage('El campo dueDate debe ser una fecha en formato ISO 8601');
const validateIsPaid = (0, express_validator_1.check)('isPaid')
    .exists().withMessage('El campo isPaid es requerido')
    .isBoolean().withMessage('El campo isPaid debe ser booleano');
const validatePaymentDate = (0, express_validator_1.check)('paymentDate')
    .optional()
    .isISO8601().toDate().withMessage('El campo paymentDate debe ser una fecha en formato ISO 8601');
// * Validación para la creación de un CreditSchedule
exports.validateCreateCreditSchedule = [
    validateCreditId,
    validateAmount,
    validateDueDate,
    validateIsPaid,
    validatePaymentDate,
    handleValidationResult
];
// * Validación para la actualización de un CreditSchedule
exports.validateUpdateCreditSchedule = [
    validateCreditScheduleId,
    validateIsPaid,
    validatePaymentDate,
    handleValidationResult
];
// * Validación para la eliminación de un CreditSchedule
exports.validateDeleteCreditSchedule = [
    validateCreditScheduleId,
    handleValidationResult
];
//# sourceMappingURL=creditSchedule.validator.js.map