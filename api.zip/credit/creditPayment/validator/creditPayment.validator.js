"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteCreditPayment = exports.validateUpdateCreditPayment = exports.validateCreateCreditPayment = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateCreditPaymentId = (0, express_validator_1.check)('creditPaymentId')
    .exists().withMessage('El campo creditPaymentId es requerido')
    .isNumeric().withMessage('El campo creditPaymentId debe ser numérico');
const validateAmount = (0, express_validator_1.check)('amount')
    .exists().withMessage('El campo amount es requerido')
    .isDecimal({ decimal_digits: '0,2' }).withMessage('El campo amount debe ser un número decimal con hasta 2 decimales');
const validateCreditScheduleId = (0, express_validator_1.check)('creditScheduleId')
    .exists().withMessage('El campo creditScheduleId es requerido')
    .isInt().withMessage('El campo creditScheduleId debe ser un número entero');
const validatePaymentTypeId = (0, express_validator_1.check)('paymentTypeId')
    .exists().withMessage('El campo paymentTypeId es requerido')
    .isInt().withMessage('El campo paymentTypeId debe ser un número entero');
// * Validación para la creación de un CreditPayment
exports.validateCreateCreditPayment = [
    validateAmount,
    validateCreditScheduleId,
    validatePaymentTypeId,
    handleValidationResult
];
// * Validación para la actualización de un CreditPayment
exports.validateUpdateCreditPayment = [
    validateCreditPaymentId,
    validateAmount,
    validateCreditScheduleId,
    validatePaymentTypeId,
    handleValidationResult
];
// * Validación para la eliminación de un CreditPayment
exports.validateDeleteCreditPayment = [
    validateCreditPaymentId,
    handleValidationResult
];
//# sourceMappingURL=creditPayment.validator.js.map