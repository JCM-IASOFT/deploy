"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditPaymentRoute = void 0;
const express_1 = require("express");
const creditPayment_controller_1 = require("../controller/creditPayment.controller");
const creditPayment_validator_1 = require("../validator/creditPayment.validator");
exports.creditPaymentRoute = (0, express_1.Router)();
exports.creditPaymentRoute.get('/', creditPayment_controller_1.creditPaymentController.findCreditPayment);
exports.creditPaymentRoute.post('/', creditPayment_controller_1.creditPaymentController.createCreditPayment);
exports.creditPaymentRoute.put('/:creditPaymentId', creditPayment_validator_1.validateUpdateCreditPayment, creditPayment_controller_1.creditPaymentController.updateCreditPayment);
exports.creditPaymentRoute.delete('/:creditPaymentId', creditPayment_validator_1.validateDeleteCreditPayment, creditPayment_controller_1.creditPaymentController.deleteCreditPayment);
//# sourceMappingURL=creditPayment.router.js.map