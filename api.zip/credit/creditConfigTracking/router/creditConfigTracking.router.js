"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditConfigTrackingRoute = void 0;
const express_1 = require("express");
const creditConfigTracking_controller_1 = require("../controller/creditConfigTracking.controller");
exports.creditConfigTrackingRoute = (0, express_1.Router)();
exports.creditConfigTrackingRoute.get('/', creditConfigTracking_controller_1.creditConfigTrackingController.findCreditConfigTracking);
exports.creditConfigTrackingRoute.post('/', creditConfigTracking_controller_1.creditConfigTrackingController.saveCreditConfigTrackings);
//# sourceMappingURL=creditConfigTracking.router.js.map