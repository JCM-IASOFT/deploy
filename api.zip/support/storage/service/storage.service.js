"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.storageService = exports.StorageService = void 0;
const node_path_1 = __importDefault(require("node:path"));
const promises_1 = __importDefault(require("node:fs/promises"));
const node_fs_1 = __importDefault(require("node:fs"));
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
class StorageService {
    static getInstance() {
        if (!this.instance)
            this.instance = new StorageService();
        return this.instance;
    }
    findFileForCampus(campusName) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const pathFile = `${process.env.RUTE_UPLOAD}/${this.getCampusNameWithoutSpaces(campusName)}`;
                const files = yield promises_1.default.readdir(pathFile);
                const images = yield Promise.all(files.map((file) => __awaiter(this, void 0, void 0, function* () {
                    const filePath = `${pathFile}/${file}`;
                    const imageData = yield promises_1.default.readFile(filePath);
                    const ext = file.split('.').pop();
                    return { name: file, data: imageData.toString('base64'), ext: ext };
                })));
                return images;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createFileForCampus(storage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const campusName = this.getCampusNameWithoutSpaces(storage.campusName);
                const date = this.getDateWithoutSpaces(storage.date);
                const pathFile = `${process.env.RUTE_UPLOAD}/${campusName}`;
                const absolutePath = node_path_1.default.join(pathFile, `${campusName}_${date}.${storage.extension}`);
                if (!node_fs_1.default.existsSync(pathFile))
                    promises_1.default.mkdir(pathFile, { recursive: true });
                const existFiles = yield promises_1.default.readdir(pathFile);
                if (existFiles.length === 0) {
                    if (Array.isArray(storage.file)) {
                        storage.file.forEach((item) => {
                            promises_1.default.writeFile(node_path_1.default.join(pathFile, `${campusName}_${date}.${storage.extension}`), item.data, 'binary');
                            // item.mv(path.join(pathFile, `${campusName}_${date}.${storage.extension}`))
                        });
                    }
                }
                else {
                    throw Error(`Ya existe un logo asociado a esta sede ${storage.campusName}`);
                }
                return absolutePath;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateFileForCampus(storage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const campusName = this.getCampusNameWithoutSpaces(storage.campusName);
                const date = this.getDateWithoutSpaces(storage.date);
                const pathFile = `${process.env.RUTE_UPLOAD}/${campusName}`;
                const existFiles = yield promises_1.default.readdir(pathFile);
                if (existFiles.length > 0) {
                    yield promises_1.default.unlink(node_path_1.default.join(pathFile, existFiles[0]));
                    if (Array.isArray(storage.file)) {
                        storage.file.forEach((item) => {
                            promises_1.default.writeFile(node_path_1.default.join(pathFile, `${campusName}_${date}.${storage.extension}`), item.data, 'binary');
                            // item.mv(path.join(pathFile, `${campusName}_${date}.${storage.extension}`))
                        });
                    }
                }
                else {
                    throw Error(`no se encontró un logo asociado a esta sede "${storage.campusName}"`);
                }
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    getCampusNameWithoutSpaces(name) {
        // Elimina espacios en blanco y caracteres no permitidos
        return name.replace(/\s/g, '').replace(/[\\/:*?"<>|]/g, '');
    }
    getDateWithoutSpaces(date) {
        //elimina espacios, dobles puntos y guiones
        return date.toString().replace(/[\s:-]/g, '');
    }
}
exports.StorageService = StorageService;
exports.storageService = StorageService.getInstance();
//# sourceMappingURL=storage.service.js.map