"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.storageRoute = void 0;
const express_1 = require("express");
const storage_1 = require("../controller/storage");
exports.storageRoute = (0, express_1.Router)();
exports.storageRoute.post('/', storage_1.storageController.findFileForCampus);
exports.storageRoute.post('/upload', storage_1.storageController.createFileForCampus);
exports.storageRoute.post('/updateFile', storage_1.storageController.updateFileForCampus);
//# sourceMappingURL=storage.routes.js.map