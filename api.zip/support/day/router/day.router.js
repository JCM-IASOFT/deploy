"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dayRoute = void 0;
const express_1 = require("express");
const day_controller_1 = require("../controller/day.controller");
exports.dayRoute = (0, express_1.Router)();
exports.dayRoute.get('/', day_controller_1.dayController.findDay);
//# sourceMappingURL=day.router.js.map