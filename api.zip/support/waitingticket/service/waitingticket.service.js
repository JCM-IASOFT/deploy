"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.waitingticketService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const models_1 = require("models");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class WaitingTicketService {
    static getInstance() {
        if (!this.instance)
            this.instance = new WaitingTicketService();
        return this.instance;
    }
    findAllWaitingTicket(sectorId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const waitingtickets = yield models_1.WaitingTicketModel.find({
                    where: { sectorId: sectorId }
                });
                return waitingtickets;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findOneWaitingTicket(sectorId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const waitingTicket = yield models_1.WaitingTicketModel.findOne({
                    where: {
                        sectorId: sectorId,
                        sector: {
                            campusId: campusId
                        }
                    },
                    order: { order: "DESC" }
                });
                return waitingTicket ? waitingTicket : null;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    createWaitingTicket(waitingtickets) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.WaitingTicketModel.save(waitingtickets);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateWaitingTicket(waitingtickets, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.WaitingTicketModel, waitingtickets.waitingTicketId, {
                    order: waitingtickets.order
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateStateWaitingTicket(waitingtickets, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.WaitingTicketModel, waitingtickets.waitingTicketId, {
                    state: false
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteWaitingTicket(waitingtickets) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.WaitingTicketModel.delete({ waitingTicketId: waitingtickets.waitingTicketId });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.waitingticketService = WaitingTicketService.getInstance();
//# sourceMappingURL=waitingticket.service.js.map