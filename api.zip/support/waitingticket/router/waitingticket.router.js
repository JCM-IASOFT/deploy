"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.waitingticketRoute = void 0;
const express_1 = require("express");
const waitingticket_controller_1 = require("../controller/waitingticket.controller");
const waitingticket_validator_1 = require("../validator/waitingticket.validator");
exports.waitingticketRoute = (0, express_1.Router)();
exports.waitingticketRoute.get('/', waitingticket_controller_1.waitingticketController.findAllWaitingTicket);
exports.waitingticketRoute.post('/create', waitingticket_validator_1.validateCreateWaitingTicket, waitingticket_controller_1.waitingticketController.createWaitingTickets);
exports.waitingticketRoute.delete('/', waitingticket_validator_1.validateDeleteWaitingTicket, waitingticket_controller_1.waitingticketController.deleteWaitingTicket);
//# sourceMappingURL=waitingticket.router.js.map