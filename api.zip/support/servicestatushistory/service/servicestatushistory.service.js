"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicestatushistoryService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
class ServiceStatusHistoryService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceStatusHistoryService();
        return this.instance;
    }
    findServiceStatusHistory(serviceId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const serviceStatusHistorys = yield modelslibrary_1.ServiceStatusHistoryModel.find({
                    where: { serviceId: serviceId },
                    relations: ['user', 'service'],
                    select: {
                        statusHistoryId: true,
                        serviceId: true,
                        status: true,
                        dateChanged: true,
                        userId: true,
                        coments: true,
                        complete: true,
                        user: {
                            userId: true,
                            name: true,
                            fullname: true,
                            email: true,
                            phone: true,
                            documentNumber: true,
                        },
                        service: {
                            registrationDate: true,
                            deliverDate: true,
                            totalAmount: true,
                            state: true,
                            comment: true,
                            priority: true,
                        }
                    },
                    order: {
                        status: 'asc'
                    }
                });
                return serviceStatusHistorys;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    Create(servicestatushistory, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const isComplete = [parameter_constant_1.StatusService.ENTREGADO, parameter_constant_1.StatusService.RECHAZADO, parameter_constant_1.StatusService.SIN_SOLUCION_ENTREGADO].includes(servicestatushistory.status);
                servicestatushistory.complete = isComplete;
                const history = modelslibrary_1.ServiceStatusHistoryModel.create(servicestatushistory);
                const response = yield queryRunner.manager.save(history);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    UpdateComplete(statusHistoryId, completeDate, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceStatusHistoryModel, statusHistoryId, {
                    completeDate,
                    complete: true
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    rollBackStatus(statusHistoryId, serviceId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceStatusHistoryModel, { statusHistoryId: statusHistoryId }, {
                    complete: false,
                    deletedAt: '1'
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    DeleteByService(serviceId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceStatusHistoryModel, { serviceId: serviceId }, {
                    deletedAt: '1'
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
}
exports.servicestatushistoryService = ServiceStatusHistoryService.getInstance();
//# sourceMappingURL=servicestatushistory.service.js.map