"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicePauseHistoryController = void 0;
const servicePauseHistory_service_1 = require("../service/servicePauseHistory.service");
const http_status_codes_1 = require("http-status-codes");
class ServicePauseHistoryController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ServicePauseHistoryController();
        return this.instance;
    }
    findServicePauseHistory(req, res) {
        const { serviceId } = req.query;
        const findResponse = servicePauseHistory_service_1.servicePauseHistoryService.findServicePauseHistory(Number(serviceId));
        res.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
    }
}
exports.servicePauseHistoryController = ServicePauseHistoryController.getInstance();
//# sourceMappingURL=servicePauseHistory.controller.js.map