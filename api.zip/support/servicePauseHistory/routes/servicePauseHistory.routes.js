"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicePauseHistoryRoute = void 0;
const express_1 = require("express");
const servicePauseHistory_controller_1 = require("../controller/servicePauseHistory.controller");
exports.servicePauseHistoryRoute = (0, express_1.Router)();
exports.servicePauseHistoryRoute.get('/', servicePauseHistory_controller_1.servicePauseHistoryController.findServicePauseHistory);
//# sourceMappingURL=servicePauseHistory.routes.js.map