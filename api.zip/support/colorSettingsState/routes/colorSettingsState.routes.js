"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.colorSettingsStateRoute = void 0;
const express_1 = require("express");
const colorSettingsState_controller_1 = require("../controllers/colorSettingsState.controller");
exports.colorSettingsStateRoute = (0, express_1.Router)();
exports.colorSettingsStateRoute.get('/all', colorSettingsState_controller_1.colorSettingsStateController.findColorSettingsState);
exports.colorSettingsStateRoute.get('/byType', colorSettingsState_controller_1.colorSettingsStateController.findColorSettingsStateForType);
exports.colorSettingsStateRoute.post('/create', colorSettingsState_controller_1.colorSettingsStateController.createColorSettingsState);
exports.colorSettingsStateRoute.post('/creates', colorSettingsState_controller_1.colorSettingsStateController.createsColorSettingsState);
exports.colorSettingsStateRoute.put('/update', colorSettingsState_controller_1.colorSettingsStateController.updateColorSettingsState);
exports.colorSettingsStateRoute.put('/updates', colorSettingsState_controller_1.colorSettingsStateController.updatesColorSettingsState);
exports.colorSettingsStateRoute.put('/delete/:colorSettingsStateId', colorSettingsState_controller_1.colorSettingsStateController.deleteColorSettingsState);
//# sourceMappingURL=colorSettingsState.routes.js.map