"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.surveyController = exports.SurveyController = void 0;
const request_handler_1 = require("../../../common/handler/request.handler");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const survey_service_1 = require("../service/survey.service");
const message_api_1 = require("../../../common/constant/message.api");
const http_status_codes_1 = require("http-status-codes");
class SurveyController {
    static getInstance() {
        if (!this.instance)
            this.instance = new SurveyController();
        return this.instance;
    }
    findSurvey(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const findResponse = yield survey_service_1.surveyService.findSurvey(Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                return {
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                };
            }
        });
    }
    findSurveyByPhone(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { phone, currentDate, lastDate, state } = request.query;
                const findResponse = yield survey_service_1.surveyService.findSurveyByPhone(phone.toString(), new Date(currentDate.toString()), new Date(lastDate.toString()));
                return response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                return {
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                };
            }
        });
    }
    createSurvey(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { survey } = request.body;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const createResponse = yield survey_service_1.surveyService.createSurvey(survey, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_TRANSACTION, data: createResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    updateSurvey(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { survey } = request.body;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const updateResponse = yield survey_service_1.surveyService.updateSurvey(survey, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_TRANSACTION, data: updateResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    deleteSurvey(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { id } = request.params;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const deleteResponse = yield survey_service_1.surveyService.deleteSurvey(Number(id), queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_TRANSACTION, data: deleteResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
}
exports.SurveyController = SurveyController;
exports.surveyController = SurveyController.getInstance();
//# sourceMappingURL=survey.js.map