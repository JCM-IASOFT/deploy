"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.surveyRoute = void 0;
const express_1 = require("express");
const survey_1 = require("../controller/survey");
exports.surveyRoute = (0, express_1.Router)();
exports.surveyRoute.get('/all', survey_1.surveyController.findSurvey);
exports.surveyRoute.post('/create', survey_1.surveyController.createSurvey);
exports.surveyRoute.put('/update', survey_1.surveyController.updateSurvey);
exports.surveyRoute.put('/delete', survey_1.surveyController.deleteSurvey);
exports.surveyRoute.get('/phone', survey_1.surveyController.findSurveyByPhone);
//# sourceMappingURL=survey.routes.js.map