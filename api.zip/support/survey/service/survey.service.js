"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.surveyService = exports.SurveyService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const typeorm_1 = require("typeorm");
class SurveyService {
    static getInstance() {
        if (!this.instance)
            this.instance = new SurveyService();
        return this.instance;
    }
    findSurvey(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield models_1.SurveyModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findSurveyByPhone(phone_1, currentDate_1, lastDate_1) {
        return __awaiter(this, arguments, void 0, function* (phone, currentDate, lastDate, state = false) {
            try {
                const findResponse = yield models_1.SurveyModel.find({
                    where: {
                        deletedAt: '0',
                        client: {
                            phone: phone
                        },
                        date: (0, typeorm_1.Between)(lastDate, currentDate),
                        complete: state
                    },
                    relations: {
                        client: true
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createSurvey(survey, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const createResponse = models_1.SurveyModel.create({
                    clientId: survey.clientId,
                    userTechnicalId: survey.userTechnicalId,
                    codeSurvey: survey.codeSurvey,
                    complete: survey.complete,
                    date: survey.date,
                    rating: survey.rating,
                    campusId: survey.campusId
                });
                return yield queryRunner.manager.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateSurvey(survey, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = yield queryRunner.manager.update(models_1.SurveyModel, { surveyId: survey.surveyId }, {
                    clientId: survey.clientId,
                    userTechnicalId: survey.userTechnicalId,
                    codeSurvey: survey.codeSurvey,
                    complete: survey.complete,
                    date: survey.date,
                    rating: survey.rating,
                    campusId: survey.campusId
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteSurvey(id, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = yield queryRunner.manager.update(models_1.SurveyModel, { surveyId: id }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.SurveyService = SurveyService;
exports.surveyService = SurveyService.getInstance();
//# sourceMappingURL=survey.service.js.map