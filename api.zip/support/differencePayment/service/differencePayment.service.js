"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.differencePaymentService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const models_1 = require("models");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class DifferencePaymentService {
    static getInstance() {
        if (!this.instance)
            this.instance = new DifferencePaymentService();
        return this.instance;
    }
    findDifferencePayment(differenceId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const differencePayments = yield models_1.DifferencePaymentModel.find({
                    where: {
                        deletedAt: '0',
                        differenceId
                    }
                });
                return differencePayments;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createDifferencePayment(differencePayment, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const diferenceEntity = models_1.DifferencePaymentModel.create(differencePayment);
                const response = yield queryRunner.manager.save(diferenceEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.differencePaymentService = DifferencePaymentService.getInstance();
//# sourceMappingURL=differencePayment.service.js.map