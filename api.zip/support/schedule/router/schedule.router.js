"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleRoute = void 0;
const express_1 = require("express");
const schedule_controller_1 = require("../controller/schedule.controller");
exports.scheduleRoute = (0, express_1.Router)();
exports.scheduleRoute.post('/', schedule_controller_1.scheduleController.scheduleServicePauseAndResume);
exports.scheduleRoute.post('/time', schedule_controller_1.scheduleController.scheduleServiceTime);
//# sourceMappingURL=schedule.router.js.map