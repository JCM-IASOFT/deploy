"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleService = void 0;
class ScheduleService {
    constructor() {
        this.tasks = [];
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ScheduleService();
        return this.instance;
    }
    getTask() {
        return this.tasks;
    }
    addTask(tasks) {
        this.tasks.push(...tasks);
    }
}
exports.scheduleService = ScheduleService.getInstance();
//# sourceMappingURL=schedule.service.js.map