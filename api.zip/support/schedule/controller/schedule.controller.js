"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleController = void 0;
const http_status_codes_1 = require("http-status-codes");
const serviceRequest_controller_1 = require("../../serviceRequests/controller/serviceRequest.controller");
const setting_service_1 = require("../../setting/service/setting.service");
const node_cron_1 = __importDefault(require("node-cron"));
const webSocketService_1 = require("../../../socket/webSocketService");
const message_api_1 = require("../../../common/constant/message.api");
const service_service_1 = require("../../service/service/service.service");
const save_error_1 = require("../../../common/handler/save.error");
const schedule_service_1 = require("../service/schedule.service");
const serviceRequest_service_1 = require("../../serviceRequests/service/serviceRequest.service");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class ScheduleController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ScheduleController();
        return this.instance;
    }
    /**
     * Programar pausa y reanudación de servicios
     */
    scheduleServicePauseAndResume(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId, campusId } = req.body;
                const setting = yield setting_service_1.settingService.getOneSetting(companyId, campusId);
                const key = `${companyId}_${campusId}`;
                console.log("🚀 ~ ScheduleController ~ scheduleServicePauseAndResume ~ key:", key);
                webSocketService_1.webSocketService.changePauseService(companyId, campusId);
                const keyPause = key + '_pause';
                const keyStart = key + '_start';
                const taskIndexPause = schedule_service_1.scheduleService.getTask().findIndex(task => task.key === keyPause);
                if (taskIndexPause !== -1) {
                    schedule_service_1.scheduleService.getTask()[taskIndexPause].cronJob.stop();
                    schedule_service_1.scheduleService.getTask().splice(taskIndexPause, 1);
                }
                const taskIndexStart = schedule_service_1.scheduleService.getTask().findIndex(task => task.key === keyStart);
                if (taskIndexStart !== -1) {
                    schedule_service_1.scheduleService.getTask()[taskIndexStart].cronJob.stop();
                    schedule_service_1.scheduleService.getTask().splice(taskIndexStart, 1);
                }
                const newTasks = [];
                setting.forEach(element => {
                    const [pauseHour, pauseMinute] = element.pauseTime.split(':');
                    const [startHour, startMinute] = element.startTime.split(':');
                    // Programar pausa
                    if (element.statePause) {
                        const pauseJob = node_cron_1.default.schedule(`${pauseMinute} ${pauseHour} * * ${element.day.code}`, () => __awaiter(this, void 0, void 0, function* () {
                            console.log("PAUSADO PROGRAMADO");
                            yield service_service_1.serviceService.togglePauseByCampus(element.campusId, true);
                            webSocketService_1.webSocketService.changePauseService(element.companyId, element.campusId);
                        }), {
                            timezone: "America/Lima",
                        });
                        newTasks.push({ key: key + '_pause', cronJob: pauseJob });
                    }
                    // Programar reanudación
                    if (element.stateStart) {
                        console.log(`${startMinute} ${startHour}`);
                        const startJob = node_cron_1.default.schedule(`${startMinute} ${startHour} * * ${element.day.code}`, () => __awaiter(this, void 0, void 0, function* () {
                            console.log("START AUTOMATICO");
                            yield service_service_1.serviceService.togglePauseByCampus(element.campusId, false);
                            webSocketService_1.webSocketService.changeStartService(element.companyId, element.campusId);
                        }));
                        newTasks.push({ key: key + '_start', cronJob: startJob });
                    }
                });
                // Agregar nuevas tareas al array
                schedule_service_1.scheduleService.addTask(newTasks);
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    code: http_status_codes_1.StatusCodes.OK,
                    success: true,
                    message: message_api_1.MessageCustomApi.SETTING_SCHEDULE_SUCCESS,
                });
            }
            catch (error) {
                save_error_1.logger.error(`Schedule controller: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                });
            }
        });
    }
    // Método para cargar y reprogramar cron jobs al iniciar el servidor
    loadCronJobsFromDatabase() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const allSettings = yield setting_service_1.settingService.getAllSetting();
                for (const setting of allSettings) {
                    const [pauseHour, pauseMinute] = setting.pauseTime.split(':');
                    const [startHour, startMinute] = setting.startTime.split(':');
                    const key = `${setting.companyId}_${setting.campusId}`;
                    const newTasks = [];
                    // Programar los cron jobs
                    if (setting.statePause) {
                        const pauseJob = node_cron_1.default.schedule(`${pauseMinute} ${pauseHour} * * ${setting.day.code}`, () => __awaiter(this, void 0, void 0, function* () {
                            yield service_service_1.serviceService.togglePauseByCampus(setting.campusId, true);
                            webSocketService_1.webSocketService.changePauseService(setting.companyId, setting.campusId);
                        }));
                        newTasks.push({ key: key + '_pause', cronJob: pauseJob });
                    }
                    if (setting.stateStart) {
                        const startJob = node_cron_1.default.schedule(`${startMinute} ${startHour} * * ${setting.day.code}`, () => __awaiter(this, void 0, void 0, function* () {
                            yield service_service_1.serviceService.togglePauseByCampus(setting.campusId, false);
                            webSocketService_1.webSocketService.changeStartService(setting.companyId, setting.campusId);
                        }));
                        newTasks.push({ key: key + '_start', cronJob: startJob });
                    }
                    // Agregar las tareas programadas
                    schedule_service_1.scheduleService.addTask(newTasks);
                }
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    scheduleServiceTime(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId, campusId } = req.body;
                const serviceRequest = yield serviceRequest_service_1.serviceRequestsService.findServiceRequest(campusId);
                const newTasks = [];
                if (serviceRequest.length > 0) {
                    const key = `${companyId}_${campusId}`;
                    if (!newTasks[key]) {
                        const task = node_cron_1.default.schedule(`* * * * *`, () => __awaiter(this, void 0, void 0, function* () {
                            yield serviceRequest_controller_1.serviceRequestsController.processServiceRequest(companyId, campusId);
                            const serviceRequests = yield serviceRequest_service_1.serviceRequestsService.findServiceRequest(campusId);
                            if (serviceRequests.length === 0) {
                                task.stop(); // Detener la tarea
                                delete newTasks[key]; // Eliminar la referencia de la tarea
                            }
                        }));
                        newTasks.push({ key: key, cronJob: task });
                    }
                    schedule_service_1.scheduleService.addTask(newTasks);
                }
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    code: http_status_codes_1.StatusCodes.OK,
                    success: true,
                    message: message_api_1.MessageCustomApi.TIME_SCHEDULE_SUCCESS,
                });
            }
            catch (error) {
                save_error_1.logger.error(`Schedule controller: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                });
            }
        });
    }
    loadCronJobsFromServiceRequest() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const allServiceRequest = yield serviceRequest_service_1.serviceRequestsService.findAllServiceRequest();
                for (const request of allServiceRequest) {
                    const campusId = request.campusId;
                    const companyId = request.companyId;
                    const key = `${companyId}_${campusId}`;
                    const newTasks = [];
                    // Programar cron jobs al iniciar si hay solicitudes de servicio
                    if (!newTasks[key]) {
                        const task = node_cron_1.default.schedule('* * * * *', () => __awaiter(this, void 0, void 0, function* () {
                            yield serviceRequest_controller_1.serviceRequestsController.processServiceRequest(companyId, campusId);
                            //se detendrá el cron job si ya no hay solicitudes de servicio
                            const serviceRequests = yield serviceRequest_service_1.serviceRequestsService.findServiceRequest(campusId);
                            if (serviceRequests.length === 0) {
                                task.stop();
                                delete newTasks[key];
                            }
                        }));
                        newTasks.push({ key: key, cronJob: task });
                    }
                    schedule_service_1.scheduleService.addTask(newTasks);
                }
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
}
exports.scheduleController = ScheduleController.getInstance();
//# sourceMappingURL=schedule.controller.js.map