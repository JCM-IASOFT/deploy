"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicetypeController = void 0;
const http_status_codes_1 = require("http-status-codes");
const servicetype_service_1 = require("../service/servicetype.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
class ServiceTypeController {
    constructor() {
        this.findServiceType = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { deviceId, campusId } = req.query;
            const servicetypes = yield servicetype_service_1.servicetypeService.findServiceType(Number(deviceId), Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(servicetypes);
        });
        this.findAllServiceType = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.body;
            const servicetypes = yield servicetype_service_1.servicetypeService.findAllServiceType(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json({
                data: servicetypes,
                draw: Math.random(),
                recordsFiltered: servicetypes.length,
                recordsTotal: servicetypes.length,
            });
        });
        this.createServiceTypes = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield servicetype_service_1.servicetypeService.createServiceType(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_TYPESERVICE, data: response };
            }));
        });
        this.updateServiceType = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield servicetype_service_1.servicetypeService.updateServiceType(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_TYPESERVICE, data: response };
            }));
        });
        this.deleteServiceType = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield servicetype_service_1.servicetypeService.deleteServiceType(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_TYPESERVICE, data: response };
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceTypeController();
        return this.instance;
    }
}
exports.servicetypeController = ServiceTypeController.getInstance();
//# sourceMappingURL=servicetype.controller.js.map