"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicetypeRoute = void 0;
const express_1 = require("express");
const servicetype_controller_1 = require("../controller/servicetype.controller");
const servicetype_validator_1 = require("../validator/servicetype.validator");
exports.servicetypeRoute = (0, express_1.Router)();
exports.servicetypeRoute.get('/', servicetype_validator_1.validateFindServiceType, servicetype_controller_1.servicetypeController.findServiceType);
exports.servicetypeRoute.post('/all', servicetype_controller_1.servicetypeController.findAllServiceType);
exports.servicetypeRoute.post('/create', servicetype_validator_1.validateCreateServiceType, servicetype_controller_1.servicetypeController.createServiceTypes);
exports.servicetypeRoute.put('/edit', servicetype_validator_1.validateUpdateServiceType, servicetype_controller_1.servicetypeController.updateServiceType);
exports.servicetypeRoute.put('/delete', servicetype_validator_1.validateDeleteServiceType, servicetype_controller_1.servicetypeController.deleteServiceType);
//# sourceMappingURL=servicetype.router.js.map