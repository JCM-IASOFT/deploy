"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceRequestsController = void 0;
const serviceRequest_service_1 = require("../service/serviceRequest.service");
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const service_service_1 = require("../../service/service/service.service");
const webSocketService_1 = require("../../../socket/webSocketService");
const serviceRequestType_constant_1 = require("../../../common/constant/serviceRequestType.constant");
class ServiceRequestsController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceRequestsController();
        return this.instance;
    }
    findServiceRequest(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = req.query;
                const findResponse = yield serviceRequest_service_1.serviceRequestsService.findServiceRequest(Number(campusId));
                res.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER
                });
            }
        });
    }
    createServiceRequest(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { serviceRequest } = req.body;
                    const createResponse = yield serviceRequest_service_1.serviceRequestsService.createServiceRequest(serviceRequest);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_SERVICE_REQUESTS, data: createResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER
                    };
                }
            }));
        });
    }
    createServiceRequests(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { serviceRequests } = req.body;
                    if (!Array.isArray(serviceRequests)) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageApi.ERROR_SERVER };
                    }
                    const createResponse = yield Promise.all(serviceRequests.map(request => serviceRequest_service_1.serviceRequestsService.createServiceRequest(request)));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_SERVICE_REQUESTS, data: createResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER
                    };
                }
            }));
        });
    }
    updateServiceRequest(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { serviceRequest } = req.body;
                    const updateResponse = yield serviceRequest_service_1.serviceRequestsService.updateServiceRequest(serviceRequest);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_SERVICE_REQUESTS, data: updateResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER
                    };
                }
            }));
        });
    }
    deleteServiceRequest(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { serviceRequestId } = req.params;
                    const createResponse = yield serviceRequest_service_1.serviceRequestsService.deleteServiceRequest(Number(serviceRequestId));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_SERVICE_REQUESTS, data: createResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER
                    };
                }
            }));
        });
    }
    processServiceRequest(companyId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const processResponse = yield serviceRequest_service_1.serviceRequestsService.processServiceRequest();
                const processingPromises = processResponse.map(request => {
                    return this.updateStateServiceProcess(request, companyId, campusId);
                });
                yield Promise.all(processingPromises);
            }
            catch (error) {
            }
        });
    }
    updateStateServiceProcess(serviceRequest, companyId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            const service = yield service_service_1.serviceService.findOneService(serviceRequest.serviceId);
            if (service) {
                const processPause = service.pause;
                if (serviceRequest.action == serviceRequestType_constant_1.serviceRequestType.PAUSE) {
                    service.pause = true;
                }
                else if (serviceRequest.action == serviceRequestType_constant_1.serviceRequestType.RESUME) {
                    service.pause = false;
                }
                yield service_service_1.serviceService.updateServiceForPause(service);
                if (processPause != service.pause) {
                    webSocketService_1.webSocketService.changeServiceStatus(companyId, campusId);
                }
                yield serviceRequest_service_1.serviceRequestsService.deleteServiceRequest(serviceRequest.serviceRequestId);
            }
        });
    }
}
exports.serviceRequestsController = ServiceRequestsController.getInstance();
//# sourceMappingURL=serviceRequest.controller.js.map