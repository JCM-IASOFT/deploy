"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceRequestsService = void 0;
const serviceRequests_1 = require("modelslibrary/src/entities/support/serviceRequests");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const moment_1 = __importDefault(require("moment"));
class ServiceRequestsService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceRequestsService();
        return this.instance;
    }
    findServiceRequest(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield serviceRequests_1.ServiceRequestsModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relations: {
                        user: true
                    }
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    findAllServiceRequest() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield serviceRequests_1.ServiceRequestsModel.find({
                    where: {
                        deletedAt: '0'
                    }
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    findOneServiceRequest(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield serviceRequests_1.ServiceRequestsModel.findOne({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    }
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    createServiceRequest(serviceRequest) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield serviceRequests_1.ServiceRequestsModel.save(serviceRequest);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    updateServiceRequest(serviceRequest) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield serviceRequests_1.ServiceRequestsModel.update({ serviceRequestId: serviceRequest.serviceRequestId }, {
                    action: serviceRequest.action,
                    scheduledDate: serviceRequest.scheduledDate,
                    startingDate: serviceRequest.startingDate,
                    serviceId: serviceRequest.serviceId,
                    lapseTime: serviceRequest.lapseTime,
                    campusId: serviceRequest.campusId,
                    status: serviceRequest.status,
                    typeTime: serviceRequest.typeTime,
                    userId: serviceRequest.userId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    deleteServiceRequest(serviceRequestId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield serviceRequests_1.ServiceRequestsModel.update({ serviceRequestId: serviceRequestId }, {
                    deletedAt: '1'
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    processServiceRequest() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const currentDate = (0, moment_1.default)();
                console.log("🚀 ~ ServiceRequestsService ~ processServiceRequest ~ const currentDate = moment():", currentDate);
                const requestProcess = yield serviceRequests_1.ServiceRequestsModel
                    .createQueryBuilder('serviceRequest')
                    .where('serviceRequest.scheduledDate <= :currentDate', { currentDate: currentDate })
                    .getMany();
                return requestProcess;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
}
exports.serviceRequestsService = ServiceRequestsService.getInstance();
//# sourceMappingURL=serviceRequest.service.js.map