"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceRequestsRoute = void 0;
const express_1 = require("express");
const serviceRequest_controller_1 = require("../controller/serviceRequest.controller");
exports.serviceRequestsRoute = (0, express_1.Router)();
exports.serviceRequestsRoute.get('/', serviceRequest_controller_1.serviceRequestsController.findServiceRequest);
exports.serviceRequestsRoute.post('/create', serviceRequest_controller_1.serviceRequestsController.createServiceRequest);
exports.serviceRequestsRoute.post('/creates', serviceRequest_controller_1.serviceRequestsController.createServiceRequests);
exports.serviceRequestsRoute.put('/update', serviceRequest_controller_1.serviceRequestsController.updateServiceRequest);
exports.serviceRequestsRoute.put('/delete/:serviceRequestId', serviceRequest_controller_1.serviceRequestsController.deleteServiceRequest);
//# sourceMappingURL=serviceRequest.routes.js.map