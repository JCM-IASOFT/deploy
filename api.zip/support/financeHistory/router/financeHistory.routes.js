"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.financeHistoryRoute = void 0;
const express_1 = require("express");
const financeHistory_1 = require("../controller/financeHistory");
exports.financeHistoryRoute = (0, express_1.Router)();
exports.financeHistoryRoute.get('/findAll', financeHistory_1.financeHistoryController.findFinanceHistory);
exports.financeHistoryRoute.get('/operation/day', financeHistory_1.financeHistoryController.typeOperationForDay);
exports.financeHistoryRoute.get('/operation/month', financeHistory_1.financeHistoryController.typeOperationForMounth);
exports.financeHistoryRoute.get('/operation/user/day', financeHistory_1.financeHistoryController.typeOperationForUserDay);
exports.financeHistoryRoute.get('/operation/user/month', financeHistory_1.financeHistoryController.typeOperationForUserMonth);
exports.financeHistoryRoute.get('/operation/typeTransaction/day', financeHistory_1.financeHistoryController.typeOperationForTypeTransactionDay);
exports.financeHistoryRoute.get('/operation/typeTransaction/month', financeHistory_1.financeHistoryController.typeOperationForTypeTransactionMonth);
exports.financeHistoryRoute.get('/operation/income-expenses/details', financeHistory_1.financeHistoryController.findFinanceDetails);
//# sourceMappingURL=financeHistory.routes.js.map