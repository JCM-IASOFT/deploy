"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.financeHistoryService = void 0;
const typeorm_1 = require("typeorm");
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const moment_1 = __importDefault(require("moment"));
class FinanceHistoryService {
    static getInstance() {
        if (!this.instance)
            this.instance = new FinanceHistoryService();
        return this.instance;
    }
    findFinanceHistory(startDate, endDate, campusId, userId, typeOperation, typeTransactionId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const whereOption = {
                    deliverDate: (0, typeorm_1.Between)((0, moment_1.default)(startDate).startOf('day'), (0, moment_1.default)(endDate).endOf('day')),
                    campusId: campusId,
                    deletedAt: '0'
                };
                if (userId !== 0) {
                    whereOption.attendant = userId;
                }
                if (typeOperation !== '') {
                    whereOption.typeOperation = typeOperation;
                }
                if (typeTransactionId !== 0) {
                    whereOption.typeTransactionId = typeTransactionId;
                }
                const result = yield modelslibrary_1.FinanceModel.find({
                    where: whereOption,
                    relations: {
                        // service: {
                        //     differences: true
                        // },
                        user: true,
                        paymentTransaction: true,
                        typeTransaction: true
                    }
                });
                return result;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findTransactionforOperationForDay(typeOperation, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const finance = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.FinanceModel);
                const response = finance.createQueryBuilder('f')
                    .select([
                    'f.financeId AS "financeId"',
                    'f.details AS "details"',
                    'TO_CHAR(DATE(f.deliverDate), \'YYYY-MM-DD\') AS "deliverDate"',
                    `SUM(pt.amount) AS "totalAmount"`,
                    'paymentType.description AS "typePayment"',
                    'paymentType.paymentTypeId AS "paymentTypeId"',
                    'COUNT(pt.paymentTypeId) AS "paymentCount"'
                ])
                    .innerJoin('f.paymentTransaction', 'pt')
                    .innerJoin('pt.paymentType', 'paymentType')
                    .where('f.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('f.campusId = :campusId', { campusId })
                    .andWhere('f.typeOperation = :typeOperation', { typeOperation })
                    .groupBy('"deliverDate", paymentType.paymentTypeId, f.financeId')
                    .orderBy('"deliverDate", f.financeId', 'ASC')
                    .getRawMany();
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findTransactionforOperationForMonth(typeOperation, campusId) {
        try {
            const finance = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.FinanceModel);
            const response = finance.createQueryBuilder('f')
                .select([
                'f.financeId AS "financeId"',
                'f.details AS "details"',
                'TO_CHAR(DATE(f.deliverDate), \'YYYY-MM\') AS "deliverDate"',
                `SUM(pt.amount) AS "totalAmount"`,
                'paymentType.description AS "typePayment"',
                'paymentType.paymentTypeId AS "paymentTypeId"',
                'COUNT(pt.paymentTypeId) AS "paymentCount"'
            ])
                .innerJoin('f.paymentTransaction', 'pt')
                .innerJoin('pt.paymentType', 'paymentType')
                .where('f.deletedAt = :deletedAt', { deletedAt: '0' })
                .andWhere('f.campusId = :campusId', { campusId })
                .andWhere('f.typeOperation = :typeOperation', { typeOperation })
                .groupBy('"deliverDate", paymentType.paymentTypeId, f.financeId')
                .orderBy('"deliverDate", f.financeId', 'ASC')
                .getRawMany();
            return response;
        }
        catch (error) {
            save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            return [];
        }
    }
    findTransactionByUserforOperationDay(campusId) {
        try {
            const finance = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.FinanceModel);
            const response = finance.createQueryBuilder('f')
                .select([
                'f.financeId AS "financeId"',
                'f.details AS "details"',
                'f.typeOperation AS "typeOperation"',
                'u.id as "userId"',
                'u.name AS "username"',
                'TO_CHAR(DATE(f.deliverDate), \'YYYY-MM-DD\') AS "deliverDate"',
                'SUM(pt.amount) AS "totalAmount"',
                'paymentType.paymentTypeId AS "paymentTypeId"',
                'paymentType.description AS "typePayment"',
                'COUNT(pt.paymentTypeId) AS "paymentCount"',
            ])
                .innerJoin('f.paymentTransaction', 'pt')
                .innerJoin('pt.paymentType', 'paymentType')
                .innerJoin('f.user', 'u')
                .where('f.deletedAt = :deletedAt', { deletedAt: '0' })
                .andWhere('f.campusId = :campusId', { campusId })
                .groupBy('u.id, "deliverDate", paymentType.paymentTypeId, f.financeId')
                .orderBy('"username", f.financeId', 'ASC')
                .getRawMany();
            return response;
        }
        catch (error) {
            save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            return [];
        }
    }
    findTransactionByUserforOperationMonth(campusId) {
        try {
            const finance = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.FinanceModel);
            const response = finance.createQueryBuilder('f')
                .select([
                'f.financeId AS "financeId"',
                'f.details AS "details"',
                'f.typeOperation AS "typeOperation"',
                'u.id as "userId"',
                'u.name AS "username"',
                'TO_CHAR(DATE(f.deliverDate), \'YYYY-MM\') AS "deliverDate"',
                'SUM(pt.amount) AS "totalAmount"',
                'paymentType.paymentTypeId AS "paymentTypeId"',
                'paymentType.description AS "typePayment"',
                'COUNT(pt.paymentTypeId) AS "paymentCount"',
            ])
                .innerJoin('f.paymentTransaction', 'pt')
                .innerJoin('pt.paymentType', 'paymentType')
                .innerJoin('f.user', 'u')
                .where('f.deletedAt = :deletedAt', { deletedAt: '0' })
                .andWhere('f.campusId = :campusId', { campusId })
                .groupBy('u.id, "deliverDate", paymentType.paymentTypeId, f.financeId')
                .orderBy('"username", f.financeId', 'ASC')
                .getRawMany();
            return response;
        }
        catch (error) {
            save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            return [];
        }
    }
    findTransactionByTypeTransactionforOperationDay(campusId) {
        try {
            const finance = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.FinanceModel);
            const response = finance.createQueryBuilder('f')
                .select([
                'f.financeId AS "financeId"',
                'f.details AS "details"',
                'f.typeOperation AS "typeOperation"',
                'TO_CHAR(DATE(f.deliverDate), \'YYYY-MM-DD\') AS "deliverDate"',
                'tt.description AS "typeTransaction"',
                'SUM(pt.amount) AS "totalAmount"',
                'paymentType.paymentTypeId AS "paymentTypeId"',
                'tt.typeTransactionId AS "typeTransactionId"',
                'paymentType.description AS "typePayment"',
                'COUNT(pt.paymentTypeId) AS "paymentCount"'
            ])
                .innerJoin('f.paymentTransaction', 'pt')
                .innerJoin('pt.paymentType', 'paymentType')
                .innerJoin('f.typeTransaction', 'tt')
                .where('f.deletedAt = :deletedAt', { deletedAt: '0' })
                .andWhere('f.campusId = :campusId', { campusId })
                .groupBy('tt.typeTransactionId, "typePayment", "paymentTypeId", "deliverDate", f.financeId')
                .orderBy('"deliverDate", "financeId"', 'ASC')
                .getRawMany();
            return response;
        }
        catch (error) {
            save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            return [];
        }
    }
    findTransactionByTypeTransactionforOperationMonth(campusId) {
        try {
            const finance = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.FinanceModel);
            const response = finance.createQueryBuilder('f')
                .select([
                'f.financeId AS "financeId"',
                'f.details AS "details"',
                'f.typeOperation AS "typeOperation"',
                'TO_CHAR(DATE(f.deliverDate), \'YYYY-MM\') AS "deliverDate"',
                'tt.description AS "typeTransaction"',
                'SUM(pt.amount) AS "totalAmount"',
                'paymentType.paymentTypeId AS "paymentTypeId"',
                'tt.typeTransactionId AS "typeTransactionId"',
                'paymentType.description AS "typePayment"',
                'COUNT(pt.paymentTypeId) AS "paymentCount"'
            ])
                .innerJoin('f.paymentTransaction', 'pt')
                .innerJoin('pt.paymentType', 'paymentType')
                .innerJoin('f.typeTransaction', 'tt')
                .where('f.deletedAt = :deletedAt', { deletedAt: '0' })
                .andWhere('f.campusId = :campusId', { campusId })
                .groupBy('tt.typeTransactionId, "typePayment", paymentType.paymentTypeId, "deliverDate", f.financeId')
                .orderBy('"deliverDate", f.financeId', 'ASC')
                .getRawMany();
            return response;
        }
        catch (error) {
            save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            return [];
        }
    }
    findTransactionForRange(startDate, endDate, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.FinanceModel.find({
                    where: {
                        deliverDate: (0, typeorm_1.Between)((0, moment_1.default)(startDate).startOf('day').toDate(), (0, moment_1.default)(endDate).endOf('day').toDate()),
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relations: {
                        paymentTransaction: {
                            paymentType: true
                        },
                        typeTransaction: true
                    }
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
}
exports.financeHistoryService = FinanceHistoryService.getInstance();
//# sourceMappingURL=financeHistory.service.js.map