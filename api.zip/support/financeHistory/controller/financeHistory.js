"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.financeHistoryController = void 0;
const financeHistory_service_1 = require("../service/financeHistory.service");
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
class FinanceHistoryController {
    static getInstance() {
        if (!this.instance)
            this.instance = new FinanceHistoryController();
        return this.instance;
    }
    findFinanceHistory(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { startDate, endDate, campusId, userId, typeOperation, typeTransactionId } = request.query;
                const financeHistoryResponse = yield financeHistory_service_1.financeHistoryService.findFinanceHistory(startDate.toString(), endDate.toString(), Number(campusId), Number(userId), typeOperation, Number(typeTransactionId));
                response.status(http_status_codes_1.StatusCodes.OK).json(financeHistoryResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    typeOperationForDay(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { typeOperation, campusId } = request.query;
                const summary = yield financeHistory_service_1.financeHistoryService.findTransactionforOperationForDay(typeOperation.toString(), Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(summary);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    typeOperationForMounth(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { typeOperation, campusId } = request.query;
                const summary = yield financeHistory_service_1.financeHistoryService.findTransactionforOperationForMonth(typeOperation.toString(), Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(summary);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    typeOperationForUserDay(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const summary = yield financeHistory_service_1.financeHistoryService.findTransactionByUserforOperationDay(Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(summary);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    typeOperationForUserMonth(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const summary = yield financeHistory_service_1.financeHistoryService.findTransactionByUserforOperationMonth(Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(summary);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    typeOperationForTypeTransactionDay(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const summary = yield financeHistory_service_1.financeHistoryService.findTransactionByTypeTransactionforOperationDay(Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(summary);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    typeOperationForTypeTransactionMonth(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const summary = yield financeHistory_service_1.financeHistoryService.findTransactionByTypeTransactionforOperationMonth(Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(summary);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findFinanceDetails(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { startDate, endDate, campusId, } = request.query;
                const responseTransaction = yield financeHistory_service_1.financeHistoryService.findTransactionForRange(startDate.toString(), endDate.toString(), Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(responseTransaction);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
}
exports.financeHistoryController = FinanceHistoryController.getInstance();
//# sourceMappingURL=financeHistory.js.map