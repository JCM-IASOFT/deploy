"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deviceproductRoute = void 0;
const express_1 = require("express");
const deviceproduct_controller_1 = require("../controller/deviceproduct.controller");
const deviceproduct_validator_1 = require("../validator/deviceproduct.validator");
exports.deviceproductRoute = (0, express_1.Router)();
exports.deviceproductRoute.post('/create', deviceproduct_validator_1.validateCreateDeviceProduct, deviceproduct_controller_1.deviceproductController.createDeviceProducts);
exports.deviceproductRoute.put('/', deviceproduct_validator_1.validateUpdateDeviceProduct, deviceproduct_controller_1.deviceproductController.updateDeviceProduct);
exports.deviceproductRoute.delete('/', deviceproduct_validator_1.validateDeleteDeviceProduct, deviceproduct_controller_1.deviceproductController.deleteDeviceProduct);
//# sourceMappingURL=deviceproduct.router.js.map