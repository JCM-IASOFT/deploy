"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verificationController = void 0;
const http_status_codes_1 = require("http-status-codes");
const verification_service_1 = require("../service/verification.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
class VerificationController {
    constructor() {
        this.verifyCode = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { verification } = req.body;
                    const verifications = yield verification_service_1.verificationService.verifyCode(verification);
                    const dateExired = new Date(verifications.expiryDate);
                    const dateCurrent = new Date();
                    if (dateExired < dateCurrent) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.EXPIRED_ERROR_VERIFICATION };
                    }
                    if (verifications.code !== verification.code) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.CODE_ERROR_VERIFICATION };
                    }
                    if (verifications) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CODE_SUCCES_VERIFICATION };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.createVerifications = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { campusId, userId } = req.body;
                    const currentDate = new Date();
                    currentDate.setMinutes(currentDate.getMinutes() + 5);
                    const code = yield this.generateRandomNumber();
                    const expiryDate = currentDate;
                    const verification = {
                        code: code,
                        expired: false,
                        used: false,
                        expiryDate: expiryDate,
                        userId: userId,
                        campusId: campusId,
                    };
                    const response = yield verification_service_1.verificationService.createVerification(verification);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_DEVICE, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER, data: error };
                }
            }));
        });
        this.generateRandomNumber = () => __awaiter(this, void 0, void 0, function* () {
            const randomNumber = Math.floor(Math.random() * 1000000);
            const randomNumberString = randomNumber.toString().padStart(6, '0');
            return randomNumberString;
        });
        this.updateVerification = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const response = yield verification_service_1.verificationService.updateVerification(req.body);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_DEVICE, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new VerificationController();
        return this.instance;
    }
}
exports.verificationController = VerificationController.getInstance();
//# sourceMappingURL=verification.controller.js.map