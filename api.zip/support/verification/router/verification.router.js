"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verificationRoute = void 0;
const express_1 = require("express");
const verification_controller_1 = require("../controller/verification.controller");
exports.verificationRoute = (0, express_1.Router)();
exports.verificationRoute.post('/', verification_controller_1.verificationController.verifyCode);
exports.verificationRoute.post('/create', verification_controller_1.verificationController.createVerifications);
exports.verificationRoute.put('/', verification_controller_1.verificationController.updateVerification);
//# sourceMappingURL=verification.router.js.map