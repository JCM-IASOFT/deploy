"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.devicetypeController = void 0;
const http_status_codes_1 = require("http-status-codes");
const devicebrand_service_1 = require("../service/devicebrand.service");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
class DeviceBrandController {
    constructor() {
        this.findDeviceBrand = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const devicetypes = yield devicebrand_service_1.devicetypeService.findDeviceBrand(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(devicetypes);
        });
        this.findAllDeviceBrand = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const devicetypes = yield devicebrand_service_1.devicetypeService.findAllDeviceBrand(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json({
                data: devicetypes,
                draw: Math.random(),
                recordsFiltered: devicetypes.length,
                recordsTotal: devicetypes.length,
            });
        });
        this.createDeviceBrands = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield devicebrand_service_1.devicetypeService.createDeviceBrand(req.body);
                if (response) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_DEVICE, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.updateDeviceBrand = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const response = yield devicebrand_service_1.devicetypeService.updateDeviceBrand(req.body);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_DEVICE, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.deleteDeviceBrand = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield devicebrand_service_1.devicetypeService.deleteDeviceBrand(req.body);
                if (response.affected > 0) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_DEVICE, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new DeviceBrandController();
        return this.instance;
    }
}
exports.devicetypeController = DeviceBrandController.getInstance();
//# sourceMappingURL=devicebrand.controller.js.map