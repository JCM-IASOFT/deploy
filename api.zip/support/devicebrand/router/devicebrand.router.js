"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.devicebrandRoute = void 0;
const express_1 = require("express");
const devicebrand_controller_1 = require("../controller/devicebrand.controller");
const devicebrand_validator_1 = require("../validator/devicebrand.validator");
exports.devicebrandRoute = (0, express_1.Router)();
exports.devicebrandRoute.get('/', devicebrand_controller_1.devicetypeController.findDeviceBrand);
exports.devicebrandRoute.post('/all', devicebrand_controller_1.devicetypeController.findAllDeviceBrand);
exports.devicebrandRoute.post('/create', devicebrand_validator_1.validateCreateDeviceBrand, devicebrand_controller_1.devicetypeController.createDeviceBrands);
exports.devicebrandRoute.put('/', devicebrand_validator_1.validateUpdateDeviceBrand, devicebrand_controller_1.devicetypeController.updateDeviceBrand);
exports.devicebrandRoute.delete('/', devicebrand_validator_1.validateDeleteDeviceBrand, devicebrand_controller_1.devicetypeController.deleteDeviceBrand);
//# sourceMappingURL=devicebrand.router.js.map