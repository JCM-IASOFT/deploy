"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicedevicehistoryService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const enum_1 = require("modelslibrary/src/core/enum/enum");
class ServiceDeviceHistoryService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceDeviceHistoryService();
        return this.instance;
    }
    createDeviceHistory(servicedevicehistory, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const history = modelslibrary_1.ServiceDeviceHistoryModel.create(servicedevicehistory);
                const response = yield queryRunner.manager.save(history);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateDeviceHistoryByDevice(servicedevicehistory, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceDeviceHistoryModel, {
                    serviceDeviceId: servicedevicehistory.serviceDeviceId,
                    type: servicedevicehistory.type
                }, {
                    estimatedAmount: servicedevicehistory.estimatedAmount
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteDeviceHistory(serviceDeviceId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.createQueryBuilder()
                    .delete()
                    .from(modelslibrary_1.ServiceDeviceHistoryModel)
                    .where("serviceDeviceId = :serviceDeviceId", { serviceDeviceId })
                    .andWhere("type != :type", { type: enum_1.TypeOperationDeviceHistory.Initialization }) // Ajusta según tu campo y valor de tipo1
                    .execute();
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.servicedevicehistoryService = ServiceDeviceHistoryService.getInstance();
//# sourceMappingURL=servicedevicehistory.service.js.map