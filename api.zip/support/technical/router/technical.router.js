"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.technicalRoute = void 0;
const express_1 = require("express");
const technical_controller_1 = require("../controller/technical.controller");
const technical_validator_1 = require("../validator/technical.validator");
exports.technicalRoute = (0, express_1.Router)();
exports.technicalRoute.get('/', technical_validator_1.validateEfficiencyTechnical, technical_controller_1.technicalController.obtainTechnicianEfficiency);
//# sourceMappingURL=technical.router.js.map