"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.technicalService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const models_1 = require("models");
const typeorm_1 = require("typeorm");
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
class TechnicalService {
    static getInstance() {
        if (!this.instance)
            this.instance = new TechnicalService();
        return this.instance;
    }
    obtainTechnicianEfficiency(startDate, endDate, campusId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const whereOption = {
                    registrationDate: (0, typeorm_1.Between)(new Date(startDate.setHours(0, 0, 0)), new Date(endDate.setHours(23, 59, 59))),
                    campusId: campusId,
                    state: (0, typeorm_1.Not)((0, typeorm_1.In)([parameter_constant_1.StatusService.POR_ASIGNAR, parameter_constant_1.StatusService.EN_PROCESO, parameter_constant_1.StatusService.RECHAZADO, parameter_constant_1.StatusService.SIN_SOLUCION, parameter_constant_1.StatusService.GARANTIA, parameter_constant_1.StatusService.POR_ENTREGAR])),
                };
                if (userId !== 0) {
                    whereOption.userTechnicalId = userId;
                }
                const devices = yield models_1.ServiceModel.find({
                    where: whereOption,
                    relations: ["userTechnical", "serviceStatusHistorys", "serviceDevices", "serviceDevices.device", "serviceDevices.serviceTypeDevices", "serviceDevices.serviceTypeDevices.serviceType"],
                    select: {
                        serviceId: true,
                        registrationDate: true,
                        deliverDate: true,
                        totalAmount: true,
                        state: true,
                        priority: true,
                        userTechnical: {
                            userId: true,
                            name: true,
                            fullname: true,
                            email: true,
                            phone: true,
                        },
                        serviceStatusHistorys: {
                            statusHistoryId: true,
                            serviceId: true,
                            status: true,
                            dateChanged: true,
                            userId: true,
                            coments: true,
                            complete: true,
                        },
                        serviceDevices: {
                            serviceDeviceId: true,
                            accessories: true,
                            reason: true,
                            estimatedAmount: true,
                            serviceTypeDevices: {
                                serviceTypeDeviceId: true,
                                serviceTypeId: true,
                                serviceDeviceId: true,
                                serviceType: {
                                    serviceTypeId: true,
                                    description: true,
                                    typeTime: true,
                                    time: true,
                                }
                            },
                            device: {
                                deviceId: true,
                                description: true
                            },
                            deviceBrand: {
                                deviceBrandId: true,
                                description: true,
                            }
                        }
                    }
                });
                return devices;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
}
exports.technicalService = TechnicalService.getInstance();
//# sourceMappingURL=technical.service.js.map