"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deviceRoute = void 0;
const express_1 = require("express");
const device_controller_1 = require("../controller/device.controller");
const device_validator_1 = require("../validator/device.validator");
exports.deviceRoute = (0, express_1.Router)();
exports.deviceRoute.get('/', device_controller_1.deviceController.findDevice);
exports.deviceRoute.post('/all', device_controller_1.deviceController.findAllDevice);
exports.deviceRoute.post('/create', device_validator_1.validateCreateDevice, device_controller_1.deviceController.createDevices);
exports.deviceRoute.put('/', device_validator_1.validateUpdateDevice, device_controller_1.deviceController.updateDevice);
exports.deviceRoute.delete('/', device_validator_1.validateDeleteDevice, device_controller_1.deviceController.deleteDevice);
//# sourceMappingURL=device.router.js.map