"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const models_1 = require("models");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
class PaymentService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PaymentService();
        return this.instance;
    }
    findTodayPayments(campusId, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Obtener la fecha actual en el formato adecuado basado en la zona horaria
                const currentDate = (0, moment_timezone_1.default)().tz(timeZone).format("YYYY-MM-DD");
                // Consulta para obtener los pagos del día
                const services = yield models_1.PaymentModel.createQueryBuilder("payment")
                    .innerJoinAndSelect("payment.paymentType", "paymentType")
                    .select([
                    "payment",
                    "paymentType"
                ])
                    .where("DATE(payment.date) = :currentDate", { currentDate }) // Comparar la fecha del pago con la fecha actual
                    .andWhere("payment.campusId = :campusId", { campusId }) // Comparar el campusId
                    .getMany(); // Obtener múltiples resultados si existen
                return services;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    createPayment(payment, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const PaymentEntity = models_1.PaymentModel.create(payment);
                const response = yield queryRunner.manager.save(PaymentEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deletePayment(payment, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.PaymentModel, { serviceId: payment.serviceId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    getTotalPaymentService(paymentType, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const paymentRepository = models_1.AppDataSource.getRepository(models_1.PaymentModel);
                const totalService = yield paymentRepository.createQueryBuilder('paymentService')
                    .select('SUM(paymentService.amount)', 'total')
                    .innerJoin('paymentService.paymentType', 'paymentType')
                    .where('paymentType.type = :type', { type: paymentType })
                    .andWhere('paymentService.campusId = :campusId', { campusId: campusId })
                    .andWhere('paymentService.deletedAt = :deletedAt', { deletedAt: '0' })
                    .getRawOne();
                const total = totalService ? Number(totalService.total) : 0;
                return total;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.paymentService = PaymentService.getInstance();
//# sourceMappingURL=payment.service.js.map