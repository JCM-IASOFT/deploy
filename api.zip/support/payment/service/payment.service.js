"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class PaymentService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PaymentService();
        return this.instance;
    }
    findPayments(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const serviceRepository = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.PaymentModel);
                const services = yield serviceRepository
                    .createQueryBuilder('payment')
                    .select([
                    'SUM(payment.amount) AS "amount"',
                    'paymentType.description AS description',
                ])
                    .innerJoin('payment.paymentType', 'paymentType')
                    .where('payment.campusId = :campusId', { campusId: campusId })
                    .andWhere('payment.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('DATE(payment.createdBy) = CURRENT_DATE')
                    .groupBy('paymentType.description')
                    .getRawMany();
                return services;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createPayment(payment, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const PaymentEntity = modelslibrary_1.PaymentModel.create(payment);
                const response = yield queryRunner.manager.save(PaymentEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deletePayment(payment, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.PaymentModel, { serviceId: payment.serviceId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    getTotalPaymentService(paymentType, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const paymentRepository = modelslibrary_1.AppDataSource.getRepository(modelslibrary_1.PaymentModel);
                const totalService = yield paymentRepository.createQueryBuilder('paymentService')
                    .select('SUM(paymentService.amount)', 'total')
                    .innerJoin('paymentService.paymentType', 'paymentType')
                    .where('paymentType.type = :type', { type: paymentType })
                    .andWhere('paymentService.campusId = :campusId', { campusId: campusId })
                    .andWhere('paymentService.deletedAt = :deletedAt', { deletedAt: '0' })
                    .getRawOne();
                const total = totalService ? Number(totalService.total) : 0;
                return total;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.paymentService = PaymentService.getInstance();
//# sourceMappingURL=payment.service.js.map