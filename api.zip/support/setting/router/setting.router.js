"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingRoute = void 0;
const express_1 = require("express");
const setting_controller_1 = require("../controller/setting.controller");
const setting_validator_1 = require("../validator/setting.validator");
exports.settingRoute = (0, express_1.Router)();
exports.settingRoute.get('/one', setting_controller_1.settingController.getOneSetting);
exports.settingRoute.post('/', setting_validator_1.validateSaveSetting, setting_controller_1.settingController.saveSetting);
//# sourceMappingURL=setting.router.js.map