"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateSaveSetting = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateCampusId = (0, express_validator_1.check)('settings.*.campusId')
    .exists().withMessage('El campusId es requerido')
    .isInt().withMessage('El campusId debe ser un número entero');
const validateCompanyId = (0, express_validator_1.check)('settings.*.companyId')
    .exists().withMessage('El companyId es requerido')
    .isInt().withMessage('El companyId debe ser un número entero');
const validatePauseTime = (0, express_validator_1.check)('settings.*.pauseTime')
    .exists().withMessage('El pauseTime es requerido')
    .withMessage('El formato de pauseTime debe ser HH:mm');
const validateStartTime = (0, express_validator_1.check)('settings.*.startTime')
    .exists().withMessage('El startTime es requerido')
    .withMessage('El formato de startTime debe ser HH:mm');
const validateStatePause = (0, express_validator_1.check)('settings.*.statePause')
    .exists().withMessage('El estado es requerido')
    .isBoolean().withMessage('El estado debe ser un valor booleano');
const validateStateStart = (0, express_validator_1.check)('settings.*.stateStart')
    .exists().withMessage('El estado es requerido')
    .isBoolean().withMessage('El estado debe ser un valor booleano');
// * Validación para la creación de una configuración (setting)
exports.validateSaveSetting = [
    validateCampusId,
    validateCompanyId,
    validatePauseTime,
    validateStartTime,
    validateStatePause,
    validateStateStart,
    handleValidationResult
];
//# sourceMappingURL=setting.validator.js.map