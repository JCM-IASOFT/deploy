"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateUpdatePauseService = exports.validateDeleteService = exports.validateEndService = exports.validateChangeStateService = exports.validateUpdateService = exports.validateCreateService = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateService = [
    (0, express_validator_1.check)('service.registrationDate').exists().not().isEmpty(),
    //check('service.deliverDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('service.totalAmount').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('service.state').exists().not().isEmpty(),
    //check('service.comment').exists().isEmpty(),
    (0, express_validator_1.check)('service.priority').exists().not().isEmpty(),
    // check('service.clientId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('service.campusId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('service.userReceptionId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('serviceDevices.*.accessories').exists().not().isEmpty(),
    (0, express_validator_1.check)('serviceDevices.*.reason').exists().not().isEmpty(),
    //check('serviceDevices.*.observations').exists().not().isEmpty(),
    //check('serviceDevices.*.estimatedAmount').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('serviceDevices.*.deviceId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('serviceDevices.*.deviceBrandId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('serviceDevices.*.campusId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('serviceDevices.*.serviceTypeDevices.*.serviceTypeId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('serviceDevices.*.serviceTypeDevices.*.serviceDeviceId').exists().isNumeric().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateService = [
    (0, express_validator_1.check)('serviceId').exists().not().isEmpty(),
    (0, express_validator_1.check)('registrationDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('deliverDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('totalAmount').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('state').exists().not().isEmpty(),
    (0, express_validator_1.check)('comment').exists().not().isEmpty(),
    (0, express_validator_1.check)('priority').exists().not().isEmpty(),
    (0, express_validator_1.check)('clientId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('employeId').exists().isNumeric().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateChangeStateService = [
    (0, express_validator_1.check)('service.serviceId').exists().not().isEmpty(),
    (0, express_validator_1.check)('service.state').exists().not().isEmpty(),
    (0, express_validator_1.check)('service.userTechnicalId').exists().not().isEmpty(),
    (0, express_validator_1.check)('serviceStatusHistory.serviceId').exists().not().isEmpty(),
    (0, express_validator_1.check)('serviceStatusHistory.status').exists().not().isEmpty(),
    (0, express_validator_1.check)('serviceStatusHistory.userId').exists().not().isEmpty(),
    (0, express_validator_1.check)('serviceStatusHistory.coments').exists().not().isEmpty(),
    (0, express_validator_1.check)("statusHistoryId").exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateEndService = [
    (0, express_validator_1.check)('service.serviceId').exists().not().isEmpty(),
    (0, express_validator_1.check)('service.state').exists().notEmpty(),
    (0, express_validator_1.check)('service.userDeliveryId').exists().not().isEmpty(),
    (0, express_validator_1.check)('statusHistoryId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('serviceStatusHistory').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteService = [
    (0, express_validator_1.check)('serviceId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdatePauseService = [
    (0, express_validator_1.check)('service.serviceId').exists().not().isEmpty(),
    (0, express_validator_1.check)('service.pause').exists().not().isEmpty(),
    (0, express_validator_1.check)('servicePauseHistory.dossier').exists().not().isEmpty(),
    (0, express_validator_1.check)('servicePauseHistory.serviceId').exists().not().isEmpty(),
    (0, express_validator_1.check)('servicePauseHistory.userTechnicalId').exists().not().isEmpty(),
    (0, express_validator_1.check)('servicePauseHistory.registrationDate').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=service.validator.js.map