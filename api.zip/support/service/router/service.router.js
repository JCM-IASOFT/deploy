"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceRoute = void 0;
const express_1 = require("express");
const service_controller_1 = require("../controller/service.controller");
const service_validator_1 = require("../validator/service.validator");
exports.serviceRoute = (0, express_1.Router)();
exports.serviceRoute.get('/', service_controller_1.serviceController.findOneService);
exports.serviceRoute.post('/', service_controller_1.serviceController.findService);
exports.serviceRoute.get('/expiring', service_controller_1.serviceController.getExpiringService);
exports.serviceRoute.post('/change-technical', service_controller_1.serviceController.changeTechnical);
exports.serviceRoute.post('/update-totalamount', service_controller_1.serviceController.updateTotalAmount);
exports.serviceRoute.get('/all', service_controller_1.serviceController.findServiceTransaction);
exports.serviceRoute.get('/find/:id', service_controller_1.serviceController.findServiceId);
// serviceRoute.get('/frfrfr', serviceController.findServiceTransaction)
exports.serviceRoute.post('/create', service_validator_1.validateCreateService, service_controller_1.serviceController.createServices);
exports.serviceRoute.post('/reset', service_controller_1.serviceController.resetAdjustments);
exports.serviceRoute.post('/endservice', service_validator_1.validateEndService, service_controller_1.serviceController.endService);
exports.serviceRoute.post('/changestate', service_validator_1.validateChangeStateService, service_controller_1.serviceController.changeStateService);
exports.serviceRoute.post('/update_sd', service_controller_1.serviceController.updateServiceDevice);
exports.serviceRoute.post('/delete', service_validator_1.validateDeleteService, service_controller_1.serviceController.deleteService);
exports.serviceRoute.post('/pause', service_validator_1.validateUpdatePauseService, service_controller_1.serviceController.updatePauseService);
exports.serviceRoute.get('/find/phone', service_controller_1.serviceController.findServiceByPhone);
exports.serviceRoute.get('/process', service_controller_1.serviceController.findServiceInProcess);
//# sourceMappingURL=service.router.js.map