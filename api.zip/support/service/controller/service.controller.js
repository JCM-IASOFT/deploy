"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceController = void 0;
const http_status_codes_1 = require("http-status-codes");
const service_service_1 = require("../service/service.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const models_1 = require("models");
const servicestatushistory_service_1 = require("../../servicestatushistory/service/servicestatushistory.service");
const difference_service_1 = require("../../difference/service/difference.service");
const payment_service_1 = require("../../payment/service/payment.service");
const servicetypedevice_service_1 = require("../../servicetypedevice/service/servicetypedevice.service");
const servicedevicehistory_service_1 = require("../../servicedevicehistory/service/servicedevicehistory.service");
const servicePauseHistory_service_1 = require("../../servicePauseHistory/service/servicePauseHistory.service");
const servicedevice_service_1 = require("../../servicedevice/service/servicedevice.service");
const enum_1 = require("models/src/core/enum/enum");
const serviceTechnicalHistory_service_1 = require("../../serviceTechnicalHistory/service/serviceTechnicalHistory.service");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
const differencePayment_service_1 = require("../../differencePayment/service/differencePayment.service");
class ServiceController {
    constructor() {
        this.findServiceTransaction = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { search, campusId } = req.query;
                const services = yield service_service_1.serviceService.findServiceTransaction(search.toString(), Number(campusId));
                res.status(http_status_codes_1.StatusCodes.OK).json(services);
            }
            catch (err) {
                res.status(500).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: err
                });
            }
        });
        // findService = async (req: Request, res: Response) => {
        //     const { servicefilter, page, sizePage } = req.body
        //     const services = await serviceService.findService(servicefilter, Number(page), Number(sizePage));
        //     const total = await serviceService.allCountService()
        //     res.status(StatusCodes.OK).json({
        //         data: services,
        //         draw: Math.random(),
        //         recordsFiltered: services.length,
        //         recordsTotal: total,
        //     });
        // }
        this.ee = 0;
        this.findService = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { servicefilter, page, sizePage } = req.body;
            const findServices = yield service_service_1.serviceService.findService(servicefilter, Number(page), Number(sizePage));
            const services = (yield findServices) ? findServices.services : [];
            const total = (yield findServices) ? findServices.total : 0;
            res.status(http_status_codes_1.StatusCodes.OK).json({
                data: services,
                draw: Math.random(),
                recordsFiltered: services.length,
                recordsTotal: total,
            });
        });
        this.findServiceId = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { id } = req.params;
            const services = yield service_service_1.serviceService.findOneService(Number(id));
            res.status(http_status_codes_1.StatusCodes.OK).json(services);
        });
        this.findServiceByPhone = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { phone } = req.query;
            const service = yield service_service_1.serviceService.findServiceByPhone(phone.toString());
            return res.status(http_status_codes_1.StatusCodes.OK).json(service);
        });
        this.getExpiringService = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const services = yield service_service_1.serviceService.getExpiringService(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(services);
        });
        this.findOneService = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { serviceId } = req.query;
            const services = yield service_service_1.serviceService.findOneService(Number(serviceId));
            res.status(http_status_codes_1.StatusCodes.OK).json(services);
        });
        this.createServices = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { service, payments, serviceDevices } = req.body;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const savedService = yield service_service_1.serviceService.createService(service, queryRunner);
                        const paymentWithServiceId = payments.map(payment => (Object.assign(Object.assign({}, payment), { serviceId: savedService.serviceId })));
                        yield Promise.all(paymentWithServiceId.map(payment => payment_service_1.paymentService.createPayment(payment, queryRunner)));
                        const servicedevicesWithServiceId = serviceDevices.map(serviceDevices => (Object.assign(Object.assign({}, serviceDevices), { serviceId: savedService.serviceId })));
                        for (const serviceDevice of servicedevicesWithServiceId) {
                            const savedServiceDevice = yield servicedevice_service_1.servicedeviceService.createServiceDevice(serviceDevice, queryRunner);
                            for (const servicetypedevice of serviceDevice.serviceTypeDevices) {
                                servicetypedevice.serviceDeviceId = savedServiceDevice.serviceDeviceId;
                                yield servicetypedevice_service_1.servicetypedeviceService.createServiceTypeDevice(servicetypedevice, queryRunner);
                            }
                            const servicedeviceHistory = {
                                serviceDeviceId: savedServiceDevice.serviceDeviceId,
                                estimatedAmount: savedServiceDevice.estimatedAmount,
                                coments: 'Se ha iniciado el historial de monto estimado',
                            };
                            yield servicedevicehistory_service_1.servicedevicehistoryService.createDeviceHistory(servicedeviceHistory, queryRunner);
                        }
                        const serviceHistory = {
                            serviceId: savedService.serviceId,
                            status: service.type === models_1.TypeService.Detail ? parameter_constant_1.StatusService.POR_ASIGNAR : parameter_constant_1.StatusService.ENTREGADO,
                            userId: service.userReceptionId,
                            dateChanged: service.registrationDate,
                            coments: service.type === models_1.TypeService.Detail ? 'Iniciado el proceso de asignación' : 'Servicio rápido'
                        };
                        yield servicestatushistory_service_1.servicestatushistoryService.Create(serviceHistory, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_SERVICE, data: savedService };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.changeStateService = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { OK, FORBIDDEN, INTERNAL_SERVER_ERROR } = http_status_codes_1.StatusCodes;
            const { ERROR_SERVER, NOT_CANNOT_CHANGE_STATE, CHANGE_STATE_SUCCES_SERVICE } = message_api_1.MessageCustomApi;
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { service, serviceStatusHistory, statusHistoryId, completeDate } = req.body;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const serviceParse = service;
                        const serviceResult = yield service_service_1.serviceService.findOneService(serviceParse.serviceId);
                        if (!serviceResult) {
                            return { code: FORBIDDEN, success: false, message: ERROR_SERVER };
                        }
                        const statusCanChange = ![parameter_constant_1.StatusService.ENTREGADO, parameter_constant_1.StatusService.RECHAZADO, parameter_constant_1.StatusService.SIN_SOLUCION_ENTREGADO].includes(serviceResult.state);
                        if (!statusCanChange) {
                            return { code: FORBIDDEN, success: false, message: NOT_CANNOT_CHANGE_STATE };
                        }
                        const savedChangeState = yield service_service_1.serviceService.changeState(service, queryRunner);
                        const updateComplete = yield servicestatushistory_service_1.servicestatushistoryService.UpdateComplete(statusHistoryId, completeDate, queryRunner);
                        const savedHistory = yield servicestatushistory_service_1.servicestatushistoryService.Create(serviceStatusHistory, queryRunner);
                        if (!savedChangeState && !updateComplete && !savedHistory) {
                            throw new Error(ERROR_SERVER);
                        }
                        return { code: OK, success: true, message: CHANGE_STATE_SUCCES_SERVICE };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.endService = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { service, payments, serviceStatusHistory, statusHistoryId, completeDate } = req.body;
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const updateService = yield service_service_1.serviceService.updateService(service, queryRunner);
                        if (service.state === parameter_constant_1.StatusService.RECHAZADO) {
                            const payment = {
                                serviceId: service.serviceId
                            };
                            yield payment_service_1.paymentService.deletePayment(payment, queryRunner);
                        }
                        const differences = yield difference_service_1.differenceService.findDifferenceByService(service.serviceId);
                        let total = 0;
                        if (differences.length > 0) {
                            const promises = differences.map((difference) => __awaiter(this, void 0, void 0, function* () {
                                const differencePayments = yield differencePayment_service_1.differencePaymentService.findDifferencePayment(difference.differenceId);
                                return differencePayments.reduce((sum, diffPay) => sum + diffPay.amount, 0);
                            }));
                            const totals = yield Promise.all(promises);
                            total = totals.reduce((acc, current) => acc + current, 0);
                        }
                        // const differencesWithServiceId = differences.map(difference => ({ ...difference, serviceId: service.serviceId }));
                        // const savedDifferences = await Promise.all(differencesWithServiceId.map(difference => differenceService.createDifference(difference, queryRunner)));
                        const paymentWithServiceId = payments.map(payment => (Object.assign(Object.assign({}, payment), { serviceId: service.serviceId })));
                        const savedPayments = yield Promise.all(paymentWithServiceId.map(payment => payment_service_1.paymentService.createPayment(payment, queryRunner)));
                        const updateComplete = yield servicestatushistory_service_1.servicestatushistoryService.UpdateComplete(statusHistoryId, completeDate, queryRunner);
                        const savedHistory = yield servicestatushistory_service_1.servicestatushistoryService.Create(serviceStatusHistory, queryRunner);
                        if (!updateService || !savedPayments || !updateComplete || !savedHistory) {
                            throw new Error(message_api_1.MessageApi.ERROR_SERVER);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.END_SUCCESS_SERVICE };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        /**
         *  * Solo permite hacer cambio de monto estimado y algunos campos de service device
         * @param req
         * @param res
         */
        this.updateServiceDevice = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { service, serviceDevices, payments, serviceStatusHistory, statusHistoryId, completeDate } = req.body;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        yield service_service_1.serviceService.updateTotalAmount(service, queryRunner);
                        if (payments && payments.length > 0) {
                            yield Promise.all(payments.map(payment => payment_service_1.paymentService.createPayment(payment, queryRunner)));
                        }
                        // * SOLO CAMBIAMOS DE ESTADO CUANDO ME ASIGNAN UN TECNICO
                        if (service.userTechnicalId && service.userTechnicalId > 0) {
                            yield service_service_1.serviceService.changeState(service, queryRunner);
                            yield servicestatushistory_service_1.servicestatushistoryService.UpdateComplete(statusHistoryId, completeDate, queryRunner);
                            yield servicestatushistory_service_1.servicestatushistoryService.Create(serviceStatusHistory, queryRunner);
                        }
                        yield Promise.all(serviceDevices.map(serviceDevice => servicedevice_service_1.servicedeviceService.update(serviceDevice, queryRunner)));
                        for (const element of serviceDevices) {
                            const serviceDeviceHistory = {
                                serviceDeviceId: element.serviceDeviceId,
                                type: enum_1.TypeOperationDeviceHistory.Initialization,
                                estimatedAmount: element.estimatedAmount
                            };
                            yield servicedevicehistory_service_1.servicedevicehistoryService.updateDeviceHistoryByDevice(serviceDeviceHistory, queryRunner);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATE_ESTIMATED_AMOUNT_SUCCESS };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.deleteService = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield service_service_1.serviceService.deleteService(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_DEVICE, data: response };
            }));
        });
        this.changeTechnical = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { service, serviceTechnicalHistory } = req.body;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const changeTechnical = yield service_service_1.serviceService.changeTechnical(service, queryRunner);
                        const createTechnicalHistory = yield serviceTechnicalHistory_service_1.serviceTechnicalHistoryService.createServiceTechnicalHistory(serviceTechnicalHistory, queryRunner);
                        if (changeTechnical.affected > 0 && createTechnicalHistory) {
                            return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CHANGE_TECHNICAL_SUCCESS, data: changeTechnical };
                        }
                        else {
                            return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                        }
                    }));
                    return result;
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER, data: error };
                }
            }));
        });
        this.updateTotalAmount = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { service, serviceDevice, serviceDeviceHistory } = req.body;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        yield service_service_1.serviceService.updateTotalAmount(service, queryRunner);
                        yield servicedevice_service_1.servicedeviceService.updateEstimatedAmount(serviceDevice, queryRunner);
                        yield servicedevicehistory_service_1.servicedevicehistoryService.createDeviceHistory(serviceDeviceHistory, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATE_TOTAL_AMOUNT_SUCCESS };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.updatePauseService = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { service, servicePauseHistory } = req.body;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        yield service_service_1.serviceService.updatePauseService(service, queryRunner);
                        if (service.pause) {
                            yield servicePauseHistory_service_1.servicePauseHistoryService.createServicePauseHistory(servicePauseHistory, queryRunner);
                        }
                        else {
                            yield servicePauseHistory_service_1.servicePauseHistoryService.updateServicePauseHistory(servicePauseHistory, queryRunner);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATE_PAUSE_SERVICE_SUCCESS };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        /**
         * * Reseteamos todo los cambios tanto de aumentos,descuentos y devoluciones
         * @param req
         * @param res
         */
        this.resetAdjustments = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { serviceDevice, service, differences } = req.body;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        yield servicedevicehistory_service_1.servicedevicehistoryService.deleteDeviceHistory(serviceDevice.serviceDeviceId, queryRunner);
                        yield service_service_1.serviceService.updateTotalAmount(service, queryRunner);
                        yield servicedevice_service_1.servicedeviceService.updateEstimatedAmount(serviceDevice, queryRunner);
                        if (differences && differences.length > 0) {
                            yield Promise.all(differences.map(difference => difference_service_1.differenceService.deleteDifferenceByDevice(difference.differenceId, difference.serviceDeviceId, queryRunner)));
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.ROLLBACK_SUCCESS };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceController();
        return this.instance;
    }
    rollbackStatus() {
    }
    findServiceInProcess(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = req.query;
                const response = yield service_service_1.serviceService.findServiceInProcess(Number(campusId));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER
                });
            }
        });
    }
}
exports.serviceController = ServiceController.getInstance();
//# sourceMappingURL=service.controller.js.map