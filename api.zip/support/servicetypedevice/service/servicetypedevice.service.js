"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.servicetypedeviceService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class ServiceTypeDeviceService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ServiceTypeDeviceService();
        return this.instance;
    }
    createServiceTypeDevice(servicetypedevice, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const ServiceTypeDeviceEntity = modelslibrary_1.ServiceTypeDeviceModel.create(servicetypedevice);
                const response = yield queryRunner.manager.save(ServiceTypeDeviceEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteServiceTypeDevice(differences, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ServiceTypeDeviceModel, { serviceTypeDeviceId: differences.serviceTypeDeviceId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.servicetypedeviceService = ServiceTypeDeviceService.getInstance();
//# sourceMappingURL=servicetypedevice.service.js.map