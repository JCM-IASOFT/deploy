"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.differenceController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const message_api_1 = require("../../../common/constant/message.api");
const difference_service_1 = require("../service/difference.service");
const differencePayment_service_1 = require("../../differencePayment/service/differencePayment.service");
const service_service_1 = require("../../service/service/service.service");
const servicedevicehistory_service_1 = require("../../servicedevicehistory/service/servicedevicehistory.service");
class DifferenceController {
    constructor() {
        this.createDifference = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { service, difference, differencePayments, serviceDeviceHistory } = req.body;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const savedDifference = yield difference_service_1.differenceService.createDifference(difference, queryRunner);
                        yield servicedevicehistory_service_1.servicedevicehistoryService.createDeviceHistory(serviceDeviceHistory, queryRunner);
                        yield service_service_1.serviceService.updateTotalAmount(service, queryRunner);
                        const differencePaymentWithId = differencePayments.map(payment => (Object.assign(Object.assign({}, payment), { differenceId: savedDifference.differenceId })));
                        yield Promise.all(differencePaymentWithId.map(paymentd => differencePayment_service_1.differencePaymentService.createDifferencePayment(paymentd, queryRunner)));
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_SERVICE, data: savedDifference };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new DifferenceController();
        return this.instance;
    }
}
exports.differenceController = DifferenceController.getInstance();
//# sourceMappingURL=difference.controller.js.map