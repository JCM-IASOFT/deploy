"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.differenceService = void 0;
const save_error_1 = require("../../../common/handler/save.error");
const models_1 = require("models");
class DifferenceService {
    static getInstance() {
        if (!this.instance)
            this.instance = new DifferenceService();
        return this.instance;
    }
    findDifference() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const differences = yield models_1.DifferenceModel.find({ where: { deletedAt: '0' } });
                return differences;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                return error;
            }
        });
    }
    findDifferenceByService(serviceId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const differences = yield models_1.DifferenceModel.find({
                    where: {
                        deletedAt: '0',
                        serviceId
                    }
                });
                return differences;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                return [];
            }
        });
    }
    createDifference(difference, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const diferenceEntity = models_1.DifferenceModel.create(difference);
                const response = yield queryRunner.manager.save(diferenceEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    updateDifference(differences) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.DifferenceModel.update({ differenceId: differences.differenceId }, {
                    description: differences.description,
                    // amount: differences.amount,
                    //paymentTypeId: differences.paymentTypeId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    deleteDifference(differences, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.DifferenceModel, { serviceId: differences.serviceId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    deleteDifferenceByDevice(differenceId, serviceDeviceId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // const response = await queryRunner.manager.createQueryBuilder()
                //     .delete()
                //     .from(DifferenceModel)
                //     .where("serviceDeviceId = :serviceDeviceId", { serviceDeviceId })
                //     .execute();            
                const responseDelete = yield queryRunner.manager.delete(models_1.DifferencePaymentModel, { differenceId });
                let response = null;
                if (responseDelete) {
                    response = yield queryRunner.manager.delete(models_1.DifferenceModel, { serviceDeviceId });
                }
                //const response = await queryRunner.manager.delete(DifferenceModel, { serviceDeviceId })
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    deleteDifferenceTransaction(differences, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.delete(models_1.DifferenceModel, {
                    serviceId: differences.serviceId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    getErrorMessage(error) {
        return error instanceof Error ? error.message : 'Se produjo un error desconocido';
    }
}
exports.differenceService = DifferenceService.getInstance();
//# sourceMappingURL=difference.service.js.map