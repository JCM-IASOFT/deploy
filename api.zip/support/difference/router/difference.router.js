"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.differenceRoute = void 0;
const express_1 = require("express");
const difference_controller_1 = require("../controller/difference.controller");
exports.differenceRoute = (0, express_1.Router)();
exports.differenceRoute.post('/', difference_controller_1.differenceController.createDifference);
//# sourceMappingURL=difference.router.js.map