"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateLoginAuth = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../common/handler/validate.result");
exports.validateLoginAuth = [
    (0, express_validator_1.check)('email').exists().not().isEmpty(),
    (0, express_validator_1.check)('password').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=auth.validator.js.map