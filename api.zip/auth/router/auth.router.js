"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRoute = void 0;
const express_1 = require("express");
const auth_controller_1 = require("../controller/auth.controller");
const auth_validator_1 = require("../validator/auth.validator");
exports.authRoute = (0, express_1.Router)();
exports.authRoute.post('/', auth_validator_1.validateLoginAuth, auth_controller_1.authController.loginAuth);
exports.authRoute.post('/register', auth_controller_1.authController.registerAuth);
//# sourceMappingURL=auth.router.js.map