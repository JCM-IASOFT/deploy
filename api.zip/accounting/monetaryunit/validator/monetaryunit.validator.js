"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteMonetaryUnit = exports.validateUpdateMonetaryUnit = exports.validateCreateMonetaryUnit = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateMonetaryUnit = [
    (0, express_validator_1.check)('monetaryUnit').exists().not().isEmpty(),
    (0, express_validator_1.check)('denomination').exists().not().isEmpty(),
    (0, express_validator_1.check)('companyId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateMonetaryUnit = [
    (0, express_validator_1.check)('monetaryUnitId').exists().not().isEmpty(),
    (0, express_validator_1.check)('monetaryUnit').exists().not().isEmpty(),
    (0, express_validator_1.check)('denomination').exists().not().isEmpty(),
    (0, express_validator_1.check)('companyId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteMonetaryUnit = [
    (0, express_validator_1.check)('monetaryUnitId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=monetaryunit.validator.js.map