"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.monetaryunitService = void 0;
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
class MonetaryUnitService {
    static getInstance() {
        if (!this.instance)
            this.instance = new MonetaryUnitService();
        return this.instance;
    }
    findMonetaryUnit(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const monetaryunits = yield models_1.MonetaryUnitModel.find({
                    where: {
                        companyId: companyId,
                        deletedAt: '0',
                    },
                });
                return monetaryunits;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    createMonetaryUnit(monetaryunits) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.MonetaryUnitModel.save(monetaryunits);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateMonetaryUnit(monetaryunits) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.MonetaryUnitModel.update({ monetaryUnitId: monetaryunits.monetaryUnitId }, {
                    denomination: monetaryunits.denomination,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteMonetaryUnit(monetaryunits) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.MonetaryUnitModel.update({ monetaryUnitId: monetaryunits.monetaryUnitId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.monetaryunitService = MonetaryUnitService.getInstance();
//# sourceMappingURL=monetaryunit.service.js.map