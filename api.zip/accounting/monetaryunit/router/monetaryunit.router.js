"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.monetaryunitRoute = void 0;
const express_1 = require("express");
const monetaryunit_controller_1 = require("../controller/monetaryunit.controller");
const monetaryunit_validator_1 = require("../validator/monetaryunit.validator");
exports.monetaryunitRoute = (0, express_1.Router)();
exports.monetaryunitRoute.get('/', monetaryunit_controller_1.monetaryunitController.findMonetaryUnit);
exports.monetaryunitRoute.post('/', monetaryunit_validator_1.validateCreateMonetaryUnit, monetaryunit_controller_1.monetaryunitController.createMonetaryUnits);
exports.monetaryunitRoute.put('/', monetaryunit_validator_1.validateUpdateMonetaryUnit, monetaryunit_controller_1.monetaryunitController.updateMonetaryUnit);
exports.monetaryunitRoute.delete('/', monetaryunit_validator_1.validateDeleteMonetaryUnit, monetaryunit_controller_1.monetaryunitController.deleteMonetaryUnit);
//# sourceMappingURL=monetaryunit.router.js.map