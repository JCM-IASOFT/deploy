"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentTransactionService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const moment_1 = __importDefault(require("moment"));
class PaymentTransactionService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PaymentTransactionService();
        return this.instance;
    }
    findOnePayment(financeId, paymentTransactionId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = models_1.PaymentTransactionModel.findOne({
                    where: {
                        financeId: financeId,
                        paymentTransactionId: paymentTransactionId
                    }
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    findTodayPayments(campusId, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Obtener la fecha actual en el formato adecuado basado en la zona horaria
                const currentDate = (0, moment_1.default)().tz(timeZone).format("YYYY-MM-DD");
                // Consulta para obtener los pagos del día
                const services = yield models_1.PaymentTransactionModel.createQueryBuilder("paymentTransaction")
                    .innerJoinAndSelect("paymentTransaction.paymentType", "paymentType")
                    .select([
                    "paymentTransaction",
                    "paymentType"
                ])
                    .where("DATE(paymentTransaction.date) = :currentDate", { currentDate }) // Comparar la fecha del pago con la fecha actual
                    .andWhere("paymentTransaction.campusId = :campusId", { campusId }) // Comparar el campusId
                    .getMany(); // Obtener múltiples resultados si existen
                return services;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    createPaymentTransaction(paymenttransaction, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const paymentEntity = models_1.PaymentTransactionModel.create(paymenttransaction);
                const response = yield queryRunner.manager.save(paymentEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updatePaymentTransaction(paymentTransaction, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const paymentEntity = models_1.PaymentTransactionModel.create(paymentTransaction);
                const response = yield queryRunner.manager.update(models_1.PaymentTransactionModel, { paymentTransactionId: paymentEntity.paymentTransactionId }, {
                    amount: paymentTransaction.amount,
                    financeId: paymentTransaction.financeId,
                    paymentTypeId: paymentTransaction.paymentTypeId,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deletePaymentTransaction(paymentTransaction, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = queryRunner.manager.delete(models_1.PaymentTransactionModel, {
                    paymentTransactionId: paymentTransaction.paymentTransactionId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deletedPaymentTransactionForFinanceId(paymentTransaction, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.delete(models_1.PaymentTransactionModel, {
                    financeId: paymentTransaction.financeId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    getTotalPaymentTransaction(paymentType, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalTransaction = yield models_1.PaymentTransactionModel.createQueryBuilder('paymenttransaction')
                    .select('SUM(paymenttransaction.amount)', 'total')
                    .leftJoinAndSelect('paymenttransaction.paymentType', 'paymentType')
                    .leftJoinAndSelect('paymenttransaction.finance', 'transaction')
                    .where('paymentType.type = :type', { type: paymentType })
                    .andWhere('transaction.typeOperation = :typeOperation', { typeOperation: 'ingreso' })
                    .andWhere('paymenttransaction.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('paymenttransaction.campusId = :campusId', { campusId: campusId })
                    .groupBy('paymentType.paymentTypeId, transaction.financeId')
                    .getRawMany();
                const total = totalTransaction.reduce((total, value) => total + Number(value.total), 0);
                return Number(total) > 0 ? Number(total) : 0;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.paymentTransactionService = PaymentTransactionService.getInstance();
//# sourceMappingURL=paymentTransaction.service.js.map