"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentTransactionRoute = void 0;
const express_1 = require("express");
const paymentTransaction_controller_1 = require("../controller/paymentTransaction.controller");
exports.paymentTransactionRoute = (0, express_1.Router)();
exports.paymentTransactionRoute.get('/today', paymentTransaction_controller_1.paymentTransactionController.findTodayPayments);
//# sourceMappingURL=paymentTransaction.routes.js.map