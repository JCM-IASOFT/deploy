"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteCashBox = exports.validateUpdateCashBox = exports.validateCreateCashBox = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateCashBox = [
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (0, express_validator_1.check)('name').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateCashBox = [
    (0, express_validator_1.check)('cashBoxId').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (0, express_validator_1.check)('name').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteCashBox = [
    (0, express_validator_1.check)('cashBoxId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=cashbox.validator.js.map