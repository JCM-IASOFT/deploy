"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashboxdetailService = void 0;
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const terminal_service_1 = require("../../../sales/terminal/service/terminal.service");
class CashBoxDetailService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CashBoxDetailService();
        return this.instance;
    }
    findDataTableCashBoxDetail(page, sizePage, cashBoxDetail) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const cashBoxDetailBuilder = modelslibrary_1.CashBoxDetailModel.createQueryBuilder('cashBoxDetail')
                    .leftJoin('cashBoxDetail.cashBox', 'cashBox')
                    .leftJoin('cashBoxDetail.services', 'services')
                    .leftJoin('cashBoxDetail.cashTonnages', 'cashTonnages')
                    .leftJoin('services.payments', 'payments')
                    .leftJoin('payments.paymentType', 'paymentType')
                    .leftJoin('cashBoxDetail.finances', 'finances')
                    .leftJoin('finances.paymentTransaction', 'paymentTransaction')
                    .leftJoin('paymentTransaction.paymentType', 'paymentTypeT')
                    .where('cashBoxDetail.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('cashBox.campusId = :campusId', { campusId: cashBoxDetail.cashBox.campusId });
                if (cashBoxDetail.cashBoxId && cashBoxDetail.cashBoxId > 0) {
                    cashBoxDetailBuilder.andWhere('cashBoxDetail.cashBoxId = :cashBoxId', { cashBoxId: cashBoxDetail.cashBoxId });
                }
                if (cashBoxDetail.openingAmount && cashBoxDetail.openingAmount > 0) {
                    cashBoxDetailBuilder.andWhere("cashBoxDetail.openingAmount ILIKE :openingAmount", { openingAmount: `%${cashBoxDetail.openingAmount}%` });
                }
                if (cashBoxDetail.closingAmount && cashBoxDetail.closingAmount > 0) {
                    cashBoxDetailBuilder.andWhere('cashBoxDetail.closingAmount ILIKE :closingAmount', { closingAmount: `%${cashBoxDetail.closingAmount}%` });
                }
                if (cashBoxDetail.openingDate && cashBoxDetail.closeDate) {
                    cashBoxDetailBuilder.andWhere("cashBoxDetail.openingDate >= :openingDate", { openingDate: `${cashBoxDetail.openingDate}` });
                    cashBoxDetailBuilder.andWhere("cashBoxDetail.closeDate >= :closeDate", { closeDate: `${cashBoxDetail.closeDate}` });
                }
                cashBoxDetailBuilder.select([
                    'cashBoxDetail.cashBoxDetailId',
                    'cashBoxDetail.openingAmount',
                    'cashBoxDetail.closingAmount',
                    'cashBoxDetail.cashBalance',
                    'cashBoxDetail.leftoverBalance',
                    'cashBoxDetail.missingBalance',
                    'cashBoxDetail.openingDate',
                    'cashBoxDetail.isOpen',
                    'cashBoxDetail.cashRegister',
                    'cashBoxDetail.closeDate',
                    'services',
                    'cashTonnages',
                    'payments',
                    'paymentType',
                    'finances',
                    'cashBox',
                    'paymentTransaction',
                    'paymentTypeT',
                ]);
                const [cashBoxDetails, total] = yield cashBoxDetailBuilder.orderBy("cashBoxDetail.openingDate", "DESC")
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { cashBoxDetails, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findOneCashBoxDetail(cashBoxDetailId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const cashboxdetails = yield modelslibrary_1.CashBoxDetailModel.findOne({
                    where: {
                        cashBoxDetailId: cashBoxDetailId,
                        deletedAt: '0',
                    },
                    relations: ["cashBox", "services", "shift", "cashTonnages", "cashTonnages.cashTonnageDetails",
                        "cashTonnages.cashTonnageDetails.monetaryUnit", "services.payments", "services.payments.paymentType", "finances",
                        "finances.paymentTransaction", "finances.paymentTransaction.paymentType", "sales", "sales.paymentSales", "sales.paymentSales.paymentType"],
                    select: {
                        cashBoxDetailId: true,
                        cashBoxId: true,
                        openingAmount: true,
                        closingAmount: true,
                        cashBalance: true,
                        leftoverBalance: true,
                        missingBalance: true,
                        openingDate: true,
                        shift: {
                            shiftId: true,
                            acronym: true,
                            description: true,
                            startDate: true,
                            endDate: true,
                        },
                        // sales: {
                        //     salesId: true,
                        //     paymentSales: {
                        //         paymentSalesId: true,
                        //         amount: true,
                        //         paymentType: {
                        //             paymentTypeId: true,
                        //             description: true,
                        //             type: true
                        //         }
                        //     }
                        // },
                        cashBox: {
                            cashBoxId: true,
                            campusId: true,
                            name: true,
                        },
                        // services: {
                        //     serviceId: true,
                        //     payments: {
                        //         amount: true,
                        //         paymentType: {
                        //             description: true,
                        //             type: true
                        //         }
                        //     }
                        // },
                        // finances: {
                        //     financeId: true,
                        //     typeOperation: true,
                        //     attendant: true,
                        //     paymentTransaction: {
                        //         amount: true,
                        //         paymentType: {
                        //             description: true,
                        //             type: true
                        //         }
                        //     },
                        //     typeTransaction: {
                        //         typeTransactionId: true,
                        //         description: true,
                        //         typeTransaction: true,
                        //     }
                        // },
                        cashTonnages: {
                            cashTonnageId: true,
                            responsibleId: true,
                            cashBoxDetailId: true,
                            registrationDate: true,
                            cashTonnageDetails: {
                                cashTonnageDetailId: true,
                                monetaryUnitId: true,
                                cashTonnageId: true,
                                amount: true,
                                monetaryUnit: {
                                    monetaryUnitId: true,
                                    monetaryUnit: true,
                                    denomination: true,
                                    companyId: true,
                                }
                            }
                        },
                    }
                });
                return cashboxdetails;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    findCashBoxDetail(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const cashboxdetails = yield modelslibrary_1.CashBoxDetailModel.find({
                    where: {
                        cashBox: {
                            campusId: campusId
                        },
                        deletedAt: '0',
                    },
                    relations: ["cashBox", "services", "cashTonnages", "services.payments",
                        "services.payments.paymentType", "finances",
                        "finances.paymentTransaction", "finances.paymentTransaction.paymentType"],
                    // select: {
                    //     services: {
                    //         serviceId: true,
                    //         payments: {
                    //             amount: true,
                    //             paymentType: {
                    //                 description: true,
                    //                 type: true
                    //             }
                    //         }
                    //     },
                    //     finances: {
                    //         typeOperation: true,
                    //         attendant: true,
                    //         paymentTransaction: {
                    //             amount: true,
                    //             paymentType: {
                    //                 description: true,
                    //                 type: true
                    //             }
                    //         }
                    //     }
                    // },
                    order: {
                        openingDate: 'DESC'
                    }
                });
                return cashboxdetails;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    isTheBoxOpened(campusId, terminalId, openingDate, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const cashboxdetails = yield modelslibrary_1.CashBoxDetailModel
                    .createQueryBuilder("cash_box_detail")
                    .innerJoinAndSelect("cash_box_detail.cashBox", "cashBox")
                    .where("cashBox.campusId = :campusId", { campusId })
                    .andWhere("cash_box_detail.terminalId = :terminalId", { terminalId })
                    .andWhere("DATE(cash_box_detail.openingDate AT TIME ZONE :timeZone) = DATE(:openingDate AT TIME ZONE :timeZone)", { timeZone, openingDate })
                    .getMany();
                return cashboxdetails;
            }
            catch (error) {
                save_error_1.logger.error(`isTheBoxOpened by: ${(0, errormessage_handler_1.getErrorMessage)(error)}`);
                return [];
            }
        });
    }
    /**
     * Verifica cantidad de caja aperturado
     * @param campusId
     * @param terminalId
     * @param openingDate
     * @returns
     */
    checkCashBoxOpeningsCount(terminalId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const terminal = yield terminal_service_1.terminalService.findOneTerminal(terminalId);
                return terminal;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    createCashBoxDetail(cashboxdetails) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                save_error_1.logger.info(`createCashBoxDetail for (Fecha de apertura): ${cashboxdetails.openingDate}`);
                const response = yield modelslibrary_1.CashBoxDetailModel.save(cashboxdetails);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    /**
     * Cerrar caja chica
     * @param cashboxdetails
     */
    closePettyCash(cashboxdetails) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.CashBoxDetailModel.update({ cashBoxDetailId: cashboxdetails.cashBoxDetailId }, {
                    closingAmount: cashboxdetails.closingAmount,
                    cashBalance: cashboxdetails.cashBalance,
                    closeDate: cashboxdetails.closeDate,
                    leftoverBalance: cashboxdetails.leftoverBalance,
                    missingBalance: cashboxdetails.missingBalance,
                    isOpen: false
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateCashRegister(cashBoxDetailId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.CashBoxDetailModel, { cashBoxDetailId: cashBoxDetailId }, {
                    cashRegister: true
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteCashBoxDetail(cashboxdetails) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.CashBoxDetailModel.update({ cashBoxDetailId: cashboxdetails.cashBoxDetailId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.cashboxdetailService = CashBoxDetailService.getInstance();
//# sourceMappingURL=cashboxdetail.service.js.map