"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashboxdetailController = void 0;
const http_status_codes_1 = require("http-status-codes");
const cashboxdetail_service_1 = require("../service/cashboxdetail.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const cashBoxCode_constant_1 = require("../../../common/constant/cashBoxCode.constant");
class CashBoxDetailController {
    constructor() {
        this.findCashBoxDetailDataTable = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { page, sizePage, cashBoxDetail } = req.body;
                const findCashboxdetails = yield cashboxdetail_service_1.cashboxdetailService.findDataTableCashBoxDetail(page, sizePage, cashBoxDetail);
                const cashBoxDetails = findCashboxdetails ? findCashboxdetails.cashBoxDetails : [];
                const total = findCashboxdetails ? findCashboxdetails.total : 0;
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    data: cashBoxDetails,
                    draw: Math.random(),
                    recordsFiltered: cashBoxDetails.length,
                    recordsTotal: total
                });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
        this.findOneCashBoxDetail = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { cashBoxDetailId } = req.query;
            const cashboxdetails = yield cashboxdetail_service_1.cashboxdetailService.findOneCashBoxDetail(Number(cashBoxDetailId));
            res.status(http_status_codes_1.StatusCodes.OK).json(cashboxdetails);
        });
        this.findCashBoxDetail = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const cashboxdetails = yield cashboxdetail_service_1.cashboxdetailService.findCashBoxDetail(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(cashboxdetails);
        });
        this.isTheBoxOpened = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId, terminalId, openingDate, timeZone } = req.body;
                // ** Validación de parámetros
                if (!campusId || !terminalId || !openingDate || !timeZone) {
                    return res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json({
                        code: 400,
                        success: false,
                        message: "Missing required parameters"
                    });
                }
                // ** Verificar la cantidad permitida de aperturas
                const allowedAmount = yield cashboxdetail_service_1.cashboxdetailService.checkCashBoxOpeningsCount(terminalId);
                if (!allowedAmount) {
                    return res.status(http_status_codes_1.StatusCodes.OK).json({
                        code: cashBoxCode_constant_1.StatusCodesCashBox.NO_PERMISSION,
                        success: false,
                        message: message_api_1.MessageCustomApi.CONFIG_NOT_PERMISSION_OPEN
                    });
                }
                // ** Obtener cajas aperturadas del día
                const cashBoxDetails = yield cashboxdetail_service_1.cashboxdetailService.isTheBoxOpened(campusId, terminalId, openingDate, timeZone);
                // ** Filtrar cajas abiertas
                const openBoxes = cashBoxDetails.filter(p => p.isOpen);
                if (openBoxes.length === 1) {
                    return res.status(http_status_codes_1.StatusCodes.OK).json({
                        code: cashBoxCode_constant_1.StatusCodesCashBox.SUCCESS_OPEN_CASH_BOX,
                        success: true,
                        message: message_api_1.MessageCustomApi.SUCCESS_OPEN_CASH_BOX,
                        data: openBoxes[0]
                    });
                }
                // ** Si no hay cajas abiertas, verificar si se puede abrir una nueva caja
                if (openBoxes.length === 0 && cashBoxDetails.length <= allowedAmount.maxShift) {
                    return res.status(http_status_codes_1.StatusCodes.OK).json({
                        code: cashBoxCode_constant_1.StatusCodesCashBox.NEED_TO_OPEN_BOX,
                        success: false,
                        message: message_api_1.MessageCustomApi.NEED_TO_OPEN_BOX
                    });
                }
                // ** Caso en el que no se permite abrir más cajas
                return res.status(http_status_codes_1.StatusCodes.OK).json({
                    code: cashBoxCode_constant_1.StatusCodesCashBox.MAX_BOXES_OPENED,
                    success: false,
                    message: message_api_1.MessageCustomApi.CONFIG_NOT_PERMISSION_OPEN
                });
            }
            catch (error) {
                console.error('Error checking if the box is opened:', error);
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: 500,
                    success: false,
                    message: "An internal server error occurred"
                });
            }
        });
        this.checkCashBoxOpeningsCount = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { terminalId } = req.query;
            const cashboxdetails = yield cashboxdetail_service_1.cashboxdetailService.checkCashBoxOpeningsCount(terminalId);
            res.status(http_status_codes_1.StatusCodes.OK).json(cashboxdetails);
        });
        this.createCashBoxDetails = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield cashboxdetail_service_1.cashboxdetailService.createCashBoxDetail(req.body);
                if (response) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_DEVICE, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.closePettyCash = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const response = yield cashboxdetail_service_1.cashboxdetailService.closePettyCash(req.body);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_DEVICE, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.deleteCashBoxDetail = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield cashboxdetail_service_1.cashboxdetailService.deleteCashBoxDetail(req.body);
                if (response) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_DEVICE, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new CashBoxDetailController();
        return this.instance;
    }
}
exports.cashboxdetailController = CashBoxDetailController.getInstance();
//# sourceMappingURL=cashboxdetail.controller.js.map