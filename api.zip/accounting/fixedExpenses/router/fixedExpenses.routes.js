"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixedExpensesRoute = void 0;
const express_1 = require("express");
const fixedExpenses_1 = require("../controller/fixedExpenses");
exports.fixedExpensesRoute = (0, express_1.Router)();
exports.fixedExpensesRoute.get('/all', fixedExpenses_1.fixedExpensesController.findFixedExpenses);
exports.fixedExpensesRoute.get('/total', fixedExpenses_1.fixedExpensesController.getTotalFixedExpenses);
exports.fixedExpensesRoute.post('/create', fixedExpenses_1.fixedExpensesController.createFixedExpenses);
exports.fixedExpensesRoute.put('/update', fixedExpenses_1.fixedExpensesController.updateFixedExpenses);
exports.fixedExpensesRoute.put('/delete', fixedExpenses_1.fixedExpensesController.deleteFixedExpenses);
//# sourceMappingURL=fixedExpenses.routes.js.map