"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixedExpensesService = exports.FixedExpensesService = void 0;
const models_1 = require("models");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
class FixedExpensesService {
    static getInstance() {
        if (!this.instance)
            this.instance = new FixedExpensesService();
        return this.instance;
    }
    findFixedExpenses(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield models_1.FixedExpensesModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relations: {
                        fixedType: true
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findFixedExpensesRange(campusId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const queryBuilder = models_1.FixedExpensesModel.createQueryBuilder('fixed_expenses')
                    .where('fixed_expenses.campusId = :campusId', { campusId })
                    .andWhere('fixed_expenses.deletedAt = :deletedAt', { deletedAt: '0' });
                //.andWhere("DATE(fixed_expenses.date AT TIME ZONE 'UTC' AT TIME ZONE :zone) BETWEEN :start AND :end", { start: startDate, end: endDate, zone });
                const findResponse = yield queryBuilder.getMany();
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findOneFixedExpenses(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield models_1.FixedExpensesModel.findOne({
                    where: {
                        fixedExpensesId: id
                    },
                    relations: {
                        fixedType: true
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    getTotalFixedExpenses(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const fixedExpensesBuilder = models_1.FixedExpensesModel.createQueryBuilder('fixed_expenses')
                    .select("SUM(fixed_expenses.amount)", "totalSum")
                    .addSelect("SUM(fixed_expenses.dailyPayment)", "dailyPaymentSum")
                    .where('fixed_expenses.campusId = :campusId', { campusId })
                    .andWhere('fixed_expenses.deletedAt = :deletedAt', { deletedAt: '0' });
                const total = yield fixedExpensesBuilder.getRawOne();
                return total;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return { totalSum: 0, dailyPaymentSum: 0 };
            }
        });
    }
    createFixedExpenses(fixedExpenses, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const createResponse = models_1.FixedExpensesModel.create({
                    amount: fixedExpenses.amount,
                    campusId: fixedExpenses.campusId,
                    dailyPayment: fixedExpenses.dailyPayment,
                    date: fixedExpenses.date,
                    description: fixedExpenses.description,
                    fixedExpensesTypeId: fixedExpenses.fixedExpensesTypeId
                });
                return yield queryRunner.manager.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateFixedExpenses(fixedExpenses, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = yield queryRunner.manager.update(models_1.FixedExpensesModel, { fixedExpensesId: fixedExpenses.fixedExpensesId }, {
                    amount: fixedExpenses.amount,
                    campusId: fixedExpenses.campusId,
                    dailyPayment: fixedExpenses.dailyPayment,
                    description: fixedExpenses.description,
                    date: fixedExpenses.date,
                    fixedExpensesTypeId: fixedExpenses.fixedExpensesTypeId
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteFixedExpenses(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = yield models_1.FixedExpensesModel.update({ fixedExpensesId: id }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.FixedExpensesService = FixedExpensesService;
exports.fixedExpensesService = FixedExpensesService.getInstance();
//# sourceMappingURL=fixedExpenses.service.js.map