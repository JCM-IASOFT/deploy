"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixedExpensesController = exports.FixedExpensesController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const fixedExpenses_service_1 = require("../service/fixedExpenses.service");
const fixedExpensesHistory_service_1 = require("../../fixedExpensesHistory/service/fixedExpensesHistory.service");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const request_handler_1 = require("../../../common/handler/request.handler");
class FixedExpensesController {
    static getInstance() {
        if (!this.instance)
            this.instance = new FixedExpensesController();
        return this.instance;
    }
    findFixedExpenses(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const findResponse = yield fixedExpenses_service_1.fixedExpensesService.findFixedExpenses(Number(campusId));
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    getTotalFixedExpenses(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const findResponse = yield fixedExpenses_service_1.fixedExpensesService.getTotalFixedExpenses(Number(campusId));
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    createFixedExpenses(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { fixedExpenses, date } = request.body;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const createResponse = yield fixedExpenses_service_1.fixedExpensesService.createFixedExpenses(fixedExpenses, queryRunner);
                        if (!createResponse && createResponse.fixedExpensesId === 0)
                            throw new Error(message_api_1.MessageApi.ERROR_SERVER);
                        if (createResponse) {
                            yield fixedExpensesHistory_service_1.fixedExpensesHistoryService.createFixedHistoryExpenses({
                                amount: createResponse.amount,
                                dailyPayment: createResponse.dailyPayment,
                                fixedExpensesId: createResponse.fixedExpensesId,
                                date: date,
                                campusId: createResponse.campusId,
                            }, queryRunner);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_FIXED_EXPENSES, data: createResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    updateFixedExpenses(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { fixedExpenses, date } = request.body;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const findResponse = yield fixedExpenses_service_1.fixedExpensesService.findOneFixedExpenses(fixedExpenses.fixedExpensesId);
                        const updateResponse = yield fixedExpenses_service_1.fixedExpensesService.updateFixedExpenses(fixedExpenses, queryRunner);
                        if (!updateResponse || updateResponse.affected === 0) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        if (findResponse.amount !== fixedExpenses.amount) {
                            yield fixedExpensesHistory_service_1.fixedExpensesHistoryService.createFixedHistoryExpenses({
                                amount: fixedExpenses.amount,
                                dailyPayment: fixedExpenses.dailyPayment,
                                fixedExpensesId: fixedExpenses.fixedExpensesId,
                                date: date,
                                campusId: fixedExpenses.campusId,
                                deletedAt: fixedExpenses.deletedAt
                            }, queryRunner);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_FIXED_EXPENSES, data: updateResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    deleteFixedExpenses(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { id, date } = request.body;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const deleteResponse = yield fixedExpenses_service_1.fixedExpensesService.deleteFixedExpenses(Number(id));
                        if (!deleteResponse && deleteResponse.affected === 0) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        if (deleteResponse.affected > 0) {
                            const findOneResponse = yield fixedExpenses_service_1.fixedExpensesService.findOneFixedExpenses(Number(id));
                            yield fixedExpensesHistory_service_1.fixedExpensesHistoryService.createFixedHistoryExpenses({
                                amount: findOneResponse.amount,
                                dailyPayment: findOneResponse.dailyPayment,
                                fixedExpensesId: findOneResponse.fixedExpensesId,
                                date: date,
                                campusId: findOneResponse.campusId,
                                deletedAt: findOneResponse.deletedAt
                            }, queryRunner);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_FIXED_EXPENSES, data: deleteResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
}
exports.FixedExpensesController = FixedExpensesController;
exports.fixedExpensesController = FixedExpensesController.getInstance();
//# sourceMappingURL=fixedExpenses.js.map