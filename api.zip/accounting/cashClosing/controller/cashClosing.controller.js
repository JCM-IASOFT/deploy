"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashClosingController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const cashClosing_service_1 = require("../service/cashClosing.service");
class CashClosingController {
    constructor() {
        this.findCashClosing = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId, timeZone, startDate, endDate } = req.query;
            const cashClosings = yield cashClosing_service_1.cashClosingService.findCashClosing(campusId, timeZone, startDate, endDate);
            res.status(http_status_codes_1.StatusCodes.OK).json(cashClosings);
        });
        this.createCashClosings = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const { cashClosing, cashClosingDetails } = req.body;
                return yield cashClosing_service_1.cashClosingService.createCashClosingTrans(cashClosing, cashClosingDetails);
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new CashClosingController();
        return this.instance;
    }
}
exports.cashClosingController = CashClosingController.getInstance();
//# sourceMappingURL=cashClosing.controller.js.map