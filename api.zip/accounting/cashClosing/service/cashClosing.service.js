"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashClosingService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const cashClosing_service_1 = require("../../cashClosingDetail/service/cashClosing.service");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
class CashClosingService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CashClosingService();
        return this.instance;
    }
    findCashClosing(campusId, timeZone, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const cashClosings = yield modelslibrary_1.CashClosingModel.createQueryBuilder('cashClosing')
                    .leftJoinAndSelect('cashClosing.cashClosingDetails', 'cashClosingDetails')
                    .where('cashClosing.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere("DATE(cashClosing.openingDate AT TIME ZONE :timeZone) BETWEEN DATE(:startDate) AND DATE(:endDate)", { timeZone, startDate, endDate })
                    .andWhere('cashClosing.campusId = :campusId', { campusId })
                    .select([
                    'cashClosing',
                    'cashClosingDetails',
                ])
                    .orderBy('cashClosing.cashClosingId', 'DESC')
                    .getMany();
                return cashClosings;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createCashClosingTrans(cashClosing, cashClosingDetails) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                const savedCashClosing = yield this.createCashClosing(cashClosing, queryRunner);
                const updateCashClosingDetails = cashClosingDetails.map(detail => (Object.assign(Object.assign({}, detail), { cashClosingId: savedCashClosing.cashClosingId })));
                yield Promise.all(updateCashClosingDetails.map(detail => cashClosing_service_1.cashClosingDetailService.createCashClosingDetail(detail, queryRunner)));
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.SALES_SUCCESS, data: savedCashClosing };
            }));
            return result;
        });
    }
    createCashClosing(cashClosing, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _cashClosing = modelslibrary_1.CashClosingModel.create(cashClosing);
                return yield queryRunner.manager.save(_cashClosing);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.cashClosingService = CashClosingService.getInstance();
//# sourceMappingURL=cashClosing.service.js.map