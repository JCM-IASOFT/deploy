"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashClosingRoute = void 0;
const express_1 = require("express");
const cashClosing_controller_1 = require("../controller/cashClosing.controller");
const cashClosing_validator_1 = require("../validator/cashClosing.validator");
exports.cashClosingRoute = (0, express_1.Router)();
exports.cashClosingRoute.get('/', cashClosing_controller_1.cashClosingController.findCashClosing);
exports.cashClosingRoute.post('/', cashClosing_validator_1.validateCreateCashClosing, cashClosing_controller_1.cashClosingController.createCashClosings);
//# sourceMappingURL=cashClosing.router.js.map