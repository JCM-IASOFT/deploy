"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateCreateCashClosing = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateNumber = (0, express_validator_1.check)('cashClosing.number')
    .exists().withMessage('El número es requerido')
    .isInt().withMessage('El número debe ser un entero');
const validateCampusId = (0, express_validator_1.check)('cashClosing.campusId')
    .exists().withMessage('El campusId es requerido')
    .isInt().withMessage('El campusId debe ser numérico');
const validateUserId = (0, express_validator_1.check)('cashClosing.userId')
    .exists().withMessage('El userId es requerido')
    .isInt().withMessage('El userId debe ser numérico');
const validateOpeningDate = (0, express_validator_1.check)('cashClosing.openingDate')
    .exists().withMessage('La fecha de apertura es requerida')
    .isISO8601().withMessage('La fecha de apertura debe ser una fecha válida');
const validateCurrencyId = (0, express_validator_1.check)('cashClosing.currencyId')
    .exists().withMessage('El currencyId es requerido')
    .isInt().withMessage('El currencyId debe ser numérico');
const validateAmount = (0, express_validator_1.check)('cashClosing.amount')
    .exists().withMessage('El monto es requerido')
    .isDecimal().withMessage('El monto debe ser decimal');
exports.validateCreateCashClosing = [
    validateNumber,
    validateCampusId,
    validateUserId,
    validateOpeningDate,
    validateCurrencyId,
    validateAmount,
    handleValidationResult
];
//# sourceMappingURL=cashClosing.validator.js.map