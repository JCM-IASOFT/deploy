"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashWithdrawalsService = exports.CashWithdrawalsService = void 0;
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const paymenttransaction_service_1 = require("../../paymenttransaction/service/paymenttransaction.service");
const payment_service_1 = require("../../../support/payment/service/payment.service");
const paymentsales_service_1 = require("../../../sales/paymentsales/service/paymentsales.service");
class CashWithdrawalsService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CashWithdrawalsService();
        return this.instance;
    }
    findDataTableCashWithdrawals(page, sizePage, cashWithdrawals) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const cashWithdrawalsBuilder = modelslibrary_1.CashWithdrawalsModel.createQueryBuilder('cashWithdrawals')
                    .leftJoin('cashWithdrawals.authorizationManager', 'authorizationManager')
                    .leftJoin('cashWithdrawals.exitManager', 'exitManager')
                    .leftJoin('cashWithdrawals.cashBox', 'cashBox')
                    .where('cashWithdrawals.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('cashWithdrawals.campusId = :campusId', { campusId: cashWithdrawals.campusId });
                if (cashWithdrawals.cashBoxId && cashWithdrawals.cashBoxId > 0) {
                    cashWithdrawalsBuilder.andWhere('cashWithdrawals.cashBoxId = :cashBoxId', { cashBoxId: cashWithdrawals.cashBoxId });
                }
                if (cashWithdrawals.exitManagerId && cashWithdrawals.exitManagerId > 0) {
                    cashWithdrawalsBuilder.andWhere('cashWithdrawals.exitManagerId = :exitManagerId', { exitManagerId: cashWithdrawals.exitManagerId });
                }
                if (cashWithdrawals.description && cashWithdrawals.description !== "") {
                    cashWithdrawalsBuilder.andWhere("cashWithdrawals.description ILIKE :description", { description: `%${cashWithdrawals.description}%` });
                }
                if (cashWithdrawals.authorizationManagerId && cashWithdrawals.authorizationManagerId > 0) {
                    cashWithdrawalsBuilder.andWhere('cashWithdrawals.authorizationManagerId = :authorizationManagerId', { authorizationManagerId: cashWithdrawals.authorizationManagerId });
                }
                if (cashWithdrawals.amount && cashWithdrawals.amount > 0) {
                    cashWithdrawalsBuilder.andWhere("cashWithdrawals.amount = :amount", { amount: cashWithdrawals.amount });
                }
                cashWithdrawalsBuilder.select([
                    'cashWithdrawals.cashWithdrawalsId',
                    'cashWithdrawals.amount',
                    'cashWithdrawals.description',
                    'cashWithdrawals.authorizationManagerId',
                    'cashWithdrawals.exitManagerId',
                    'cashWithdrawals.cashBoxId',
                    'authorizationManager',
                    'cashBox',
                    'exitManager',
                ]);
                const [cashWithdrawal, total] = yield cashWithdrawalsBuilder.orderBy("cashWithdrawals.description", "ASC")
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { cashWithdrawal, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findCashWithdrawals(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield modelslibrary_1.CashWithdrawalsModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relations: {
                        authorizationManager: true,
                        exitManager: true,
                        cashBox: true
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findOneCashWithdrawals(campusId, cashWithdrawalsId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield modelslibrary_1.CashWithdrawalsModel.findOne({
                    where: {
                        cashWithdrawalsId: cashWithdrawalsId,
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relations: {
                        exitManager: true,
                        authorizationManager: true,
                        cashBox: true
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    getTotalCashWithdrawals(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const cashWithdrawalsBuilder = modelslibrary_1.CashWithdrawalsModel.createQueryBuilder('cashWithdrawals')
                    .select("SUM(cashWithdrawals.amount)", "totalSum")
                    .where('cashWithdrawals.campusId = :campusId', { campusId })
                    .andWhere('cashWithdrawals.deletedAt = :deletedAt', { deletedAt: '0' });
                const total = yield cashWithdrawalsBuilder.getRawOne();
                return total;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return 0;
            }
        });
    }
    createCashWithdrawals(cashWithdrawals) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const createResponse = modelslibrary_1.CashWithdrawalsModel.create({
                    amount: cashWithdrawals.amount,
                    campusId: cashWithdrawals.campusId,
                    description: cashWithdrawals.description,
                    cashBoxId: cashWithdrawals.cashBoxId,
                    authorizationManagerId: cashWithdrawals.authorizationManagerId,
                    exitManagerId: cashWithdrawals.exitManagerId
                });
                return yield modelslibrary_1.CashWithdrawalsModel.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateCashWithdrawals(cashWithdrawals) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = yield modelslibrary_1.CashWithdrawalsModel.update({ cashWithdrawalsId: cashWithdrawals.cashWithdrawalsId }, {
                    amount: cashWithdrawals.amount,
                    campusId: cashWithdrawals.campusId,
                    description: cashWithdrawals.description,
                    cashBoxId: cashWithdrawals.cashBoxId,
                    authorizationManagerId: cashWithdrawals.authorizationManagerId,
                    exitManagerId: cashWithdrawals.exitManagerId
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteCashWithdrawals(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = yield modelslibrary_1.CashWithdrawalsModel.update({ cashWithdrawalsId: id }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    getTotalsPaymentInCash(paymentType, campusId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalService = yield payment_service_1.paymentService.getTotalPaymentService(paymentType, campusId);
                const totalTransaction = yield paymenttransaction_service_1.paymenttransactionService.getTotalPaymentTransaction(paymentType, campusId);
                const totalSales = yield paymentsales_service_1.paymentsalesService.getTotalPaymentSales(paymentType, campusId, queryRunner);
                const total = totalTransaction + totalService + totalSales;
                return total;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.CashWithdrawalsService = CashWithdrawalsService;
exports.cashWithdrawalsService = CashWithdrawalsService.getInstance();
//# sourceMappingURL=cashWithdrawals.service.js.map