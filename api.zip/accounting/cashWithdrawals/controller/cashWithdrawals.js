"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashWithdrawalsController = exports.CashWithdrawalsController = void 0;
const http_status_codes_1 = require("http-status-codes");
const cashWithdrawals_service_1 = require("../service/cashWithdrawals.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const paymentType_service_1 = require("../../../company/paymenttype/service/paymentType.service");
class CashWithdrawalsController {
    static getInstance() {
        if (!this.instance)
            this.instance = new CashWithdrawalsController();
        return this.instance;
    }
    findCashWithdrawalsDataTable(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { page, sizePage, cashWithdrawals } = request.body;
                const findDataTableResponse = yield cashWithdrawals_service_1.cashWithdrawalsService.findDataTableCashWithdrawals(page, sizePage, cashWithdrawals);
                const cashWithdrawal = findDataTableResponse ? findDataTableResponse.cashWithdrawal : [];
                const total = findDataTableResponse ? findDataTableResponse.total : 0;
                response.status(http_status_codes_1.StatusCodes.OK).json({
                    data: cashWithdrawal,
                    draw: Math.random(),
                    recordsFiltered: cashWithdrawal.length,
                    recordsTotal: total,
                });
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findCashWithdrawals(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const findResponse = yield cashWithdrawals_service_1.cashWithdrawalsService.findCashWithdrawals(Number(campusId));
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    getTotalCashWithdrawals(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const findResponse = yield cashWithdrawals_service_1.cashWithdrawalsService.getTotalCashWithdrawals(Number(campusId));
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findOneCashWithdrawals(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { cashWithdrawalsId, campusId } = request.query;
                const findOneResponse = yield cashWithdrawals_service_1.cashWithdrawalsService.findOneCashWithdrawals(Number(campusId), Number(cashWithdrawalsId));
                response.status(http_status_codes_1.StatusCodes.OK).json(findOneResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    createCashWithdrawals(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { cashWithdrawals } = request.body;
                    const createResponse = yield cashWithdrawals_service_1.cashWithdrawalsService.createCashWithdrawals(cashWithdrawals);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_CASH_WITHDRAWALS, data: createResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    updateCashWithdrawals(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { cashWithdrawals } = request.body;
                    const updateResponse = yield cashWithdrawals_service_1.cashWithdrawalsService.updateCashWithdrawals(cashWithdrawals);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_CASH_WITHDRAWALS, data: updateResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    deleteCashWithdrawals(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { id } = request.params;
                    const deleteResponse = yield cashWithdrawals_service_1.cashWithdrawalsService.deleteCashWithdrawals(Number(id));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_CASH_WITHDRAWALS, data: deleteResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    getTotalsPaymentInCash(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { campusId, type } = request.query;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const paymentType = yield paymentType_service_1.paymenttypeService.findOnePaymentTypeByType(type);
                        if (!paymentType) {
                            throw new Error(message_api_1.MessageApi.NOT_CONTENT);
                        }
                        const getResponse = yield cashWithdrawals_service_1.cashWithdrawalsService.getTotalsPaymentInCash(paymentType.type, Number(campusId), queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.GET_SUCCESS_PAYMENTS_CASH, data: getResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
}
exports.CashWithdrawalsController = CashWithdrawalsController;
exports.cashWithdrawalsController = CashWithdrawalsController.getInstance();
//# sourceMappingURL=cashWithdrawals.js.map