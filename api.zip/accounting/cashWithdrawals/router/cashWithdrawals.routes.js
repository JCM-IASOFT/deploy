"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashWithdrawalsRoute = void 0;
const express_1 = require("express");
const cashWithdrawals_1 = require("../controller/cashWithdrawals");
exports.cashWithdrawalsRoute = (0, express_1.Router)();
exports.cashWithdrawalsRoute.get('/all', cashWithdrawals_1.cashWithdrawalsController.findCashWithdrawals);
exports.cashWithdrawalsRoute.post('/dataTable', cashWithdrawals_1.cashWithdrawalsController.findCashWithdrawalsDataTable);
exports.cashWithdrawalsRoute.get('/one', cashWithdrawals_1.cashWithdrawalsController.findOneCashWithdrawals);
exports.cashWithdrawalsRoute.get('/total', cashWithdrawals_1.cashWithdrawalsController.getTotalCashWithdrawals);
exports.cashWithdrawalsRoute.post('/create', cashWithdrawals_1.cashWithdrawalsController.createCashWithdrawals);
exports.cashWithdrawalsRoute.put('/update', cashWithdrawals_1.cashWithdrawalsController.updateCashWithdrawals);
exports.cashWithdrawalsRoute.put('/delete/:id', cashWithdrawals_1.cashWithdrawalsController.deleteCashWithdrawals);
exports.cashWithdrawalsRoute.get('/getTotal', cashWithdrawals_1.cashWithdrawalsController.getTotalsPaymentInCash);
//# sourceMappingURL=cashWithdrawals.routes.js.map