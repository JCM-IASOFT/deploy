"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashtonnageRoute = void 0;
const express_1 = require("express");
const cashtonnage_controller_1 = require("../controller/cashtonnage.controller");
const cashtonnage_validator_1 = require("../validator/cashtonnage.validator");
exports.cashtonnageRoute = (0, express_1.Router)();
exports.cashtonnageRoute.get('/', cashtonnage_controller_1.cashtonnageController.findCashTonnage);
exports.cashtonnageRoute.post('/', cashtonnage_validator_1.validateCreateCashTonnage, cashtonnage_controller_1.cashtonnageController.createCashTonnages);
//# sourceMappingURL=cashtonnage.router.js.map