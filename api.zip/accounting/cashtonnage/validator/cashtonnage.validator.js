"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateCreateCashTonnage = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateCashTonnage = [
    (0, express_validator_1.check)('cashtonnage.responsibleId').exists().not().isEmpty(),
    (0, express_validator_1.check)('cashtonnage.cashBoxDetailId').exists().not().isEmpty(),
    (0, express_validator_1.check)('cashtonnage.registrationDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('cashtonnagedetails.*.monetaryUnitId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('cashtonnagedetails.*.cashTonnageId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('cashtonnagedetails.*.amount').exists().isNumeric().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=cashtonnage.validator.js.map