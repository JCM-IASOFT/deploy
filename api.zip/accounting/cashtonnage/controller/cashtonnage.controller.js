"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashtonnageController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const cashtonnage_service_1 = require("../service/cashtonnage.service");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const cashtonnagedetail_service_1 = require("../../cashtonnagedetail/service/cashtonnagedetail.service");
const cashboxdetail_service_1 = require("../../cashboxdetail/service/cashboxdetail.service");
class CashTonnageController {
    constructor() {
        this.findCashTonnage = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId } = req.query;
            const cashtonnages = yield cashtonnage_service_1.cashtonnageService.findCashTonnage(Number(companyId));
            res.status(http_status_codes_1.StatusCodes.OK).json(cashtonnages);
        });
        this.createCashTonnages = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { cashtonnage, cashtonnagedetails } = req.body;
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const savedCashTonnage = yield cashtonnage_service_1.cashtonnageService.createCashTonnage(cashtonnage, queryRunner);
                        yield cashboxdetail_service_1.cashboxdetailService.updateCashRegister(cashtonnage.cashBoxDetailId, queryRunner);
                        const cashtonnagedetailWithTonnageId = cashtonnagedetails.map((cashtonnagedetail) => (Object.assign(Object.assign({}, cashtonnagedetail), { cashTonnageId: savedCashTonnage.cashTonnageId })));
                        yield Promise.all(cashtonnagedetailWithTonnageId.map((difference) => cashtonnagedetail_service_1.cashtonnagedetailService.createCashTonnageDetail(difference, queryRunner)));
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.END_SUCCESS_SERVICE };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new CashTonnageController();
        return this.instance;
    }
}
exports.cashtonnageController = CashTonnageController.getInstance();
//# sourceMappingURL=cashtonnage.controller.js.map