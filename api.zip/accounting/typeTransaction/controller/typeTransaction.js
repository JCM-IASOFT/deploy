"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeTransactioncontroller = void 0;
const typeTransaction_service_1 = require("../service/typeTransaction.service");
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
class TypeTransactionController {
    static getInstance() {
        if (!this.instance)
            this.instance = new TypeTransactionController();
        return this.instance;
    }
    findTypeTransaction(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            const { campusId } = request.query;
            const typeTransaction = yield typeTransaction_service_1.typeTransactionService.findTypeTransaction(Number(campusId));
            response.status(http_status_codes_1.StatusCodes.OK).json(typeTransaction);
        });
    }
    findAllTypeTransaction(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            const { campusId } = request.params;
            const typeTransaction = yield typeTransaction_service_1.typeTransactionService.findAllTypeTransaction(Number(campusId));
            response.status(http_status_codes_1.StatusCodes.OK).json({
                data: typeTransaction,
                draw: Math.random(),
                recordsFiltered: typeTransaction.length,
                recordsTotal: typeTransaction.length,
            });
        });
    }
    createTypeTransaction(request, response) {
        (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
            const { description: description, typeTransaction: typeTransaction, campusId: campusId } = request.body;
            const typeTransactionResponse = yield typeTransaction_service_1.typeTransactionService.createTypeTransaction({ description: description, campusId: campusId, typeTransaction: typeTransaction });
            return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_TYPETRANSACTION, data: typeTransactionResponse };
        }));
    }
    updateTypeTransaction(request, response) {
        (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
            const { transactionType } = request.body;
            const typeTransactionResponse = yield typeTransaction_service_1.typeTransactionService.updateTypeTransaction(request.body);
            return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_TYPETRANSACTION, data: typeTransactionResponse };
        }));
    }
    deleteTypeTransaction(request, response) {
        (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
            const { transactionType } = request.body;
            const typeTransactionResponse = yield typeTransaction_service_1.typeTransactionService.deleteTypeTransaction(request.body);
            return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_TYPETRANSACTION, data: typeTransactionResponse };
        }));
    }
}
exports.typeTransactioncontroller = TypeTransactionController.getInstance();
//# sourceMappingURL=typeTransaction.js.map