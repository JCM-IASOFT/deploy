"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.financeController = void 0;
const finance_service_1 = require("../service/finance.service");
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const paymenttransaction_service_1 = require("../../paymenttransaction/service/paymenttransaction.service");
class FinanceController {
    static getInstance() {
        if (!this.instance)
            this.instance = new FinanceController();
        return this.instance;
    }
    findTransaction(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { transactionFilter, page, sizePage } = request.body;
                const findTransaction = yield finance_service_1.financeService.findTransaction(transactionFilter, page, sizePage);
                const transactions = findTransaction ? findTransaction.transactions : [];
                const total = findTransaction ? findTransaction.total : 0;
                response.status(http_status_codes_1.StatusCodes.OK).json({
                    data: transactions,
                    draw: Math.random(),
                    recordsFiltered: transactions.length,
                    recordsTotal: total,
                });
            }
            catch (err) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: err
                });
            }
        });
    }
    getTotalTransaction(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId, typeOperation } = request.query;
                const transactionTotal = yield finance_service_1.financeService.getTotalTransaction(Number(campusId), typeOperation.toString());
                response.status(http_status_codes_1.StatusCodes.OK).json(transactionTotal);
            }
            catch (err) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: 0
                });
            }
        });
    }
    findOneTransaction(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { financeId, campusId, } = request.query;
                const transactionOne = yield finance_service_1.financeService.findOneTransaction(Number(financeId), Number(campusId));
                response.status(http_status_codes_1.StatusCodes.OK).json(transactionOne);
            }
            catch (err) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: err
                });
            }
        });
    }
    findTransactionId(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { search, campusId } = request.query;
                const transactionId = yield finance_service_1.financeService.findTransactionId(search.toString(), Number(campusId));
                response.status(http_status_codes_1.StatusCodes.OK).json(transactionId);
            }
            catch (err) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: err
                });
            }
        });
    }
    createTransaction(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { transaction, paymentTransaction } = request.body;
                    if (!transaction || !Array.isArray(paymentTransaction)) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const savedTransaccion = yield finance_service_1.financeService.createTransaction(transaction, queryRunner);
                        if (!savedTransaccion && savedTransaccion.cashBoxDetailId === 0) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        const paymentTransactionsFinanceId = paymentTransaction.map(payment => (Object.assign(Object.assign({}, payment), { financeId: savedTransaccion.financeId })));
                        const savedPaymentTransactions = yield Promise.all(paymentTransactionsFinanceId.map(payment => paymenttransaction_service_1.paymenttransactionService.createPaymentTransaction(payment, queryRunner)));
                        if (!savedPaymentTransactions) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_TRANSACTION, data: savedTransaccion };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
    }
    updateTransaction(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { transaction, paymentTransaction } = request.body;
                    if (!transaction || !Array.isArray(paymentTransaction)) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const savedTransaccion = yield finance_service_1.financeService.updateTransaction(transaction, queryRunner);
                        if (!savedTransaccion && savedTransaccion.affected === 0) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        const deletedPaymentTransaction = yield paymenttransaction_service_1.paymenttransactionService.deletedPaymentTransactionForFinanceId({ financeId: transaction.financeId }, queryRunner);
                        const paymentTransactionsFinanceId = paymentTransaction.map(payment => (Object.assign(Object.assign({}, payment), { financeId: transaction.financeId })));
                        const savedPaymentTransactionsPromises = paymentTransactionsFinanceId.map((payment) => __awaiter(this, void 0, void 0, function* () {
                            return paymenttransaction_service_1.paymenttransactionService.createPaymentTransaction(payment, queryRunner);
                        }));
                        const savedPaymentTransactions = yield Promise.all(savedPaymentTransactionsPromises);
                        if (!savedPaymentTransactions || !deletedPaymentTransaction) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_TRANSACTION };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
    }
    deleteTransaction(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            const { id } = request.params;
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const responseTransaction = yield finance_service_1.financeService.deleteTransaction(parseInt(id));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_TRANSACTION, data: responseTransaction };
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
    }
}
exports.financeController = FinanceController.getInstance();
//# sourceMappingURL=finance.controller.js.map