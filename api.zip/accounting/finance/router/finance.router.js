"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.financeRoute = void 0;
const express_1 = require("express");
const finance_controller_1 = require("../controller/finance.controller");
exports.financeRoute = (0, express_1.Router)();
exports.financeRoute.post('/all', finance_controller_1.financeController.findTransaction);
exports.financeRoute.post('/add', finance_controller_1.financeController.createTransaction);
exports.financeRoute.get('/one', finance_controller_1.financeController.findOneTransaction);
exports.financeRoute.get('/total', finance_controller_1.financeController.getTotalTransaction);
exports.financeRoute.put('/edit', finance_controller_1.financeController.updateTransaction);
exports.financeRoute.delete('/delete/:id', finance_controller_1.financeController.deleteTransaction);
//# sourceMappingURL=finance.router.js.map