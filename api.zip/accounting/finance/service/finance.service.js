"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.financeService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class FinanceService {
    static getInstance() {
        if (!this.instance)
            this.instance = new FinanceService();
        return this.instance;
    }
    getTotalTransaction(campusId, typeOperation) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const transactionQueryBuilder = models_1.FinanceModel.createQueryBuilder("transaction")
                    .leftJoinAndSelect("transaction.paymentTransaction", "paymentTransaction")
                    .select("SUM(paymentTransaction.amount)", "totalSum")
                    .where("transaction.campusId = :campusId", { campusId: campusId })
                    .andWhere("transaction.deletedAt = :deletedAt", { deletedAt: '0' })
                    .andWhere("transaction.typeOperation = :typeOperation", { typeOperation: typeOperation });
                const totalSum = yield transactionQueryBuilder.getRawOne();
                return totalSum;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return 0;
            }
        });
    }
    findTransactionId(search, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const transactionRepository = models_1.AppDataSource.getRepository(models_1.FinanceModel);
                const transaction = yield transactionRepository
                    .createQueryBuilder('transaction')
                    .leftJoinAndSelect("transaction.paymentTransaction", "paymentTransaction")
                    .leftJoinAndSelect("paymentTransaction.paymentType", "paymentType")
                    .leftJoinAndSelect("transaction.typeTransaction", "typeTransaction")
                    .leftJoinAndSelect("transaction.user", "user")
                    .orderBy("transaction.financeId", "ASC")
                    .where("transaction.campusId = :campusId", { campusId: campusId })
                    .andWhere('cast(transaction.financeId as varchar) ILIKE :search', { search: `%${search}%` })
                    .andWhere("transaction.deletedAt = :deletedAt", { deletedAt: '0' })
                    .getMany();
                return transaction;
            }
            catch (error) {
            }
        });
    }
    findAllTransaction(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.FinanceModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relationLoadStrategy: 'join',
                    relations: {
                        user: true,
                        paymentTransaction: {
                            paymentType: true
                        },
                        typeTransaction: true
                    }
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findTransactionDatatable(transactionFilter, page, sizePage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const transactionQueryBuilder = models_1.FinanceModel.createQueryBuilder("transaction")
                    .where("transaction.campusId = :campusId", { campusId: transactionFilter.campusId })
                    .andWhere("transaction.deletedAt = :deletedAt", { deletedAt: '0' });
                if (transactionFilter.startDate && transactionFilter.endDate) {
                    transactionQueryBuilder.andWhere("DATE(transaction.deliverDate) BETWEEN :startDate AND :endDate", { startDate: transactionFilter.startDate, endDate: transactionFilter.endDate });
                }
                if (transactionFilter.typeOperation && transactionFilter.typeOperation !== '') {
                    transactionQueryBuilder.andWhere("transaction.typeOperation = :typeOperation", { typeOperation: transactionFilter.typeOperation });
                }
                if (transactionFilter.typeTransaction && transactionFilter.typeTransaction !== '') {
                    transactionQueryBuilder.andWhere("typeTransaction.description = :typeTransaction", { typeTransaction: transactionFilter.typeTransaction });
                }
                if (transactionFilter.financeId && transactionFilter.financeId > 0) {
                    transactionQueryBuilder.andWhere("transaction.financeId = :financeId", { financeId: transactionFilter.financeId });
                }
                if (transactionFilter.user && transactionFilter.user !== '') {
                    transactionQueryBuilder.andWhere("user.name = :attendant", { attendant: transactionFilter.user });
                }
                if (transactionFilter.like) {
                    transactionQueryBuilder.andWhere(builder => {
                        builder.where("typeTransaction.description LIKE :typeTransaction", { typeTransaction: `%${transactionFilter.like}%` })
                            .orWhere("cast(transaction.typeOperation as text) LIKE :typeOperation", { typeOperation: `%${transactionFilter.like}%` })
                            .orWhere("user.name LIKE :attendant", { attendant: `%${transactionFilter.like}%` });
                    });
                }
                transactionQueryBuilder.leftJoinAndSelect("transaction.paymentTransaction", "paymentTransaction")
                    .leftJoinAndSelect("paymentTransaction.paymentType", "paymentType")
                    .leftJoinAndSelect("transaction.typeTransaction", "typeTransaction")
                    .leftJoinAndSelect("transaction.user", "user");
                const [transactions, total] = yield transactionQueryBuilder.orderBy("transaction.financeId", "DESC")
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { transactions, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findOneTransaction(financeId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const transactionOne = yield models_1.FinanceModel.findOne({
                    where: {
                        financeId: financeId,
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relations: {
                        paymentTransaction: true,
                        typeTransaction: true,
                        user: true
                    },
                });
                return transactionOne;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createTransaction(finance, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const financeEntity = models_1.FinanceModel.create(finance);
                return yield queryRunner.manager.save(financeEntity);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateTransaction(transaction, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.FinanceModel, { financeId: transaction.financeId }, {
                    typeOperation: transaction.typeOperation,
                    details: transaction.details,
                    attendant: transaction.attendant,
                    deliverDate: transaction.deliverDate,
                    typeTransactionId: transaction.typeTransactionId,
                    campusId: transaction.campusId,
                    cashClosingId: transaction.cashClosingId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteTransaction(financeId) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield models_1.FinanceModel.update({ financeId: financeId }, { deletedAt: '1' });
            return response;
        });
    }
}
exports.financeService = FinanceService.getInstance();
//# sourceMappingURL=finance.service.js.map