"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixedExpensesHistoryRoute = void 0;
const express_1 = require("express");
const fixedExpensesHistory_1 = require("../controller/fixedExpensesHistory");
exports.fixedExpensesHistoryRoute = (0, express_1.Router)();
exports.fixedExpensesHistoryRoute.get('/all', fixedExpensesHistory_1.fixedExpensesHistoryController.findFixedExpensesHistory);
exports.fixedExpensesHistoryRoute.post('/create', fixedExpensesHistory_1.fixedExpensesHistoryController.createFixedExpensesHistory);
exports.fixedExpensesHistoryRoute.put('/update', fixedExpensesHistory_1.fixedExpensesHistoryController.updateFixedExpensesHistory);
exports.fixedExpensesHistoryRoute.put('/delete', fixedExpensesHistory_1.fixedExpensesHistoryController.deleteFixedExpensesHistory);
//# sourceMappingURL=fixedExpensesHistory.routes.js.map