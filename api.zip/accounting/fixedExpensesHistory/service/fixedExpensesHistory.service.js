"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixedExpensesHistoryService = exports.FixedExpensesHistoryService = void 0;
const models_1 = require("models");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
class FixedExpensesHistoryService {
    static getInstance() {
        if (!this.instance)
            this.instance = new FixedExpensesHistoryService();
        return this.instance;
    }
    findFixedHistoryExpenses(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield models_1.FixedExpensesHistoryModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relations: {
                        fixedExpenses: true
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findOneFixedHistoryExpenses(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findOneResponse = yield models_1.FixedExpensesHistoryModel.findOne({
                    where: {
                        fixedExpensesHistoryId: id
                    },
                    relations: {
                        fixedExpenses: true
                    }
                });
                return findOneResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createFixedHistoryExpenses(fixedExpensesHistory, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const maxFixedExpensesIdResult = yield models_1.FixedExpensesHistoryModel
                    .createQueryBuilder("fixed_expenses_history")
                    .select("MAX(fixed_expenses_history.fixedExpensesId)", "max")
                    .where("fixed_expenses_history.fixedExpensesId = :fixedExpensesId", { fixedExpensesId: fixedExpensesHistory.fixedExpensesId })
                    .andWhere("fixed_expenses_history.amount != :amount", { amount: fixedExpensesHistory.amount })
                    .getRawOne();
                if (maxFixedExpensesIdResult !== null) {
                }
                const createResponse = models_1.FixedExpensesHistoryModel.create({
                    amount: fixedExpensesHistory.amount,
                    campusId: fixedExpensesHistory.campusId,
                    date: fixedExpensesHistory.date,
                    dailyPayment: fixedExpensesHistory.dailyPayment,
                    fixedExpensesId: fixedExpensesHistory.fixedExpensesId
                });
                return yield queryRunner.manager.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateFixedHistoryExpenses(fixedExpensesHistory, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = yield queryRunner.manager.update(models_1.FixedExpensesHistoryModel, { fixedExpensesHistoryId: fixedExpensesHistory.fixedExpensesHistoryId }, {
                    amount: fixedExpensesHistory.amount,
                    campusId: fixedExpensesHistory.campusId,
                    dailyPayment: fixedExpensesHistory.dailyPayment,
                    date: fixedExpensesHistory.date,
                    fixedExpensesId: fixedExpensesHistory.fixedExpensesId
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteFixedHistoryExpenses(id, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = yield queryRunner.manager.update(models_1.FixedExpensesHistoryModel, { id: id }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.FixedExpensesHistoryService = FixedExpensesHistoryService;
exports.fixedExpensesHistoryService = FixedExpensesHistoryService.getInstance();
//# sourceMappingURL=fixedExpensesHistory.service.js.map