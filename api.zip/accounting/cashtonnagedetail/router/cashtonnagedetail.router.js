"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cashtonnagedetailRoute = void 0;
const express_1 = require("express");
const cashtonnagedetail_controller_1 = require("../controller/cashtonnagedetail.controller");
exports.cashtonnagedetailRoute = (0, express_1.Router)();
exports.cashtonnagedetailRoute.get('/', cashtonnagedetail_controller_1.cashtonnagedetailController.findCashTonnageDetail);
//# sourceMappingURL=cashtonnagedetail.router.js.map