"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixedExpensesTypeRoute = void 0;
const express_1 = require("express");
const fixedExpensesType_1 = require("../controller/fixedExpensesType");
exports.fixedExpensesTypeRoute = (0, express_1.Router)();
exports.fixedExpensesTypeRoute.get('/all', fixedExpensesType_1.fixedExpensesTypeController.findFixedExpensesType);
exports.fixedExpensesTypeRoute.post('/create', fixedExpensesType_1.fixedExpensesTypeController.createFixedExpensesType);
exports.fixedExpensesTypeRoute.put('/update', fixedExpensesType_1.fixedExpensesTypeController.updateFixedExpensesType);
exports.fixedExpensesTypeRoute.put('/delete/:id', fixedExpensesType_1.fixedExpensesTypeController.deleteFixedExpensesType);
//# sourceMappingURL=fixedExpensesType.routes.js.map