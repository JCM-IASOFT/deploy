"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixedExpensesTypeService = exports.FixedExpensesTypeService = void 0;
const models_1 = require("models");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
class FixedExpensesTypeService {
    static getInstance() {
        if (!this.instance)
            this.instance = new FixedExpensesTypeService();
        return this.instance;
    }
    findFixedExpensesType(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield models_1.FixedExpensesTypeModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createFixedExpensesType(fixedExpensesType) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const createResponse = models_1.FixedExpensesTypeModel.create({
                    campusId: fixedExpensesType.campusId,
                    description: fixedExpensesType.description
                });
                return yield models_1.FixedExpensesTypeModel.save(createResponse);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateFixedExpensesType(fixedExpensesType) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updateResponse = yield models_1.FixedExpensesTypeModel.update({ fixedExpensesTypeId: fixedExpensesType.fixedExpensesTypeId }, {
                    campusId: fixedExpensesType.campusId,
                    description: fixedExpensesType.description
                });
                return updateResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteFixedExpensesType(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = yield models_1.FixedExpensesTypeModel.update({ fixedExpensesTypeId: id }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.FixedExpensesTypeService = FixedExpensesTypeService;
exports.fixedExpensesTypeService = FixedExpensesTypeService.getInstance();
//# sourceMappingURL=fixedExpensesType.service.js.map