"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.membershipPaymentController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const membershipPayment_service_1 = require("../service/membershipPayment.service");
class MembershipPaymentController {
    constructor() {
        this.findMembershipPayment = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId } = req.query;
            const membershipPayments = yield membershipPayment_service_1.membershipPaymentService.findMembershipPayment(Number(companyId));
            res.status(http_status_codes_1.StatusCodes.OK).json(membershipPayments);
        });
        this.createMembershipPayments = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield membershipPayment_service_1.membershipPaymentService.createMembershipPayment(req.body);
                if (response) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_BRAND, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.updateMembershipPayment = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const membershipPaymentId = req.params.membershipPaymentId;
                    const membershipPayment = req.body;
                    const response = yield membershipPayment_service_1.membershipPaymentService.updateMembershipPayment(Number(membershipPaymentId), membershipPayment);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_BRAND, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.deleteMembershipPayment = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const membershipPaymentId = req.params.membershipPaymentId;
                const response = yield membershipPayment_service_1.membershipPaymentService.deleteMembershipPayment(Number(membershipPaymentId));
                if (response.affected > 0) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_BRAND, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new MembershipPaymentController();
        return this.instance;
    }
}
exports.membershipPaymentController = MembershipPaymentController.getInstance();
//# sourceMappingURL=membershipPayment.controller.js.map