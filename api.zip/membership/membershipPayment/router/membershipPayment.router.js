"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.membershipPaymentRoute = void 0;
const express_1 = require("express");
const membershipPayment_controller_1 = require("../controller/membershipPayment.controller");
const membershipPayment_validator_1 = require("../validator/membershipPayment.validator");
exports.membershipPaymentRoute = (0, express_1.Router)();
exports.membershipPaymentRoute.get('/', membershipPayment_controller_1.membershipPaymentController.findMembershipPayment);
exports.membershipPaymentRoute.post('/', membershipPayment_validator_1.validateCreateMembershipPayment, membershipPayment_controller_1.membershipPaymentController.createMembershipPayments);
exports.membershipPaymentRoute.put('/:membershipPaymentId', membershipPayment_validator_1.validateUpdateMembershipPayment, membershipPayment_controller_1.membershipPaymentController.updateMembershipPayment);
exports.membershipPaymentRoute.delete('/:membershipPaymentId', membershipPayment_validator_1.validateDeleteMembershipPayment, membershipPayment_controller_1.membershipPaymentController.deleteMembershipPayment);
//# sourceMappingURL=membershipPayment.router.js.map