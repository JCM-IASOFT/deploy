"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteMembershipPayment = exports.validateUpdateMembershipPayment = exports.validateCreateMembershipPayment = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateMembershipPaymentId = (0, express_validator_1.param)('membershipPaymentId')
    .exists().withMessage('El parámetro membershipPaymentId es requerido')
    .isNumeric().withMessage('El parámetro membershipPaymentId debe ser numérico');
const validateMembershipPaymentName = (0, express_validator_1.check)('name')
    .exists().trim().not().isEmpty().withMessage('El nombre de la categoria es requerido');
const validateCompanyId = (0, express_validator_1.check)('companyId')
    .exists().not().isEmpty().withMessage('El companyId es requerido');
// * Validación para la creación de una categoria
exports.validateCreateMembershipPayment = [
    validateMembershipPaymentName,
    validateCompanyId,
    handleValidationResult
];
// * Validación para la actualización de una categoria
exports.validateUpdateMembershipPayment = [
    validateMembershipPaymentId,
    validateMembershipPaymentName,
    handleValidationResult
];
// * Validación para la eliminación de una categoria
exports.validateDeleteMembershipPayment = [
    validateMembershipPaymentId,
    handleValidationResult
];
//# sourceMappingURL=membershipPayment.validator.js.map