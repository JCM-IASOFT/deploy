"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.membershipPaymentService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class MembershipPaymentService {
    static getInstance() {
        if (!this.instance)
            this.instance = new MembershipPaymentService();
        return this.instance;
    }
    findMembershipPayment(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const membershipPayments = yield models_1.MembershipPaymentModel.createQueryBuilder('membershipPayment')
                    .leftJoinAndSelect('membershipPayment.subMembershipPayments', 'subMembershipPayments', 'subMembershipPayments.deletedAt = :subDeletedAt', { subDeletedAt: '0' })
                    .where('membershipPayment.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('membershipPayment.companyId = :companyId', { companyId: companyId })
                    .select([
                    'membershipPayment.membershipPaymentId',
                    'membershipPayment.name',
                    'subMembershipPayments.subMembershipPaymentId',
                    'subMembershipPayments.name',
                    'subMembershipPayments.membershipPaymentId'
                ])
                    .getMany();
                return membershipPayments;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    existMembershipPayment(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const exist = yield models_1.MembershipPaymentModel.exists({
                    where: {
                        userId: userId
                    }
                });
                return exist;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return false;
            }
        });
    }
    createMembershipPayment(membershipPayments) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.MembershipPaymentModel.save(membershipPayments);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateMembershipPayment(membershipPaymentId, membershipPayment) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.MembershipPaymentModel.update({ membershipPaymentId }, {
                    amount: membershipPayment.amount,
                    date: membershipPayment.date,
                    companyId: membershipPayment.companyId,
                    userId: membershipPayment.userId,
                    membershipId: membershipPayment.membershipId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteMembershipPayment(membershipPaymentId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.MembershipPaymentModel.update({ membershipPaymentId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.membershipPaymentService = MembershipPaymentService.getInstance();
//# sourceMappingURL=membershipPayment.service.js.map