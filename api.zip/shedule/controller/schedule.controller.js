"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleController = void 0;
const http_status_codes_1 = require("http-status-codes");
const schedule_service_1 = require("../service/schedule.service");
const message_api_1 = require("../../common/constant/message.api");
const save_error_1 = require("../../common/handler/save.error");
class ScheduleController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ScheduleController();
        return this.instance;
    }
    /**
     * Programar pausa y reanudación de servicios
     */
    scheduleSales(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                schedule_service_1.scheduleSalesService.deleteAllTasks();
                const { companyId, campusId } = req.body;
                yield schedule_service_1.scheduleSalesService.sendAlert(companyId, campusId);
                yield schedule_service_1.scheduleSalesService.schedule(companyId, campusId);
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    code: http_status_codes_1.StatusCodes.OK,
                    success: true,
                    message: message_api_1.MessageCustomApi.SETTING_SCHEDULE_SUCCESS,
                });
            }
            catch (error) {
                save_error_1.logger.error(`ScheduleSales controller: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    scheduleAll() {
        return __awaiter(this, void 0, void 0, function* () {
            yield schedule_service_1.scheduleSalesService.scheduleAll();
        });
    }
    /**
     * Cancelar programacion
     */
    cancelAlertSchedule(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId, campusId } = req.body;
                const response = schedule_service_1.scheduleSalesService.cancelAlertSchedule(companyId, campusId);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.SCHEDULE_CALCEL_SUCCESS });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: message_api_1.MessageCustomApi.SCHEDULE_CALCEL_ERROR });
                }
            }
            catch (error) {
                save_error_1.logger.error(`Error in cancelSchedule: controller${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
}
exports.scheduleController = ScheduleController.getInstance();
//# sourceMappingURL=schedule.controller.js.map