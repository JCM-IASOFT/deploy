"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cors_1 = __importDefault(require("cors"));
const express_1 = __importDefault(require("express"));
const models_1 = require("models");
const pdf_controller_1 = require("./pdf/router/pdf.controller");
const auth_router_1 = require("./auth/router/auth.router");
const reniec_router_1 = require("./reniec/router/reniec.router");
const http_1 = __importDefault(require("http"));
const dashboard_router_1 = require("./dashboard/router/dashboard.router");
const cashbox_router_1 = require("./accounting/cashbox/router/cashbox.router");
const monetaryunit_router_1 = require("./accounting/monetaryunit/router/monetaryunit.router");
const cashtonnage_router_1 = require("./accounting/cashtonnage/router/cashtonnage.router");
const express_fileupload_1 = __importDefault(require("express-fileupload"));
const device_router_1 = require("./support/device/router/device.router");
const user_router_1 = require("./system/user/router/user.router");
const employe_router_1 = require("./humanResource/employe/router/employe.router");
const service_router_1 = require("./support/service/router/service.router");
const difference_router_1 = require("./support/difference/router/difference.router");
const price_router_1 = require("./sales/price/router/price.router");
const client_router_1 = require("./sales/client/router/client.router");
const product_router_1 = require("./inventory/product/router/product.router");
const deviceproduct_router_1 = require("./support/deviceproduct/router/deviceproduct.router");
const servicetype_router_1 = require("./support/servicetype/router/servicetype.router");
const parameter_router_1 = require("./system/parameter/router/parameter.router");
const invoicecampus_router_1 = require("./logistics/invoicecampus/router/invoicecampus.router");
const paymentType_router_1 = require("./company/paymenttype/router/paymentType.router");
const finance_router_1 = require("./accounting/finance/router/finance.router");
const typeTransaction_routes_1 = require("./accounting/typeTransaction/router/typeTransaction.routes");
const technical_router_1 = require("./support/technical/router/technical.router");
const sales_router_1 = require("./sales/sales/router/sales.router");
const correlative_router_1 = require("./system/correlative/router/correlative.router");
const servicestatushistory_router_1 = require("./support/servicestatushistory/router/servicestatushistory.router");
const serviceTechnicalHistory_routes_1 = require("./support/serviceTechnicalHistory/router/serviceTechnicalHistory.routes");
const campus_router_1 = require("./company/campus/router/campus.router");
const verification_router_1 = require("./support/verification/router/verification.router");
const payment_router_1 = require("./support/payment/router/payment.router");
const financeHistory_routes_1 = require("./support/financeHistory/router/financeHistory.routes");
const bank_routes_1 = require("./company/bank/router/bank.routes");
const bankAccount_routes_1 = require("./company/bankAccount/router/bankAccount.routes");
const bankAccountType_routes_1 = require("./company/bankAccountType/router/bankAccountType.routes");
const fixedExpenses_routes_1 = require("./accounting/fixedExpenses/router/fixedExpenses.routes");
const fixedExpensesType_routes_1 = require("./accounting/fixedExpensesType/router/fixedExpensesType.routes");
const cashWithdrawals_routes_1 = require("./accounting/cashWithdrawals/router/cashWithdrawals.routes");
const waitingticket_router_1 = require("./support/waitingticket/router/waitingticket.router");
const cashboxdetail_router_1 = require("./accounting/cashboxdetail/router/cashboxdetail.router");
const errorLog_routes_1 = require("./errorLog/router/errorLog.routes");
const credit_router_1 = require("./credit/credit/router/credit.router");
const creditAdvance_router_1 = require("./credit/creditAdvance/router/creditAdvance.router");
const creditModality_router_1 = require("./credit/creditModality/router/creditModality.router");
const creditPayment_router_1 = require("./credit/creditPayment/router/creditPayment.router");
const creditSchedule_router_1 = require("./credit/creditSchedule/router/creditSchedule.router");
const permissionrole_router_1 = require("./system/permissionrole/router/permissionrole.router");
const permissionuser_router_1 = require("./system/permissionuser/router/permissionuser.router");
const roleuser_router_1 = require("./system/roleuser/router/roleuser.router");
const action_router_1 = require("./system/action/router/action.router");
const role_router_1 = require("./system/role/router/role.router");
const system_router_1 = require("./system/system/router/system.router");
const position_routes_1 = require("./humanResource/position/router/position.routes");
const company_router_1 = require("./company/company/router/company.router");
const devicebrand_router_1 = require("./support/devicebrand/router/devicebrand.router");
const accessories_router_1 = require("./support/accessories/router/accessories.router");
const sector_router_1 = require("./company/sector/router/sector.router");
const store_router_1 = require("./inventory/store/router/store.router");
const priceGroup_router_1 = require("./sales/priceGroup/router/priceGroup.router");
const currencyCoins_routes_1 = require("./company/currencyCoins/router/currencyCoins.routes");
const category_router_1 = require("./inventory/category/router/category.router");
const subCategory_router_1 = require("./inventory/subCategory/router/subCategory.router");
const documentType_routes_1 = require("./humanResource/documentType/router/documentType.routes");
const survey_routes_1 = require("./support/survey/router/survey.routes");
const brand_router_1 = require("./inventory/brand/router/brand.router");
const typechangemoney_router_1 = require("./company/typechangemoney/router/typechangemoney.router");
const unitMeasurement_router_1 = require("./inventory/unitMeasurement/router/unitMeasurement.router");
const measurement_router_1 = require("./inventory/measurement/router/measurement.router");
const presentation_router_1 = require("./inventory/presentation/router/presentation.router");
const group_router_1 = require("./inventory/group/router/group.router");
const tax_router_1 = require("./company/tax/router/tax.router");
const country_routes_1 = require("./company/country/router/country.routes");
const departament_routes_1 = require("./company/departament/router/departament.routes");
const province_routes_1 = require("./company/province/router/province.routes");
const district_routes_1 = require("./company/district/router/district.routes");
const storeType_router_1 = require("./inventory/storeType/router/storeType.router");
const clientType_routes_1 = require("./sales/clientType/router/clientType.routes");
const zone_routes_1 = require("./company/zone/router/zone.routes");
const supplier_routes_1 = require("./logistics/supplier/router/supplier.routes");
const proformaQuoteType_routes_1 = require("./sales/proformaquotetype/router/proformaQuoteType.routes");
const proformaQuoteDetail_router_1 = require("./sales/proformaquotedetail/router/proformaQuoteDetail.router");
const proformaQuote_router_1 = require("./sales/proformaquote/router/proformaQuote.router");
const storage_routes_1 = require("./support/storage/router/storage.routes");
const menu_router_1 = require("./system/menu/router/menu.router");
const menuAction_router_1 = require("./system/menuAction/router/menuAction.router");
const colorSettingsState_routes_1 = require("./support/colorSettingsState/routes/colorSettingsState.routes");
const terminal_router_1 = require("./sales/terminal/router/terminal.router");
const conecction_1 = require("./socket/conecction");
const xlsx_routes_1 = require("./xlsx/routes/xlsx.routes");
const transaction_router_1 = require("./inventory/transaction/router/transaction.router");
const product_router_2 = require("./inventory/movement/routers/product.router");
const cards_routes_1 = require("./company/cards/router/cards.routes");
const serviceRequest_routes_1 = require("./support/serviceRequests/router/serviceRequest.routes");
const permissionCompany_router_1 = require("./system/permissionCompany/router/permissionCompany.router");
const permissionCampus_router_1 = require("./system/permissionCampus/router/permissionCampus.router");
const userCampus_router_1 = require("./system/userCampus/router/userCampus.router");
const userCompany_router_1 = require("./system/userCompany/router/userCompany.router");
const cashClosing_router_1 = require("./accounting/cashClosing/router/cashClosing.router");
const setting_router_1 = require("./support/setting/router/setting.router");
const schedule_router_1 = require("./support/schedule/router/schedule.router");
//import { scheduleController } from "./support/schedule/controller/schedule.controller";
const invoice_router_1 = require("./logistics/invoice/router/invoice.router");
const configCampus_router_1 = require("./company/configCampus/router/configCampus.router");
const day_router_1 = require("./support/day/router/day.router");
const paymentTypeCompany_router_1 = require("./company/paymentTypeCompany/router/paymentTypeCompany.router");
const salesTracking_routes_1 = require("./sales/salesTracking/routes/salesTracking.routes");
const configSalesTracking_router_1 = require("./sales/configSalesTracking/router/configSalesTracking.router");
const scheduleSales_router_1 = require("./sales/schedule/router/scheduleSales.router");
const scheduleSales_controller_1 = require("./sales/schedule/controller/scheduleSales.controller");
const pdf_service_router_1 = require("./pdf/router/pdf.service.router");
//import { scheduleCreditController } from "./credit/scheduleCredit/controller/scheduleCredit.controller";
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield models_1.AppDataSource.initialize()
                .then(() => __awaiter(this, void 0, void 0, function* () {
                var _a, _b;
                const app = (0, express_1.default)();
                app.use((0, cors_1.default)());
                app.use((0, express_fileupload_1.default)());
                app.use(express_1.default.json({ limit: '50mb' }));
                app.use('/public', express_1.default.static('public'));
                app.use('/device', device_router_1.deviceRoute);
                app.use('/user', user_router_1.userRoute);
                app.use('/employe', employe_router_1.employeRoute);
                app.use('/service', service_router_1.serviceRoute);
                app.use('/difference', difference_router_1.differenceRoute);
                app.use('/price', price_router_1.priceRoute);
                app.use('/client', client_router_1.clientRoute);
                app.use('/product', product_router_1.productRoute);
                app.use('/deviceproduct', deviceproduct_router_1.deviceproductRoute);
                app.use('/pdf', pdf_controller_1.pdfRoute);
                app.use('/xlsx', xlsx_routes_1.xlsxRoute);
                app.use('/auth', auth_router_1.authRoute);
                app.use('/transaction', transaction_router_1.transactionRoute);
                app.use('/movement', product_router_2.movementRoute);
                app.use('/reniec', reniec_router_1.reniecRoute);
                app.use('/serviceType', servicetype_router_1.servicetypeRoute);
                app.use('/parameter', parameter_router_1.parameterRoute);
                app.use('/invoicecampus', invoicecampus_router_1.invoicecampusRoute);
                app.use('/paymentType', paymentType_router_1.paymenttypeRoute);
                app.use('/finance/transaction', finance_router_1.financeRoute);
                app.use('/finance/typeTransaction', typeTransaction_routes_1.typeTransactionRoute);
                app.use('/technical', technical_router_1.technicalRoute);
                app.use('/sales', sales_router_1.salesRoute);
                app.use('/dashboard', dashboard_router_1.dashboardRoute);
                app.use('/correlatives', correlative_router_1.correlativeRoute);
                app.use('/servicestatushistory', servicestatushistory_router_1.servicestatushistoryRoute);
                app.use('/serviceTechnicalHistory', serviceTechnicalHistory_routes_1.serviceTechnicalHistoryRoute);
                app.use('/finance', finance_router_1.financeRoute);
                app.use('/campus', campus_router_1.campusRoute);
                app.use('/verification', verification_router_1.verificationRoute);
                app.use('/payment', payment_router_1.paymentRoute);
                app.use('/finance/history', financeHistory_routes_1.financeHistoryRoute);
                app.use('/bank', bank_routes_1.bankRoute);
                app.use('/bank_account', bankAccount_routes_1.bankAccountRoute);
                app.use('/bank_account_type', bankAccountType_routes_1.bankAccountTypeRoute);
                app.use('/fixed_expenses', fixedExpenses_routes_1.fixedExpensesRoute);
                app.use('/fixed_expenses_type', fixedExpensesType_routes_1.fixedExpensesTypeRoute);
                app.use('/cash_withdrawals', cashWithdrawals_routes_1.cashWithdrawalsRoute);
                // ** Finance
                app.use('/credit', credit_router_1.creditRoute);
                app.use('/credit_advance', creditAdvance_router_1.creditAdvanceRoute);
                app.use('/credit_modality', creditModality_router_1.creditModalityRoute);
                app.use('/credit_payment', creditPayment_router_1.creditPaymentRoute);
                app.use('/credit_schedule', creditSchedule_router_1.creditScheduleRoute);
                // ** SERVICE
                app.use('/waiting_ticket', waitingticket_router_1.waitingticketRoute);
                // ** ACCOUNTING
                app.use('/cash_box', cashbox_router_1.cashboxRoute);
                app.use('/cash_closing', cashClosing_router_1.cashClosingRoute);
                app.use('/cash_box_detail', cashboxdetail_router_1.cashboxdetailRoute);
                app.use('/monetary_unit', monetaryunit_router_1.monetaryunitRoute);
                app.use('/cash_tonnage', cashtonnage_router_1.cashtonnageRoute);
                // ** PERMISSION
                app.use('/permission_role', permissionrole_router_1.permissionroleRoute);
                app.use('/permission_user', permissionuser_router_1.permissionuserRoute);
                app.use('/role_user', roleuser_router_1.roleuserRoute);
                app.use('/action', action_router_1.actionRoute);
                app.use('/role', role_router_1.roleRoute);
                app.use('/system', system_router_1.systemRoute);
                app.use('/position', position_routes_1.positionRoute);
                // ** ADMINISTRATION            
                app.use('/company', company_router_1.companyRoute);
                app.use('/deviceBrand', devicebrand_router_1.devicebrandRoute);
                app.use('/accessory', accessories_router_1.accessoryRoute);
                app.use('/sector', sector_router_1.sectorRoute);
                app.use('/store', store_router_1.storeRoute);
                app.use('/price_group', priceGroup_router_1.priceGroupRoute);
                app.use('/currency', currencyCoins_routes_1.currencyRoute);
                app.use('/category', category_router_1.categoryRoute);
                app.use('/sub_category', subCategory_router_1.subCategoryRoute);
                app.use('/documentType', documentType_routes_1.documentTypeRoute);
                app.use('/survey', survey_routes_1.surveyRoute);
                app.use('/brand', brand_router_1.brandRoute);
                app.use('/type_change_money', typechangemoney_router_1.typechangemoneyRoute);
                app.use('/unit_measurement', unitMeasurement_router_1.unitMeasurementRoute);
                app.use('/measurement', measurement_router_1.measurementRoute);
                app.use('/presentation', presentation_router_1.presentationRoute);
                app.use('/group', group_router_1.groupRoute);
                app.use('/tax', tax_router_1.taxRoute);
                app.use('/country', country_routes_1.countryRoute);
                app.use('/departament', departament_routes_1.departamentRoute);
                app.use('/province', province_routes_1.provinceRoute);
                app.use('/district', district_routes_1.districtRoute);
                app.use('/store_type', storeType_router_1.storeTypeRoute);
                app.use('/client_type', clientType_routes_1.clientTypeRoute);
                app.use('/zone', zone_routes_1.zoneRoute);
                app.use('/supplier', supplier_routes_1.supplierRoute);
                app.use('/color_settings_state', colorSettingsState_routes_1.colorSettingsStateRoute);
                app.use('/cards', cards_routes_1.cardsRoute);
                app.use('/payment_type_company', paymentTypeCompany_router_1.paymentTypeCompanyRoute);
                app.use('/sales_tracking', salesTracking_routes_1.salesTrackingRoute);
                // ** BILLING
                app.use('/proforma_quote_detail', proformaQuoteDetail_router_1.proformaQuoteDetailRoute);
                app.use('/proforma_quote_type', proformaQuoteType_routes_1.proformaQuoteTypeRoute);
                app.use('/proforma_quote', proformaQuote_router_1.proformaQuoteRoute);
                app.use('/storage', storage_routes_1.storageRoute);
                app.use('/log', errorLog_routes_1.errorLogRoute);
                app.use('/terminal', terminal_router_1.terminalRoute);
                // ** SYSTEM
                app.use('/menu', menu_router_1.menuRoute);
                app.use('/menu_action', menuAction_router_1.menuActionRoute);
                app.use('/permission_company', permissionCompany_router_1.permissionCompanyRoute);
                app.use('/permission_campus', permissionCampus_router_1.permissionCampusRoute);
                app.use('/user_campus', userCampus_router_1.userCampusRoute);
                app.use('/user_company', userCompany_router_1.userCompanyRoute);
                // ** SUPPORT
                app.use('/service_requests', serviceRequest_routes_1.serviceRequestsRoute);
                app.use('/schedule', schedule_router_1.scheduleRoute);
                app.use('/setting', setting_router_1.settingRoute);
                app.use('/day', day_router_1.dayRoute);
                app.use('/pdf_service', pdf_service_router_1.pdfServiceRoute);
                app.use('/invoice', invoice_router_1.invoiceRoute);
                app.use('/config_campus', configCampus_router_1.configCampusRoute);
                //app.use('/service_pause_history', servicePauseHistoryRoute)
                app.use('/config_sales_tracking', configSalesTracking_router_1.configSalesTrackingRoute);
                app.use('/schedule_sales', scheduleSales_router_1.scheduleSalesRoute);
                const server = http_1.default.createServer(app);
                //scheduleController.loadCronJobsFromDatabase()
                //scheduleController.loadCronJobsFromServiceRequest()
                // scheduleController.loadCronJobsFromDatabase()
                // scheduleCreditController.loadCronJobsFromCredit()
                scheduleSales_controller_1.scheduleSalesController.scheduleSalesInitalExecute();
                (0, conecction_1.initializeSocketServer)(server);
                server.listen((_a = process.env.PORT) !== null && _a !== void 0 ? _a : 4000);
                console.info(`🌟 ¡El servidor Express ha comenzado en el puerto ${(_b = process.env.PORT) !== null && _b !== void 0 ? _b : 3000}! 🚀✨`);
            }))
                .catch((error) => console.error('Error en la appdata Source: ', error));
        }
        catch (error) {
            console.error(error);
        }
    });
}
main();
//# sourceMappingURL=app.js.map