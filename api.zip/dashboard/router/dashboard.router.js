"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dashboardRoute = void 0;
const express_1 = require("express");
const dashboard_controller_1 = require("../controller/dashboard.controller");
exports.dashboardRoute = (0, express_1.Router)();
exports.dashboardRoute.get('/all', dashboard_controller_1.dashboardController.totalDashboard);
//# sourceMappingURL=dashboard.router.js.map