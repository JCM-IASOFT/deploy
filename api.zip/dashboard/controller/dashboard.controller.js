"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dashboardController = void 0;
const http_status_codes_1 = require("http-status-codes");
const dashboard_service_1 = require("../service/dashboard.service");
const modelslibrary_1 = require("modelslibrary");
const moment_1 = __importDefault(require("moment"));
const fixedExpenses_service_1 = require("../../accounting/fixedExpenses/service/fixedExpenses.service");
class DashboardController {
    constructor() {
        this.totalDashboard = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId, startDate, endDate, zone, companyId } = req.query;
                const campusIdParse = Number(campusId);
                const companyIdParse = Number(companyId);
                const startDateParse = startDate.toString();
                const endDateParse = endDate.toString();
                const zoneParse = zone ? zone.toString() : '';
                // ** Servicios
                const services = yield dashboard_service_1.dashboardService.totalsServices(campusIdParse, startDateParse, endDateParse, zoneParse);
                const paymentServices = yield dashboard_service_1.dashboardService.findTotalServicePayments(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Servicios Rapidos
                const fastServices = yield dashboard_service_1.dashboardService.totalsFastService(campusIdParse, startDateParse, endDateParse, zoneParse);
                const paymentFastServices = yield dashboard_service_1.dashboardService.findTotalFastServicePayments(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Sales 
                const chartSales = yield dashboard_service_1.dashboardService.chartSales(campusIdParse, startDateParse, endDateParse, zoneParse);
                const paymentsSales = yield dashboard_service_1.dashboardService.paymentsSales(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Sales Free
                const chartSalesFree = yield dashboard_service_1.dashboardService.chartSalesFree(campusIdParse, startDateParse, endDateParse, zoneParse);
                const paymentsSalesFree = yield dashboard_service_1.dashboardService.paymentsSalesFree(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Transaccion Ingreso
                const transaccionIngresoPayments = yield dashboard_service_1.dashboardService.findTransactionPayments(campusIdParse, modelslibrary_1.typeOperation.ingreso, startDateParse, endDateParse, zoneParse);
                const transaccionIngreso = yield dashboard_service_1.dashboardService.totalsTransaction(campusIdParse, modelslibrary_1.typeOperation.ingreso, startDateParse, endDateParse, zoneParse);
                // ** Transaccion Egreso
                const transaccionEgresoPayments = yield dashboard_service_1.dashboardService.findTransactionPayments(campusIdParse, modelslibrary_1.typeOperation.egreso, startDateParse, endDateParse, zoneParse);
                const transaccionEgreso = yield dashboard_service_1.dashboardService.totalsTransaction(campusIdParse, modelslibrary_1.typeOperation.egreso, startDateParse, endDateParse, zoneParse);
                // ** Differences
                const transaccionDifferencesPayments = yield dashboard_service_1.dashboardService.findDifferencePayments(campusIdParse, startDateParse, endDateParse, zoneParse);
                const transaccionDifferences = yield dashboard_service_1.dashboardService.totalsDifferences(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Technical
                const technicals = yield dashboard_service_1.dashboardService.totalsTechnical(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Records Technicals
                const technicalRecors = yield dashboard_service_1.dashboardService.technicalRecors(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Servicios por mes 
                const servicesMonths = yield dashboard_service_1.dashboardService.totalsServiceMonth(campusIdParse, zoneParse);
                // ** Ventas por mes
                const salesMonths = yield dashboard_service_1.dashboardService.totalsSalesMonth(campusIdParse, zoneParse);
                // ** Total pendiente
                const totalPending = yield dashboard_service_1.dashboardService.totalPending(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Cantidad de horas trabajados Tecnicos
                const chartTechnicalHoursWorkerd = yield dashboard_service_1.dashboardService.chartTechnicalHoursWorkerd(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Chart Prioridades
                const chartPriority = yield dashboard_service_1.dashboardService.chartPriority(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Chart Servicios rapidos por tecnico
                const chartFastOrderByTechnical = yield dashboard_service_1.dashboardService.chartFastOrderByTechnical(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Servicios no concluidos
                const chartUnfinishedServices = yield dashboard_service_1.dashboardService.chartUnfinishedServices(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Servicios recepcionados con tecnicos asociado
                const chartReceptionWithTechnical = yield dashboard_service_1.dashboardService.chartReceptionWithTechnical(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Servicios reparaciones con tecnicos asociado
                const chartRepairWithTechnical = yield dashboard_service_1.dashboardService.chartRepairWithTechnical(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Servicios entregados con tecnicos asociado
                const chartDeliveredWithTechnical = yield dashboard_service_1.dashboardService.chartDeliveredWithTechnical(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Saldo en caja y retiros en efectivo
                const chartWithdrawals = yield dashboard_service_1.dashboardService.chartWithdrawals(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Gastos fijos
                const fixedExpenses = yield fixedExpenses_service_1.fixedExpensesService.findFixedExpensesRange(campusIdParse, startDateParse, endDateParse);
                // ** Gastos Variables                   
                const profits = this.totalFixedExpenses(transaccionEgresoPayments, fixedExpenses, paymentServices, [], startDateParse, endDateParse);
                // **total en efectivo
                const cashBalance = yield dashboard_service_1.dashboardService.findTotalCashBalance(campusIdParse, startDateParse, endDateParse, zoneParse);
                // **total en transferecias o pagos de billeteras digitales
                const cashBank = yield dashboard_service_1.dashboardService.findTotalCashInBank(campusIdParse, startDateParse, endDateParse, zoneParse);
                // **total general
                const generalBalance = yield dashboard_service_1.dashboardService.findTotalgeneralBalance(campusIdParse, startDateParse, endDateParse, zoneParse);
                // **total de operaciones
                const totalOperations = yield dashboard_service_1.dashboardService.findTotalOperations(campusIdParse, startDateParse, endDateParse, zoneParse);
                // **ajuste de precio 
                const priceAdjustment = yield dashboard_service_1.dashboardService.findTotalPriceAdjustment(campusIdParse, startDateParse, endDateParse, zoneParse);
                // ** Total Margen de Ganancia
                const marginGainSales = yield dashboard_service_1.dashboardService.findMarginGainSales(campusIdParse, startDateParse, endDateParse, zoneParse);
                // **total de pagos a credito
                const creditPayment = yield dashboard_service_1.dashboardService.findTotalCreditPayment(companyIdParse, startDateParse, endDateParse, zoneParse);
                // ** Ganancia de servicio neta
                const profitService = yield dashboard_service_1.dashboardService.findNetProfitService(campusIdParse, startDateParse, endDateParse, zoneParse);
                const dashboards = {
                    profits: profits,
                    withdrawals: chartWithdrawals,
                    totals: {
                        cashBalance: cashBalance,
                        cashBank: cashBank,
                        generalBalance: generalBalance,
                        totalOperations: totalOperations,
                        profitService: profitService,
                        profitSales: marginGainSales,
                        priceAdjustment: priceAdjustment,
                        creditPayment: creditPayment
                    },
                    pending: totalPending,
                    technical: technicalRecors,
                    charts: [{
                            description: "servicios",
                            payment: paymentServices,
                            chart: services
                        },
                        {
                            description: "fastService",
                            payment: paymentFastServices,
                            chart: fastServices
                        },
                        {
                            description: "chartSales",
                            payment: paymentsSales,
                            chart: chartSales
                        },
                        {
                            description: "salesFree",
                            payment: paymentsSalesFree,
                            chart: chartSalesFree
                        },
                        {
                            description: "ingresos",
                            payment: transaccionIngresoPayments,
                            chart: transaccionIngreso
                        },
                        {
                            description: "egresos",
                            payment: transaccionEgresoPayments,
                            chart: transaccionEgreso
                        },
                        {
                            description: "diferencias",
                            payment: transaccionDifferencesPayments,
                            chart: transaccionDifferences
                        },
                        {
                            description: "technical",
                            payment: null,
                            chart: technicals,
                        },
                        {
                            description: "monthService",
                            payment: null,
                            chart: servicesMonths
                        },
                        {
                            description: "salesMonths",
                            payment: null,
                            chart: salesMonths
                        },
                        {
                            description: "technicalHoursWorkerd", // Horas trabajadas
                            payment: null,
                            chart: chartTechnicalHoursWorkerd
                        },
                        {
                            description: "chartPriority", // Prioridades
                            payment: null,
                            chart: chartPriority
                        },
                        {
                            description: "chartFastOrderByTechnical",
                            payment: null,
                            chart: chartFastOrderByTechnical
                        },
                        {
                            description: "chartUnfinishedServices",
                            payment: null,
                            chart: chartUnfinishedServices
                        },
                        {
                            description: 'chartReceptionWithTechnical',
                            payment: null,
                            chart: chartReceptionWithTechnical
                        },
                        {
                            description: 'chartRepairWithTechnical',
                            payment: null,
                            chart: chartRepairWithTechnical
                        },
                        {
                            description: 'chartDeliveredWithTechnical',
                            payment: null,
                            chart: chartDeliveredWithTechnical
                        },
                    ],
                    productivity: []
                };
                res.status(http_status_codes_1.StatusCodes.OK).json(dashboards);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json(error);
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new DashboardController();
        return this.instance;
    }
    /**
     * Calculo de salida de dinero en efectivo
     */
    totalFixedExpenses(egresos, fixedExpenses, services, sales, startDate, endDate) {
        let totalEgreso = 0;
        let totalService = 0;
        let totalSales = 0;
        let totalFixedExpenses = 0;
        const start = (0, moment_1.default)(startDate);
        const end = (0, moment_1.default)(endDate);
        const cantDays = end.diff(start, 'days');
        egresos.forEach(element => {
            totalEgreso += parseFloat(element.amount.toString());
        });
        services.forEach(element => {
            totalService += parseFloat(element.amount.toString());
        });
        sales.forEach(element => {
            totalSales += parseFloat(element.amount.toString());
        });
        fixedExpenses.forEach(element => {
            totalFixedExpenses += parseFloat(element.dailyPayment.toString());
        });
        const profitService = totalService - (totalEgreso + (totalFixedExpenses * (cantDays + 1)));
        const profit = {
            service: profitService,
            sales: totalSales,
            netaTotal: profitService + totalSales
        };
        return profit;
    }
}
exports.dashboardController = DashboardController.getInstance();
//# sourceMappingURL=dashboard.controller.js.map