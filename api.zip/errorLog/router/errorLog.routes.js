"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorLogRoute = void 0;
const express_1 = require("express");
const errorLog_controller_1 = require("../controller/errorLog.controller");
exports.errorLogRoute = (0, express_1.Router)();
exports.errorLogRoute.get('/all', errorLog_controller_1.errorLogController.getErrorsMessages);
//# sourceMappingURL=errorLog.routes.js.map