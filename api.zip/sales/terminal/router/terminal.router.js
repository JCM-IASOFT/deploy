"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.terminalRoute = void 0;
const express_1 = require("express");
const terminal_controller_1 = require("../controller/terminal.controller");
const terminal_validator_1 = require("../validator/terminal.validator");
exports.terminalRoute = (0, express_1.Router)();
exports.terminalRoute.get('/', terminal_controller_1.terminalController.findTerminal);
exports.terminalRoute.get('/one', terminal_controller_1.terminalController.findOneTerminal);
exports.terminalRoute.post('/', terminal_validator_1.validateCreateTerminal, terminal_controller_1.terminalController.createTerminals);
exports.terminalRoute.put('/:terminalId', terminal_validator_1.validateUpdateTerminal, terminal_controller_1.terminalController.updateTerminal);
exports.terminalRoute.delete('/:terminalId', terminal_validator_1.validateDeleteTerminal, terminal_controller_1.terminalController.deleteTerminal);
//# sourceMappingURL=terminal.router.js.map