"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteTerminal = exports.validateUpdateTerminal = exports.validateCreateTerminal = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateTerminalId = (0, express_validator_1.param)('terminalId')
    .exists().withMessage('El parámetro terminalId es requerido')
    .isNumeric().withMessage('El parámetro terminalId debe ser numérico');
const validateTerminalName = (0, express_validator_1.check)('name')
    .exists().trim().not().isEmpty().withMessage('El nombre de la categoria es requerido');
const validateCompanyId = (0, express_validator_1.check)('companyId')
    .exists().not().isEmpty().withMessage('El companyId es requerido');
// * Validación para la creación de una categoria
exports.validateCreateTerminal = [
    validateTerminalName,
    validateCompanyId,
    handleValidationResult
];
// * Validación para la actualización de una categoria
exports.validateUpdateTerminal = [
    validateTerminalId,
    validateTerminalName,
    handleValidationResult
];
// * Validación para la eliminación de una categoria
exports.validateDeleteTerminal = [
    validateTerminalId,
    handleValidationResult
];
//# sourceMappingURL=terminal.validator.js.map