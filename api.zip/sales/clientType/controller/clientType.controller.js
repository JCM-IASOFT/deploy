"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientTypeController = exports.ClientTypeController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const clientType_service_1 = require("../service/clientType.service");
const message_api_1 = require("../../../common/constant/message.api");
class ClientTypeController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ClientTypeController();
        return this.instance;
    }
    findClientType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId } = request.query;
                const findResponse = yield clientType_service_1.clientTypeService.findClientType(Number(companyId));
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    createClientType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { clientType } = request.body;
                    const createResponse = yield clientType_service_1.clientTypeService.createClientType(clientType);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_CLIENT_TYPE, data: createResponse };
                }
                catch (error) {
                    response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    });
                }
            }));
        });
    }
    updateClientType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { clientType } = request.body;
                    const updateResponse = yield clientType_service_1.clientTypeService.updateClientType(clientType);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_CLIENT_TYPE, data: updateResponse };
                }
                catch (error) {
                    response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    });
                }
            }));
        });
    }
    deleteClientType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { clientTypeId } = request.params;
                    const deleteResponse = yield clientType_service_1.clientTypeService.deleteClientType(Number(clientTypeId));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_CLIENT_TYPE, data: deleteResponse };
                }
                catch (error) {
                    response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    });
                }
            }));
        });
    }
}
exports.ClientTypeController = ClientTypeController;
exports.clientTypeController = ClientTypeController.getInstance();
//# sourceMappingURL=clientType.controller.js.map