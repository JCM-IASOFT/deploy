"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleSalesRoute = void 0;
const express_1 = require("express");
const scheduleSales_controller_1 = require("../controller/scheduleSales.controller");
exports.scheduleSalesRoute = (0, express_1.Router)();
exports.scheduleSalesRoute.post('/', scheduleSales_controller_1.scheduleSalesController.scheduleSales);
exports.scheduleSalesRoute.post('/cancel_alert', scheduleSales_controller_1.scheduleSalesController.cancelAlertSchedule);
//# sourceMappingURL=scheduleSales.router.js.map