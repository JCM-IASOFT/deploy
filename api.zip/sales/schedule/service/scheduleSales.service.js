"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleSalesService = void 0;
const campus_service_1 = require("./../../../company/campus/service/campus.service");
const models_1 = require("models");
const webSocketService_1 = require("../../../socket/webSocketService");
const node_cron_1 = __importDefault(require("node-cron"));
const salesTracking_service_1 = require("../../salesTracking/service/salesTracking.service");
const company_service_1 = require("../../../company/company/service/company.service");
const configSalesTracking_service_1 = require("../../configSalesTracking/service/configSalesTracking.service");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const save_error_1 = require("../../../common/handler/save.error");
const proformaConfigTracking_service_1 = require("../../proformaConfigTracking/service/proformaConfigTracking.service");
const typeorm_1 = require("typeorm");
const parameter_constant_1 = require("../../../common/constant/parameter.constant");
const whatsapp_service_1 = require("../../../whatsapp/service/whatsapp.service");
const employeTracking_service_1 = require("../../../humanResource/employeTracking/service/employeTracking.service");
const creditConfigTracking_service_1 = require("../../../credit/creditConfigTracking/service/creditConfigTracking.service");
const creditSchedule_service_1 = require("../../../credit/creditSchedule/service/creditSchedule.service");
class ScheduleSalesService {
    constructor() {
        this.tasks = [];
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ScheduleSalesService();
        return this.instance;
    }
    getTask() {
        return this.tasks;
    }
    addTask(tasks) {
        this.tasks.push(...tasks);
    }
    deleteAllTasks() {
        for (const task of this.tasks) {
            if (task.cronJob && typeof task.cronJob.stop === 'function') {
                task.cronJob.stop();
            }
        }
        this.tasks.length = 0; // Vacía el array manteniendo la referencia
    }
    //#region ALERTAS
    cancelAlertSchedule(companyId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const key = `${companyId}_${campusId}`;
                const keyAlertSales = `${key}_alert`;
                yield configSalesTracking_service_1.configSalesTrackingService.toggleStateAlert(campusId, false);
                const taskIndexAlertSales = this.getTask().findIndex(task => task.key === keyAlertSales);
                // Detener y eliminar la tarea existente si ya existe
                if (taskIndexAlertSales !== -1) {
                    this.getTask()[taskIndexAlertSales].cronJob.stop();
                    this.getTask().splice(taskIndexAlertSales, 1);
                }
                return true;
            }
            catch (error) {
                save_error_1.logger.error(`Error in cancelSchedule: ${error.message}`);
                return false;
            }
        });
    }
    sendAlert(companyId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            const key = `${companyId}_${campusId}`;
            const keyAlertSales = `${key}_alert`;
            const taskIndexAlertSales = this.getTask().findIndex(task => task.key === keyAlertSales);
            // Detener y eliminar la tarea existente si ya existe
            if (taskIndexAlertSales !== -1) {
                this.getTask()[taskIndexAlertSales].cronJob.stop();
                this.getTask().splice(taskIndexAlertSales, 1);
            }
            const sendAlertJob = node_cron_1.default.schedule('* * * * *', () => __awaiter(this, void 0, void 0, function* () {
                const company = yield company_service_1.companyService.findOneCompany(companyId);
                const proformaTracking = yield this.prepareProformasAlert(campusId, company.timeZone);
                const salesTracking = yield this.prepareTrackingSalesAlert(companyId, campusId, company.timeZone);
                const services = yield this.getServicesTracking(campusId);
                const creditSchedule = yield this.prepareCreditAlert(companyId, campusId, company.timeZone);
                const tracking = {
                    salesTrackings: salesTracking,
                    proformas: proformaTracking,
                    services: services,
                    creditSchedules: creditSchedule
                };
                webSocketService_1.webSocketService.alertTracking(companyId, campusId, tracking);
            }));
            this.addTask([{ key: keyAlertSales, cronJob: sendAlertJob }]);
        });
    }
    prepareCreditAlert(companyId, campusId, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Obtener las ventas de seguimiento del día actual
                const creditSchedule = yield creditSchedule_service_1.creditScheduleService.findCreditSchedule(companyId);
                const config = yield creditConfigTracking_service_1.creditConfigTrackingService.findCreditConfigTracking(campusId);
                if (!config || !config.stateAlert)
                    return [];
                const today = (0, moment_timezone_1.default)().tz(timeZone).startOf('day');
                const creditScheduleAlert = [];
                // Función para verificar si el seguimiento de ventas ya está en la lista de alertas
                const verifyExist = (creditScheduleId) => {
                    return creditScheduleAlert.some(p => p.creditScheduleId === creditScheduleId);
                };
                // Procesar cada seguimiento de ventas
                for (const credit of creditSchedule) {
                    const dueDateCredit = (0, moment_timezone_1.default)(credit.dueDate).toDate();
                    const previousDays = this.getPreviousDays(dueDateCredit, config.previousDays);
                    const nextDays = this.getNextDays(dueDateCredit, config.daysLater);
                    const shouldSchedule = (0, moment_timezone_1.default)().isSame(dueDateCredit, 'day') ||
                        previousDays.some(day => (0, moment_timezone_1.default)(day).isSame(today, 'day')) ||
                        nextDays.some(day => (0, moment_timezone_1.default)(day).isSame(today, 'day'));
                    if (shouldSchedule && !verifyExist(credit.creditScheduleId)) {
                        creditScheduleAlert.push(credit);
                    }
                }
                return creditScheduleAlert;
            }
            catch (error) {
                save_error_1.logger.error(`Error in sendAlert: ${error.message}`);
                return [];
            }
        });
    }
    prepareTrackingSalesAlert(companyId, campusId, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Obtener las ventas de seguimiento del día actual
                const salesTrackings = yield salesTracking_service_1.salesTrackingService.findSalesTrackingToday(companyId, campusId);
                const configTrackingSales = yield configSalesTracking_service_1.configSalesTrackingService.findConfigSalesTracking(campusId);
                if (!configTrackingSales || !configTrackingSales.stateAlert)
                    return [];
                const today = (0, moment_timezone_1.default)().tz(timeZone).startOf('day');
                const salesTrackingAlert = [];
                // Función para verificar si el seguimiento de ventas ya está en la lista de alertas
                const verifyExist = (salesTrackingId) => {
                    return salesTrackingAlert.some(p => p.salesTrackingId === salesTrackingId);
                };
                // Procesar cada seguimiento de ventas
                for (const tracking of salesTrackings) {
                    const dateMaintenance = (0, moment_timezone_1.default)(tracking.regDate)
                        .add(tracking.product.maintenance, 'months')
                        .startOf('day'); // Fecha de mantenimiento calculada
                    const previousDays = this.getPreviousDays(dateMaintenance.toDate(), configTrackingSales.previousDays);
                    const nextDays = this.getNextDays(dateMaintenance.toDate(), configTrackingSales.daysLater);
                    // Verificar si hoy es la fecha exacta de mantenimiento
                    if (today.isSame(dateMaintenance, 'day') && !verifyExist(tracking.salesTrackingId)) {
                        salesTrackingAlert.push(tracking);
                    }
                    // Verificar si hoy está dentro del rango de días anteriores
                    if (previousDays.some(day => (0, moment_timezone_1.default)(day).startOf('day').isSame(today))) {
                        if (!verifyExist(tracking.salesTrackingId)) {
                            salesTrackingAlert.push(tracking);
                        }
                    }
                    // Verificar si hoy está dentro del rango de días posteriores
                    if (nextDays.some(day => (0, moment_timezone_1.default)(day).startOf('day').isSame(today))) {
                        if (!verifyExist(tracking.salesTrackingId)) {
                            salesTrackingAlert.push(tracking);
                        }
                    }
                }
                return salesTrackingAlert;
            }
            catch (error) {
                save_error_1.logger.error(`Error in sendAlert: ${error.message}`);
                return [];
            }
        });
    }
    /**
     * - Obtenmos solo los registros necesarios que cumplan con la fecha de hacer seguimiento
     * @param campusId - identificado de sede
     * @param timeZone - zona horaria
     * @returns
     */
    prepareProformasAlert(campusId, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            const config = yield proformaConfigTracking_service_1.proformaConfigTrackingService.findProformaConfigTracking(campusId);
            const proformas = yield this.getProformasTracking(campusId);
            const today = (0, moment_timezone_1.default)().tz(timeZone).startOf('day');
            const proformasTracking = [];
            if (!config || !config.stateAlert)
                return [];
            const verifyExist = (proformaQuoteId) => {
                return proformasTracking.some(p => p.proformaQuoteId === proformaQuoteId);
            };
            for (const proforma of proformas) {
                const dateMaintenance = (0, moment_timezone_1.default)(proforma.trackingDate)
                    .startOf('day'); // Fecha de mantenimiento calculada
                const previousDays = this.getPreviousDays(dateMaintenance.toDate(), config.previousDays);
                const nextDays = this.getNextDays(dateMaintenance.toDate(), config.daysLater);
                // Verificar si hoy es la fecha exacta de mantenimiento
                if (today.isSame(dateMaintenance, 'day') && !verifyExist(proforma.proformaQuoteId)) {
                    proformasTracking.push(proforma);
                }
                // Verificar si hoy está dentro del rango de días anteriores
                if (previousDays.some(day => (0, moment_timezone_1.default)(day).startOf('day').isSame(today))) {
                    if (!verifyExist(proforma.proformaQuoteId)) {
                        proformasTracking.push(proforma);
                    }
                }
                // Verificar si hoy está dentro del rango de días posteriores
                if (nextDays.some(day => (0, moment_timezone_1.default)(day).startOf('day').isSame(today))) {
                    if (!verifyExist(proforma.proformaQuoteId)) {
                        proformasTracking.push(proforma);
                    }
                }
            }
            return proformasTracking;
        });
    }
    // Obtennemos todo los registros que tiene la opcion de seguimiento
    getProformasTracking(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return models_1.ProformaQuoteModel.find({
                    where: {
                        campusId,
                        isTracking: true,
                    },
                    relations: {
                        client: true,
                    },
                    select: {
                        client: {
                            clientId: true,
                            fullname: true,
                            phone: true,
                        }
                    }
                });
            }
            catch (error) {
                save_error_1.logger.error(error);
            }
        });
    }
    // Obtennemos todo los registros que tiene la opcion de seguimiento
    getSchedulesCreditTracking(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return models_1.CreditScheduleModel.find({
                    where: {
                        credit: {
                            campusId
                        },
                    },
                    relations: {
                        credit: {
                            client: true
                        }
                    },
                    select: {
                        credit: {
                            client: {
                                clientId: true,
                                fullname: true,
                                phone: true,
                            }
                        }
                    }
                });
            }
            catch (error) {
                save_error_1.logger.error(error);
            }
        });
    }
    // Obtenemos servicios con falta de entregar
    getServicesTracking(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const services = yield models_1.ServiceModel.find({
                    where: {
                        campusId,
                        state: (0, typeorm_1.In)([parameter_constant_1.StatusService.POR_ENTREGAR]),
                        deletedAt: '0'
                    },
                    relations: {
                        userTechnical: true,
                        client: true
                    },
                    select: {
                        client: {
                            fullname: true
                        },
                        userTechnical: {
                            name: true,
                        }
                    }
                });
                return services;
            }
            catch (error) {
                save_error_1.logger.error(error);
            }
        });
    }
    //#endregion  
    //#region WHATSAPP
    schedule(companyId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            const company = yield company_service_1.companyService.findOneCompany(companyId);
            //await this.sendAlert(companyId, campusId)       
            yield this.scheduleSalesTracking(companyId, campusId, company.timeZone);
            yield this.scheduleCreditTracking(companyId, campusId, company.timeZone);
            yield this.scheduleProformaTracking(companyId, campusId, company.timeZone);
            const key = `${companyId}_${campusId}`;
            const keyReprograming = `${key}_reprograming`;
            const taskIndexSales = this.getTask().findIndex(task => task.key === keyReprograming);
            if (taskIndexSales !== -1) {
                this.getTask()[taskIndexSales].cronJob.stop();
                this.getTask().splice(taskIndexSales, 1);
            }
            const verificationJob = node_cron_1.default.schedule('0 0 * * *', () => __awaiter(this, void 0, void 0, function* () {
                yield this.scheduleSalesTracking(companyId, campusId, company.timeZone);
                yield this.scheduleCreditTracking(companyId, campusId, company.timeZone);
                yield this.scheduleProformaTracking(companyId, campusId, company.timeZone);
            }), { timezone: company.timeZone });
            this.addTask([{
                    key: keyReprograming,
                    cronJob: verificationJob
                }]);
            this.getTask().forEach(element => {
                console.log(element.key);
            });
        });
    }
    scheduleAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const companys = yield company_service_1.companyService.findAllCompany();
            let count = 0;
            for (const company of companys) {
                const campus = yield campus_service_1.campusService.findAllCampus(company.companyId);
                for (const c of campus) {
                    yield this.sendAlert(company.companyId, c.campusId);
                    yield this.schedule(company.companyId, c.campusId);
                    count++;
                }
            }
            console.log('Total processed:', count);
            this.getTask().forEach(element => {
                console.log(element.key);
            });
        });
    }
    scheduleSalesTracking(companyId, campusId, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            const salesTracking = yield salesTracking_service_1.salesTrackingService.findSalesTracking(companyId, campusId);
            const config = yield configSalesTracking_service_1.configSalesTrackingService.findConfigSalesTracking(campusId);
            const key = `${companyId}_${campusId}`;
            if (!config || !config.state)
                return;
            const today = (0, moment_timezone_1.default)().tz(timeZone).startOf('day');
            const newTasks = [];
            for (const tracking of salesTracking) {
                if (!tracking.product.isMaintenance)
                    continue;
                const trackingDate = (0, moment_timezone_1.default)(tracking.regDate).add(tracking.product.maintenance, 'month').toDate();
                const previousDays = this.getPreviousDays(trackingDate, config.previousDays);
                const nextDays = this.getNextDays(trackingDate, config.daysLater);
                const shouldSchedule = (0, moment_timezone_1.default)().isSame(trackingDate, 'day') ||
                    previousDays.some(day => (0, moment_timezone_1.default)(day).isSame(today, 'day')) ||
                    nextDays.some(day => (0, moment_timezone_1.default)(day).isSame(today, 'day'));
                if (shouldSchedule) {
                    config.hours.forEach(time => {
                        const keySales = `${key}_sales_schedule_${time}`;
                        const taskIndexSales = this.getTask().findIndex(task => task.key === keySales);
                        if (taskIndexSales === -1) {
                            const [hour, minute] = time.split(':');
                            const job = node_cron_1.default.schedule(`${minute} ${hour} * * *`, () => __awaiter(this, void 0, void 0, function* () {
                                // Lógica para envío masivo
                                const employes = yield employeTracking_service_1.employeTrackingService.findEmployeTracking(campusId, models_1.EmployeTrackingType.sales);
                                for (const employe of employes) {
                                    if (employe.employe.cellPhone) {
                                        yield this.sendMessageWhatsapp(employe.employe.cellPhone, config.message, config.campus.company.uuid);
                                    }
                                }
                                yield this.sendMessageWhatsapp(tracking.client.phone, config.message, config.campus.company.uuid);
                            }), { timezone: timeZone });
                            newTasks.push({ key: keySales, cronJob: job });
                        }
                    });
                }
            }
            // Agregar nuevas tareas al programador
            this.addTask(newTasks);
        });
    }
    scheduleProformaTracking(companyId, campusId, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            const proformas = yield this.getProformasTracking(campusId);
            const config = yield proformaConfigTracking_service_1.proformaConfigTrackingService.findProformaConfigTracking(campusId);
            const key = `${companyId}_${campusId}`;
            if (!config || !config.state)
                return;
            const today = (0, moment_timezone_1.default)().tz(timeZone).startOf('day');
            const newTasks = [];
            for (const proforma of proformas) {
                if (!proforma.isTracking)
                    continue;
                const trakingDate = (0, moment_timezone_1.default)(proforma.trackingDate).toDate();
                const previousDays = this.getPreviousDays(trakingDate, config.previousDays);
                const nextDays = this.getNextDays(trakingDate, config.daysLater);
                const shouldSchedule = (0, moment_timezone_1.default)().isSame(trakingDate, 'day') ||
                    previousDays.some(day => (0, moment_timezone_1.default)(day).isSame(today, 'day')) ||
                    nextDays.some(day => (0, moment_timezone_1.default)(day).isSame(today, 'day'));
                if (shouldSchedule) {
                    config.hours.forEach(time => {
                        const keyProforma = `${key}_proforma_schedule_${time}`;
                        const taskIndexProforma = newTasks.findIndex(task => task.key === keyProforma);
                        if (taskIndexProforma === -1) {
                            const [hour, minute] = time.split(':');
                            const pauseJob = node_cron_1.default.schedule(`${minute} ${hour} * * *`, () => __awaiter(this, void 0, void 0, function* () {
                                var _a;
                                const employes = yield employeTracking_service_1.employeTrackingService.findEmployeTracking(campusId, models_1.EmployeTrackingType.proforma);
                                for (const employe of employes) {
                                    if (employe.employe.cellPhone) {
                                        yield this.sendMessageWhatsapp(employe.employe.cellPhone, config.messageEmploye, config.campus.company.uuid);
                                    }
                                }
                                if ((_a = proforma.client) === null || _a === void 0 ? void 0 : _a.phone) {
                                    yield this.sendMessageWhatsapp(proforma.client.phone, config.message, config.campus.company.uuid);
                                }
                            }), { timezone: timeZone });
                            newTasks.push({ key: keyProforma, cronJob: pauseJob });
                        }
                    });
                }
            }
            // Add new tasks to the schedule
            this.addTask(newTasks);
        });
    }
    scheduleCreditTracking(companyId, campusId, timeZone) {
        return __awaiter(this, void 0, void 0, function* () {
            const schedules = yield this.getSchedulesCreditTracking(campusId);
            const config = yield creditConfigTracking_service_1.creditConfigTrackingService.findCreditConfigTracking(campusId);
            const key = `${companyId}_${campusId}`;
            if (!config || !config.state)
                return;
            const today = (0, moment_timezone_1.default)().tz(timeZone).startOf('day');
            const newTasks = [];
            for (const credit of schedules) {
                // if (!credit.isTracking) continue;
                const dueDateCredit = (0, moment_timezone_1.default)(credit.dueDate).toDate();
                const previousDays = this.getPreviousDays(dueDateCredit, config.previousDays);
                const nextDays = this.getNextDays(dueDateCredit, config.daysLater);
                const shouldSchedule = (0, moment_timezone_1.default)().isSame(dueDateCredit, 'day') ||
                    previousDays.some(day => (0, moment_timezone_1.default)(day).isSame(today, 'day')) ||
                    nextDays.some(day => (0, moment_timezone_1.default)(day).isSame(today, 'day'));
                if (shouldSchedule) {
                    config.hours.forEach(time => {
                        const keyCredit = `${key}_credit_${time}`;
                        const taskIndexProforma = newTasks.findIndex(task => task.key === keyCredit);
                        if (taskIndexProforma === -1) {
                            const [hour, minute] = time.split(':');
                            const pauseJob = node_cron_1.default.schedule(`${minute} ${hour} * * *`, () => __awaiter(this, void 0, void 0, function* () {
                                var _a, _b;
                                const employes = yield employeTracking_service_1.employeTrackingService.findEmployeTracking(campusId, models_1.EmployeTrackingType.proforma);
                                for (const employe of employes) {
                                    if (employe.employe.cellPhone) {
                                        yield this.sendMessageWhatsapp(employe.employe.cellPhone, config.message, config.campus.company.uuid);
                                    }
                                }
                                const schedulesCredits = yield this.getSchedulesCreditTracking(campusId);
                                for (const schedule of schedulesCredits) {
                                    const phone = schedule.credit.client.phone;
                                    if (phone) {
                                        yield this.sendMessageWhatsapp(phone, config.messageEmploye, config.campus.company.uuid);
                                    }
                                }
                                if ((_b = (_a = credit.credit) === null || _a === void 0 ? void 0 : _a.client) === null || _b === void 0 ? void 0 : _b.phone) {
                                    yield this.sendMessageWhatsapp(credit.credit.client.phone, config.message, config.campus.company.uuid);
                                }
                            }), { timezone: timeZone });
                            newTasks.push({ key: keyCredit, cronJob: pauseJob });
                        }
                    });
                }
            }
            // Add new tasks to the schedule
            this.addTask(newTasks);
        });
    }
    sendMessageWhatsapp(phone, message, uuid) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield whatsapp_service_1.whatsappService.sendMessage(phone, message, uuid);
            }
            catch (error) {
                save_error_1.logger.error(error);
                return null;
            }
        });
    }
    //#endregion
    getPreviousDays(date, daysBefore) {
        const previousDays = [];
        for (let i = 1; i <= daysBefore; i++) {
            previousDays.push((0, moment_timezone_1.default)(date).subtract(i, 'days').toDate());
        }
        return previousDays;
    }
    getNextDays(date, daysAfter) {
        const nextDays = [];
        for (let i = 1; i <= daysAfter; i++) {
            nextDays.push((0, moment_timezone_1.default)(date).add(i, 'days').toDate());
        }
        return nextDays;
    }
}
exports.scheduleSalesService = ScheduleSalesService.getInstance();
//# sourceMappingURL=scheduleSales.service.js.map