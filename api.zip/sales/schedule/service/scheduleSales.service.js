"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleSalesService = void 0;
const webSocketService_1 = require("../../../socket/webSocketService");
const node_cron_1 = __importDefault(require("node-cron"));
const salesTracking_service_1 = require("../../salesTracking/service/salesTracking.service");
const company_service_1 = require("../../../company/company/service/company.service");
const configSalesTracking_service_1 = require("../../configSalesTracking/service/configSalesTracking.service");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const save_error_1 = require("../../../common/handler/save.error");
class ScheduleSalesService {
    constructor() {
        this.tasks = [];
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ScheduleSalesService();
        return this.instance;
    }
    getTask() {
        return this.tasks;
    }
    addTask(tasks) {
        this.tasks.push(...tasks);
    }
    cancelAlertSchedule(companyId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const key = `${companyId}_${campusId}`;
                const keyAlertSales = `${key}_sales_alert`;
                yield configSalesTracking_service_1.configSalesTrackingService.toggleStateAlert(campusId, false);
                const taskIndexAlertSales = this.getTask().findIndex(task => task.key === keyAlertSales);
                // Detener y eliminar la tarea existente si ya existe
                if (taskIndexAlertSales !== -1) {
                    this.getTask()[taskIndexAlertSales].cronJob.stop();
                    this.getTask().splice(taskIndexAlertSales, 1);
                }
                return true;
            }
            catch (error) {
                save_error_1.logger.error(`Error in cancelSchedule: ${error.message}`);
                return false;
            }
        });
    }
    sendAlert(companyId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const key = `${companyId}_${campusId}`;
                const keyAlertSales = `${key}_sales_alert`;
                const taskIndexAlertSales = this.getTask().findIndex(task => task.key === keyAlertSales);
                // Detener y eliminar la tarea existente si ya existe
                if (taskIndexAlertSales !== -1) {
                    this.getTask()[taskIndexAlertSales].cronJob.stop();
                    this.getTask().splice(taskIndexAlertSales, 1);
                }
                // Obtener las ventas de seguimiento del día actual
                const salesTrackings = yield salesTracking_service_1.salesTrackingService.findSalesTrackingToday(companyId, campusId);
                const company = yield company_service_1.companyService.findOneCompany(companyId);
                const configTrackingSales = yield configSalesTracking_service_1.configSalesTrackingService.findConfigSalesTracking(campusId);
                if (!configTrackingSales.stateAlert)
                    return;
                const today = (0, moment_timezone_1.default)().tz(company.timeZone).startOf('day'); // Inicio del día en la zona horaria de la compañía
                const salesTrackingAlert = [];
                // Función para verificar si el seguimiento de ventas ya está en la lista de alertas
                const verifyExist = (salesTrackingId) => {
                    return salesTrackingAlert.some(p => p.salesTrackingId === salesTrackingId);
                };
                // Procesar cada seguimiento de ventas
                for (const tracking of salesTrackings) {
                    const dateMaintenance = (0, moment_timezone_1.default)(tracking.regDate)
                        .add(tracking.product.maintenance, 'months')
                        .startOf('day'); // Fecha de mantenimiento calculada
                    const previousDays = this.getPreviousDays(dateMaintenance.toDate(), configTrackingSales.previousDays);
                    const nextDays = this.getNextDays(dateMaintenance.toDate(), configTrackingSales.daysLater);
                    // Verificar si hoy es la fecha exacta de mantenimiento
                    if (today.isSame(dateMaintenance, 'day') && !verifyExist(tracking.salesTrackingId)) {
                        salesTrackingAlert.push(tracking);
                    }
                    // Verificar si hoy está dentro del rango de días anteriores
                    if (previousDays.some(day => (0, moment_timezone_1.default)(day).startOf('day').isSame(today))) {
                        if (!verifyExist(tracking.salesTrackingId)) {
                            salesTrackingAlert.push(tracking);
                        }
                    }
                    // Verificar si hoy está dentro del rango de días posteriores
                    if (nextDays.some(day => (0, moment_timezone_1.default)(day).startOf('day').isSame(today))) {
                        if (!verifyExist(tracking.salesTrackingId)) {
                            salesTrackingAlert.push(tracking);
                        }
                    }
                }
                // Si hay alertas de seguimiento de ventas, iniciar el cron job
                if (salesTrackingAlert.length > 0) {
                    const sendAlertJob = node_cron_1.default.schedule('* * * * *', () => {
                        webSocketService_1.webSocketService.alertSalesTracking(companyId, campusId, salesTrackingAlert);
                    });
                    // Añadir la tarea programada a la lista de tareas activas
                    this.addTask([{ key: keyAlertSales, cronJob: sendAlertJob }]);
                }
            }
            catch (error) {
                save_error_1.logger.error(`Error in sendAlert: ${error.message}`);
            }
        });
    }
    getPreviousDays(date, daysBefore) {
        const previousDays = [];
        for (let i = 1; i <= daysBefore; i++) {
            previousDays.push((0, moment_timezone_1.default)(date).subtract(i, 'days').toDate());
        }
        return previousDays;
    }
    getNextDays(date, daysAfter) {
        const nextDays = [];
        for (let i = 1; i <= daysAfter; i++) {
            nextDays.push((0, moment_timezone_1.default)(date).add(i, 'days').toDate());
        }
        return nextDays;
    }
}
exports.scheduleSalesService = ScheduleSalesService.getInstance();
//# sourceMappingURL=scheduleSales.service.js.map