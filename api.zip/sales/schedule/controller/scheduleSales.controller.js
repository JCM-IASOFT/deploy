"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleSalesController = void 0;
const http_status_codes_1 = require("http-status-codes");
const node_cron_1 = __importDefault(require("node-cron"));
const message_api_1 = require("../../../common/constant/message.api");
const save_error_1 = require("../../../common/handler/save.error");
const scheduleSales_service_1 = require("../service/scheduleSales.service");
const salesTracking_service_1 = require("../../salesTracking/service/salesTracking.service");
const configSalesTracking_service_1 = require("../../configSalesTracking/service/configSalesTracking.service");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const whatsapp_service_1 = require("../../../whatsapp/service/whatsapp.service");
class ScheduleSalesController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ScheduleSalesController();
        return this.instance;
    }
    /**
     * Programar pausa y reanudación de servicios
     */
    scheduleSales(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId, campusId } = req.body;
                const salesTracking = yield salesTracking_service_1.salesTrackingService.findSalesTracking(companyId, campusId);
                const configSalesTracking = yield configSalesTracking_service_1.configSalesTrackingService.findConfigSalesTracking(campusId);
                const key = `${companyId}_${campusId}`;
                // webSocketService.changePauseService(companyId, campusId);
                const keySales = `${key}_sales`;
                const taskIndexSales = scheduleSales_service_1.scheduleSalesService.getTask().findIndex(task => task.key === keySales);
                if (taskIndexSales !== -1) {
                    scheduleSales_service_1.scheduleSalesService.getTask()[taskIndexSales].cronJob.stop();
                    scheduleSales_service_1.scheduleSalesService.getTask().splice(taskIndexSales, 1);
                }
                const newTasks = [];
                for (const traking of salesTracking) {
                    if (traking.product.isMaintenance) {
                        const datemMaintenance = (0, moment_timezone_1.default)(traking.regDate).add(traking.product.maintenance, 'month').toDate();
                        if ((0, moment_timezone_1.default)().isSame(datemMaintenance, 'day')) {
                            if (configSalesTracking.stateAlert) {
                                yield scheduleSales_service_1.scheduleSalesService.sendAlert(companyId, campusId);
                            }
                            configSalesTracking.hours.forEach(element => {
                                const [hour, minute] = element.split(':');
                                const pauseJob = node_cron_1.default.schedule(`${minute} ${hour} * * *`, () => __awaiter(this, void 0, void 0, function* () {
                                    const clientPhone = traking.client.phone;
                                    const message = configSalesTracking.message;
                                    const clientId = configSalesTracking.campus.company.uuid;
                                    const responseWa = yield whatsapp_service_1.whatsappService.sendMessage(clientPhone, message, clientId);
                                    if (responseWa.success) {
                                        save_error_1.logger.info("enviando mensaje correctamente");
                                    }
                                }), {
                                    timezone: "America/Lima",
                                });
                                newTasks.push({ key: keySales, cronJob: pauseJob });
                            });
                        }
                    }
                }
                // Agregar nuevas tareas al array
                scheduleSales_service_1.scheduleSalesService.addTask(newTasks);
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    code: http_status_codes_1.StatusCodes.OK,
                    success: true,
                    message: message_api_1.MessageCustomApi.SETTING_SCHEDULE_SUCCESS,
                });
            }
            catch (error) {
                save_error_1.logger.error(`ScheduleSales controller: ${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    /**
     * Cancelar programacion
     */
    cancelAlertSchedule(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId, campusId } = req.body;
                const response = scheduleSales_service_1.scheduleSalesService.cancelAlertSchedule(companyId, campusId);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.SCHEDULE_CALCEL_SUCCESS });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: message_api_1.MessageCustomApi.SCHEDULE_CALCEL_ERROR });
                }
            }
            catch (error) {
                save_error_1.logger.error(`Error in cancelSchedule: controller${error.message}`);
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    scheduleSalesInitalExecute() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const configSalesTrackings = yield configSalesTracking_service_1.configSalesTrackingService.findAllConfigSalesTracking();
                for (const config of configSalesTrackings) {
                    if (!config.state)
                        continue; // Si el estado es falso, salta al siguiente registro
                    const companyId = config.campus.company.companyId;
                    const campusId = config.campus.campusId;
                    const salesTracking = yield salesTracking_service_1.salesTrackingService.findSalesTracking(companyId, campusId);
                    const key = `${companyId}_${campusId}`;
                    const keySales = `${key}_sales`;
                    // Detener y eliminar la tarea existente si ya está programada
                    const taskIndexSales = scheduleSales_service_1.scheduleSalesService.getTask().findIndex(task => task.key === keySales);
                    if (taskIndexSales !== -1) {
                        scheduleSales_service_1.scheduleSalesService.getTask()[taskIndexSales].cronJob.stop();
                        scheduleSales_service_1.scheduleSalesService.getTask().splice(taskIndexSales, 1);
                    }
                    const newTasks = [];
                    for (const tracking of salesTracking) {
                        if (tracking.product.isMaintenance) {
                            const dateMaintenance = (0, moment_timezone_1.default)(tracking.regDate).add(tracking.product.maintenance, 'month').toDate();
                            // Verificar si la fecha de mantenimiento es hoy
                            if ((0, moment_timezone_1.default)().isSame(dateMaintenance, 'day')) {
                                if (config.stateAlert) {
                                    yield scheduleSales_service_1.scheduleSalesService.sendAlert(companyId, campusId);
                                }
                                config.hours.forEach((element) => __awaiter(this, void 0, void 0, function* () {
                                    const [hour, minute] = element.split(':');
                                    const pauseJob = node_cron_1.default.schedule(`${minute} ${hour} * * *`, () => __awaiter(this, void 0, void 0, function* () {
                                        const clientPhone = tracking.client.phone;
                                        const message = config.message;
                                        const clientId = config.campus.company.uuid;
                                        const responseWa = yield whatsapp_service_1.whatsappService.sendMessage(clientPhone, message, clientId);
                                        if (responseWa.success) {
                                            save_error_1.logger.info("enviando mensaje correctamente");
                                        }
                                    }), {
                                        timezone: "America/Lima",
                                    });
                                    newTasks.push({ key: keySales, cronJob: pauseJob });
                                }));
                            }
                        }
                    }
                    // Agregar nuevas tareas al array
                    scheduleSales_service_1.scheduleSalesService.addTask(newTasks);
                }
            }
            catch (error) {
                save_error_1.logger.error(`ScheduleSales controller: ${error.message}`);
            }
        });
    }
}
exports.scheduleSalesController = ScheduleSalesController.getInstance();
//# sourceMappingURL=scheduleSales.controller.js.map