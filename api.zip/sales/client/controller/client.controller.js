"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientController = void 0;
const http_status_codes_1 = require("http-status-codes");
const client_service_1 = require("../service/client.service");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
class ClientController {
    constructor() {
        /**
        * Busca un cliente por DNI y companyId.
        * @param req - Objeto de solicitud de Express.
        * @param res - Objeto de respuesta de Express.
        * @returns Promise<void>
        */
        this.searchByDni = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { documentNumber, companyId } = req.query;
                if (!documentNumber || !companyId) {
                    res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json({
                        error: 'Se requieren los parámetros "documentNumber" y "companyId".'
                    });
                    return;
                }
                const client = yield client_service_1.clientService.searchByDni(documentNumber, Number(companyId));
                res.status(http_status_codes_1.StatusCodes.OK).json(client);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ error: error.message });
            }
        });
        this.createClient = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield client_service_1.clientService.createClient(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_CLIENT, data: response };
            }));
        });
        this.updateClient = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { clients } = req.body;
                    const response = yield client_service_1.clientService.updateClient(clients);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_CLIENT, data: response };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
        this.updatePhoneClient = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield client_service_1.clientService.updateClient(req.body);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATE_PHONE_SUCCES_CLIENT, data: response };
            }));
        });
        this.addReferenceNumberPhoneClient = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield client_service_1.clientService.addReferenceNumberPhoneClient(req.body);
                if (response) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATE_REFERENCE_PHONE_SUCCES_CLIENT, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER, data: response };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ClientController();
        return this.instance;
    }
    findDataTableClient(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { page, sizePage, client } = req.body;
                const findClients = yield client_service_1.clientService.findDataTableClient(page, sizePage, client);
                const clients = findClients ? findClients.clients : [];
                const total = findClients ? findClients.total : 0;
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    data: clients,
                    draw: Math.random(),
                    recordsFiltered: clients.length,
                    recordsTotal: total,
                });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findClient(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId } = req.query;
                const findClients = yield client_service_1.clientService.findClient(Number(companyId));
                res.status(http_status_codes_1.StatusCodes.OK).json(findClients);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    deleteClient(req, res) {
        (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
            try {
                const { clientId } = req.params;
                const response = yield client_service_1.clientService.deleteClient(Number(clientId));
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_CLIENT, data: response };
            }
            catch (error) {
                return {
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                };
            }
        }));
    }
}
exports.clientController = ClientController.getInstance();
//# sourceMappingURL=client.controller.js.map