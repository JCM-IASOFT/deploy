"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateAddReferencePhoneClient = exports.validateUpdateNumberPhoneClient = exports.validateCreateClient = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateClient = [
    (0, express_validator_1.check)('fullname').exists().not().isEmpty(),
    (0, express_validator_1.check)('documentNumber').exists(),
    (0, express_validator_1.check)('phone').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateNumberPhoneClient = [
    (0, express_validator_1.check)('clientId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('phone').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateAddReferencePhoneClient = [
    (0, express_validator_1.check)('clientId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('referencePhone').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=client.validator.js.map