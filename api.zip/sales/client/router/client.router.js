"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientRoute = void 0;
const express_1 = require("express");
const client_controller_1 = require("../controller/client.controller");
const client_validator_1 = require("../validator/client.validator");
exports.clientRoute = (0, express_1.Router)();
exports.clientRoute.get('/', client_controller_1.clientController.findClient);
exports.clientRoute.post('/dataTable', client_controller_1.clientController.findDataTableClient);
exports.clientRoute.get('/searchDni', client_controller_1.clientController.searchByDni);
exports.clientRoute.post('/add', client_validator_1.validateCreateClient, client_controller_1.clientController.createClient);
exports.clientRoute.post('/updatephone', client_validator_1.validateUpdateNumberPhoneClient, client_controller_1.clientController.updatePhoneClient);
exports.clientRoute.post('/updatephonereference', client_validator_1.validateAddReferencePhoneClient, client_controller_1.clientController.addReferenceNumberPhoneClient);
exports.clientRoute.put('/update', client_controller_1.clientController.updateClient);
exports.clientRoute.put('/delete/:clientId', client_controller_1.clientController.deleteClient);
//# sourceMappingURL=client.router.js.map