"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientService = void 0;
const bycrypt_handler_1 = require("../../../common/handler/bycrypt.handler");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const models_1 = require("models");
class ClientService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ClientService();
        return this.instance;
    }
    findDataTableClient(page, sizePage, client) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const clientBuilder = models_1.ClientModel.createQueryBuilder('client')
                    .leftJoin('client.clientType', 'clientType')
                    .leftJoin('client.district', 'district')
                    .leftJoin('district.province', 'province')
                    .leftJoin('province.departament', 'departament')
                    .leftJoin('departament.country', 'country')
                    .leftJoin('client.documentType', 'documentType')
                    .where('client.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('client.companyId = :companyId', { companyId: client.companyId });
                if (client.clientTypeId && client.clientTypeId > 0) {
                    clientBuilder.andWhere('client.clientTypeId = :clientTypeId', { clientTypeId: client.clientTypeId });
                }
                if (client.fullname && client.fullname !== "") {
                    clientBuilder.andWhere("client.fullname ILIKE :fullname", { fullname: `%${client.fullname}%` });
                }
                if (client.documentNumber && client.documentNumber !== '') {
                    clientBuilder.andWhere('client.documentNumber ILIKE :documentNumber', { documentNumber: `%${client.documentNumber}%` });
                }
                if (client.phone && client.phone !== '') {
                    clientBuilder.andWhere("client.phone ILIKE :phone", { phone: `%${client.phone}%` });
                }
                if (client.referencePhone && client.referencePhone !== '') {
                    clientBuilder.andWhere("client.referencePhone ILIKE :referencePhone", { referencePhone: `%${client.referencePhone}%` });
                }
                if (client.email && client.email !== '') {
                    clientBuilder.andWhere("client.email ILIKE :email", { email: `%${client.email}%` });
                }
                if (client.address && client.address !== '') {
                    clientBuilder.andWhere("client.address ILIKE :address", { address: `%${client.address}%` });
                }
                clientBuilder.select([
                    'client.clientId',
                    'client.fullname',
                    'client.documentNumber',
                    'client.phone',
                    'client.referencePhone',
                    'client.email',
                    'client.address',
                    'client.companyId',
                    'client.clientTypeId',
                    'client.districtId',
                    'client.documentTypeId',
                    'clientType',
                    'district',
                    'documentType',
                    'province',
                    'departament',
                    'country'
                ]);
                const [clients, total] = yield clientBuilder.orderBy("client.fullname", "ASC")
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { clients, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findClient(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield models_1.ClientModel.find({
                    where: {
                        deletedAt: '0',
                        companyId: companyId
                    },
                    relations: {
                        clientType: true
                    }
                });
                return findResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    searchByDni(documentNumber, companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const clients = yield models_1.ClientModel.findOne({
                    where: {
                        documentNumber: documentNumber,
                        company: {
                            companyId: companyId,
                        },
                    }
                });
                return clients;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    createClient(clients) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (clients.password) {
                    const hashPassword = yield (0, bycrypt_handler_1.encrypt)(clients.password);
                    if (hashPassword) {
                        clients.password = hashPassword;
                    }
                }
                const response = yield models_1.ClientModel.save(clients);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateClient(clients) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const hashPassword = yield (0, bycrypt_handler_1.encrypt)(clients.password);
                if (hashPassword) {
                    clients.password = hashPassword;
                }
                const response = yield models_1.ClientModel.update({ clientId: clients.clientId }, {
                    address: clients.address,
                    documentNumber: clients.documentNumber,
                    fullname: clients.fullname,
                    email: clients.email,
                    phone: clients.phone,
                    referencePhone: clients.referencePhone,
                    receiveWhatsapp: clients.receiveWhatsapp,
                    companyId: clients.companyId,
                    districtId: clients.districtId,
                    documentTypeId: clients.documentTypeId,
                    clientTypeId: clients.clientTypeId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateNumberPhoneClient(client) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.ClientModel.update({ clientId: client.clientId }, { phone: client.phone });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    addReferenceNumberPhoneClient(client) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.ClientModel.update({ clientId: client.clientId }, { referencePhone: client.referencePhone });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteClient(clientId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const deleteResponse = yield models_1.ClientModel.update({ clientId: clientId }, {
                    deletedAt: '1'
                });
                return deleteResponse;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.clientService = ClientService.getInstance();
//# sourceMappingURL=client.service.js.map