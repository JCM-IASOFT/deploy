"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaQuoteRoute = void 0;
const express_1 = require("express");
const proformaQuote_controller_1 = require("../controller/proformaQuote.controller");
const proformaquote_validator_1 = require("../validator/proformaquote.validator");
exports.proformaQuoteRoute = (0, express_1.Router)();
exports.proformaQuoteRoute.get('/allForRange', proformaQuote_controller_1.proformaQuoteController.findProformaQuote);
exports.proformaQuoteRoute.get('/all', proformaQuote_controller_1.proformaQuoteController.findAllProformaQuotes);
exports.proformaQuoteRoute.get('/', proformaQuote_controller_1.proformaQuoteController.findAllProformaQuote);
exports.proformaQuoteRoute.get('/one', proformaQuote_controller_1.proformaQuoteController.findOneProformaQuote);
exports.proformaQuoteRoute.post('/create', proformaquote_validator_1.validateCreateProformaQuote, proformaQuote_controller_1.proformaQuoteController.createProformaQuotes);
exports.proformaQuoteRoute.put('/:proformaQuoteId', proformaquote_validator_1.validateUpdateProformaQuote, proformaQuote_controller_1.proformaQuoteController.updateProformaQuote);
exports.proformaQuoteRoute.put('/state/:id', proformaquote_validator_1.validateUpdateStateProformaQuote, proformaQuote_controller_1.proformaQuoteController.updateStateProformaQuote);
exports.proformaQuoteRoute.post('/delete', proformaquote_validator_1.validateDeleteProformaQuote, proformaQuote_controller_1.proformaQuoteController.deleteProformaQuote);
//# sourceMappingURL=proformaQuote.router.js.map