"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteProformaQuote = exports.validateUpdateStateProformaQuote = exports.validateUpdateProformaQuote = exports.validateCreateProformaQuote = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateProformaQuote = [
    // check('proformaQuote.clientId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.campusId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.storeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.proformaQuoteTypeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.employeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.currencyId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.paymentTypeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.priceGroupId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.registrationDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.expirationDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.state').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.correlative').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateProformaQuote = [
    (0, express_validator_1.check)('proformaQuote.proformaQuoteId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.campusId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.storeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.proformaQuoteTypeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.employeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.currencyId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.paymentTypeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.priceGroupId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.registrationDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.expirationDate').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.state').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuote.correlative').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateStateProformaQuote = [
    (0, express_validator_1.check)('state').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteProformaQuote = [
    (0, express_validator_1.check)('proformaQuoteId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=proformaquote.validator.js.map