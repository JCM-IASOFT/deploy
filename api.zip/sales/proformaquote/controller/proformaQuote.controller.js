"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaQuoteController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const proformaQuoteDetail_service_1 = require("../../proformaquotedetail/service/proformaQuoteDetail.service");
const proformaquote_service_1 = require("../service/proformaquote.service");
const invoiceSerie_service_1 = require("../../../logistics/invoiceSerie/service/invoiceSerie.service");
class ProformaQuoteController {
    constructor() {
        this.findAllProformaQuote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId, timeZone, startDate, endDate } = req.query;
            const proformas = yield proformaquote_service_1.proformaQuoteService.findAllProformaQuote(campusId, timeZone, startDate, endDate);
            res.status(http_status_codes_1.StatusCodes.OK).json(proformas);
        });
        this.findProformaQuote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId, state } = req.query;
            const proformaQuotes = yield proformaquote_service_1.proformaQuoteService.findProformaQuote(Number(campusId), state);
            res.status(http_status_codes_1.StatusCodes.OK).json({
                data: proformaQuotes,
                draw: Math.random(),
                recordsFiltered: proformaQuotes.length,
                recordsTotal: proformaQuotes.length,
            });
            // res.status(StatusCodes.OK).json(proformaQuotes);
        });
        this.findAllProformaQuotes = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const proformas = yield proformaquote_service_1.proformaQuoteService.findProformaQuotes(campusId);
            res.status(http_status_codes_1.StatusCodes.OK).json(proformas);
        });
        this.findOneProformaQuote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { proformaQuoteId } = req.query;
            const proformaQuotes = yield proformaquote_service_1.proformaQuoteService.findOneProformaQuote(Number(proformaQuoteId));
            res.status(http_status_codes_1.StatusCodes.OK).json(proformaQuotes);
        });
        this.createProformaQuotes = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { proformaQuote, proformeQuoteDetails, invoiceSerie } = req.body;
                    let proformaQuoteId = 0;
                    if (!proformaQuote || !Array.isArray(proformeQuoteDetails) || !Array.isArray(proformeQuoteDetails)) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const savedProformaQuote = yield proformaquote_service_1.proformaQuoteService.createProformaQuote(proformaQuote, queryRunner);
                        if (!savedProformaQuote && savedProformaQuote.proformaQuoteId === 0) {
                            throw new Error(message_api_1.MessageCustomApi.ERROR_SERVER);
                        }
                        proformaQuoteId = savedProformaQuote.proformaQuoteId;
                        const proformaQuoteDetailProformaId = proformeQuoteDetails.map((proforma) => (Object.assign(Object.assign({}, proforma), { proformaQuoteId: proformaQuoteId })));
                        yield Promise.all(proformaQuoteDetailProformaId.map((proforma) => proformaQuoteDetail_service_1.proformaQuoteDetailService.createProformaQuoteDetail(proforma, queryRunner)));
                        yield invoiceSerie_service_1.invoiceSerieService.incrementNumberInvoiceSerie(invoiceSerie.invoiceSerieId, invoiceSerie.number, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.SALES_SUCCESS, data: savedProformaQuote };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.updateProformaQuote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const proformaQuoteId = req.params.proformaQuoteId;
                    const { proformaQuote, proformeQuoteDetails } = req.body;
                    if (!proformaQuote || !Array.isArray(proformeQuoteDetails) || !Array.isArray(proformeQuoteDetails)) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const updatedProformaQuote = yield proformaquote_service_1.proformaQuoteService.updateProformaQuote(proformaQuoteId, proformaQuote, queryRunner);
                        yield proformaQuoteDetail_service_1.proformaQuoteDetailService.deleteProformaQuoteDetail(proformaQuote.proformaQuoteId, queryRunner);
                        yield Promise.all(proformeQuoteDetails.map((proforma) => proformaQuoteDetail_service_1.proformaQuoteDetailService.createProformaQuoteDetail(proforma, queryRunner)));
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_PROFORMA_QUOTE, data: updatedProformaQuote };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.updateStateProformaQuote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const proformaQuoteId = req.params.id;
                    const { state } = req.body;
                    if (!proformaQuoteId || !state) {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const proforma = {
                            proformaQuoteId: Number(proformaQuoteId),
                            state: state
                        };
                        yield proformaquote_service_1.proformaQuoteService.updateStateProformaQuote(proforma, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATE_STATE_SUCCESS_PROFORMA };
                    }));
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
        this.deleteProformaQuote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield proformaquote_service_1.proformaQuoteService.deleteProformaQuote(req.body);
                if (response.affected > 0) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_DEVICE, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ProformaQuoteController();
        return this.instance;
    }
}
exports.proformaQuoteController = ProformaQuoteController.getInstance();
//# sourceMappingURL=proformaQuote.controller.js.map