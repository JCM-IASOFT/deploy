"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaQuoteService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
class ProformaQuoteService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProformaQuoteService();
        return this.instance;
    }
    findAllProformaQuote(campusId, timeZone, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (!startDate && !endDate) {
                    startDate = (0, moment_timezone_1.default)().tz(timeZone).format("YYYY-MM-DD");
                    endDate = (0, moment_timezone_1.default)().tz(timeZone).format("YYYY-MM-DD");
                }
                const proformaQueryBuilder = models_1.ProformaQuoteModel
                    .createQueryBuilder('proforma')
                    .leftJoinAndSelect("proforma.client", "client")
                    .leftJoinAndSelect("proforma.proformaQuoteType", "proformaQuoteType")
                    .leftJoinAndSelect("proforma.store", "store")
                    .leftJoinAndSelect("proforma.employe", "employe")
                    .leftJoinAndSelect("proforma.currency", "currency")
                    .leftJoinAndSelect("proforma.paymentType", "paymentType")
                    .leftJoinAndSelect("proforma.priceGroup", "priceGroup")
                    .leftJoinAndSelect("proforma.proformaQuoteDetails", "proformaQuoteDetails")
                    .leftJoinAndSelect("proformaQuoteDetails.product", "product")
                    .leftJoinAndSelect("product.category", "category")
                    .leftJoinAndSelect("product.brand", "brand")
                    .where('proforma.campusId = :campusId', { campusId })
                    .andWhere('proforma.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('DATE(proforma.registrationDate AT TIME ZONE :timeZone) BETWEEN :startDate AND :endDate', {
                    startDate: startDate,
                    endDate: endDate,
                    timeZone: timeZone
                })
                    .orderBy("proforma.proformaQuoteId", "DESC");
                const proformas = yield proformaQueryBuilder.getMany();
                return proformas;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findAllCountProformaQuoteDataTable(proformaFilter) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const proformaQueryBuilder = models_1.ProformaQuoteModel
                    .createQueryBuilder('proforma')
                    .where('proforma.campusId = :campusId', { campusId: proformaFilter.campusId })
                    .andWhere('proforma.deletedAt = :deletedAt', { deletedAt: '0' });
                if (proformaFilter.state && proformaFilter.state !== '0') {
                    proformaQueryBuilder.andWhere('proforma.state = :state', { state: proformaFilter.state });
                }
                if (proformaFilter.startDate && proformaFilter.endDate) {
                    proformaQueryBuilder.andWhere('proforma.registrationDate BETWEEN :startDate AND :endDate', { startDate: proformaFilter.startDate, endDate: proformaFilter.endDate });
                }
                if (proformaFilter.startDate && proformaFilter.endDate === undefined) {
                    proformaQueryBuilder.andWhere("'DATE(proforma.registrationDate AT TIME ZONE 'UTC') = DATE(:startDate AT TIME ZONE 'UTC')", { startDate: proformaFilter.startDate });
                }
                if (proformaFilter.proformaQuoteId && proformaFilter.proformaQuoteId > 0) {
                    proformaQueryBuilder.andWhere('proforma.proformaQuoteId = :proformaQuoteId', { proformaQuoteId: proformaFilter.proformaQuoteId });
                }
                if (proformaFilter.proformaQuoteType && proformaFilter.proformaQuoteType !== '') {
                    proformaQueryBuilder.andWhere('proformaQuoteType.description = :proformaQuoteType', { proformaQuoteType: proformaFilter.proformaQuoteType });
                }
                if (proformaFilter.like) {
                    proformaQueryBuilder.andWhere(builder => {
                        builder.where('proformaQuoteType.description = :proformaQuoteType', { proformaQuoteType: `%${proformaFilter.like}%` })
                            .orWhere('client.documentNumber = :documentNumber', { documentNumber: `%${proformaFilter.like}%` });
                        // .orWhere('proforma.state = :state', {state:  `%${proformaFilter.like}%`})
                    });
                }
                proformaQueryBuilder.leftJoinAndSelect("proforma.client", "client")
                    .leftJoinAndSelect("proforma.proformaQuoteType", "proformaQuoteType")
                    .leftJoinAndSelect("proforma.store", "store")
                    .leftJoinAndSelect("proforma.employe", "employe")
                    .leftJoinAndSelect("proforma.currency", "currency")
                    .leftJoinAndSelect("proforma.paymentType", "paymentType")
                    .leftJoinAndSelect("proforma.priceGroup", "priceGroup")
                    .leftJoinAndSelect("proforma.proformaQuoteDetails", "proformaQuoteDetails")
                    .leftJoinAndSelect("proformaQuoteDetails.product", "product")
                    .select("COUNT(*)", 'count');
                const proforma = yield proformaQueryBuilder.getRawOne();
                const allRow = Number(proforma.count);
                return allRow;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    findProformaQuotes(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const proformaQuotes = yield models_1.ProformaQuoteModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    },
                    relations: {
                        client: true,
                        store: true,
                        proformaQuoteType: true,
                        employe: true,
                        currency: true,
                        paymentType: true,
                        priceGroup: true,
                        proformaQuoteDetails: {
                            product: {
                                brand: true,
                                category: true,
                                subCategory: true
                            }
                        }
                    }
                });
                return proformaQuotes;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findProformaQuote(campusId, state) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const whereOption = {
                    deletedAt: '0', campusId: campusId
                };
                if (state && state !== '0') {
                    whereOption.state = state;
                }
                const proformaQuotes = yield models_1.ProformaQuoteModel.find({
                    where: whereOption,
                    relations: ["client", "store", "proformaQuoteType", "employe",
                        "currency", "paymentType", "priceGroup", "proformaQuoteDetails",
                        "proformaQuoteDetails.product"]
                });
                return proformaQuotes;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findOneProformaQuote(proformaQuoteId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const proformaQuotes = yield models_1.ProformaQuoteModel.findOne({
                    where: { deletedAt: '0', proformaQuoteId: proformaQuoteId },
                    // relations: ["client", "store", "proformaQuoteType", "employe", "campus", "currency",
                    //     "paymentType", "priceGroup", "proformaQuoteDetails", "proformaQuoteDetails.product",
                    //     "proformaQuoteDetails.product.unitMeasurement", "proformaQuoteDetails.product.brand"],
                    relations: {
                        client: {
                            district: {
                                province: {
                                    departament: true
                                }
                            }
                        },
                        store: true,
                        proformaQuoteType: true,
                        employe: true,
                        campus: true,
                        currency: true,
                        paymentType: true,
                        priceGroup: true,
                        proformaQuoteDetails: {
                            product: {
                                unitMeasurement: true,
                                brand: true
                            }
                        }
                    },
                    select: {
                        proformaQuoteId: true,
                        correlative: true,
                        registrationDate: true,
                        expirationDate: true,
                        observation: true,
                        client: {
                            clientId: true,
                            fullname: true,
                            documentNumber: true,
                            email: true,
                            phone: true,
                            referencePhone: true,
                            address: true,
                        },
                        campus: {
                            campusId: true,
                            name: true,
                            address: true,
                            phone: true,
                        },
                        store: {
                            storeId: true,
                            name: true,
                            address: true,
                        },
                        proformaQuoteType: {
                            proformaQuoteTypeId: true,
                            description: true,
                        },
                        employe: {
                            userId: true,
                            name: true,
                            fullname: true,
                            email: true,
                        },
                        currency: {
                            currencyId: true,
                            companyId: true,
                            code: true,
                            symbol: true,
                            currencyName: true,
                            countryName: true,
                        },
                        paymentType: {
                            paymentTypeId: true,
                            description: true,
                        },
                        priceGroup: {
                            priceGroupId: true,
                            name: true
                        },
                        proformaQuoteDetails: {
                            proformaQuoteDetailId: true,
                            proformaQuoteId: true,
                            productId: true,
                            amount: true,
                            price: true,
                            total: true,
                            product: {
                                productId: true,
                                code: true,
                                stock: true,
                                codes: {
                                    codeId: true,
                                    code: true
                                },
                                description: true,
                                brand: {
                                    brandId: true,
                                    name: true,
                                },
                                unitMeasurement: {
                                    unitMeasurementId: true,
                                    name: true
                                },
                                priceDistributor: true,
                                priceProduct: true,
                            }
                        }
                    }
                });
                return proformaQuotes;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    createProformaQuote(proformaQuotes, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const proformaQuotesEntity = models_1.ProformaQuoteModel.create(proformaQuotes);
                const response = yield queryRunner.manager.save(proformaQuotesEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateProformaQuote(proformaQuoteId, proformaQuotes, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.ProformaQuoteModel, { proformaQuoteId }, {
                    clientId: proformaQuotes.clientId,
                    storeId: proformaQuotes.storeId,
                    proformaQuoteTypeId: proformaQuotes.proformaQuoteTypeId,
                    employeId: proformaQuotes.employeId,
                    currencyId: proformaQuotes.currencyId,
                    paymentTypeId: proformaQuotes.paymentTypeId,
                    priceGroupId: proformaQuotes.priceGroupId,
                    registrationDate: proformaQuotes.registrationDate,
                    expirationDate: proformaQuotes.expirationDate,
                    state: proformaQuotes.state,
                    totalAmount: proformaQuotes.totalAmount,
                    totalPrice: proformaQuotes.totalPrice,
                    observation: proformaQuotes.observation
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateStateProformaQuote(proformaQuotes, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.ProformaQuoteModel, { proformaQuoteId: proformaQuotes.proformaQuoteId }, {
                    state: proformaQuotes.state,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteProformaQuote(proformaQuotes) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.ProformaQuoteModel.update({ proformaQuoteId: proformaQuotes.proformaQuoteId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.proformaQuoteService = ProformaQuoteService.getInstance();
//# sourceMappingURL=proformaquote.service.js.map