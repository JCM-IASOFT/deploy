"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesTrackingRoute = void 0;
const express_1 = require("express");
const salesTracking_controller_1 = require("../controller/salesTracking.controller");
exports.salesTrackingRoute = (0, express_1.Router)();
exports.salesTrackingRoute.get('/', salesTracking_controller_1.salesTrackingController.findSalesTracking);
exports.salesTrackingRoute.post('/toggle', salesTracking_controller_1.salesTrackingController.toggleState);
exports.salesTrackingRoute.put('/update', salesTracking_controller_1.salesTrackingController.updateSalesTracking);
exports.salesTrackingRoute.delete('/:salesTrackingId', salesTracking_controller_1.salesTrackingController.deleteSalesTracking);
//# sourceMappingURL=salesTracking.routes.js.map