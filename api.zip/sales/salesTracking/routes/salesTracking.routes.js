"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesTrackingRoute = void 0;
const express_1 = require("express");
const salesTracking_controller_1 = require("../controller/salesTracking.controller");
exports.salesTrackingRoute = (0, express_1.Router)();
exports.salesTrackingRoute.get('/', salesTracking_controller_1.salesTrackingController.findSalesTracking);
exports.salesTrackingRoute.post('/create', salesTracking_controller_1.salesTrackingController.createSalesTracking);
exports.salesTrackingRoute.put('/update', salesTracking_controller_1.salesTrackingController.updateSalesTracking);
exports.salesTrackingRoute.put('/delete', salesTracking_controller_1.salesTrackingController.deleteSalesTracking);
//# sourceMappingURL=salesTracking.routes.js.map