"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaConfigTrackingRoute = void 0;
const express_1 = require("express");
const proformaConfigTracking_controller_1 = require("../controller/proformaConfigTracking.controller");
exports.proformaConfigTrackingRoute = (0, express_1.Router)();
exports.proformaConfigTrackingRoute.get('/', proformaConfigTracking_controller_1.proformaConfigTrackingController.findProformaConfigTracking);
exports.proformaConfigTrackingRoute.post('/', proformaConfigTracking_controller_1.proformaConfigTrackingController.saveProformaConfigTrackings);
//# sourceMappingURL=proformaConfigTracking.router.js.map