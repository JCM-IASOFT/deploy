"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaConfigTrackingController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const proformaConfigTracking_service_1 = require("../service/proformaConfigTracking.service");
class ProformaConfigTrackingController {
    constructor() {
        this.findProformaConfigTracking = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const proformaConfigTrackings = yield proformaConfigTracking_service_1.proformaConfigTrackingService.findProformaConfigTracking(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(proformaConfigTrackings);
        });
        this.saveProformaConfigTrackings = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const response = yield proformaConfigTracking_service_1.proformaConfigTrackingService.saveProformaConfigTracking(req.body);
            if (response) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.SAVED_SUCCESS_CONFIG, data: response });
            }
            else {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: message_api_1.MessageCustomApi.SAVED_ERROR_CONFIG });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ProformaConfigTrackingController();
        return this.instance;
    }
}
exports.proformaConfigTrackingController = ProformaConfigTrackingController.getInstance();
//# sourceMappingURL=proformaConfigTracking.controller.js.map