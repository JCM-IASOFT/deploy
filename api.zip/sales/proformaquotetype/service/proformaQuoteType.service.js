"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaQuoteTypeService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class ProformaQuoteTypeService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProformaQuoteTypeService();
        return this.instance;
    }
    findProformaQuoteType(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.ProformaQuoteTypeModel.find({
                    where: {
                        campusId: campusId,
                        deletedAt: '0'
                    }
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createProformaQuoteType(proformaQuoteType) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = models_1.ProformaQuoteTypeModel.create({
                    campusId: proformaQuoteType.campusId,
                    description: proformaQuoteType.description,
                });
                return yield models_1.ProformaQuoteTypeModel.save(response);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateProformaQuoteType(proformaQuoteType) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.ProformaQuoteTypeModel.update({ proformaQuoteTypeId: proformaQuoteType.proformaQuoteTypeId }, {
                    campusId: proformaQuoteType.campusId,
                    description: proformaQuoteType.description
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteProformaQuoteType(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.ProformaQuoteTypeModel.update({ proformaQuoteTypeId: id }, {
                    deletedAt: '1'
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.proformaQuoteTypeService = ProformaQuoteTypeService.getInstance();
//# sourceMappingURL=proformaQuoteType.service.js.map