"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesService = void 0;
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const models_1 = require("models");
class SalesService {
    static getInstance() {
        if (!this.instance)
            this.instance = new SalesService();
        return this.instance;
    }
    findOneSales(salesId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const sales = yield models_1.SalesModel.findOne({
                    where: { salesId: salesId, deletedAt: '0' },
                    relations: ["client", "campus", "seller", "invoice", "paymentSales", "currency", "salesDetails", "salesFrees", "salesDetails.product"]
                });
                return sales;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findSales(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const sales = yield models_1.SalesModel.find({
                    where: { campusId: campusId, deletedAt: '0' },
                    relations: ["invoice", "currency"],
                    select: {
                        salesId: true,
                        date: true,
                        clientId: true,
                        sellerId: true,
                        campusId: true,
                        totalPayment: true,
                        invoiceId: true,
                        correlative: true,
                        change: true,
                        type: true,
                        state: true,
                        warehouseId: true,
                        observations: true,
                        invoice: {
                            invoiceId: true,
                            code: true,
                            name: true,
                        },
                        currency: {
                            currencyId: true,
                            code: true,
                            symbol: true,
                            currencyName: true
                        }
                    }
                });
                return sales;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findAllSales(salesfilter, page, sizePage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const serviceQueryBuilder = models_1.SalesModel.createQueryBuilder("sales")
                    .where("sales.campusId = :campusId", { campusId: salesfilter.campusId })
                    .andWhere("sales.deletedAt = :deletedAt", { deletedAt: '0' });
                if (salesfilter.startDate !== '' && salesfilter.endDate !== '') {
                    serviceQueryBuilder.andWhere("DATE(sales.date AT TIME ZONE :timeZone) BETWEEN :startDate AND :endDate", { startDate: salesfilter.startDate, endDate: salesfilter.endDate, timeZone: salesfilter.timeZone });
                }
                if (salesfilter.state && salesfilter.state !== '') {
                    serviceQueryBuilder.andWhere("sales.state = :state", { state: salesfilter.state });
                }
                serviceQueryBuilder.leftJoinAndSelect("sales.seller", "seller")
                    .leftJoinAndSelect("sales.invoice", "invoice")
                    .leftJoinAndSelect("sales.client", "client")
                    .leftJoinAndSelect("sales.paymentSales", "paymentSales")
                    .leftJoinAndSelect("sales.currency", "currency")
                    .leftJoinAndSelect("sales.salesDetails", "salesDetails")
                    .leftJoinAndSelect("sales.salesFrees", "salesFrees")
                    .leftJoinAndSelect("salesDetails.product", "product")
                    .leftJoinAndSelect("paymentSales.paymentType", "paymentType")
                    .select([
                    "sales.salesId",
                    "sales.date",
                    "sales.observations",
                    "sales.clientId",
                    "sales.sellerId",
                    "sales.type",
                    "sales.modality",
                    "sales.totalPayment",
                    "sales.invoiceId",
                    "sales.correlative",
                    "sales.change",
                    "sales.warehouseId",
                    "sales.state",
                    "seller.userId",
                    "seller.name",
                    "seller.fullname",
                    "seller.name",
                    "seller.fullname",
                    "paymentSales.paymentSalesId",
                    "paymentSales.amount",
                    "paymentSales.paymentTypeId",
                    "paymentType.paymentTypeId",
                    "paymentType.description",
                    "paymentType.type",
                    "paymentType.logo",
                    "client.clientId",
                    "client.fullname",
                    "client.documentNumber",
                    "client.email",
                    "invoice.code",
                    "invoice.name",
                    "currency.currencyId",
                    "currency.code",
                    "currency.symbol",
                    'currency.currencyName',
                    'salesDetails',
                    'product',
                    'salesFrees'
                ])
                    .orderBy("sales.salesId", "DESC")
                    .skip(omit)
                    .take(sizePage);
                const [sales, total] = yield serviceQueryBuilder.getManyAndCount();
                return { sales, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createSales(sales, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const salesEntity = models_1.SalesModel.create(sales);
                const response = yield queryRunner.manager.save(salesEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateSales(sales) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.SalesModel.update({ salesId: sales.salesId }, {
                    clientId: sales.campusId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteSales(salesId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.SalesModel, { salesId }, { state: 2 });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    changeStatus(sales) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.SalesModel.update({ salesId: sales.salesId }, {
                    state: sales.state,
                    observations: sales.observations
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.salesService = SalesService.getInstance();
//# sourceMappingURL=sales.service.js.map