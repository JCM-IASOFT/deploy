"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.priceGroupService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class PriceGroupService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PriceGroupService();
        return this.instance;
    }
    findPriceGroup(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const priceGroups = yield modelslibrary_1.PriceGroupModel.find({
                    where: {
                        campusId,
                        deletedAt: '0'
                    },
                    select: {
                        priceGroupId: true,
                        default: true,
                        name: true,
                    },
                    order: {
                        priceGroupId: 'ASC'
                    }
                });
                return priceGroups;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createPriceGroup(priceGroup) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.PriceGroupModel.save(priceGroup);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updatePriceGroup(priceGroupId, priceGroup) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.PriceGroupModel.update({ priceGroupId }, {
                    name: priceGroup.name
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deletePriceGroup(priceGroupId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.PriceGroupModel, { priceGroupId }, {
                    deletedAt: '1'
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.priceGroupService = PriceGroupService.getInstance();
//# sourceMappingURL=priceGroup.service.js.map