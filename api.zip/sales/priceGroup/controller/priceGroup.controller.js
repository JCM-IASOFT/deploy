"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.priceGroupController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const priceGroup_service_1 = require("../service/priceGroup.service");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const price_service_1 = require("../../price/service/price.service");
class PriceGroupController {
    constructor() {
        this.findPriceGroup = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const priceGroups = yield priceGroup_service_1.priceGroupService.findPriceGroup(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(priceGroups);
        });
        this.createPriceGroup = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield priceGroup_service_1.priceGroupService.createPriceGroup(req.body);
                if (response) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_BRAND, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.updatePriceGroup = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const priceGroupId = req.params.priceGroupId;
                    const priceGroup = req.body;
                    const response = yield priceGroup_service_1.priceGroupService.updatePriceGroup(Number(priceGroupId), priceGroup);
                    if (response) {
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_BRAND, data: response };
                    }
                    else {
                        return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                    }
                }
                catch (error) {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
        this.deletePriceGroup = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const priceGroupId = req.params.priceGroupId;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const response = yield priceGroup_service_1.priceGroupService.deletePriceGroup(Number(priceGroupId), queryRunner);
                        if (response.affected && response.affected > 0) {
                            yield price_service_1.priceService.deletePrice(Number(priceGroupId), queryRunner);
                        }
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_PRICE_GROUP };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new PriceGroupController();
        return this.instance;
    }
}
exports.priceGroupController = PriceGroupController.getInstance();
//# sourceMappingURL=priceGroup.controller.js.map