"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeletePriceGroup = exports.validateUpdatePriceGroup = exports.validateCreatePriceGroup = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreatePriceGroup = [
    (0, express_validator_1.check)('name').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdatePriceGroup = [
    (0, express_validator_1.check)('priceGroupId').exists().not().isEmpty(),
    (0, express_validator_1.check)('name').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeletePriceGroup = [
    (0, express_validator_1.check)('priceGroupId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=priceGroup.validator.js.map