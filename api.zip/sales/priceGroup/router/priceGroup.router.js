"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.priceGroupRoute = void 0;
const express_1 = require("express");
const priceGroup_controller_1 = require("../controller/priceGroup.controller");
const priceGroup_validator_1 = require("../validator/priceGroup.validator");
exports.priceGroupRoute = (0, express_1.Router)();
exports.priceGroupRoute.get('/', priceGroup_controller_1.priceGroupController.findPriceGroup);
exports.priceGroupRoute.post('/', priceGroup_validator_1.validateCreatePriceGroup, priceGroup_controller_1.priceGroupController.createPriceGroup);
exports.priceGroupRoute.put('/:priceGroupId', priceGroup_validator_1.validateUpdatePriceGroup, priceGroup_controller_1.priceGroupController.updatePriceGroup);
exports.priceGroupRoute.delete('/:priceGroupId', priceGroup_validator_1.validateDeletePriceGroup, priceGroup_controller_1.priceGroupController.deletePriceGroup);
//# sourceMappingURL=priceGroup.router.js.map