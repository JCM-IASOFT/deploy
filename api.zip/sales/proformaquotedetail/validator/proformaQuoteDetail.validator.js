"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteProformaQuoteDetail = exports.validateUpdateProformaQuoteDetail = exports.validateCreateProformaQuoteDetail = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateProformaQuoteDetail = [
    (0, express_validator_1.check)('proformaQuoteId').exists().not().isEmpty(),
    (0, express_validator_1.check)('productId').exists().not().isEmpty(),
    (0, express_validator_1.check)('amount').exists().not().isEmpty(),
    (0, express_validator_1.check)('price').exists().not().isEmpty(),
    (0, express_validator_1.check)('total').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateProformaQuoteDetail = [
    (0, express_validator_1.check)('proformaQuoteDetailId').exists().not().isEmpty(),
    (0, express_validator_1.check)('proformaQuoteId').exists().not().isEmpty(),
    (0, express_validator_1.check)('productId').exists().not().isEmpty(),
    (0, express_validator_1.check)('amount').exists().not().isEmpty(),
    (0, express_validator_1.check)('price').exists().not().isEmpty(),
    (0, express_validator_1.check)('total').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteProformaQuoteDetail = [
    (0, express_validator_1.check)('proformaQuoteDetailId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=proformaQuoteDetail.validator.js.map