"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaQuoteDetailRoute = void 0;
const express_1 = require("express");
const proformaQuoteDetail_controller_1 = require("../controller/proformaQuoteDetail.controller");
const proformaQuoteDetail_validator_1 = require("../validator/proformaQuoteDetail.validator");
exports.proformaQuoteDetailRoute = (0, express_1.Router)();
exports.proformaQuoteDetailRoute.get('/', proformaQuoteDetail_controller_1.proformaQuoteDetailController.findProformaQuoteDetail);
exports.proformaQuoteDetailRoute.put('/', proformaQuoteDetail_validator_1.validateUpdateProformaQuoteDetail, proformaQuoteDetail_controller_1.proformaQuoteDetailController.updateProformaQuoteDetail);
//# sourceMappingURL=proformaQuoteDetail.router.js.map