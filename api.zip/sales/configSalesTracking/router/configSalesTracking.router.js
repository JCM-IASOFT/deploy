"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configSalesTrackingRoute = void 0;
const express_1 = require("express");
const configSalesTracking_controller_1 = require("../controller/configSalesTracking.controller");
exports.configSalesTrackingRoute = (0, express_1.Router)();
exports.configSalesTrackingRoute.get('/', configSalesTracking_controller_1.configSalesTrackingController.findConfigSalesTracking);
exports.configSalesTrackingRoute.post('/', configSalesTracking_controller_1.configSalesTrackingController.saveConfigSalesTrackings);
//# sourceMappingURL=configSalesTracking.router.js.map