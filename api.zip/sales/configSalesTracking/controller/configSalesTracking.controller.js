"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.configSalesTrackingController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const configSalesTracking_service_1 = require("../service/configSalesTracking.service");
class ConfigSalesTrackingController {
    constructor() {
        this.findConfigSalesTracking = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.query;
            const configSalesTrackings = yield configSalesTracking_service_1.configSalesTrackingService.findConfigSalesTracking(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(configSalesTrackings);
        });
        this.saveConfigSalesTrackings = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const response = yield configSalesTracking_service_1.configSalesTrackingService.saveConfigSalesTracking(req.body);
            if (response) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.SAVED_SUCCESS_CONFIG, data: response });
            }
            else {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: message_api_1.MessageCustomApi.SAVED_ERROR_CONFIG });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ConfigSalesTrackingController();
        return this.instance;
    }
}
exports.configSalesTrackingController = ConfigSalesTrackingController.getInstance();
//# sourceMappingURL=configSalesTracking.controller.js.map