"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.typechangemoneyController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const typechangemoney_service_1 = require("../service/typechangemoney.service");
class TypeChangeMoneyController {
    constructor() {
        this.findTypeChangeMoney = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { date } = req.query;
            const typechangemoneys = yield typechangemoney_service_1.typechangemoneyService.findTypeChangeMoney(date);
            res.status(http_status_codes_1.StatusCodes.OK).json(typechangemoneys);
        });
        this.createTypeChangeMoneys = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const response = yield typechangemoney_service_1.typechangemoneyService.createTypeChangeMoney(req.body);
                if (response) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_TYPE_CHANGE_MONEY, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new TypeChangeMoneyController();
        return this.instance;
    }
}
exports.typechangemoneyController = TypeChangeMoneyController.getInstance();
//# sourceMappingURL=typechangemoney.controller.js.map