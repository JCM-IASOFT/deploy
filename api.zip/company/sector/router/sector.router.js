"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sectorRoute = void 0;
const express_1 = require("express");
const sector_controller_1 = require("../controller/sector.controller");
const sector_validator_1 = require("../validator/sector.validator");
exports.sectorRoute = (0, express_1.Router)();
exports.sectorRoute.get('/', sector_controller_1.sectorController.findSector);
exports.sectorRoute.post('/create', sector_validator_1.validateCreateSector, sector_controller_1.sectorController.createSectors);
exports.sectorRoute.put('/', sector_validator_1.validateUpdateSector, sector_controller_1.sectorController.updateSector);
exports.sectorRoute.delete('/', sector_validator_1.validateDeleteSector, sector_controller_1.sectorController.deleteSector);
//# sourceMappingURL=sector.router.js.map