"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.zoneRoute = void 0;
const express_1 = require("express");
const zone_controller_1 = require("../controller/zone.controller");
exports.zoneRoute = (0, express_1.Router)();
exports.zoneRoute.get('/findAll', zone_controller_1.zoneController.findZone);
exports.zoneRoute.post('/create', zone_controller_1.zoneController.createZone);
exports.zoneRoute.put('/update', zone_controller_1.zoneController.updateZone);
exports.zoneRoute.put('/delete/:zoneId', zone_controller_1.zoneController.deleteZone);
//# sourceMappingURL=zone.routes.js.map