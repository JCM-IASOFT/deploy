"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.zoneController = exports.ZoneController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const zone_service_1 = require("../service/zone.service");
class ZoneController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ZoneController();
        return this.instance;
    }
    findZone(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield zone_service_1.zoneService.findZone();
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    createZone(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { zone } = request.body;
                    const createResponse = yield zone_service_1.zoneService.createZone(zone);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_ZONE, data: createResponse };
                }
                catch (error) {
                    response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    });
                }
            }));
        });
    }
    updateZone(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { zone } = request.body;
                    const updateResponse = yield zone_service_1.zoneService.updateZone(zone);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_ZONE, data: updateResponse };
                }
                catch (error) {
                    response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    });
                }
            }));
        });
    }
    deleteZone(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { zoneId } = request.params;
                    const deleteResponse = yield zone_service_1.zoneService.deleteZone(Number(zoneId));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_ZONE, data: deleteResponse };
                }
                catch (error) {
                    response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    });
                }
            }));
        });
    }
}
exports.ZoneController = ZoneController;
exports.zoneController = ZoneController.getInstance();
//# sourceMappingURL=zone.controller.js.map