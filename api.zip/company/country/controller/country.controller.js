"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.countryController = exports.CountryController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const country_service_1 = require("../service/country.service");
class CountryController {
    static getInstance() {
        if (!this.instance)
            this.instance = new CountryController();
        return this.instance;
    }
    findCountryDatatable(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield country_service_1.countryService.findCountry();
                response.status(http_status_codes_1.StatusCodes.OK).json({
                    data: findResponse,
                    draw: Math.random(),
                    recordsFiltered: findResponse.length,
                    recordsTotal: findResponse.length,
                });
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findCountry(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield country_service_1.countryService.findCountry();
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
}
exports.CountryController = CountryController;
exports.countryController = CountryController.getInstance();
//# sourceMappingURL=country.controller.js.map