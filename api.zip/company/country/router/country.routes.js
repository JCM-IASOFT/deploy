"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.countryRoute = void 0;
const express_1 = require("express");
const country_controller_1 = require("../controller/country.controller");
exports.countryRoute = (0, express_1.Router)();
exports.countryRoute.get('/findAllD', country_controller_1.countryController.findCountryDatatable);
exports.countryRoute.get('/findAll', country_controller_1.countryController.findCountry);
//# sourceMappingURL=country.routes.js.map