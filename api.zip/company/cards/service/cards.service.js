"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cardsService = exports.CardsService = void 0;
const cards_1 = require("modelslibrary/src/entities/company/cards");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
class CardsService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CardsService();
        return this.instance;
    }
    findCards(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield cards_1.CardsModel.find({
                    where: {
                        companyId: companyId,
                        deletedAt: '0'
                    },
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    createCards(cards) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield cards_1.CardsModel.save(cards);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    updateCards(cards) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield cards_1.CardsModel.update({ cardId: cards.cardId }, {
                    description: cards.description,
                    comission: cards.comission,
                    companyId: cards.companyId,
                    status: cards.status
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    deleteCards(cardId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield cards_1.CardsModel.update({ cardId: cardId }, {
                    deletedAt: '1'
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
}
exports.CardsService = CardsService;
exports.cardsService = CardsService.getInstance();
//# sourceMappingURL=cards.service.js.map