"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cardsRoute = void 0;
const express_1 = require("express");
const cards_controller_1 = require("../controller/cards.controller");
exports.cardsRoute = (0, express_1.Router)();
exports.cardsRoute.get('/', cards_controller_1.cardsController.findCards);
exports.cardsRoute.post('/create', cards_controller_1.cardsController.createCards);
exports.cardsRoute.put('/update', cards_controller_1.cardsController.updateCards);
exports.cardsRoute.put('/delete/:cardId', cards_controller_1.cardsController.deleteCards);
//# sourceMappingURL=cards.routes.js.map