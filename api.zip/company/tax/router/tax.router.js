"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.taxRoute = void 0;
const express_1 = require("express");
const tax_controller_1 = require("../controller/tax.controller");
const tax_validator_1 = require("../validator/tax.validator");
exports.taxRoute = (0, express_1.Router)();
exports.taxRoute.get('/', tax_validator_1.validateFindTax, tax_controller_1.taxController.findTax);
//# sourceMappingURL=tax.router.js.map