"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.provinceController = exports.ProvinceController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const province_service_1 = require("../service/province.service");
/**
 * currency - divisa
 */
class ProvinceController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProvinceController();
        return this.instance;
    }
    findProvinceDatatable(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield province_service_1.provinceService.findProvince();
                response.status(http_status_codes_1.StatusCodes.OK).json({
                    data: findResponse,
                    draw: Math.random(),
                    recordsFiltered: findResponse.length,
                    recordsTotal: findResponse.length,
                });
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findProvince(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield province_service_1.provinceService.findProvince();
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findProvinceByDepartament(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { departamentId } = request.query;
                const findResponse = yield province_service_1.provinceService.findProvinceByDepartament(departamentId.toString());
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
}
exports.ProvinceController = ProvinceController;
exports.provinceController = ProvinceController.getInstance();
//# sourceMappingURL=province.controller.js.map