"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.provinceRoute = void 0;
const express_1 = require("express");
const province_controller_1 = require("../controller/province.controller");
exports.provinceRoute = (0, express_1.Router)();
exports.provinceRoute.get('/findAllD', province_controller_1.provinceController.findProvinceDatatable);
exports.provinceRoute.get('/findAll', province_controller_1.provinceController.findProvince);
exports.provinceRoute.get('/departament', province_controller_1.provinceController.findProvinceByDepartament);
//# sourceMappingURL=province.routes.js.map