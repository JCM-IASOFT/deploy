"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.campusService = void 0;
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
class CampusService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CampusService();
        return this.instance;
    }
    findAllCampus(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const campus = yield modelslibrary_1.CampusModel.find({
                    where: {
                        company: {
                            companyId: companyId
                        },
                        deletedAt: '0'
                    },
                    relations: {
                        district: {
                            province: {
                                departament: {
                                    country: true
                                }
                            }
                        }
                    },
                    relationLoadStrategy: 'join',
                    select: {
                        campusId: true,
                        name: true,
                        address: true,
                        districtId: true,
                        phone: true,
                        status: true
                    },
                });
                return campus;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findAllCampusByUser(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const campus = yield modelslibrary_1.PermissionCampusModel.find({
                    where: {
                        userId
                    },
                    relations: {
                        user: true,
                        campus: {
                            company: true
                        },
                        role: true
                    },
                    select: {
                        roleId: true,
                        user: {
                            userId: true,
                            name: true,
                            fullname: true,
                            email: true,
                        },
                        role: {
                            name: true,
                            roleId: true,
                        },
                        campus: {
                            campusId: true,
                            name: true,
                            address: true,
                            tokenAccess: true,
                            company: {
                                companyId: true,
                                uuid: true,
                                name: true,
                                ruc: true,
                                timeZone: true
                            }
                        }
                    },
                });
                return campus;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findOneCampus(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.CampusModel.findOne({
                    where: {
                        campusId
                    }
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    createCampus(campus) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = modelslibrary_1.CampusModel.create(campus);
                return modelslibrary_1.CampusModel.save(response);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateCampus(campus) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.CampusModel.update({ campusId: campus.campusId }, {
                    name: campus.name,
                    address: campus.address,
                    phone: campus.phone,
                    districtId: campus.districtId,
                    status: campus.status
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteCampus(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.CampusModel.update({ campusId }, {
                    deletedAt: '1'
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.campusService = CampusService.getInstance();
//# sourceMappingURL=campus.service.js.map