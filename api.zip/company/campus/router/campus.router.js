"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.campusRoute = void 0;
const express_1 = require("express");
const campus_controller_1 = require("../controller/campus.controller");
exports.campusRoute = (0, express_1.Router)();
exports.campusRoute.get('/campus-user', campus_controller_1.campusController.findAllCampusByUser);
exports.campusRoute.get('/', campus_controller_1.campusController.findAllCampus);
exports.campusRoute.post('/create', campus_controller_1.campusController.createCampus);
exports.campusRoute.put('/update', campus_controller_1.campusController.updateCampus);
exports.campusRoute.put('/delete/:campusId', campus_controller_1.campusController.deleteCampus);
//# sourceMappingURL=campus.router.js.map