"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.companyRoute = void 0;
const express_1 = require("express");
const company_controller_1 = require("../controller/company.controller");
const company_validator_1 = require("../validator/company.validator");
exports.companyRoute = (0, express_1.Router)();
exports.companyRoute.get('/', company_controller_1.companyController.findCompany);
exports.companyRoute.get('/one', company_controller_1.companyController.findOneCompany);
exports.companyRoute.post('/', company_validator_1.validateCreateCompany, company_controller_1.companyController.createCompany);
exports.companyRoute.put('/:companyId', company_validator_1.validateUpdateCompany, company_controller_1.companyController.updateCompany);
exports.companyRoute.put('/update/logo', company_validator_1.validateUpdateLogoCompany, company_controller_1.companyController.updateCompanyLogo);
exports.companyRoute.delete('/:companyId', company_validator_1.validateDeleteCompany, company_controller_1.companyController.deleteCompany);
//# sourceMappingURL=company.router.js.map