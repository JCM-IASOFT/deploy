"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.companyService = void 0;
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
class CompanyService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CompanyService();
        return this.instance;
    }
    findCompany(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const company = yield modelslibrary_1.CompanyModel.find({
                    where: {
                        permissionCompanys: {
                            userId
                        },
                    },
                    relations: ["district"]
                });
                return company;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findOneCompany(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const company = yield modelslibrary_1.CompanyModel.findOne({
                    where: {
                        companyId: companyId
                    },
                    relations: {
                        district: {
                            province: {
                                departament: true
                            }
                        },
                    }
                });
                return company;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    createCompany(companys, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const companyEntity = modelslibrary_1.CompanyModel.create(companys);
                const response = yield queryRunner.manager.save(companyEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateCompany(companyId, company, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.CompanyModel, { companyId }, {
                    ruc: company.ruc,
                    name: company.name,
                    alias: company.alias,
                    address: company.address,
                    countryId: company.countryId,
                    districtId: company.districtId,
                    web: company.web,
                    email: company.email,
                    phone: company.phone
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateLogoForCompany(company) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.CompanyModel.update({ companyId: company.companyId }, {
                    image: company.image
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteCompany(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.CompanyModel.update({ companyId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.companyService = CompanyService.getInstance();
//# sourceMappingURL=company.service.js.map