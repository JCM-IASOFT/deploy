"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteCompany = exports.validateUpdateLogoCompany = exports.validateUpdateCompany = exports.validateCreateCompany = void 0;
const express_validator_1 = require("express-validator");
// Función para manejar el resultado de la validación
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
// Validación para el nombre de la empresa
const validateCompanyName = (0, express_validator_1.check)('company.name')
    .exists().withMessage('El nombre de la empresa es requerido')
    .trim()
    .not().isEmpty().withMessage('El nombre de la empresa no puede estar vacío')
    .isLength({ max: 100 }).withMessage('El nombre de la empresa no puede exceder los 100 caracteres');
// Validación para el RUC de la empresa
const validateCompanyRUC = (0, express_validator_1.check)('company.ruc')
    .exists().withMessage('El RUC de la empresa es requerido')
    .isNumeric().withMessage('El RUC de la empresa debe ser un valor numérico')
    .isLength({ min: 11, max: 11 }).withMessage('El RUC de la empresa debe tener 11 dígitos');
// Validación para la dirección de la empresa
const validateCompanyAddress = (0, express_validator_1.check)('company.address')
    .exists().withMessage('La dirección de la empresa es requerida')
    .trim()
    .not().isEmpty().withMessage('La dirección de la empresa no puede estar vacía')
    .isLength({ max: 255 }).withMessage('La dirección de la empresa no puede exceder los 255 caracteres');
// Validación para el país de la empresa
const validateCompanyCountryId = (0, express_validator_1.check)('company.countryId')
    .exists().withMessage('El ID del país de la empresa es requerido')
    .isLength({ max: 10 }).withMessage('El ID del país de la empresa no puede exceder los 10 caracteres');
// Validación para el ID de distrito de la empresa
const validateCompanyDistrictId = (0, express_validator_1.check)('company.districtId')
    .exists().withMessage('El ID del distrito de la empresa es requerido')
    .isLength({ max: 10 }).withMessage('El ID del distrito de la empresa no puede exceder los 10 caracteres');
// Validación para el correo electrónico de la empresa
const validateCompanyEmail = (0, express_validator_1.check)('company.email')
    .exists().withMessage('El correo electrónico de la empresa es requerido')
    .isEmail().withMessage('El correo electrónico de la empresa debe tener un formato válido')
    .isLength({ max: 255 }).withMessage('El correo electrónico de la empresa no puede exceder los 255 caracteres');
// Validación para el correo electrónico de la empresa
const validateCompanyLogo = (0, express_validator_1.check)('company.image')
    .exists().withMessage('La imagen es requerida')
    .isLength({ max: 500 }).withMessage('La ruta no puede exceder los 500 caracteres');
// Agrega aquí las validaciones adicionales según las propiedades de CompanyModel que desees validar
// * Validación para la creación de una empresa
exports.validateCreateCompany = [
    validateCompanyName,
    validateCompanyRUC,
    validateCompanyAddress,
    validateCompanyCountryId,
    validateCompanyDistrictId,
    handleValidationResult
];
// * Validación para la actualización de una empresa
exports.validateUpdateCompany = [
    (0, express_validator_1.param)('companyId')
        .exists().withMessage('El ID de la empresa es requerido')
        .isNumeric().withMessage('El ID de la empresa debe ser un valor numérico'),
    validateCompanyName,
    validateCompanyRUC,
    validateCompanyAddress,
    validateCompanyCountryId,
    validateCompanyDistrictId,
    handleValidationResult
];
// * Validación para la actualización de una imagen
exports.validateUpdateLogoCompany = [
    validateCompanyLogo
];
// * Validación para la eliminación de una empresa
exports.validateDeleteCompany = [
    (0, express_validator_1.param)('companyId')
        .exists().withMessage('El ID de la empresa es requerido')
        .isNumeric().withMessage('El ID de la empresa debe ser un valor numérico'),
    handleValidationResult
];
//# sourceMappingURL=company.validator.js.map