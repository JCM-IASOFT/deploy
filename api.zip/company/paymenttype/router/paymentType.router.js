"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymenttypeRoute = void 0;
const express_1 = require("express");
const paymentType_controller_1 = require("../controller/paymentType.controller");
const paymentType_validator_1 = require("../validator/paymentType.validator");
exports.paymenttypeRoute = (0, express_1.Router)();
exports.paymenttypeRoute.get('/', paymentType_controller_1.paymenttypeController.findPaymentType);
exports.paymenttypeRoute.post('/', paymentType_validator_1.validateCreatePaymentType, paymentType_controller_1.paymenttypeController.createPaymentTypes);
exports.paymenttypeRoute.put('/', paymentType_validator_1.validateUpdatePaymentType, paymentType_controller_1.paymenttypeController.updatePaymentType);
exports.paymenttypeRoute.delete('/', paymentType_validator_1.validateDeletePaymentType, paymentType_controller_1.paymenttypeController.deletePaymentType);
//# sourceMappingURL=paymentType.router.js.map