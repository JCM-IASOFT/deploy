"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeletePaymentType = exports.validateUpdatePaymentType = exports.validateCreatePaymentType = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreatePaymentType = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdatePaymentType = [
    (0, express_validator_1.check)('paymentTypeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeletePaymentType = [
    (0, express_validator_1.check)('paymentTypeId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=paymentType.validator.js.map