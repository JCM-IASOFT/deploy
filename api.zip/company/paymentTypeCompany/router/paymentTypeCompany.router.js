"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentTypeCompanyRoute = void 0;
const express_1 = require("express");
const paymentTypeCompany_controller_1 = require("../controller/paymentTypeCompany.controller");
exports.paymentTypeCompanyRoute = (0, express_1.Router)();
exports.paymentTypeCompanyRoute.post('/', paymentTypeCompany_controller_1.paymentTypeCompanyController.createPaymentTypeCompanys);
//# sourceMappingURL=paymentTypeCompany.router.js.map