"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.currencyRoute = void 0;
const express_1 = require("express");
const currencyCoins_1 = require("../controller/currencyCoins");
exports.currencyRoute = (0, express_1.Router)();
exports.currencyRoute.get('/findAllD', currencyCoins_1.currencyCoinsController.findCurrencyCoinDatatable);
exports.currencyRoute.get('/findAll', currencyCoins_1.currencyCoinsController.findCurrencyCoin);
exports.currencyRoute.post('/create', currencyCoins_1.currencyCoinsController.createCurrencyCoin);
exports.currencyRoute.patch('/update', currencyCoins_1.currencyCoinsController.updateCurrencyCoin);
exports.currencyRoute.put('/delete/:id', currencyCoins_1.currencyCoinsController.deleteCurrencyCoin);
//# sourceMappingURL=currencyCoins.routes.js.map