"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.currencyCoinsService = exports.CurrencyCoinsService = void 0;
const modelslibrary_1 = require("modelslibrary");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
class CurrencyCoinsService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CurrencyCoinsService();
        return this.instance;
    }
    findCurrencyCoins(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const currencyFind = yield modelslibrary_1.CurrencyModel.find({
                    where: {
                        companyId: companyId,
                        deletedAt: '0'
                    }
                });
                return currencyFind;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createCurrencyCoins(currencyCoin, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const currencyCreate = modelslibrary_1.CurrencyModel.create({
                    code: currencyCoin.code,
                    currencyName: currencyCoin.currencyName,
                    symbol: currencyCoin.symbol,
                    countryName: currencyCoin.countryName,
                    companyId: currencyCoin.companyId
                });
                return yield queryRunner.manager.save(currencyCreate);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateCurrencyCoins(currencyCoin, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const currencyUpdate = yield queryRunner.manager.update(modelslibrary_1.CurrencyModel, { currencyId: currencyCoin.currencyId }, {
                    code: currencyCoin.code,
                    symbol: currencyCoin.symbol,
                    currencyName: currencyCoin.currencyName,
                    countryName: currencyCoin.countryName,
                    companyId: currencyCoin.companyId
                });
                return currencyUpdate;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteCurrencyCoins(id, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const currencyDelete = yield queryRunner.manager.update(modelslibrary_1.CurrencyModel, { currencyCoinId: id }, { deletedAt: '1' });
                return currencyDelete;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.CurrencyCoinsService = CurrencyCoinsService;
exports.currencyCoinsService = CurrencyCoinsService.getInstance();
//# sourceMappingURL=currencyCoins.service.js.map