"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bankRoute = void 0;
const express_1 = require("express");
const bank_1 = require("../controller/bank");
exports.bankRoute = (0, express_1.Router)();
exports.bankRoute.get('/all', bank_1.bankController.findBank);
exports.bankRoute.post('/create', bank_1.bankController.createBank);
exports.bankRoute.put('/update', bank_1.bankController.updateBank);
exports.bankRoute.put('/delete/:id', bank_1.bankController.deleteBank);
//# sourceMappingURL=bank.routes.js.map