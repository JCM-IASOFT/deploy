"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configCampusRoute = void 0;
const express_1 = require("express");
const configCampus_controller_1 = require("../controller/configCampus.controller");
const configCampus_validator_1 = require("../validator/configCampus.validator");
exports.configCampusRoute = (0, express_1.Router)();
exports.configCampusRoute.get('/', configCampus_controller_1.configCampusController.findConfigCampus);
exports.configCampusRoute.post('/', configCampus_validator_1.validateCreateConfigCampus, configCampus_controller_1.configCampusController.createConfigCampuss);
//# sourceMappingURL=configCampus.router.js.map