"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateCreateConfigCampus = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
// * Validación para 'configCampusId'
const validateConfigCampusId = (0, express_validator_1.check)('configCampusId')
    .exists().withMessage('El parámetro configCampusId es requerido')
    .isNumeric().withMessage('El parámetro configCampusId debe ser numérico');
// * Validación para 'sellWithoutStock' (booleano)
const validateSellWithoutStock = (0, express_validator_1.check)('sellWithoutStock')
    .exists().withMessage('El parámetro sellWithoutStock es requerido')
    .isBoolean().withMessage('El parámetro sellWithoutStock debe ser booleano (true/false)');
// * Validación para 'campusId'
const validateCampusId = (0, express_validator_1.check)('campusId')
    .exists().withMessage('El parámetro campusId es requerido')
    .isNumeric().withMessage('El parámetro campusId debe ser numérico');
// * Validación para la creación de una configuración del campus
exports.validateCreateConfigCampus = [
    validateConfigCampusId,
    validateSellWithoutStock,
    validateCampusId,
    handleValidationResult
];
//# sourceMappingURL=configCampus.validator.js.map