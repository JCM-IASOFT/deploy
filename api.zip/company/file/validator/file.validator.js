"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteFile = exports.validateCreateFile = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
// Validadores específicos
const validateFileId = (0, express_validator_1.param)('fileId')
    .exists().withMessage('El parámetro fileId es requerido')
    .isNumeric().withMessage('El parámetro fileId debe ser numérico');
const validateUrlFile = (0, express_validator_1.check)('urlFile')
    .exists().withMessage('La URL del archivo es requerida')
    .isString().withMessage('La URL del archivo debe ser una cadena de texto')
    .isLength({ max: 200 }).withMessage('La URL del archivo no puede exceder los 50 caracteres');
const validateDescription = (0, express_validator_1.check)('description')
    .exists().withMessage('La descripción es requerida')
    .isString().withMessage('La descripción debe ser una cadena de texto')
    .isLength({ max: 200 }).withMessage('La descripción no puede exceder los 50 caracteres');
const validateCompanyId = (0, express_validator_1.check)('companyId')
    .exists().withMessage('El companyId es requerido')
    .isNumeric().withMessage('El companyId debe ser numérico');
const validateProductId = (0, express_validator_1.check)('productId')
    .optional()
    .isNumeric().withMessage('El productId debe ser numérico si está presente');
// Validación para la creación de un archivo
exports.validateCreateFile = [
    validateUrlFile,
    validateDescription,
    validateCompanyId,
    validateProductId,
    handleValidationResult
];
// Validación para la eliminación de un archivo
exports.validateDeleteFile = [
    validateFileId,
    handleValidationResult
];
//# sourceMappingURL=file.validator.js.map