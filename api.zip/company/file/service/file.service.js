"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class FileService {
    static getInstance() {
        if (!this.instance)
            this.instance = new FileService();
        return this.instance;
    }
    findFiles(companyId, productId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const filesBuilder = modelslibrary_1.FileModel.createQueryBuilder('file');
                if (!productId && productId > 0) {
                    filesBuilder.leftJoinAndSelect('file.product', 'product');
                }
                filesBuilder.leftJoinAndSelect('file.subFiles', 'subFiles', 'subFiles.deletedAt = :subDeletedAt', { subDeletedAt: '0' })
                    .where('file.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('file.companyId = :companyId', { companyId: companyId })
                    .select([
                    'file.fileId',
                    'file.typeFile',
                    'file.urlFile',
                    'file.description'
                ]);
                const files = yield filesBuilder.getMany();
                return files;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createFile(files) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.FileModel.save(files);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    /**
     * Crea una transacción de archivo y guarda el archivo en la base de datos.
     *
     * @param {FileModel} files - El modelo de archivo que se va a guardar.
     * @param {QueryRunner} queryRunner - El administrador de consultas utilizado para la transacción.
     * @returns {Promise<FileModel>} Una promesa que resuelve con la entidad de archivo guardada.
     * @throws {Error} Si ocurre un error durante el proceso de guardado.
     */
    createFileTrans(files, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const fileEntity = modelslibrary_1.FileModel.create(files);
                const response = yield queryRunner.manager.save(fileEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteFile(fileId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.FileModel.update({ fileId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.fileService = FileService.getInstance();
//# sourceMappingURL=file.service.js.map