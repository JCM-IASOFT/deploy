"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.districtController = exports.DistrictController = void 0;
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const district_service_1 = require("../service/district.service");
/**
 * currency - divisa
 */
class DistrictController {
    static getInstance() {
        if (!this.instance)
            this.instance = new DistrictController();
        return this.instance;
    }
    findDistrictDatatable(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield district_service_1.districtService.findDistrict();
                response.status(http_status_codes_1.StatusCodes.OK).json({
                    data: findResponse,
                    draw: Math.random(),
                    recordsFiltered: findResponse.length,
                    recordsTotal: findResponse.length,
                });
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findDistrict(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const findResponse = yield district_service_1.districtService.findDistrict();
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findDistrictByProvince(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { provinceId } = request.query;
                const findResponse = yield district_service_1.districtService.findDistrictByProvince(provinceId.toString());
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
}
exports.DistrictController = DistrictController;
exports.districtController = DistrictController.getInstance();
//# sourceMappingURL=district.controller.js.map