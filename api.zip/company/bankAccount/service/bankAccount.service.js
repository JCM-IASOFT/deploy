"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bankAccountService = void 0;
const models_1 = require("models");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
class BankAccountService {
    static getInstance() {
        if (!this.instance)
            this.instance = new BankAccountService();
        return this.instance;
    }
    findBankAccount(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.BankAccountModel.find({
                    where: {
                        companyId: companyId,
                        deletedAt: '0',
                    },
                    relations: ["bank", "currency", "bankAccountType"]
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createBankAccount(bankAccount) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = models_1.BankAccountModel.create({
                    bankId: bankAccount.bankId,
                    accountNumber: bankAccount.accountNumber,
                    accountHolder: bankAccount.accountHolder,
                    CCI: bankAccount.CCI,
                    currencyId: bankAccount.currencyId,
                    bankAccountTypeId: bankAccount.bankAccountTypeId,
                    companyId: bankAccount.companyId,
                });
                return yield models_1.BankAccountModel.save(response);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateBankAccount(bankAccount) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.BankAccountModel.update({ bankAccountId: bankAccount.bankAccountId }, {
                    bankId: bankAccount.bankId,
                    accountNumber: bankAccount.accountNumber,
                    accountHolder: bankAccount.accountHolder,
                    CCI: bankAccount.CCI,
                    currencyId: bankAccount.currencyId,
                    bankAccountTypeId: bankAccount.bankAccountTypeId,
                    companyId: bankAccount.companyId,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteBankAccount(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.BankAccountModel.update({ bankAccountId: id }, {
                    deletedAt: '1'
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    changeStatusBankAccount(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.BankAccountModel.update({ bankAccountId: id }, {
                    stateAccount: false
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.bankAccountService = BankAccountService.getInstance();
//# sourceMappingURL=bankAccount.service.js.map