"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bankAccountRoute = void 0;
const express_1 = require("express");
const bankAccount_1 = require("../controller/bankAccount");
exports.bankAccountRoute = (0, express_1.Router)();
exports.bankAccountRoute.get('/allD', bankAccount_1.bankAccountController.findBankAccountDataTable);
exports.bankAccountRoute.get('/all', bankAccount_1.bankAccountController.findBankAccount);
exports.bankAccountRoute.post('/create', bankAccount_1.bankAccountController.createBankAccount);
exports.bankAccountRoute.put('/update', bankAccount_1.bankAccountController.updateBankAccount);
exports.bankAccountRoute.put('/delete/:id', bankAccount_1.bankAccountController.deleteBankAccount);
exports.bankAccountRoute.put('/change/:id', bankAccount_1.bankAccountController.changeStatusBankAccount);
//# sourceMappingURL=bankAccount.routes.js.map