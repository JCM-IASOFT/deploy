"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.roleRoute = void 0;
const express_1 = require("express");
const role_controller_1 = require("../controller/role.controller");
exports.roleRoute = (0, express_1.Router)();
exports.roleRoute.get('/', role_controller_1.roleController.findAllRole);
exports.roleRoute.post('/', role_controller_1.roleController.createRoles);
exports.roleRoute.put('/', role_controller_1.roleController.updateRole);
exports.roleRoute.delete('/', role_controller_1.roleController.deleteRole);
//# sourceMappingURL=role.router.js.map