"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativeService = void 0;
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
class CorrelativeService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CorrelativeService();
        return this.instance;
    }
    findOneCorrelative(campusId, invoiceId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const paymentSales = yield modelslibrary_1.CorrelativeModel.findOne({
                    where: { campusId: campusId, invoiceId: invoiceId },
                    relations: ["invoice"],
                    select: {
                        correlativeId: true,
                        name: true,
                        code: true,
                        invoiceId: true,
                        number: true,
                        campusId: true,
                        invoice: {
                            invoiceId: true,
                            code: true,
                            name: true,
                        }
                    }
                });
                return paymentSales;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findCorrelative(campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const paymentSales = yield modelslibrary_1.CorrelativeModel.find({
                    where: { campusId: campusId }, select: {
                        correlativeId: true,
                        name: true,
                        code: true,
                        invoiceId: true,
                        number: true,
                        campusId: true,
                    }
                });
                return paymentSales;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createCorrelative(correlative, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const paymentEntity = modelslibrary_1.CorrelativeModel.create(correlative);
                const response = yield queryRunner.manager.save(paymentEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateCorrelative(correlative, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.CorrelativeModel, { correlativeId: correlative.correlativeId }, {
                    name: correlative.name,
                    invoiceId: correlative.invoiceId,
                    number: correlative.number,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    incrementCorrelative(correlative, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.CorrelativeModel, { correlativeId: correlative.correlativeId }, {
                    number: correlative.number,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.correlativeService = CorrelativeService.getInstance();
//# sourceMappingURL=correlative.service.js.map