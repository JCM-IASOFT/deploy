"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateFindOneCorrelative = exports.validateFindCorrelative = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateFindCorrelative = [
    (0, express_validator_1.query)('campusId').exists().isNumeric().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateFindOneCorrelative = [
    (0, express_validator_1.query)('campusId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.query)('invoiceId').exists().isNumeric().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=correlative.validator.js.map