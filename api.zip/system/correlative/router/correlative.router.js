"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativeRoute = void 0;
const express_1 = require("express");
const correlative_controller_1 = require("../controller/correlative.controller");
const correlative_validator_1 = require("../validator/correlative.validator");
exports.correlativeRoute = (0, express_1.Router)();
exports.correlativeRoute.get('/all', correlative_validator_1.validateFindCorrelative, correlative_controller_1.correlativeController.findCorrelative);
exports.correlativeRoute.get('/one', correlative_validator_1.validateFindOneCorrelative, correlative_controller_1.correlativeController.findOneCorrelative);
//# sourceMappingURL=correlative.router.js.map