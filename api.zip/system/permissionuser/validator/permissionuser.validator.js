"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeletePermissionUser = exports.validateUpdatePermissionUser = exports.validateCreatePermissionUser = exports.validateFindPermissionUser = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateFindPermissionUser = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateCreatePermissionUser = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('typeTime').exists().not().isEmpty(),
    (0, express_validator_1.check)('time').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdatePermissionUser = [
    (0, express_validator_1.check)('serviceTypeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('typeTime').exists().not().isEmpty(),
    (0, express_validator_1.check)('time').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeletePermissionUser = [
    (0, express_validator_1.check)('serviceTypeId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=permissionuser.validator.js.map