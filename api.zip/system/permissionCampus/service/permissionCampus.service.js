"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionCampusService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class PermissionCampusService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PermissionCampusService();
        return this.instance;
    }
    findPermissionCampus(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const permissionCampus = yield models_1.PermissionCampusModel.createQueryBuilder('permissionCampus')
                    .innerJoinAndSelect('permissionCampus.campus', 'campus')
                    .innerJoinAndSelect('campus.company', 'company')
                    .andWhere('permissionCampus.userId = :userId', { userId })
                    .select([
                    'permissionCampus',
                    'campus',
                    'company',
                ])
                    .getMany();
                return permissionCampus;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createPermissionCampus(permissionCampuss, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const permissionEntity = models_1.PermissionCampusModel.create(permissionCampuss);
                const response = yield queryRunner.manager.save(permissionEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updatePermissionCampus(permissionCampusId, permissionCampus, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.PermissionCampusModel, { permissionCampusId }, {
                    campusId: permissionCampus.campusId,
                    userId: permissionCampus.userId,
                    roleId: permissionCampus.roleId,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deletePermissionCampus(permissionCampusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.PermissionCampusModel.delete({ permissionCampusId });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.permissionCampusService = PermissionCampusService.getInstance();
//# sourceMappingURL=permissionCampus.service.js.map