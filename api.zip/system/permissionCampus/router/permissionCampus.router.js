"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionCampusRoute = void 0;
const express_1 = require("express");
const permissionCampus_controller_1 = require("../controller/permissionCampus.controller");
exports.permissionCampusRoute = (0, express_1.Router)();
exports.permissionCampusRoute.get('/', permissionCampus_controller_1.permissionCampusController.findPermissionCampus);
exports.permissionCampusRoute.post('/', permissionCampus_controller_1.permissionCampusController.createPermissionCampuss);
exports.permissionCampusRoute.put('/:permissionCampusId', permissionCampus_controller_1.permissionCampusController.updatePermissionCampus);
exports.permissionCampusRoute.delete('/:permissionCampusId', permissionCampus_controller_1.permissionCampusController.deletePermissionCampus);
//# sourceMappingURL=permissionCampus.router.js.map