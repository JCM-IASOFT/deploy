"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userController = void 0;
const http_status_codes_1 = require("http-status-codes");
const user_service_1 = require("../service/user.service");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
class UserController {
    constructor() {
        this.findUser = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { companyId } = req.query;
            const users = yield user_service_1.userService.findUser(Number(companyId));
            res.status(http_status_codes_1.StatusCodes.OK).json(users);
        });
        this.findOne = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { userId } = req.query;
            const users = yield user_service_1.userService.findOne(Number(userId));
            res.status(http_status_codes_1.StatusCodes.OK).json(users);
        });
        this.getUserByRole = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId, role } = req.query;
            console.log("🚀 ~ UserController ~ getUserByRole= ~ req.query:", req.query);
            const users = yield user_service_1.userService.getUserByRole(Number(campusId), Number(role));
            res.status(http_status_codes_1.StatusCodes.OK).json(users);
        });
        this.createUsers = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const { user, userCompanies, userCampus, roleUser } = req.body;
                return yield user_service_1.userService.createUserTrans(user, userCompanies, userCampus, roleUser);
            }));
        });
        this.updateUser = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const userId = req.params.userId;
                const { user, userCompanies, userCampus, roleUser } = req.body;
                return yield user_service_1.userService.updateUserTrans(userId, user, userCompanies, userCampus, roleUser);
            }));
            // HandleRequest(res, async () => {
            //     const userId = req.params.userId as unknown as number
            //     const { user, userCompanies, userCampus,roleUser } = req.body as {
            //         user: UserModel
            //         userCompanies: UserCompanyModel[]
            //         userCampus: UserCampusModel[]
            //         roleUser: RoleUserModel
            //     }
            //     if (user.password && user.password !== "") {
            //         const passwordHash = await encrypt(user.password)
            //         user.password = await passwordHash
            //     }
            //     const result = await handleTransaction(async (queryRunner) => {
            //         const response = await userService.updateUser(userId, user, queryRunner);
            //         await permissionCampusService.updatePermissionCampus(permissionCampus.permissionCampusId, permissionCampus, queryRunner)
            //         if (response.affected === 0) {
            //             throw new Error("No se modificó nada")
            //         }
            //         return { code: StatusCodes.OK, success: true, message: MessageCustomApi.SALES_SUCCESS, data: response };
            //     })
            //     return result
            // });
        });
        this.deleteUser = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const userId = req.params.userId;
                const response = yield user_service_1.userService.deleteUser(Number(userId));
                if (response.affected > 0) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_BRAND, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new UserController();
        return this.instance;
    }
}
exports.userController = UserController.getInstance();
//# sourceMappingURL=user.controller.js.map