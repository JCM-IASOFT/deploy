"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userRoute = void 0;
const express_1 = require("express");
const user_controller_1 = require("../controller/user.controller");
const verifytoken_middeware_1 = __importDefault(require("../../../common/middleware/verifytoken.middeware"));
exports.userRoute = (0, express_1.Router)();
exports.userRoute.get('/', verifytoken_middeware_1.default, user_controller_1.userController.findUser);
exports.userRoute.get('/one', verifytoken_middeware_1.default, user_controller_1.userController.findOne);
exports.userRoute.get('/by-role', user_controller_1.userController.getUserByRole);
exports.userRoute.post('/', user_controller_1.userController.createUsers);
exports.userRoute.put('/:userId', user_controller_1.userController.updateUser);
exports.userRoute.delete('/:userId', user_controller_1.userController.deleteUser);
//# sourceMappingURL=user.router.js.map