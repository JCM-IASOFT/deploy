"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userService = void 0;
const models_1 = require("models");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const userCompany_service_1 = require("../../userCompany/service/userCompany.service");
const userCampus_service_1 = require("../../userCampus/service/userCampus.service");
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const bycrypt_handler_1 = require("../../../common/handler/bycrypt.handler");
const roleuser_service_1 = require("../../roleuser/service/roleuser.service");
class UserService {
    static getInstance() {
        if (!this.instance)
            this.instance = new UserService();
        return this.instance;
    }
    getUserByRole(campusId, role) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const users = yield models_1.UserModel.find({
                    where: {
                        userCampus: {
                            campusId
                        },
                        deletedAt: '0'
                    },
                    relations: ['userCampus'],
                });
                return users;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findUser(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const users = yield models_1.UserModel.find({
                    where: {
                        userCompanies: {
                            companyId
                        },
                        deletedAt: '0'
                    },
                    relations: {
                        roleUsers: {
                            role: true
                        }
                    },
                });
                return users;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findOne(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const user = yield models_1.UserModel.findOne({
                    where: {
                        userId,
                        deletedAt: '0'
                    },
                    relations: {
                        roleUsers: {
                            role: true
                        },
                        userCampus: {
                            campus: true,
                        },
                        userCompanies: {
                            company: true
                        }
                    }
                });
                return user;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findOneUser(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const users = yield models_1.UserModel.findOne({
                    where: {
                        userId
                    },
                });
                return users;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
            }
        });
    }
    createUserTrans(user, userCompanies, userCampus, roleUser) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                // Encriptamos la contraseña
                const passwordHash = yield (0, bycrypt_handler_1.encrypt)(user.password);
                user.password = yield passwordHash;
                const userSaved = yield this.createUser(user, queryRunner);
                if (userCompanies && userCompanies.length > 0) {
                    const _userCompanies = this.prepareUserCompanies(userSaved.userId, userCompanies);
                    yield Promise.all(_userCompanies.map(userCompany => userCompany_service_1.userCompanyService.createUserCompany(userCompany, queryRunner)));
                }
                if (userCampus && userCampus.length > 0) {
                    const _userCampus = this.prepareUserCampus(userSaved.userId, userCampus);
                    yield Promise.all(_userCampus.map(userCampus => userCampus_service_1.userCampusService.createUserCampus(userCampus, queryRunner)));
                }
                roleUser.userId = userSaved.userId;
                yield roleuser_service_1.roleUserService.createRoleUser(roleUser, queryRunner);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCES_USER, data: userSaved };
            }));
            return result;
        });
    }
    prepareUserCompanies(userId, userCompanies) {
        return userCompanies.map(u => {
            return Object.assign(Object.assign({}, u), { userId: userId });
        });
    }
    prepareUserCampus(userId, userCampus) {
        return userCampus.map(u => {
            return Object.assign(Object.assign({}, u), { userId: userId });
        });
    }
    createUser(users, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const userEntity = models_1.UserModel.create(users);
                const response = yield queryRunner.manager.save(userEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateUserTrans(userId, user, userCompanies, userCampus, roleUser) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                yield this.updateUser(userId, user, queryRunner);
                if (userCompanies && userCompanies.length > 0) {
                    yield userCompany_service_1.userCompanyService.deleteUserCompany(userId, queryRunner);
                    yield Promise.all(userCompanies.map(userCompany => userCompany_service_1.userCompanyService.createUserCompany(userCompany, queryRunner)));
                }
                if (userCampus && userCampus.length > 0) {
                    yield userCampus_service_1.userCampusService.deleteUserCampus(userId, queryRunner);
                    yield Promise.all(userCampus.map(userCampus => userCampus_service_1.userCampusService.createUserCampus(userCampus, queryRunner)));
                }
                yield roleuser_service_1.roleUserService.deleteRoleUser(userId, queryRunner);
                yield roleuser_service_1.roleUserService.createRoleUser(roleUser, queryRunner);
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCES_USER };
            }));
            return result;
        });
    }
    updateUser(userId, user, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(models_1.UserModel, { userId }, {
                    name: user.name,
                    fullname: user.fullname,
                    email: user.email,
                    phone: user.phone,
                    employeId: user.employeId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteUser(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield models_1.UserModel.update({ userId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.userService = UserService.getInstance();
//# sourceMappingURL=user.service.js.map