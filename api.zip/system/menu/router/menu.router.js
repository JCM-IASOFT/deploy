"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.menuRoute = void 0;
const express_1 = require("express");
const menu_controller_1 = require("../controller/menu.controller");
const menu_validator_1 = require("../validator/menu.validator");
exports.menuRoute = (0, express_1.Router)();
exports.menuRoute.get('/', menu_controller_1.menuController.findMenu);
exports.menuRoute.post('/permission', menu_controller_1.menuController.findMenuPermission);
exports.menuRoute.post('/', menu_controller_1.menuController.createMenus);
exports.menuRoute.post('/child', menu_controller_1.menuController.createChild);
exports.menuRoute.put('/:menuId', menu_controller_1.menuController.updateMenu);
exports.menuRoute.delete('/:menuId', menu_validator_1.validateDeleteMenu, menu_controller_1.menuController.deleteMenu);
//# sourceMappingURL=menu.router.js.map