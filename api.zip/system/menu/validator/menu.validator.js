"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteMenu = exports.validateUpdateMenu = exports.validateCreateMenu = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateMenuId = (0, express_validator_1.param)('menuId')
    .exists().withMessage('El parámetro menuId es requerido')
    .isNumeric().withMessage('El parámetro menuId debe ser numérico');
const validateMenuName = (0, express_validator_1.check)('name')
    .exists().trim().not().isEmpty().withMessage('El nombre de la categoria es requerido');
const validateCompanyId = (0, express_validator_1.check)('companyId')
    .exists().not().isEmpty().withMessage('El companyId es requerido');
// * Validación para la creación de una categoria
exports.validateCreateMenu = [
    validateMenuName,
    validateCompanyId,
    handleValidationResult
];
// * Validación para la actualización de una categoria
exports.validateUpdateMenu = [
    validateMenuId,
    validateMenuName,
    handleValidationResult
];
// * Validación para la eliminación de una categoria
exports.validateDeleteMenu = [
    validateMenuId,
    handleValidationResult
];
//# sourceMappingURL=menu.validator.js.map