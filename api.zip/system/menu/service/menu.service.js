"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.menuService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class MenuService {
    static getInstance() {
        if (!this.instance)
            this.instance = new MenuService();
        return this.instance;
    }
    findMenuPermission(roleId, systemId, campusId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Obtener menús principales (sin padres)
                const menus = yield modelslibrary_1.MenuModel
                    .createQueryBuilder("menu")
                    .innerJoinAndSelect("menu.permissionRoles", "permissionRoles")
                    .leftJoinAndSelect("menu.parent", "parent")
                    .leftJoinAndSelect("menu.children", "children")
                    .leftJoinAndSelect("menu.menuActions", "menuActions")
                    .select([
                    "menu",
                    "parent",
                    "children",
                    "permissionRoles",
                    "menuActions"
                ])
                    .where("permissionRoles.roleId = :roleId", { roleId })
                    .andWhere("permissionRoles.systemId = :systemId", { systemId })
                    .andWhere("permissionRoles.campusId = :campusId", { campusId })
                    .orderBy("menu.order", "ASC")
                    .getMany();
                // Crear un mapa de menús por ID para fácil acceso
                const menuMap = new Map();
                menus.forEach(menu => menuMap.set(menu.menuId, menu));
                // Crear la estructura jerárquica de menús recursivamente
                const rootMenus = [];
                const buildHierarchy = (menu) => {
                    menu.children = []; // Inicializar la propiedad children
                    menus.forEach(subMenu => {
                        if (subMenu.parent && subMenu.parent.menuId === menu.menuId) {
                            menu.children.push(subMenu);
                            buildHierarchy(subMenu); // Llamada recursiva para construir la jerarquía de submenús
                        }
                    });
                };
                // Filtrar menús raíz y construir la jerarquía
                menus.forEach(menu => {
                    if (!menu.parent) {
                        rootMenus.push(menu);
                        buildHierarchy(menu);
                    }
                });
                return rootMenus;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    findMenu(systemId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Obtener todos los menús con las relaciones necesarias
                const menus = yield modelslibrary_1.MenuModel.find({
                    where: { systemId },
                    relations: ["parent", "children", "menuActions", "menuActions.action"],
                    order: { order: "ASC" } // Solo ordenamos por el campo 'order'
                });
                // Crear un mapa de menús por ID para fácil acceso
                const menuMap = new Map();
                menus.forEach(menu => menuMap.set(menu.menuId, menu));
                // Crear la estructura jerárquica de menús recursivamente
                const rootMenus = [];
                const buildHierarchy = (menu) => {
                    menu.children = []; // Inicializar la propiedad children
                    menus.forEach(subMenu => {
                        if (subMenu.parent && subMenu.parent.menuId === menu.menuId) {
                            menu.children.push(subMenu);
                            buildHierarchy(subMenu); // Llamada recursiva para construir la jerarquía de submenús
                        }
                    });
                };
                // Filtrar menús raíz y construir la jerarquía
                menus.forEach(menu => {
                    if (!menu.parent) {
                        rootMenus.push(menu);
                        buildHierarchy(menu);
                    }
                });
                return rootMenus;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createChild(menu) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield modelslibrary_1.MenuModel.save(menu);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createMenu(menus) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let response;
                const saveMenuRecursive = (menuItems, parent) => __awaiter(this, void 0, void 0, function* () {
                    for (const menuItem of menuItems) {
                        const newMenu = new modelslibrary_1.MenuModel();
                        newMenu.headTitle = menuItem.headTitle;
                        newMenu.headTitle2 = menuItem.headTitle2;
                        newMenu.path = menuItem.path;
                        newMenu.title = menuItem.title;
                        newMenu.icon = menuItem.icon;
                        newMenu.action = menuItem.action;
                        newMenu.subject = menuItem.subject;
                        newMenu.type = menuItem.type;
                        newMenu.badgeValue = menuItem.badgeValue;
                        newMenu.badgeClass = menuItem.badgeClass;
                        newMenu.badgeText = menuItem.badgeText;
                        newMenu.active = menuItem.active;
                        newMenu.selected = menuItem.selected;
                        newMenu.bookmark = menuItem.bookmark;
                        newMenu.Menusub = menuItem.Menusub;
                        newMenu.target = menuItem.target;
                        newMenu.menutype = menuItem.menutype;
                        if (parent) {
                            newMenu.parent = parent;
                        }
                        // Guardar el menú en la base de datos
                        yield modelslibrary_1.MenuModel.save(newMenu);
                        // Si el menú tiene hijos, insertar recursivamente cada hijo
                        if (menuItem.children && menuItem.children.length > 0) {
                            yield saveMenuRecursive(menuItem.children, newMenu); // Pasar el nuevo menú como padre
                        }
                    }
                });
                yield saveMenuRecursive(menus);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateMenu(menuId, menu) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.MenuModel.update({ menuId }, {
                    headTitle: menu.headTitle,
                    headTitle2: menu.headTitle2,
                    path: menu.path,
                    title: menu.title,
                    icon: menu.icon,
                    action: menu.action,
                    subject: menu.subject,
                    type: menu.type,
                    badgeValue: menu.badgeValue,
                    badgeClass: menu.badgeClass,
                    badgeText: menu.badgeText,
                    active: menu.active,
                    selected: menu.selected,
                    bookmark: menu.bookmark,
                    Menusub: menu.Menusub,
                    target: menu.target,
                    menutype: menu.menutype,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteMenu(menuId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.MenuModel.delete(menuId);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.menuService = MenuService.getInstance();
//# sourceMappingURL=menu.service.js.map