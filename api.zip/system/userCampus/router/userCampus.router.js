"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userCampusRoute = void 0;
const express_1 = require("express");
const userCampus_controller_1 = require("../controller/userCampus.controller");
const userCampus_validator_1 = require("../validator/userCampus.validator");
exports.userCampusRoute = (0, express_1.Router)();
exports.userCampusRoute.get('/:userId', userCampus_validator_1.validateFindUserCampus, userCampus_controller_1.userCampusController.findUserCampus);
//# sourceMappingURL=userCampus.router.js.map