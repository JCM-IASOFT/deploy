"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateFindUserCampus = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateUserId = (0, express_validator_1.param)('userId')
    .exists().withMessage('El parámetro userId es requerido')
    .isNumeric().withMessage('El parámetro userId debe ser numérico');
// * Validación para la eliminación de una categoria
exports.validateFindUserCampus = [
    validateUserId,
    handleValidationResult
];
//# sourceMappingURL=userCampus.validator.js.map