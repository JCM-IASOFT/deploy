"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateCreatePermissionRole = exports.validateFindPermissionRole = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateFindPermissionRole = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateCreatePermissionRole = [
    (0, express_validator_1.check)('permissionRoles.*.actionId').exists().not().isEmpty(),
    (0, express_validator_1.check)('permissionRoles.*.menuId').exists().not().isEmpty(),
    (0, express_validator_1.check)('permissionRoles.*.roleId').exists().not().isEmpty(),
    (0, express_validator_1.check)('permissionRoles.*.systemId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=permissionrole.validator.js.map