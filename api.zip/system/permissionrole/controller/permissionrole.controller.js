"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionroleController = void 0;
const http_status_codes_1 = require("http-status-codes");
const permissionrole_service_1 = require("../service/permissionrole.service");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
const webSocketService_1 = __importDefault(require("../../../socket/webSocketService"));
class PermissionRoleController {
    constructor() {
        this.findAllPermissionRole = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { systemId, roleId } = req.query;
            const permissionroles = yield permissionrole_service_1.permissionroleService.findAllPermissionRole(Number(systemId), Number(roleId));
            res.status(http_status_codes_1.StatusCodes.OK).json(permissionroles);
        });
        this.findPermissionRole = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { systemId, roleId } = req.query;
            const permissionroles = yield permissionrole_service_1.permissionroleService.findPermissionRole(Number(systemId), Number(roleId));
            res.status(http_status_codes_1.StatusCodes.OK).json(permissionroles);
        });
        this.createPermissionRoles = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { permissionRoles } = req.body;
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const roleId = permissionRoles[0].roleId;
                    const result = yield (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        yield permissionrole_service_1.permissionroleService.deletePermissionRole(permissionRoles[0], queryRunner);
                        yield Promise.all(permissionRoles.map((permissionrole) => permissionrole_service_1.permissionroleService.createPermissionRole(permissionrole, queryRunner)));
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.END_SUCCESS_SERVICE };
                    }));
                    if (result.success) {
                        this.webSocketService = new webSocketService_1.default();
                        this.webSocketService.changePermission(roleId);
                    }
                    return result;
                }
                catch (err) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: err
                    };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new PermissionRoleController();
        return this.instance;
    }
}
exports.permissionroleController = PermissionRoleController.getInstance();
//# sourceMappingURL=permissionrole.controller.js.map