"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionroleRoute = void 0;
const express_1 = require("express");
const permissionrole_controller_1 = require("../controller/permissionrole.controller");
const permissionrole_validator_1 = require("../validator/permissionrole.validator");
exports.permissionroleRoute = (0, express_1.Router)();
exports.permissionroleRoute.get('/', permissionrole_controller_1.permissionroleController.findAllPermissionRole);
exports.permissionroleRoute.get('/all', permissionrole_controller_1.permissionroleController.findPermissionRole);
exports.permissionroleRoute.post('/', permissionrole_validator_1.validateCreatePermissionRole, permissionrole_controller_1.permissionroleController.createPermissionRoles);
//# sourceMappingURL=permissionrole.router.js.map