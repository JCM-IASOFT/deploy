"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.actionRoute = void 0;
const express_1 = require("express");
const action_controller_1 = require("../controller/action.controller");
exports.actionRoute = (0, express_1.Router)();
exports.actionRoute.get('/', action_controller_1.actionController.findAllAction);
exports.actionRoute.post('/', action_controller_1.actionController.createActions);
exports.actionRoute.put('/', action_controller_1.actionController.updateAction);
//# sourceMappingURL=action.router.js.map