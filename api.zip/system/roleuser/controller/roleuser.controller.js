"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.roleuserController = void 0;
const http_status_codes_1 = require("http-status-codes");
const roleuser_service_1 = require("../service/roleuser.service");
class RoleUserController {
    constructor() {
        this.findAllRoleUser = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { campusId } = req.body;
            const roleusers = yield roleuser_service_1.roleUserService.findAllRoleUser(Number(campusId));
            res.status(http_status_codes_1.StatusCodes.OK).json(roleusers);
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new RoleUserController();
        return this.instance;
    }
}
exports.roleuserController = RoleUserController.getInstance();
//# sourceMappingURL=roleuser.controller.js.map