"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userCompanyService = void 0;
const models_1 = require("models");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class UserCompanyService {
    static getInstance() {
        if (!this.instance)
            this.instance = new UserCompanyService();
        return this.instance;
    }
    findUserCompany(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const userCompanys = yield models_1.UserCompanyModel.createQueryBuilder('userCompany')
                    .innerJoin('userCompany.company', 'company')
                    .innerJoin('userCompany.user', 'user')
                    .where('userCompany.userId = :userId', { userId })
                    .andWhere('user.deletedAt = :deletedAt', { deletedAt: '0' })
                    .select([
                    'userCompany.userId',
                    'userCompany.companyId',
                    'company'
                ])
                    .getMany();
                return userCompanys;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createUserCompany(userCompany, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _userCompany = models_1.UserCompanyModel.create(userCompany);
                return yield queryRunner.manager.save(_userCompany);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteUserCompany(userId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield queryRunner.manager.delete(models_1.UserCompanyModel, { userId });
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.userCompanyService = UserCompanyService.getInstance();
//# sourceMappingURL=userCompany.service.js.map