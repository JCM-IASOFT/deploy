"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userCompanyRoute = void 0;
const express_1 = require("express");
const userCompany_controller_1 = require("../controller/userCompany.controller");
const userCompany_validator_1 = require("../validator/userCompany.validator");
exports.userCompanyRoute = (0, express_1.Router)();
exports.userCompanyRoute.get('/:userId', userCompany_validator_1.validateFindUserCompany, userCompany_controller_1.userCompanyController.findUserCompany);
//# sourceMappingURL=userCompany.router.js.map