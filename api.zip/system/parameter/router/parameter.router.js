"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parameterRoute = void 0;
const express_1 = require("express");
const parameter_controller_1 = require("../controller/parameter.controller");
const parameter_validator_1 = require("../validator/parameter.validator");
exports.parameterRoute = (0, express_1.Router)();
exports.parameterRoute.get('/', parameter_controller_1.parameterController.findParameter);
exports.parameterRoute.post('/', parameter_validator_1.validateCreateParameter, parameter_controller_1.parameterController.createParameters);
exports.parameterRoute.put('/', parameter_validator_1.validateUpdateParameter, parameter_controller_1.parameterController.updateParameter);
exports.parameterRoute.put('/title', parameter_validator_1.validateUpdateParameter, parameter_controller_1.parameterController.updateParameterTitle);
//# sourceMappingURL=parameter.router.js.map