"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionCompanyService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class PermissionCompanyService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PermissionCompanyService();
        return this.instance;
    }
    findPermissionCompany(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const permissionCompanys = yield modelslibrary_1.PermissionCompanyModel.createQueryBuilder('permissionCompany')
                    .innerJoinAndSelect('permissionCompany.company', 'company')
                    .andWhere('permissionCompany.userId = :userId', { userId })
                    .select([
                    'permissionCompany',
                    'company',
                ])
                    .getMany();
                return permissionCompanys;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return [];
            }
        });
    }
    createPermissionCompany(permissionCompanys, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const permissionEntity = modelslibrary_1.PermissionCompanyModel.create(permissionCompanys);
                const response = yield queryRunner.manager.save(permissionEntity);
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updatePermissionCompany(permissionCompanyId, permissionCompany, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.PermissionCompanyModel, { permissionCompanyId }, {
                    userId: permissionCompany.userId,
                    roleId: permissionCompany.roleId,
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deletePermissionCompany(permissionCompanyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.PermissionCompanyModel.delete({ permissionCompanyId });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.permissionCompanyService = PermissionCompanyService.getInstance();
//# sourceMappingURL=permissionCompany.service.js.map