"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionCompanyRoute = void 0;
const express_1 = require("express");
const permissionCompany_controller_1 = require("../controller/permissionCompany.controller");
exports.permissionCompanyRoute = (0, express_1.Router)();
exports.permissionCompanyRoute.get('/', permissionCompany_controller_1.permissionCompanyController.findPermissionCompany);
exports.permissionCompanyRoute.post('/', permissionCompany_controller_1.permissionCompanyController.createPermissionCompanys);
exports.permissionCompanyRoute.put('/:permissionCompanyId', permissionCompany_controller_1.permissionCompanyController.updatePermissionCompany);
exports.permissionCompanyRoute.delete('/:permissionCompanyId', permissionCompany_controller_1.permissionCompanyController.deletePermissionCompany);
//# sourceMappingURL=permissionCompany.router.js.map