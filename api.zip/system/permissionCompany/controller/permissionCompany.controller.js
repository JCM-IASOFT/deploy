"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionCompanyController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const permissionCompany_service_1 = require("../service/permissionCompany.service");
class PermissionCompanyController {
    constructor() {
        this.findPermissionCompany = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { userId } = req.query;
            const permissionCompanys = yield permissionCompany_service_1.permissionCompanyService.findPermissionCompany(Number(userId));
            res.status(http_status_codes_1.StatusCodes.OK).json(permissionCompanys);
        });
        this.createPermissionCompanys = (req, res) => __awaiter(this, void 0, void 0, function* () {
            // HandleRequest(res, async () => {
            //     const response = await permissionCompanyService.createPermissionCompany(req.body);
            //     if (response) {
            //         return { code: StatusCodes.OK, success: true, message: MessageCustomApi.CREATED_SUCCES_BRAND, data: response };
            //     } else {
            //         return { code: StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessageCustomApi.ERROR_SERVER };
            //     }
            // });
        });
        this.updatePermissionCompany = (req, res) => __awaiter(this, void 0, void 0, function* () {
            // HandleRequest(res, async () => {
            //     try {
            //         const permissionCompanyId = req.params.permissionCompanyId
            //         const permissionCompany = req.body
            //         const response = await permissionCompanyService.updatePermissionCompany(Number(permissionCompanyId), permissionCompany);
            //         if (response) {
            //             return { code: StatusCodes.OK, success: true, message: MessageCustomApi.UPDATED_SUCCES_BRAND, data: response };
            //         } else {
            //             return { code: StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessageCustomApi.ERROR_SERVER };
            //         }
            //     } catch (error) {
            //         return { code: StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessageCustomApi.ERROR_SERVER };
            //     }
            // });
        });
        this.deletePermissionCompany = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const permissionCompanyId = req.params.permissionCompanyId;
                const response = yield permissionCompany_service_1.permissionCompanyService.deletePermissionCompany(Number(permissionCompanyId));
                if (response.affected > 0) {
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCES_BRAND, data: response };
                }
                else {
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.ERROR_SERVER };
                }
            }));
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new PermissionCompanyController();
        return this.instance;
    }
}
exports.permissionCompanyController = PermissionCompanyController.getInstance();
//# sourceMappingURL=permissionCompany.controller.js.map