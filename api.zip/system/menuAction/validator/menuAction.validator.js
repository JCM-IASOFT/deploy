"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteMenuAction = exports.validateUpdateMenuAction = exports.validateCreateMenuAction = void 0;
const express_validator_1 = require("express-validator");
// Middleware para manejar resultados de validación
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
// Validación para parámetros
const validateMenuActionId = (0, express_validator_1.param)('menuActionId')
    .exists().withMessage('El parámetro menuActionId es requerido')
    .isNumeric().withMessage('El parámetro menuActionId debe ser numérico');
const validateMenuId = (0, express_validator_1.check)('menuActions.*.menuId')
    .exists().withMessage('El parámetro menuId es requerido')
    .isNumeric().withMessage('El parámetro menuId debe ser numérico');
const validateActionId = (0, express_validator_1.check)('menuActions.*.actionId')
    .exists().withMessage('El parámetro actionId es requerido')
    .isNumeric().withMessage('El parámetro actionId debe ser numérico');
// Validación para la creación de un MenuAction
exports.validateCreateMenuAction = [
    validateMenuId,
    validateActionId,
    handleValidationResult
];
// Validación para la actualización de un MenuAction
exports.validateUpdateMenuAction = [
    validateMenuActionId,
    validateMenuId,
    validateActionId,
    handleValidationResult
];
// Validación para la eliminación de un MenuAction
exports.validateDeleteMenuAction = [
    validateMenuActionId,
    handleValidationResult
];
//# sourceMappingURL=menuAction.validator.js.map