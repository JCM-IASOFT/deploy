"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.employeTrackingRoute = void 0;
const express_1 = require("express");
const employeTracking_controller_1 = require("../controller/employeTracking.controller");
exports.employeTrackingRoute = (0, express_1.Router)();
exports.employeTrackingRoute.get('/', employeTracking_controller_1.employeTrackingController.findEmployeTracking);
exports.employeTrackingRoute.get('/all', employeTracking_controller_1.employeTrackingController.findAllEmployeTracking);
exports.employeTrackingRoute.post('/', employeTracking_controller_1.employeTrackingController.saveEmployeTracking);
//# sourceMappingURL=employeTracking.router.js.map