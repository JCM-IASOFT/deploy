"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.positionRoute = void 0;
const express_1 = require("express");
const position_controller_1 = require("../controller/position.controller");
exports.positionRoute = (0, express_1.Router)();
exports.positionRoute.get('/findAll', position_controller_1.positionController.findPosition);
exports.positionRoute.post('/create', position_controller_1.positionController.createPosition);
exports.positionRoute.put('/update', position_controller_1.positionController.updatePosition);
exports.positionRoute.put('/delete/:positionId', position_controller_1.positionController.deletePosition);
//# sourceMappingURL=position.routes.js.map