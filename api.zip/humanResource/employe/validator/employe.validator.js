"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteEmploye = exports.validateUpdateEmploye = exports.validateCreateEmploye = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
// Validation rules
const validateEmployeId = (0, express_validator_1.param)('employeId')
    .exists().withMessage('El parámetro employeId es requerido')
    .isNumeric().withMessage('El parámetro employeId debe ser numérico');
const validateEmployeName = (0, express_validator_1.check)('name')
    .exists().withMessage('El nombre es requerido')
    .isString().withMessage('El nombre debe ser una cadena de texto')
    .isLength({ max: 150 }).withMessage('El nombre no debe exceder los 150 caracteres');
const validatePhoto = (0, express_validator_1.check)('photo')
    .optional().isString().withMessage('La foto debe ser una cadena de texto')
    .isLength({ max: 250 }).withMessage('La foto no debe exceder los 250 caracteres');
const validateFatherLastName = (0, express_validator_1.check)('fatherLastName')
    .exists().withMessage('El apellido paterno es requerido')
    .isString().withMessage('El apellido paterno debe ser una cadena de texto')
    .isLength({ max: 150 }).withMessage('El apellido paterno no debe exceder los 150 caracteres');
const validateMotherLastName = (0, express_validator_1.check)('motherLastName')
    .exists().withMessage('El apellido materno es requerido')
    .isString().withMessage('El apellido materno debe ser una cadena de texto')
    .isLength({ max: 150 }).withMessage('El apellido materno no debe exceder los 150 caracteres');
const validateBirthDate = (0, express_validator_1.check)('birthDate')
    .exists().withMessage('La fecha de nacimiento es requerida')
    .isISO8601().withMessage('La fecha de nacimiento debe ser una fecha válida');
const validateAddress = (0, express_validator_1.check)('address')
    .optional().isString().withMessage('La dirección debe ser una cadena de texto')
    .isLength({ max: 200 }).withMessage('La dirección no debe exceder los 200 caracteres');
const validateCampusId = (0, express_validator_1.check)('campusId')
    .exists().withMessage('El ID del campus es requerido')
    .isInt().withMessage('El ID del campus debe ser un número entero');
const validateEmail = (0, express_validator_1.check)('email')
    .optional().isEmail().withMessage('El correo electrónico debe ser válido')
    .isLength({ max: 100 }).withMessage('El correo electrónico no debe exceder los 100 caracteres');
const validateDocumentTypeId = (0, express_validator_1.check)('documentTypeId')
    .exists().withMessage('El tipo de documento es requerido')
    .isInt().withMessage('El tipo de documento debe ser un número entero');
const validateDocumentNumber = (0, express_validator_1.check)('documentNumber')
    .exists().withMessage('El número de documento es requerido')
    .isString().withMessage('El número de documento debe ser una cadena de texto')
    .isLength({ max: 20 }).withMessage('El número de documento no debe exceder los 20 caracteres');
const validatePhone = (0, express_validator_1.check)('phone')
    .optional().isString().withMessage('El teléfono debe ser una cadena de texto')
    .isLength({ max: 20 }).withMessage('El teléfono no debe exceder los 20 caracteres');
const validateCellPhone = (0, express_validator_1.check)('cellPhone')
    .optional().isString().withMessage('El celular debe ser una cadena de texto')
    .isLength({ max: 20 }).withMessage('El celular no debe exceder los 20 caracteres');
const validateLicense = (0, express_validator_1.check)('license')
    .optional().isString().withMessage('La licencia debe ser una cadena de texto')
    .isLength({ max: 20 }).withMessage('La licencia no debe exceder los 20 caracteres');
const validatePositionId = (0, express_validator_1.check)('positionId')
    .exists().withMessage('El ID de la posición es requerido')
    .isInt().withMessage('El ID de la posición debe ser un número entero');
// Validation for creating an employee
exports.validateCreateEmploye = [
    validateEmployeName,
    validatePhoto,
    validateFatherLastName,
    validateMotherLastName,
    validateBirthDate,
    validateCampusId,
    //validateEmail,
    validateDocumentTypeId,
    validateDocumentNumber,
    //validatePhone,
    //validateCellPhone,
    //validateLicense,
    validatePositionId,
    handleValidationResult
];
// Validation for updating an employee
exports.validateUpdateEmploye = [
    validateEmployeId,
    validateEmployeName,
    validatePhoto,
    validateFatherLastName,
    validateMotherLastName,
    validateBirthDate,
    validateAddress,
    validateCampusId,
    validateEmail,
    validateDocumentTypeId,
    validateDocumentNumber,
    validatePhone,
    validateCellPhone,
    validateLicense,
    validatePositionId,
    handleValidationResult
];
// Validation for deleting an employee
exports.validateDeleteEmploye = [
    validateEmployeId,
    handleValidationResult
];
//# sourceMappingURL=employe.validator.js.map