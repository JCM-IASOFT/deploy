"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.productService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
class ProductService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProductService();
        return this.instance;
    }
    findAllProduct(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const products = yield modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin("product.prices", "prices")
                    .leftJoin("prices.priceGroup", "priceGroup")
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.currency', 'currency')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.companyId = :companyId', { companyId: companyId })
                    .select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.stock',
                    'product.currencyId',
                    'supplier',
                    'category.categoryId',
                    'category.name',
                    'subCategory.subCategoryId',
                    'subCategory.name',
                    'unitMeasurement.unitMeasurementId',
                    'unitMeasurement.name',
                    'brand.brandId',
                    'brand.name',
                    'group.groupId',
                    'group.name',
                    'presentation.presentationId',
                    'presentation.description',
                    'tax.taxId',
                    'tax.name',
                    'currency.currencyId',
                    'currency.code',
                    'currency.symbol',
                    'currency.currencyName',
                    'prices.priceId',
                    'prices.price',
                    'prices.priceGroupId',
                    'priceGroup.priceGroupId',
                    'priceGroup.name',
                ])
                    .orderBy("product.description", "ASC")
                    .getMany();
                return products;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findProduct(companyId, page, sizePage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const [products, total] = yield modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.currency', 'currency')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.companyId = :companyId', { companyId: companyId })
                    .select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.currencyId',
                    'supplier',
                    'category',
                    'subCategory',
                    'unitMeasurement',
                    'brand',
                    'group',
                    'presentation',
                    'tax',
                    'currency',
                ])
                    .orderBy("product.description", "ASC")
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { products, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findDataTableProduct(page, sizePage, product) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const omit = (page - 1) * sizePage;
                const productBuilder = modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.codes', 'codes')
                    .leftJoin('product.currency', 'currency')
                    .leftJoin('product.prices', 'prices')
                    .leftJoin('prices.priceGroup', 'priceGroup')
                    .leftJoin('product.file', 'file')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.companyId = :companyId', { companyId: product.companyId });
                if (product.groupId && product.groupId > 0) {
                    productBuilder.andWhere('product.groupId = :groupId', { groupId: product.groupId });
                }
                if (product.brandId && product.brandId > 0) {
                    productBuilder.andWhere('product.brandId = :brandId', { brandId: product.brandId });
                }
                if (product.categoryId && product.categoryId > 0) {
                    productBuilder.andWhere('product.categoryId = :categoryId', { categoryId: product.categoryId });
                }
                if (product.subCategoryId && product.subCategoryId > 0) {
                    productBuilder.andWhere('product.subCategoryId = :subCategoryId', { subCategoryId: product.subCategoryId });
                }
                if (product.description && product.description !== "") {
                    productBuilder.andWhere("product.description ILIKE :description", { description: `%${product.description}%` });
                }
                if (product.code && product.code !== "") {
                    productBuilder.andWhere("product.code ILIKE :code", { code: `%${product.code}%` });
                }
                productBuilder.select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    'product.stock',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.registerType',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.fileId',
                    'product.currencyId',
                    'supplier',
                    'category.categoryId',
                    'category.name',
                    'subCategory.subCategoryId',
                    'subCategory.name',
                    'unitMeasurement.unitMeasurementId',
                    'unitMeasurement.name',
                    'brand.brandId',
                    'brand.name',
                    'group.groupId',
                    'group.name',
                    'presentation.presentationId',
                    'presentation.description',
                    'tax.taxId',
                    'tax.name',
                    'currency.currencyId',
                    'currency.code',
                    'currency.symbol',
                    'currency.currencyName',
                    'codes',
                    'prices.priceId',
                    'prices.price',
                    'priceGroup.priceGroupId',
                    'priceGroup.name',
                    'file'
                ]);
                const [products, total] = yield productBuilder.orderBy("product.description", "ASC")
                    .skip(omit)
                    .take(sizePage)
                    .getManyAndCount();
                return { products, total };
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    findProductListPrice(companyId, priceGroupId, storeId, search, code) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const productQueryBuilder = modelslibrary_1.ProductModel.createQueryBuilder("product")
                    .leftJoinAndSelect("product.storeItems", "storeItems")
                    .leftJoinAndSelect("storeItems.store", "store")
                    .leftJoinAndSelect("product.prices", "prices")
                    .leftJoinAndSelect("product.brand", "brand")
                    .leftJoinAndSelect("product.currency", "currency")
                    .leftJoinAndSelect("product.file", "file")
                    .leftJoinAndSelect("prices.priceGroup", "priceGroup")
                    .select([
                    "product.productId",
                    "product.code",
                    "product.stock",
                    "product.description",
                    "product.priceDistributor",
                    "product.priceProduct",
                    "product.categoryId",
                    "product.subCategoryId",
                    "brand.brandId",
                    "brand.name",
                    "prices.priceId",
                    "currency.symbol",
                    "currency.code",
                    "prices.price",
                    "prices.priceGroupId",
                    "priceGroup.name",
                    "priceGroup.priceGroupId",
                    "storeItems.quantity",
                    "store.storeId",
                    "file"
                ])
                    .where("product.companyId = :companyId", { companyId: companyId })
                    .andWhere("product.deletedAt = :deletedAt", { deletedAt: '0' });
                if (priceGroupId && priceGroupId > 0) {
                    productQueryBuilder.andWhere("priceGroup.priceGroupId = :priceGroupId", { priceGroupId: priceGroupId });
                }
                if (search && search !== '') {
                    productQueryBuilder.andWhere("LOWER(product.description) LIKE LOWER(:description)", { description: `%${search.toLowerCase()}%` });
                }
                if (code && code !== '') {
                    productQueryBuilder.andWhere("product.code = :code", { code: code });
                }
                const products = yield productQueryBuilder.getMany();
                return products;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return error;
            }
        });
    }
    findByCode(code, companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const product = yield modelslibrary_1.ProductModel.createQueryBuilder('product')
                    .leftJoin("product.prices", "prices")
                    .leftJoin("prices.priceGroup", "priceGroup")
                    .leftJoin('product.supplier', 'supplier')
                    .leftJoin('product.category', 'category')
                    .leftJoin('product.subCategory', 'subCategory')
                    .leftJoin('product.unitMeasurement', 'unitMeasurement')
                    .leftJoin('product.brand', 'brand')
                    .leftJoin('product.group', 'group')
                    .leftJoin('product.presentation', 'presentation')
                    .leftJoin('product.tax', 'tax')
                    .leftJoin('product.currency', 'currency')
                    .where('product.deletedAt = :deletedAt', { deletedAt: '0' })
                    .andWhere('product.code = :code', { code })
                    .andWhere('product.companyId = :companyId', { companyId })
                    .select([
                    'product.productId',
                    'product.code',
                    'product.description',
                    'product.priceDistributor',
                    'product.priceProduct',
                    'product.commission',
                    'product.perishable',
                    'product.countStock',
                    'product.isBillable',
                    'product.isICBPERAffected',
                    'product.isSubjectToDetraction',
                    'product.stockMin',
                    'product.stockMax',
                    'product.netWeight',
                    'product.grossWeight',
                    'product.status',
                    'product.brandId',
                    'product.unitMeasurementId',
                    'product.subCategoryId',
                    'product.categoryId',
                    'product.supplierId',
                    'product.groupId',
                    'product.presentationId',
                    'product.taxId',
                    'product.currencyId',
                    'supplier',
                    'category',
                    'subCategory',
                    'unitMeasurement',
                    'brand',
                    'group',
                    'presentation',
                    'tax',
                    'currency',
                    'prices',
                    'priceGroup'
                ])
                    .getOne();
                return product;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                return null;
            }
        });
    }
    existCode(code, companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const exist = modelslibrary_1.ProductModel.exists({
                    where: {
                        code: code,
                        companyId: companyId
                    }
                });
                return exist;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createProduct(product, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const productEntity = modelslibrary_1.ProductModel.create(product);
                return yield queryRunner.manager.save(modelslibrary_1.ProductModel, productEntity);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateProduct(productId, product, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(modelslibrary_1.ProductModel, { productId }, {
                    description: product.description,
                    priceDistributor: product.priceDistributor,
                    priceProduct: product.priceProduct,
                    stock: product.stock,
                    commission: product.commission,
                    perishable: product.perishable,
                    countStock: product.countStock,
                    isBillable: product.isBillable,
                    isICBPERAffected: product.isICBPERAffected,
                    isSubjectToDetraction: product.isSubjectToDetraction,
                    stockMin: product.stockMin,
                    stockMax: product.stockMax,
                    netWeight: product.netWeight,
                    grossWeight: product.grossWeight,
                    status: product.status,
                    brandId: product.brandId,
                    unitMeasurementId: product.unitMeasurementId,
                    subCategoryId: product.subCategoryId,
                    categoryId: product.categoryId,
                    supplierId: product.supplierId,
                    groupId: product.groupId,
                    presentationId: product.presentationId,
                    companyId: product.companyId,
                    taxId: product.taxId,
                    currencyId: product.currencyId,
                    fileId: product.fileId
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteProduct(productId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.ProductModel.update({ productId }, {
                    deletedAt: "1",
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.productService = ProductService.getInstance();
//# sourceMappingURL=product.service.js.map