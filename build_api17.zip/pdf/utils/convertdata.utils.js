"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPayments = exports.getTypePayment = exports.getPaymentsExpenses = exports.getPaymentsIncome = exports.wrapText = exports.convertNumberToTextSUNAT = void 0;
const typeOperation_constant_1 = require("../../common/constant/typeOperation.constant");
const convertNumberToTextSUNAT = (num) => {
    const parteEntera = Math.floor(num);
    const parteDecimal = Math.round((num - parteEntera) * 100);
    let resultado = convertirParteEntera(parteEntera);
    if (resultado === '') {
        resultado = 'cero';
    }
    if (parteDecimal > 0) {
        resultado += ` con ${parteDecimal}/100`;
    }
    return resultado;
};
exports.convertNumberToTextSUNAT = convertNumberToTextSUNAT;
const convertirParteEntera = (n) => {
    if (n < 0 || n > 9999) {
        return 'Número fuera de rango';
    }
    if (n === 0) {
        return '';
    }
    const unidades = [
        '',
        'uno',
        'dos',
        'tres',
        'cuatro',
        'cinco',
        'seis',
        'siete',
        'ocho',
        'nueve',
    ];
    const diezAVeinte = [
        'diez',
        'once',
        'doce',
        'trece',
        'catorce',
        'quince',
        'dieciséis',
        'diecisiete',
        'dieciocho',
        'diecinueve',
    ];
    const decenas = [
        '',
        'diez',
        'veinte',
        'treinta',
        'cuarenta',
        'cincuenta',
        'sesenta',
        'setenta',
        'ochenta',
        'noventa',
    ];
    const centenas = [
        '',
        'ciento',
        'doscientos',
        'trescientos',
        'cuatrocientos',
        'quinientos',
        'seiscientos',
        'setecientos',
        'ochocientos',
        'novecientos',
    ];
    let texto = '';
    if (n === 100) {
        return 'cien';
    }
    if (n >= 1000) {
        if (n >= 2000) {
            texto += unidades[Math.floor(n / 1000)] + ' mil ';
        }
        else {
            texto += 'mil ';
        }
        n %= 1000;
    }
    if (n >= 100) {
        texto += centenas[Math.floor(n / 100)] + ' ';
        n %= 100;
    }
    if (n >= 20) {
        texto += decenas[Math.floor(n / 10)] + ' ';
        n %= 10;
    }
    if (n >= 10 && n <= 19) {
        texto += diezAVeinte[n - 10];
        n = 0;
    }
    texto += unidades[n];
    return texto.trim();
};
const wrapText = (text, maxLength) => {
    const words = text.split(' ');
    const lines = [];
    let currentLine = '';
    for (const word of words) {
        if ((currentLine.length + word.length) <= maxLength) {
            currentLine += word + ' ';
        }
        else {
            lines.push(currentLine.trim());
            currentLine = word + ' ';
        }
    }
    lines.push(currentLine.trim());
    return lines;
};
exports.wrapText = wrapText;
const getPaymentsIncome = (transaction) => {
    let sum = 0;
    for (const item of transaction.paymentTransaction) {
        if (transaction.typeOperation === typeOperation_constant_1.typeTransaction.INGRESO) {
            sum += Number(item.amount);
        }
    }
    return sum;
};
exports.getPaymentsIncome = getPaymentsIncome;
const getPaymentsExpenses = (transaction) => {
    let sum = 0;
    for (const item of transaction.paymentTransaction) {
        if (transaction.typeOperation === typeOperation_constant_1.typeTransaction.EGRESO) {
            sum += Number(item.amount);
        }
    }
    return sum;
};
exports.getPaymentsExpenses = getPaymentsExpenses;
const getTypePayment = (transaction) => {
    const uniqueTypes = new Set();
    for (const item of transaction.paymentTransaction) {
        uniqueTypes.add(item.paymentType.description);
    }
    return Array.from(uniqueTypes).join('\n');
};
exports.getTypePayment = getTypePayment;
const getPayments = (payment) => {
    let sum = 0;
    for (const item of payment) {
        sum += Number(item.amount);
    }
    return sum;
};
exports.getPayments = getPayments;
//# sourceMappingURL=convertdata.utils.js.map