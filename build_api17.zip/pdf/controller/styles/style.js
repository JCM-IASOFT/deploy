"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pdfStyles = void 0;
exports.pdfStyles = {
    header: {
        fontSize: 9,
        bold: true,
        alignment: 'center',
    },
    titleTable: {
        fontSize: 8,
        color: '#000000',
        bold: true,
        alignment: 'left',
    },
    textGaranty: {
        fontSize: 8,
        color: '#000000',
        bold: true,
        alignment: 'left',
    },
    tHeaderLabel: {
        fontSize: 8,
        bold: true,
        alignment: 'left',
    },
    tHeaderValue: {
        fontSize: 8,
    },
    tProductsHeader: {
        fontSize: 8.5,
        bold: true,
    },
    tProductsBody: {
        fontSize: 8,
    },
    tTotals: {
        fontSize: 9,
        bold: true,
        alignment: 'right',
    },
    tClientLabel: {
        fontSize: 8,
        alignment: 'right',
    },
    tClientValue: {
        fontSize: 8,
        bold: true,
    },
    text: {
        fontSize: 8,
        alignment: 'center',
    },
    important: {
        fontSize: 9,
        bold: true,
        alignment: 'center',
    },
    message: {
        fontSize: 8.4,
        alignment: 'left',
    },
    link: {
        fontSize: 8,
        bold: true,
        margin: [0, 0, 0, 4],
        alignment: 'center',
    },
};
//# sourceMappingURL=style.js.map