"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteWaitingTicket = exports.validateUpdateWaitingTicket = exports.validateCreateWaitingTicket = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateWaitingTicket = [
    (0, express_validator_1.check)('registrationDate').exists().not().isEmpty().withMessage("Ingresa fecha de registro"),
    (0, express_validator_1.check)('state').exists().not().isEmpty().withMessage("Ingresa el estado"),
    (0, express_validator_1.check)('detail').exists().not().isEmpty().withMessage("Ingresa el detalle"),
    (0, express_validator_1.check)('userId').exists().not().isEmpty().withMessage("Ingres responsable"),
    (0, express_validator_1.check)('sectorId').exists().not().isEmpty().withMessage("Ingresa el sector"),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateWaitingTicket = [
    (0, express_validator_1.check)('waitingticketId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteWaitingTicket = [
    (0, express_validator_1.check)('waitingticketId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=waitingticket.validator.js.map