"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.colorSettingsStateController = exports.ColorSettingsStateController = void 0;
const colorSettingsState_service_1 = require("../services/colorSettingsState.service");
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
class ColorSettingsStateController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ColorSettingsStateController();
        return this.instance;
    }
    findColorSettingsState(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId } = request.query;
                const findResponse = yield colorSettingsState_service_1.colorSettingsStateService.findColorSettingsState(Number(campusId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findColorSettingsStateForType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { campusId, type } = request.query;
                const findResponse = yield colorSettingsState_service_1.colorSettingsStateService.findColorSettingsStateForType(Number(campusId), type);
                return response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    createColorSettingsState(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { colorSettingsState } = request.body;
                    const createdResponse = yield colorSettingsState_service_1.colorSettingsStateService.createColorSettingsState(colorSettingsState);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DEFAULT, data: createdResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    createsColorSettingsState(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { colorSettingsState } = request.body;
                    if (!Array.isArray(colorSettingsState)) {
                        return {
                            code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageApi.ERROR_SERVER
                        };
                    }
                    const createdResponse = Promise.all(colorSettingsState.map((colorSettingsState) => __awaiter(this, void 0, void 0, function* () { return yield colorSettingsState_service_1.colorSettingsStateService.createColorSettingsState(colorSettingsState); })));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DEFAULT, data: createdResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    updateColorSettingsState(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { colorSettingsState } = request.body;
                    const updatedResponse = yield colorSettingsState_service_1.colorSettingsStateService.updateColorSettingsState(colorSettingsState);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DEFAULT, data: updatedResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    updatesColorSettingsState(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { colorSettingsState } = request.body;
                    if (!Array.isArray(colorSettingsState)) {
                        return {
                            code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageApi.ERROR_SERVER
                        };
                    }
                    const updatedResponse = Promise.all(colorSettingsState.map((colorSettingsState) => __awaiter(this, void 0, void 0, function* () { return yield colorSettingsState_service_1.colorSettingsStateService.updateColorSettingsState(colorSettingsState); })));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DEFAULT, data: updatedResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    deleteColorSettingsState(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { colorSettingsStateId } = request.params;
                    const deletedResponse = yield colorSettingsState_service_1.colorSettingsStateService.deleteColorSettingsState(Number(colorSettingsStateId));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DEFAULT, data: deletedResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
}
exports.ColorSettingsStateController = ColorSettingsStateController;
exports.colorSettingsStateController = ColorSettingsStateController.getInstance();
//# sourceMappingURL=colorSettingsState.controller.js.map