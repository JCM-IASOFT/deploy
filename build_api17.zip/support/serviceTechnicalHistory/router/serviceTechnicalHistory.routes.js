"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceTechnicalHistoryRoute = void 0;
const express_1 = require("express");
const serviceTechnicalHistory_controller_1 = require("../controller/serviceTechnicalHistory.controller");
exports.serviceTechnicalHistoryRoute = (0, express_1.Router)();
exports.serviceTechnicalHistoryRoute.post('/create', serviceTechnicalHistory_controller_1.serviceTechnicalHistoryController.createServiceTechnicalHistory);
//# sourceMappingURL=serviceTechnicalHistory.routes.js.map