"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.accessoryRoute = void 0;
const express_1 = require("express");
const accessories_controller_1 = require("../controller/accessories.controller");
const accessories_validator_1 = require("../validator/accessories.validator");
exports.accessoryRoute = (0, express_1.Router)();
exports.accessoryRoute.get('/', accessories_controller_1.accessoryController.findAccessory);
exports.accessoryRoute.post('/all', accessories_controller_1.accessoryController.findAllAccessory);
exports.accessoryRoute.post('/create', accessories_validator_1.validateCreateAccessory, accessories_controller_1.accessoryController.createAccessorys);
exports.accessoryRoute.put('/', accessories_validator_1.validateUpdateAccessory, accessories_controller_1.accessoryController.updateAccessory);
exports.accessoryRoute.delete('/', accessories_validator_1.validateDeleteAccessory, accessories_controller_1.accessoryController.deleteAccessory);
//# sourceMappingURL=accessories.router.js.map