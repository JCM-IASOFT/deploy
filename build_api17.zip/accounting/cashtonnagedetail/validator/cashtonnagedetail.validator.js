"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateCreateCashTonnageDetail = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateCashTonnageDetail = [
    (0, express_validator_1.check)('responsibleId').exists().not().isEmpty(),
    (0, express_validator_1.check)('cashBoxDetailId').exists().not().isEmpty(),
    (0, express_validator_1.check)('registrationDate').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=cashtonnagedetail.validator.js.map