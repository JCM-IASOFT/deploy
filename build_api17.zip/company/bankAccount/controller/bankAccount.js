"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bankAccountController = void 0;
const http_status_codes_1 = require("http-status-codes");
const request_handler_1 = require("../../../common/handler/request.handler");
const message_api_1 = require("../../../common/constant/message.api");
const bankAccount_service_1 = require("../service/bankAccount.service");
class BankAccountController {
    static getInstance() {
        if (!this.instance)
            this.instance = new BankAccountController();
        return this.instance;
    }
    findBankAccountDataTable(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId } = request.query;
                const findResponse = yield bankAccount_service_1.bankAccountService.findBankAccount(Number(companyId));
                return response.status(http_status_codes_1.StatusCodes.OK).json({
                    data: findResponse,
                    draw: Math.random(),
                    recordsFiltered: findResponse.length,
                    recordsTotal: findResponse.length,
                });
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findBankAccount(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId } = request.query;
                const findResponse = yield bankAccount_service_1.bankAccountService.findBankAccount(Number(companyId));
                return response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    createBankAccount(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { bankAccount } = request.body;
                    const createResponse = yield bankAccount_service_1.bankAccountService.createBankAccount(bankAccount);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_BANK_ACCOUNT, data: createResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    updateBankAccount(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { bankAccount } = request.body;
                    const updateResponse = yield bankAccount_service_1.bankAccountService.updateBankAccount(bankAccount);
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_BANK_ACCOUNT, data: updateResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    deleteBankAccount(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { id } = request.params;
                    const deleteResponse = yield bankAccount_service_1.bankAccountService.deleteBankAccount(Number(id));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_BANK_ACCOUNT, data: deleteResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    changeStatusBankAccount(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { id } = request.params;
                    const deleteResponse = yield bankAccount_service_1.bankAccountService.changeStatusBankAccount(Number(id));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CHANGE_STATUS_SUCCESS_BANK_ACCOUNT, data: deleteResponse };
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
}
exports.bankAccountController = BankAccountController.getInstance();
//# sourceMappingURL=bankAccount.js.map