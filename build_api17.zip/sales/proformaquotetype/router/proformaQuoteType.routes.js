"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.proformaQuoteTypeRoute = void 0;
const express_1 = require("express");
const proformaQuoteType_1 = require("../../proformaquotetype/controller/proformaQuoteType");
exports.proformaQuoteTypeRoute = (0, express_1.Router)();
exports.proformaQuoteTypeRoute.get('/allD', proformaQuoteType_1.proformaQuoteTypeController.findProformaQuoteTypeDataTable);
exports.proformaQuoteTypeRoute.get('/all', proformaQuoteType_1.proformaQuoteTypeController.findProformaQuoteType);
exports.proformaQuoteTypeRoute.post('/create', proformaQuoteType_1.proformaQuoteTypeController.createProformaQuoteType);
exports.proformaQuoteTypeRoute.put('/update', proformaQuoteType_1.proformaQuoteTypeController.updateProformaQuoteType);
exports.proformaQuoteTypeRoute.put('/delete/:id', proformaQuoteType_1.proformaQuoteTypeController.deleteProformaQuoteType);
//# sourceMappingURL=proformaQuoteType.routes.js.map