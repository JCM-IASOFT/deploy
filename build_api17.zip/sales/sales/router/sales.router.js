"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesRoute = void 0;
const express_1 = require("express");
const sales_controller_1 = require("../controller/sales.controller");
const sales_validator_1 = require("../validator/sales.validator");
exports.salesRoute = (0, express_1.Router)();
exports.salesRoute.get('/', sales_controller_1.salesController.findSales);
exports.salesRoute.post('/all', sales_controller_1.salesController.findAllSales);
exports.salesRoute.get('/one', sales_controller_1.salesController.findOneSales);
exports.salesRoute.post('/create', sales_validator_1.validateCreateSales, sales_controller_1.salesController.createSales);
exports.salesRoute.post('/credit', sales_controller_1.salesController.createSalesCredit);
exports.salesRoute.put('/', sales_validator_1.validateUpdateSales, sales_controller_1.salesController.updateSales);
exports.salesRoute.delete('/', sales_validator_1.validateDeleteSales, sales_controller_1.salesController.deleteSales);
exports.salesRoute.patch('/change', sales_controller_1.salesController.changeStatus);
//# sourceMappingURL=sales.router.js.map