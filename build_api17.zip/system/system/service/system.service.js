"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.systemService = void 0;
const modelslibrary_1 = require("modelslibrary");
const save_error_1 = require("../../../common/handler/save.error");
class SystemService {
    static getInstance() {
        if (!this.instance)
            this.instance = new SystemService();
        return this.instance;
    }
    findAllSystem(companyId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const systems = yield modelslibrary_1.SystemModel.find();
                return systems;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                return [];
            }
        });
    }
    createSystem(systems) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.SystemModel.save(systems);
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    updateSystem(system) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield modelslibrary_1.SystemModel.update({ systemId: system.systemId }, {
                    name: system.name
                });
                return response;
            }
            catch (error) {
                save_error_1.logger.error(this.getErrorMessage(error));
                throw error;
            }
        });
    }
    getErrorMessage(error) {
        return error instanceof Error ? error.message : 'Se produjo un error desconocido';
    }
}
exports.systemService = SystemService.getInstance();
//# sourceMappingURL=system.service.js.map