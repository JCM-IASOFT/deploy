"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const archiver_1 = __importDefault(require("archiver"));
const output = fs_1.default.createWriteStream('build.zip');
const archive = (0, archiver_1.default)('zip', {
    zlib: { level: 9 } // Nivel de compresión máximo
});
output.on('close', () => {
    console.log(`${archive.pointer()} total bytes`);
    console.log('Archivo ZIP generado exitosamente.');
});
archive.on('error', (err) => {
    throw err;
});
archive.pipe(output);
// Cambia './dist' por la carpeta que deseas comprimir
archive.directory('./dist/', false);
archive.finalize();
//# sourceMappingURL=zip.js.map