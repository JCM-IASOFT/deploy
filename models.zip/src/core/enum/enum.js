"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeTrackingType = exports.TypeTimeRequests = exports.StatusRequests = exports.ActionTypeRequests = exports.TransactionMovementType = exports.TransactionType = exports.colorEffectType = exports.colorSettingsType = exports.RegisterProductType = exports.TypeOperationPaymentService = exports.TypeOperationDeviceHistory = void 0;
/**
 * Enumeración que representa los tipos de operaciones en el historial de dispositivos.
 *
 * Tipos de Operaciones:
 * - **Initialization (Inicialización)**: Utilizado cuando se inicializa un dispositivo por primera vez en el sistema.
 * - **Increase (Incremento)**: Utilizado cuando se incrementa la cantidad o el valor de un dispositivo.
 * - **Discount (Descuento)**: Utilizado cuando se aplica un descuento en la cantidad o el valor de un dispositivo.
 * - **Repayment (Reembolso)**: Utilizado cuando se realiza un reembolso relacionado con un dispositivo.
 */
var TypeOperationDeviceHistory;
(function (TypeOperationDeviceHistory) {
    TypeOperationDeviceHistory["Initialization"] = "initialization";
    TypeOperationDeviceHistory["Increase"] = "increase";
    TypeOperationDeviceHistory["Discount"] = "discount";
    TypeOperationDeviceHistory["Repayment"] = "repayment";
})(TypeOperationDeviceHistory || (exports.TypeOperationDeviceHistory = TypeOperationDeviceHistory = {}));
/**
 * Enumeración que representa el tipo de pago de un servicio.
 *
 * Tipos de Pago:
 * - **Advance (Anticipo)**: Utilizado cuando se realiza un pago parcial o un adelanto para el servicio.
 * - **Completion (Completado)**: Utilizado cuando el servicio se completa totalmente y se realiza el pago total.
 */
var TypeOperationPaymentService;
(function (TypeOperationPaymentService) {
    TypeOperationPaymentService["Advance"] = "advance";
    TypeOperationPaymentService["completion"] = "completion";
})(TypeOperationPaymentService || (exports.TypeOperationPaymentService = TypeOperationPaymentService = {}));
/**
 * Enumeración que representa los tipos de registro de productos.
 *
 * Tipos de Registro:
 * - **Detailed (Detallado)**: Utilizado cuando se registra un producto con información completa y detallada.
 * - **Basic (Básico)**: Utilizado cuando se registra un producto con la información mínima necesaria.
 */
var RegisterProductType;
(function (RegisterProductType) {
    RegisterProductType["Detailed"] = "detailed";
    RegisterProductType["Basic"] = "basic";
})(RegisterProductType || (exports.RegisterProductType = RegisterProductType = {}));
/**
 * Enumeración que representa los tipos de configuracion de colores
 *
 * Tipos de Registro:
 * - **service (servicio)**: Utilizado cuando se quiere agregar colores a los estados de servicio
 * - **proforma (proforma)**: Utilizado cuando se quiere agregar colores a los estados de proforma
 */
var colorSettingsType;
(function (colorSettingsType) {
    colorSettingsType["service"] = "service";
    colorSettingsType["proforma"] = "proforma";
})(colorSettingsType || (exports.colorSettingsType = colorSettingsType = {}));
/**
 * Enumeración que representa los tipos de efecto de color
 *
 * Tipos de Registro:
 * - **static (estatico)**: Utilizado cuando se quiere que el color sea estatico
 * - **blinking (parpadenate)**: Utilizado cuando se quiere que el color parpadee
 */
var colorEffectType;
(function (colorEffectType) {
    colorEffectType["static"] = "static";
    colorEffectType["blinking"] = "blinking";
})(colorEffectType || (exports.colorEffectType = colorEffectType = {}));
/**
 * Enum que representa los diferentes tipos de transacciones de inventario.
 */
var TransactionType;
(function (TransactionType) {
    TransactionType[TransactionType["INGRESO_INICIAL"] = 1] = "INGRESO_INICIAL";
    TransactionType[TransactionType["COMPRA_O_ADQUISICION"] = 2] = "COMPRA_O_ADQUISICION";
    TransactionType[TransactionType["TRANSFERENCIA_ENTRE_ALMACENES_INGRESO"] = 3] = "TRANSFERENCIA_ENTRE_ALMACENES_INGRESO";
    TransactionType[TransactionType["DEVOLUCION_DE_CLIENTES"] = 4] = "DEVOLUCION_DE_CLIENTES";
    TransactionType[TransactionType["PRODUCCION_O_FABRICACION_INGRESO"] = 5] = "PRODUCCION_O_FABRICACION_INGRESO";
    TransactionType[TransactionType["AJUSTE_DE_INVENTARIO_INGRESO"] = 6] = "AJUSTE_DE_INVENTARIO_INGRESO";
    TransactionType[TransactionType["DONACIONES_O_REGALOS"] = 7] = "DONACIONES_O_REGALOS";
    TransactionType[TransactionType["INVENTARIO_EN_CONSIGNACION"] = 8] = "INVENTARIO_EN_CONSIGNACION";
    TransactionType[TransactionType["VENTA"] = 9] = "VENTA";
    TransactionType[TransactionType["TRANSFERENCIA_ENTRE_ALMACENES_SALIDA"] = 10] = "TRANSFERENCIA_ENTRE_ALMACENES_SALIDA";
    TransactionType[TransactionType["DEVOLUCION_A_PROVEEDOR"] = 11] = "DEVOLUCION_A_PROVEEDOR";
    TransactionType[TransactionType["CONSUMO_INTERNO"] = 12] = "CONSUMO_INTERNO";
    TransactionType[TransactionType["PRODUCCION_O_FABRICACION_SALIDA"] = 13] = "PRODUCCION_O_FABRICACION_SALIDA";
    TransactionType[TransactionType["AJUSTE_DE_INVENTARIO_SALIDA"] = 14] = "AJUSTE_DE_INVENTARIO_SALIDA";
    TransactionType[TransactionType["DONACION_O_TRASLADO"] = 15] = "DONACION_O_TRASLADO";
    TransactionType[TransactionType["BAJA_POR_CONSUMO_O_VENCIMIENTO"] = 16] = "BAJA_POR_CONSUMO_O_VENCIMIENTO";
})(TransactionType || (exports.TransactionType = TransactionType = {}));
/**
 * Enum que representa los tipos de transacción de inventario.
 */
var TransactionMovementType;
(function (TransactionMovementType) {
    /**
     * Entrada de productos al inventario.
     */
    TransactionMovementType["ENTRADA"] = "E";
    /**
     * Salida de productos del inventario.
     */
    TransactionMovementType["SALIDA"] = "S";
})(TransactionMovementType || (exports.TransactionMovementType = TransactionMovementType = {}));
/**
 * Enum que representa los tipos de acciones para las solicitudes de estado
 */
var ActionTypeRequests;
(function (ActionTypeRequests) {
    ActionTypeRequests["pause"] = "pause";
    ActionTypeRequests["resume"] = "resume";
})(ActionTypeRequests || (exports.ActionTypeRequests = ActionTypeRequests = {}));
var StatusRequests;
(function (StatusRequests) {
    StatusRequests["initiated"] = "initiated";
    StatusRequests["progress"] = "progress";
    StatusRequests["complete"] = "complete";
})(StatusRequests || (exports.StatusRequests = StatusRequests = {}));
var TypeTimeRequests;
(function (TypeTimeRequests) {
    TypeTimeRequests["days"] = "days";
    TypeTimeRequests["hours"] = "hours";
    TypeTimeRequests["minutes"] = "minutes";
})(TypeTimeRequests || (exports.TypeTimeRequests = TypeTimeRequests = {}));
/**
 * * SEGUIMIENTO
 */
var EmployeTrackingType;
(function (EmployeTrackingType) {
    EmployeTrackingType["support"] = "support";
    EmployeTrackingType["sales"] = "sales";
    EmployeTrackingType["proforma"] = "proforma";
    EmployeTrackingType["credit"] = "credit";
})(EmployeTrackingType || (exports.EmployeTrackingType = EmployeTrackingType = {}));
//# sourceMappingURL=enum.js.map