"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypeInvoice = void 0;
var TypeInvoice;
(function (TypeInvoice) {
    TypeInvoice["sales"] = "sales";
    TypeInvoice["auxiliaries"] = "auxiliaries";
})(TypeInvoice || (exports.TypeInvoice = TypeInvoice = {}));
//# sourceMappingURL=invoice.enum.js.map