"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BarcodeType = void 0;
var BarcodeType;
(function (BarcodeType) {
    BarcodeType["UPC"] = "UPC";
    BarcodeType["EAN"] = "EAN";
    BarcodeType["CODE_39"] = "CODE 39";
    BarcodeType["CODE_128"] = "CODE 128";
    BarcodeType["ITF"] = "ITF";
    BarcodeType["CODABAR"] = "CODABAR";
    BarcodeType["QR_CODE"] = "QR";
    BarcodeType["DATA_MATRIX"] = "DATA MATRIX";
    BarcodeType["PDF417"] = "PDF417";
    BarcodeType["AZTEC"] = "AZTEC";
    BarcodeType["MAXICODE"] = "MAXICODE";
})(BarcodeType || (exports.BarcodeType = BarcodeType = {}));
//# sourceMappingURL=barcodeType.js.map