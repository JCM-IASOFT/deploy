"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PriceGroupModel = void 0;
const typeorm_1 = require("typeorm");
const price_1 = require("./price");
const proformaQuote_1 = require("../sales/proformaQuote");
const campus_1 = require("../company/campus");
const terminal_1 = require("./terminal");
const client_1 = require("./client");
const clientType_1 = require("../company/clientType");
/**
 * * GRUPO DE PRECIOS
 * - Guardamos tipos de grupo de precio
 *  ejm: PRECIO PRECIO
 */
let PriceGroupModel = class PriceGroupModel extends typeorm_1.BaseEntity {
};
exports.PriceGroupModel = PriceGroupModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], PriceGroupModel.prototype, "priceGroupId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '' }),
    __metadata("design:type", String)
], PriceGroupModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], PriceGroupModel.prototype, "default", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PriceGroupModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, (campus) => campus.priceGroups),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], PriceGroupModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => price_1.PriceModel, (price) => price.priceGroup),
    __metadata("design:type", Array)
], PriceGroupModel.prototype, "prices", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], PriceGroupModel.prototype, "commission", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuote_1.ProformaQuoteModel, service => service.priceGroup),
    __metadata("design:type", Array)
], PriceGroupModel.prototype, "proformaQuotes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => terminal_1.TerminalModel, (terminal) => terminal.priceGroup),
    __metadata("design:type", Array)
], PriceGroupModel.prototype, "terminals", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => client_1.ClientModel, client => client.priceGroup, { nullable: true }),
    __metadata("design:type", Array)
], PriceGroupModel.prototype, "clients", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => clientType_1.ClientTypeModel, clientType => clientType.priceGroup, { nullable: true }),
    __metadata("design:type", Array)
], PriceGroupModel.prototype, "clientTypes", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PriceGroupModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PriceGroupModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PriceGroupModel.prototype, "createdAt", void 0);
exports.PriceGroupModel = PriceGroupModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'price_group' })
], PriceGroupModel);
//# sourceMappingURL=priceGroup.js.map