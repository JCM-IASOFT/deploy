"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProformaQuoteTypeModel = void 0;
const typeorm_1 = require("typeorm");
const proformaQuote_1 = require("./proformaQuote");
/**
 * - Detalle de Proforma y Cotizacion
 */
let ProformaQuoteTypeModel = class ProformaQuoteTypeModel extends typeorm_1.BaseEntity {
};
exports.ProformaQuoteTypeModel = ProformaQuoteTypeModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ProformaQuoteTypeModel.prototype, "proformaQuoteTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 150 }),
    __metadata("design:type", String)
], ProformaQuoteTypeModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProformaQuoteTypeModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuote_1.ProformaQuoteModel, service => service.proformaQuoteType),
    __metadata("design:type", Array)
], ProformaQuoteTypeModel.prototype, "proformaQuotes", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ProformaQuoteTypeModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ProformaQuoteTypeModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ProformaQuoteTypeModel.prototype, "deletedAt", void 0);
exports.ProformaQuoteTypeModel = ProformaQuoteTypeModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'proforma_quote_type' })
], ProformaQuoteTypeModel);
//# sourceMappingURL=proformaQuoteType.js.map