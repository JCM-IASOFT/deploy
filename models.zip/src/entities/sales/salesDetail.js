"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesDetailModel = void 0;
const typeorm_1 = require("typeorm");
const product_1 = require("../inventory/product");
const sales_1 = require("./sales");
let SalesDetailModel = class SalesDetailModel extends typeorm_1.BaseEntity {
};
exports.SalesDetailModel = SalesDetailModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], SalesDetailModel.prototype, "salesDetailId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesDetailModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], SalesDetailModel.prototype, "price", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], SalesDetailModel.prototype, "total", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], SalesDetailModel.prototype, "discountPercentage", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], SalesDetailModel.prototype, "discountAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesDetailModel.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bool', default: false }),
    __metadata("design:type", Boolean)
], SalesDetailModel.prototype, "isTraking", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesDetailModel.prototype, "salesId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], SalesDetailModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], SalesDetailModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], SalesDetailModel.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sales_1.SalesModel, sales => sales.salesDetails),
    (0, typeorm_1.JoinColumn)({ name: 'salesId', referencedColumnName: 'salesId' }),
    __metadata("design:type", sales_1.SalesModel)
], SalesDetailModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_1.ProductModel, product => product.salesDetails),
    (0, typeorm_1.JoinColumn)({ name: 'productId', referencedColumnName: 'productId' }),
    __metadata("design:type", product_1.ProductModel)
], SalesDetailModel.prototype, "product", void 0);
exports.SalesDetailModel = SalesDetailModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'sales_detail' })
], SalesDetailModel);
//# sourceMappingURL=salesDetail.js.map