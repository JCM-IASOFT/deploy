"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigSalesTrackingModel = void 0;
const typeorm_1 = require("typeorm");
const campus_1 = require("../company/campus");
let ConfigSalesTrackingModel = class ConfigSalesTrackingModel extends typeorm_1.BaseEntity {
};
exports.ConfigSalesTrackingModel = ConfigSalesTrackingModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ConfigSalesTrackingModel.prototype, "configSalesTrackingId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], ConfigSalesTrackingModel.prototype, "previousDays", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], ConfigSalesTrackingModel.prototype, "daysLater", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean' }),
    __metadata("design:type", Boolean)
], ConfigSalesTrackingModel.prototype, "state", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], ConfigSalesTrackingModel.prototype, "stateAlert", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', default: '' }),
    __metadata("design:type", String)
], ConfigSalesTrackingModel.prototype, "message", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'simple-array' }),
    __metadata("design:type", Array)
], ConfigSalesTrackingModel.prototype, "hours", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ConfigSalesTrackingModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => campus_1.CampusModel, (campus) => campus.configSalesTracking, { cascade: true }),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], ConfigSalesTrackingModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char',
        length: 1,
        default: () => "'0'",
    }),
    __metadata("design:type", String)
], ConfigSalesTrackingModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ConfigSalesTrackingModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ConfigSalesTrackingModel.prototype, "createdAt", void 0);
exports.ConfigSalesTrackingModel = ConfigSalesTrackingModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'config_sales_tracking', schema: 'sales' })
], ConfigSalesTrackingModel);
//# sourceMappingURL=configSalesTracking.js.map