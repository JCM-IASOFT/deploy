"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesTrackingModel = void 0;
const typeorm_1 = require("typeorm");
const sales_1 = require("./sales");
const client_1 = require("./client");
const campus_1 = require("../company/campus");
const company_1 = require("../company/company");
const product_1 = require("../inventory/product");
let SalesTrackingModel = class SalesTrackingModel extends typeorm_1.BaseEntity {
};
exports.SalesTrackingModel = SalesTrackingModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "salesTrackingId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], SalesTrackingModel.prototype, "state", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], SalesTrackingModel.prototype, "regDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "clientId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "salesId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesTrackingModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sales_1.SalesModel, sales => sales.salesTracking),
    (0, typeorm_1.JoinColumn)({ name: 'salesId', referencedColumnName: 'salesId' }),
    __metadata("design:type", sales_1.SalesModel
    /**
    * Relacion ManyToOne con clientes
    */
    )
], SalesTrackingModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => client_1.ClientModel, client => client.salesTracking),
    (0, typeorm_1.JoinColumn)({ name: 'clientId', referencedColumnName: 'clientId' }),
    __metadata("design:type", client_1.ClientModel
    /**
    * Relacion ManyToOne con clientes
    */
    )
], SalesTrackingModel.prototype, "client", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.salesTracking),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel
    /**
    * Relacion ManyToOne con clientes
    */
    )
], SalesTrackingModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, company => company.salesTracking),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel
    /**
    * Relacion ManyToOne con clientes
    */
    )
], SalesTrackingModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_1.ProductModel, product => product.salesTracking),
    (0, typeorm_1.JoinColumn)({ name: 'productId', referencedColumnName: 'productId' }),
    __metadata("design:type", product_1.ProductModel
    /**
     * Indicador de eliminación lógica del registro ('0' = no eliminado).
     */
    )
], SalesTrackingModel.prototype, "product", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], SalesTrackingModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], SalesTrackingModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], SalesTrackingModel.prototype, "updatedAt", void 0);
exports.SalesTrackingModel = SalesTrackingModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'sales_tracking' })
], SalesTrackingModel);
//# sourceMappingURL=salesTracking.js.map