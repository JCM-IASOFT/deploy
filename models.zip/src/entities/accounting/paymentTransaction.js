"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentTransactionModel = void 0;
const typeorm_1 = require("typeorm");
const finance_model_1 = require("./finance.model");
const paymentType_1 = require("../company/paymentType");
let PaymentTransactionModel = class PaymentTransactionModel extends typeorm_1.BaseEntity {
};
exports.PaymentTransactionModel = PaymentTransactionModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], PaymentTransactionModel.prototype, "paymentTransactionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], PaymentTransactionModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentTransactionModel.prototype, "financeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentTransactionModel.prototype, "paymentTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], PaymentTransactionModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => finance_model_1.FinanceModel, finance => finance.paymentTransaction, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'financeId', referencedColumnName: 'financeId' }),
    __metadata("design:type", finance_model_1.FinanceModel)
], PaymentTransactionModel.prototype, "finance", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => paymentType_1.PaymentTypeModel, paymentType => paymentType.paymentsTransaction, { onDelete: 'CASCADE', eager: true }),
    (0, typeorm_1.JoinColumn)({ name: 'paymentTypeId', referencedColumnName: 'paymentTypeId' }),
    __metadata("design:type", paymentType_1.PaymentTypeModel)
], PaymentTransactionModel.prototype, "paymentType", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentTransactionModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentTransactionModel.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PaymentTransactionModel.prototype, "deletedAt", void 0);
exports.PaymentTransactionModel = PaymentTransactionModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'payment_transaction' })
], PaymentTransactionModel);
//# sourceMappingURL=paymentTransaction.js.map