"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CashClosingModel = void 0;
const typeorm_1 = require("typeorm");
const cashClosingDetail_1 = require("./cashClosingDetail");
const sales_1 = require("../sales/sales");
const service_1 = require("../support/service");
const finance_model_1 = require("./finance.model");
/**
 * * Cierre de caja
 */
let CashClosingModel = class CashClosingModel extends typeorm_1.BaseEntity {
};
exports.CashClosingModel = CashClosingModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CashClosingModel.prototype, "cashClosingId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashClosingModel.prototype, "number", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashClosingModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashClosingModel.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], CashClosingModel.prototype, "openingDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], CashClosingModel.prototype, "closingDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "decimal", precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CashClosingModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashClosingModel.prototype, "currencyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bool', default: true }),
    __metadata("design:type", Boolean)
], CashClosingModel.prototype, "state", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], CashClosingModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashClosingModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashClosingModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => cashClosingDetail_1.CashClosingDetailModel, cashClosingDetail => cashClosingDetail.cashClosing),
    __metadata("design:type", Array)
], CashClosingModel.prototype, "cashClosingDetails", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sales_1.SalesModel, sales => sales.cashClosing),
    __metadata("design:type", Array)
], CashClosingModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => service_1.ServiceModel, service => service.cashClosing),
    __metadata("design:type", Array)
], CashClosingModel.prototype, "services", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => finance_model_1.FinanceModel, finance => finance.cashClosing),
    __metadata("design:type", Array)
], CashClosingModel.prototype, "finances", void 0);
exports.CashClosingModel = CashClosingModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'cash_closing', comment: 'Cierre de caja' })
], CashClosingModel);
//# sourceMappingURL=cashClosing.js.map