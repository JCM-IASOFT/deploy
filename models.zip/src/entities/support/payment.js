"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentModel = void 0;
const typeorm_1 = require("typeorm");
const service_1 = require("./service");
const paymentType_1 = require("../company/paymentType");
const enum_1 = require("../../core/enum/enum");
/**
 * * payment = Pagos
 */
let PaymentModel = class PaymentModel extends typeorm_1.BaseEntity {
};
exports.PaymentModel = PaymentModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], PaymentModel.prototype, "paymentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentModel.prototype, "paymentTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], PaymentModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], PaymentModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentModel.prototype, "serviceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', default: enum_1.TypeOperationPaymentService.Advance, enum: enum_1.TypeOperationPaymentService }),
    __metadata("design:type", String)
], PaymentModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => paymentType_1.PaymentTypeModel, paymentType => paymentType.payments, { eager: true }),
    (0, typeorm_1.JoinColumn)({ name: 'paymentTypeId', referencedColumnName: 'paymentTypeId' }),
    __metadata("design:type", paymentType_1.PaymentTypeModel)
], PaymentModel.prototype, "paymentType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => service_1.ServiceModel, service => service.payments),
    (0, typeorm_1.JoinColumn)({ name: 'serviceId', referencedColumnName: 'serviceId' }),
    __metadata("design:type", service_1.ServiceModel)
], PaymentModel.prototype, "service", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PaymentModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentModel.prototype, "updatedBy", void 0);
exports.PaymentModel = PaymentModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'support', name: "payment" })
], PaymentModel);
//# sourceMappingURL=payment.js.map