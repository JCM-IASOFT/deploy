"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrencyModel = void 0;
const typeorm_1 = require("typeorm");
const company_1 = require("./company");
const sales_1 = require("../sales/sales");
const proformaQuote_1 = require("../sales/proformaQuote");
const product_1 = require("../inventory/product");
const credit_1 = require("../credit/credit");
const bankAccount_1 = require("./bankAccount");
const terminal_1 = require("../sales/terminal");
/**
 * Modelo de entidad para representar la información de moneda.
 * Esta clase mapea a la tabla 'currency' en el esquema 'finance'.
 */
let CurrencyModel = class CurrencyModel extends typeorm_1.BaseEntity {
};
exports.CurrencyModel = CurrencyModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CurrencyModel.prototype, "currencyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], CurrencyModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 100, default: '0' }),
    __metadata("design:type", String)
], CurrencyModel.prototype, "code", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 100, default: '' }),
    __metadata("design:type", String)
], CurrencyModel.prototype, "symbol", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 100, default: '' }),
    __metadata("design:type", String)
], CurrencyModel.prototype, "currencyName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 150, default: '' }),
    __metadata("design:type", String)
], CurrencyModel.prototype, "countryName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "boolean", default: false }),
    __metadata("design:type", Boolean)
], CurrencyModel.prototype, "default", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], CurrencyModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], CurrencyModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 1, default: () => '0' }),
    __metadata("design:type", String)
], CurrencyModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, company => company.currencies),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], CurrencyModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sales_1.SalesModel, sales => sales.currency),
    __metadata("design:type", Array)
], CurrencyModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => credit_1.CreditModel, credit => credit.currency),
    __metadata("design:type", Array)
], CurrencyModel.prototype, "credits", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => product_1.ProductModel, product => product.currency),
    __metadata("design:type", Array)
], CurrencyModel.prototype, "products", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuote_1.ProformaQuoteModel, service => service.currency),
    __metadata("design:type", Array)
], CurrencyModel.prototype, "proformaQuotes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => bankAccount_1.BankAccountModel, bankAccount => bankAccount.currency),
    __metadata("design:type", Array)
], CurrencyModel.prototype, "bankAccount", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => terminal_1.TerminalModel, (terminal) => terminal.currency),
    __metadata("design:type", Array)
], CurrencyModel.prototype, "terminals", void 0);
exports.CurrencyModel = CurrencyModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: 'currency' })
], CurrencyModel);
//# sourceMappingURL=currency.js.map