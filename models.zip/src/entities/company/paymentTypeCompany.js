"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentTypeCompanyModel = void 0;
const typeorm_1 = require("typeorm");
const company_1 = require("./company");
const paymentType_1 = require("./paymentType");
/**
 * * paymentType = Tipo de pagos
 */
let PaymentTypeCompanyModel = class PaymentTypeCompanyModel extends typeorm_1.BaseEntity {
};
exports.PaymentTypeCompanyModel = PaymentTypeCompanyModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentTypeCompanyModel.prototype, "paymentTypeId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentTypeCompanyModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.paymentTypeCompanies),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], PaymentTypeCompanyModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => paymentType_1.PaymentTypeModel, (paymentTypeCompany) => paymentTypeCompany.paymentTypeCompanies),
    (0, typeorm_1.JoinColumn)({ name: 'paymentTypeId', referencedColumnName: 'paymentTypeId' }),
    __metadata("design:type", paymentType_1.PaymentTypeModel)
], PaymentTypeCompanyModel.prototype, "paymentType", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PaymentTypeCompanyModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentTypeCompanyModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentTypeCompanyModel.prototype, "updatedBy", void 0);
exports.PaymentTypeCompanyModel = PaymentTypeCompanyModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: "payment_type_company" })
], PaymentTypeCompanyModel);
//# sourceMappingURL=paymentTypeCompany.js.map