"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ZoneModel = void 0;
const typeorm_1 = require("typeorm");
const district_1 = require("./district");
let ZoneModel = class ZoneModel extends typeorm_1.BaseEntity {
};
exports.ZoneModel = ZoneModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ZoneModel.prototype, "zoneId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 150
    }),
    __metadata("design:type", String)
], ZoneModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], ZoneModel.prototype, "districtId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ZoneModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => district_1.DistrictModel, district => district.zones),
    (0, typeorm_1.JoinColumn)({ name: 'districtId', referencedColumnName: 'districtId' }),
    __metadata("design:type", district_1.DistrictModel)
], ZoneModel.prototype, "district", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ZoneModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ZoneModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ZoneModel.prototype, "updatedBy", void 0);
exports.ZoneModel = ZoneModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: 'zone' })
], ZoneModel);
//# sourceMappingURL=zone.js.map