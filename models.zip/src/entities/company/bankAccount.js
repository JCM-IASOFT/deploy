"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BankAccountModel = void 0;
const typeorm_1 = require("typeorm");
const currency_1 = require("./currency");
const bank_1 = require("./bank");
const bankAccountType_1 = require("./bankAccountType");
const company_1 = require("./company");
const terminal_1 = require("../sales/terminal");
/**
 * cuentas bancarias
 */
let BankAccountModel = class BankAccountModel extends typeorm_1.BaseEntity {
};
exports.BankAccountModel = BankAccountModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], BankAccountModel.prototype, "bankAccountId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "int",
        default: 0
    }),
    __metadata("design:type", Number)
], BankAccountModel.prototype, "bankId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "varchar",
        length: 30,
        default: ''
    }),
    __metadata("design:type", String)
], BankAccountModel.prototype, "accountNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "varchar",
        length: 30,
        default: ''
    }),
    __metadata("design:type", String)
], BankAccountModel.prototype, "CCI", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "varchar",
        length: 100,
        default: ''
    }),
    __metadata("design:type", String)
], BankAccountModel.prototype, "accountHolder", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "boolean",
        default: true
    }),
    __metadata("design:type", Boolean)
], BankAccountModel.prototype, "stateAccount", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "timestamptz",
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], BankAccountModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "int",
        default: 0
    }),
    __metadata("design:type", Number)
], BankAccountModel.prototype, "bankAccountTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "int",
        default: 0
    }),
    __metadata("design:type", Number)
], BankAccountModel.prototype, "currencyId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "int",
        default: 0
    }),
    __metadata("design:type", Number)
], BankAccountModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => bank_1.BankModel, bank => bank.bankAccount),
    (0, typeorm_1.JoinColumn)({ name: 'bankId', referencedColumnName: 'bankId' }),
    __metadata("design:type", bank_1.BankModel)
], BankAccountModel.prototype, "bank", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => currency_1.CurrencyModel, currency => currency.bankAccount),
    (0, typeorm_1.JoinColumn)({ name: 'currencyId', referencedColumnName: 'currencyId' }),
    __metadata("design:type", currency_1.CurrencyModel)
], BankAccountModel.prototype, "currency", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => bankAccountType_1.BankAccountTypeModel, bankAccountType => bankAccountType.bankAccount),
    (0, typeorm_1.JoinColumn)({ name: 'bankAccountTypeId', referencedColumnName: 'bankAccountTypeId' }),
    __metadata("design:type", bankAccountType_1.BankAccountTypeModel)
], BankAccountModel.prototype, "bankAccountType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.bankAccountTypes),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], BankAccountModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => terminal_1.TerminalModel, (terminal) => terminal.bankAccount),
    __metadata("design:type", Array)
], BankAccountModel.prototype, "terminals", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], BankAccountModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], BankAccountModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], BankAccountModel.prototype, "deletedAt", void 0);
exports.BankAccountModel = BankAccountModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: 'bank_accounts' })
], BankAccountModel);
//# sourceMappingURL=bankAccount.js.map