"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentTypeTerminalModel = void 0;
const typeorm_1 = require("typeorm");
const paymentType_1 = require("./paymentType");
const terminal_1 = require("../sales/terminal");
/**
 * * paymentType = Tipo de pagos
 */
let PaymentTypeTerminalModel = class PaymentTypeTerminalModel extends typeorm_1.BaseEntity {
};
exports.PaymentTypeTerminalModel = PaymentTypeTerminalModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentTypeTerminalModel.prototype, "paymentTypeId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentTypeTerminalModel.prototype, "terminalId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => paymentType_1.PaymentTypeModel, (paymentTypeCompany) => paymentTypeCompany.paymentTypeTerminals),
    (0, typeorm_1.JoinColumn)({ name: 'paymentTypeId', referencedColumnName: 'paymentTypeId' }),
    __metadata("design:type", paymentType_1.PaymentTypeModel)
], PaymentTypeTerminalModel.prototype, "paymentType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => terminal_1.TerminalModel, (terminal) => terminal.paymentTypeTerminals),
    (0, typeorm_1.JoinColumn)({ name: 'terminalId', referencedColumnName: 'terminalId' }),
    __metadata("design:type", terminal_1.TerminalModel)
], PaymentTypeTerminalModel.prototype, "terminal", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PaymentTypeTerminalModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentTypeTerminalModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentTypeTerminalModel.prototype, "updatedBy", void 0);
exports.PaymentTypeTerminalModel = PaymentTypeTerminalModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: "payment_type_terminal" })
], PaymentTypeTerminalModel);
//# sourceMappingURL=paymentTypeTerminal.js.map