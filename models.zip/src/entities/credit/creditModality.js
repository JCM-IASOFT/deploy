"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditModalityModel = void 0;
const typeorm_1 = require("typeorm");
const credit_1 = require("./credit");
/**
 * Modelo de entidad para representar las modalidades de crédito.
 * Esta clase mapea a la tabla 'credit_modality' en el esquema 'finance'.
 */
let CreditModalityModel = class CreditModalityModel extends typeorm_1.BaseEntity {
};
exports.CreditModalityModel = CreditModalityModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CreditModalityModel.prototype, "creditModalityId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100 }),
    __metadata("design:type", String)
], CreditModalityModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditModalityModel.prototype, "days", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditModalityModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 1, default: () => '0' }),
    __metadata("design:type", String)
], CreditModalityModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], CreditModalityModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], CreditModalityModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => credit_1.CreditModel, credit => credit.creditModality),
    __metadata("design:type", Array)
], CreditModalityModel.prototype, "credits", void 0);
exports.CreditModalityModel = CreditModalityModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'credit', name: 'credit_modality' })
], CreditModalityModel);
//# sourceMappingURL=creditModality.js.map