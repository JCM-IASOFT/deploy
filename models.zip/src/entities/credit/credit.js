"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditModel = void 0;
const typeorm_1 = require("typeorm");
const creditSchedule_1 = require("./creditSchedule");
const creditAdvance_1 = require("./creditAdvance");
const currency_1 = require("../company/currency");
const creditModality_1 = require("./creditModality");
const company_1 = require("../company/company");
const service_1 = require("../support/service");
const sales_1 = require("../sales/sales");
const client_1 = require("../sales/client");
/**
 * Modelo de entidad para representar los créditos.
 * Esta clase mapea a la tabla 'credit' en el esquema 'finance'.
 */
let CreditModel = class CreditModel extends typeorm_1.BaseEntity {
};
exports.CreditModel = CreditModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CreditModel.prototype, "creditId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], CreditModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date
    /**
     * ID del cliente asociado al crédito.
     */
    )
], CreditModel.prototype, "dueDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditModel.prototype, "clientId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], CreditModel.prototype, "serviceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], CreditModel.prototype, "salesId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditModel.prototype, "creditModalityId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2 }),
    __metadata("design:type", Number)
], CreditModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CreditModel.prototype, "balance", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 5, scale: 2 }),
    __metadata("design:type", Number)
], CreditModel.prototype, "interestRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], CreditModel.prototype, "exchangeRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditModel.prototype, "dues", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], CreditModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], CreditModel.prototype, "currencyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], CreditModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], CreditModel.prototype, "isActive", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 1, default: () => '0' }),
    __metadata("design:type", String)
], CreditModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], CreditModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], CreditModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => currency_1.CurrencyModel, currency => currency.credits),
    (0, typeorm_1.JoinColumn)({ name: 'currencyId', referencedColumnName: 'currencyId' }),
    __metadata("design:type", currency_1.CurrencyModel)
], CreditModel.prototype, "currency", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => creditModality_1.CreditModalityModel, creditModality => creditModality.credits),
    (0, typeorm_1.JoinColumn)({ name: 'creditModalityId', referencedColumnName: 'creditModalityId' }),
    __metadata("design:type", creditModality_1.CreditModalityModel)
], CreditModel.prototype, "creditModality", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => creditSchedule_1.CreditScheduleModel, creditSchedule => creditSchedule.credit),
    __metadata("design:type", Array)
], CreditModel.prototype, "creditSchedules", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => creditAdvance_1.CreditAdvanceModel, creditAdvance => creditAdvance.credit),
    __metadata("design:type", Array)
], CreditModel.prototype, "creditAdvances", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => client_1.ClientModel, client => client.credit),
    (0, typeorm_1.JoinColumn)({ name: 'clientId', referencedColumnName: 'clientId' }),
    __metadata("design:type", client_1.ClientModel)
], CreditModel.prototype, "client", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, company => company.credit),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], CreditModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => service_1.ServiceModel, service => service.credit, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'serviceId', referencedColumnName: 'serviceId' }),
    __metadata("design:type", service_1.ServiceModel)
], CreditModel.prototype, "service", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => sales_1.SalesModel, sales => sales.credit, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'salesId', referencedColumnName: 'salesId' }),
    __metadata("design:type", sales_1.SalesModel)
], CreditModel.prototype, "sales", void 0);
exports.CreditModel = CreditModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'credit', name: 'credit' })
], CreditModel);
//# sourceMappingURL=credit.js.map