"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermissionCompanyModel = void 0;
const typeorm_1 = require("typeorm");
const company_1 = require("../company/company");
const role_1 = require("./role");
const user_1 = require("./user");
const permissionCampus_1 = require("./permissionCampus");
// PermissionCompanyModel.ts
let PermissionCompanyModel = class PermissionCompanyModel extends typeorm_1.BaseEntity {
};
exports.PermissionCompanyModel = PermissionCompanyModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], PermissionCompanyModel.prototype, "permissionCompanyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PermissionCompanyModel.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PermissionCompanyModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], PermissionCompanyModel.prototype, "roleId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, user => user.permissionCompanys),
    (0, typeorm_1.JoinColumn)({ name: 'userId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], PermissionCompanyModel.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, company => company.permissionCompanys),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], PermissionCompanyModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => role_1.RoleModel, role => role.permissionCompanys),
    (0, typeorm_1.JoinColumn)({ name: 'roleId', referencedColumnName: 'roleId' }),
    __metadata("design:type", role_1.RoleModel)
], PermissionCompanyModel.prototype, "role", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permissionCampus_1.PermissionCampusModel, permissionCampus => permissionCampus.permissionCompany),
    __metadata("design:type", Array)
], PermissionCompanyModel.prototype, "permissionCampus", void 0);
exports.PermissionCompanyModel = PermissionCompanyModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'system', name: 'permission_company' })
], PermissionCompanyModel);
//# sourceMappingURL=permissionCompany.js.map