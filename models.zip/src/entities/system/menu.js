"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MenuModel = void 0;
const typeorm_1 = require("typeorm");
const menuAction_1 = require("./menuAction");
const permissionRol_1 = require("./permissionRol");
let MenuModel = class MenuModel extends typeorm_1.BaseEntity {
};
exports.MenuModel = MenuModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], MenuModel.prototype, "menuId", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "headTitle", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "headTitle2", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "path", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "title", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "icon", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "action", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "subject", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "badgeValue", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "badgeClass", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "badgeText", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: true }),
    __metadata("design:type", Boolean)
], MenuModel.prototype, "active", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: true }),
    __metadata("design:type", Boolean)
], MenuModel.prototype, "selected", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: false }),
    __metadata("design:type", Boolean)
], MenuModel.prototype, "important", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: true }),
    __metadata("design:type", Boolean)
], MenuModel.prototype, "bookmark", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: true }),
    __metadata("design:type", Boolean)
], MenuModel.prototype, "Menusub", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: true }),
    __metadata("design:type", Boolean)
], MenuModel.prototype, "target", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "menutype", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "int", nullable: true }),
    __metadata("design:type", Number)
], MenuModel.prototype, "parentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "int", nullable: true }),
    __metadata("design:type", Number)
], MenuModel.prototype, "order", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "int", nullable: true }),
    __metadata("design:type", Number)
], MenuModel.prototype, "systemId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => MenuModel, menu => menu.children),
    (0, typeorm_1.JoinColumn)({ name: "parentId", referencedColumnName: "menuId" }),
    __metadata("design:type", MenuModel)
], MenuModel.prototype, "parent", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => MenuModel, menu => menu.parent),
    __metadata("design:type", Array)
], MenuModel.prototype, "children", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => menuAction_1.MenuActionModel, menuAction => menuAction.menu),
    __metadata("design:type", Array)
], MenuModel.prototype, "menuActions", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permissionRol_1.PermissionRoleModel, permissionRole => permissionRole.menu),
    __metadata("design:type", Array)
], MenuModel.prototype, "permissionRoles", void 0);
exports.MenuModel = MenuModel = __decorate([
    (0, typeorm_1.Entity)({ schema: "system", name: "menu" })
], MenuModel);
//# sourceMappingURL=menu.js.map