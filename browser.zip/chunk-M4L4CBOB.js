var r=function(t){return t.Workshop="Taller",t.Home="Domicilio",t}(r||{}),o=function(t){return t.Detail="detail",t.Fast="fast",t}(o||{});export{r as a,o as b};
