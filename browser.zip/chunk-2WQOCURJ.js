var t=function(e){return e[e.user=0]="user",e[e.administrator=1]="administrator",e[e.super_user=2]="super_user",e[e.technical=3]="technical",e}(t||{});export{t as a};
