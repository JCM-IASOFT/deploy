var t={cobrado:1,anulado:2},o=[{description:"Cobrado",state:t.cobrado},{description:"Anulado",state:t.anulado}];export{t as a,o as b};
