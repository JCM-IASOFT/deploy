var s=()=>e=>!((e.value||"").trim().length===0)?null:{whitespace:!0};export{s as a};
