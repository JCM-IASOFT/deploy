var r={detail:1,fast:2};var o=function(e){return e.workshop="Taller",e.home="Domicilio",e}(o||{});export{r as a,o as b};
