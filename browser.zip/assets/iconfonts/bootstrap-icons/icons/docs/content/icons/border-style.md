---
title: Border style
categories:
  - Typography
tags:
  - borders
  - wysiwyg
---
