"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductModel = void 0;
const typeorm_1 = require("typeorm");
const company_1 = require("../company/company");
const deviceProduct_1 = require("../support/deviceProduct");
const category_1 = require("./category");
const subCategory_1 = require("./subCategory");
const salesdetail_1 = require("../sales/salesdetail");
const proformaQuoteDetail_1 = require("../sales/proformaQuoteDetail");
const unitMeasurement_1 = require("./unitMeasurement");
const brand_1 = require("./brand");
const group_1 = require("./group");
const presentation_1 = require("./presentation");
const tax_1 = require("../company/tax");
const file_1 = require("../company/file");
const currency_1 = require("../company/currency");
const code_1 = require("./code");
const stockBalance_1 = require("./stockBalance");
const inventoryDetail_1 = require("./inventoryDetail");
const storeItems_1 = require("./storeItems");
const productFile_1 = require("./productFile");
const supplier_1 = require("../logistics/supplier");
const price_1 = require("../sales/price");
const enum_1 = require("../../core/enum/enum");
let ProductModel = class ProductModel extends typeorm_1.BaseEntity {
};
exports.ProductModel = ProductModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ProductModel.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, default: '' }),
    __metadata("design:type", String)
], ProductModel.prototype, "code", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '' }),
    __metadata("design:type", String)
], ProductModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], ProductModel.prototype, "priceDistributor", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], ProductModel.prototype, "priceProduct", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], ProductModel.prototype, "stock", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], ProductModel.prototype, "commission", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], ProductModel.prototype, "perishable", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true, }),
    __metadata("design:type", Boolean)
], ProductModel.prototype, "countStock", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true, }),
    __metadata("design:type", Boolean)
], ProductModel.prototype, "isBillable", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, }),
    __metadata("design:type", Boolean)
], ProductModel.prototype, "isICBPERAffected", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, }),
    __metadata("design:type", Boolean)
], ProductModel.prototype, "isSubjectToDetraction", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, }),
    __metadata("design:type", Boolean)
], ProductModel.prototype, "hasSerialNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, }),
    __metadata("design:type", Number)
], ProductModel.prototype, "stockMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], ProductModel.prototype, "stockMax", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], ProductModel.prototype, "netWeight", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], ProductModel.prototype, "grossWeight", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], ProductModel.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: enum_1.RegisterProductType, default: enum_1.RegisterProductType.Basic }),
    __metadata("design:type", String)
], ProductModel.prototype, "registerType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "brandId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "unitMeasurementId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "subCategoryId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "categoryId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "supplierId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "groupId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "presentationId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProductModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "taxId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "currencyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductModel.prototype, "fileId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => supplier_1.SupplierModel, (supplier) => supplier.products),
    (0, typeorm_1.JoinColumn)({ name: 'supplierId', referencedColumnName: 'supplierId' }),
    __metadata("design:type", supplier_1.SupplierModel)
], ProductModel.prototype, "supplier", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => category_1.CategoryModel, (category) => category.products),
    (0, typeorm_1.JoinColumn)({ name: 'categoryId', referencedColumnName: 'categoryId' }),
    __metadata("design:type", category_1.CategoryModel)
], ProductModel.prototype, "category", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => subCategory_1.SubCategoryModel, (subCategory) => subCategory.products),
    (0, typeorm_1.JoinColumn)({ name: 'subCategoryId', referencedColumnName: 'subCategoryId' }),
    __metadata("design:type", subCategory_1.SubCategoryModel)
], ProductModel.prototype, "subCategory", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unitMeasurement_1.UnitMeasurementModel, (unitMeasurement) => unitMeasurement.products),
    (0, typeorm_1.JoinColumn)({ name: 'unitMeasurementId', referencedColumnName: 'unitMeasurementId' }),
    __metadata("design:type", unitMeasurement_1.UnitMeasurementModel // Unidad de medida
    )
], ProductModel.prototype, "unitMeasurement", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => brand_1.BrandModel, (brand) => brand.products),
    (0, typeorm_1.JoinColumn)({ name: 'brandId', referencedColumnName: 'brandId' }),
    __metadata("design:type", brand_1.BrandModel)
], ProductModel.prototype, "brand", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => group_1.GroupModel, (group) => group.products),
    (0, typeorm_1.JoinColumn)({ name: 'groupId', referencedColumnName: 'groupId' }),
    __metadata("design:type", group_1.GroupModel)
], ProductModel.prototype, "group", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => presentation_1.PresentationModel, (presentation) => presentation.products),
    (0, typeorm_1.JoinColumn)({ name: 'presentationId', referencedColumnName: 'presentationId' }),
    __metadata("design:type", presentation_1.PresentationModel)
], ProductModel.prototype, "presentation", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tax_1.TaxModel, (tax) => tax.products),
    (0, typeorm_1.JoinColumn)({ name: 'taxId', referencedColumnName: 'taxId' }),
    __metadata("design:type", tax_1.TaxModel)
], ProductModel.prototype, "tax", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => currency_1.CurrencyModel, (currency) => currency.products),
    (0, typeorm_1.JoinColumn)({ name: 'currencyId', referencedColumnName: 'currencyId' }),
    __metadata("design:type", currency_1.CurrencyModel)
], ProductModel.prototype, "currency", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => file_1.FileModel, (file) => file.products),
    (0, typeorm_1.JoinColumn)({ name: 'fileId', referencedColumnName: 'fileId' }),
    __metadata("design:type", file_1.FileModel)
], ProductModel.prototype, "file", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.products, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], ProductModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => deviceProduct_1.DeviceProductModel, deviceProduct => deviceProduct.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "deviceProducts", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => stockBalance_1.StockBalanceModel, stockBalance => stockBalance.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "stockBalances", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => inventoryDetail_1.InventoryDetailModel, (inventoryDetail) => inventoryDetail.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "inventoryDetails", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => code_1.CodeModel, code => code.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "codes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => salesdetail_1.SalesDetailModel, salesDetails => salesDetails.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "salesDetails", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuoteDetail_1.ProformaQuoteDetailModel, proformaquotedetail => proformaquotedetail.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "proformaQuoteDetails", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => storeItems_1.StoreItemModel, (storeItems) => storeItems.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "storeItems", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => price_1.PriceModel, (price) => price.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "prices", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => productFile_1.ProductFileModel, (productFile) => productFile.product),
    __metadata("design:type", Array)
], ProductModel.prototype, "productFiles", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ProductModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ProductModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ProductModel.prototype, "createdAt", void 0);
exports.ProductModel = ProductModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'inventory', name: 'product' })
], ProductModel);
//# sourceMappingURL=product.js.map