"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StoreModel = void 0;
const typeorm_1 = require("typeorm");
const storeItems_1 = require("./storeItems");
const proformaQuote_1 = require("../sales/proformaQuote");
const campus_1 = require("../company/campus");
const storeType_1 = require("./storeType");
const user_1 = require("../system/user");
/**
 * * ALMACEN
 */
let StoreModel = class StoreModel extends typeorm_1.BaseEntity {
};
exports.StoreModel = StoreModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], StoreModel.prototype, "storeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '' }),
    __metadata("design:type", String)
], StoreModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '' }),
    __metadata("design:type", String)
], StoreModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '' }),
    __metadata("design:type", String)
], StoreModel.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bool', default: true }),
    __metadata("design:type", Boolean)
], StoreModel.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: null, nullable: true }),
    __metadata("design:type", Number)
], StoreModel.prototype, "inChargeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: null, nullable: true }),
    __metadata("design:type", Number)
], StoreModel.prototype, "storeTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '', }),
    __metadata("design:type", String)
], StoreModel.prototype, "capacity", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true, default: null }),
    __metadata("design:type", Date)
], StoreModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], StoreModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, (campus) => campus.stores),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], StoreModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, userInCharge => userInCharge.store),
    (0, typeorm_1.JoinColumn)({ name: 'inChargeId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], StoreModel.prototype, "userInCharge", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => storeType_1.StoreTypeModel, storeType => storeType.store),
    (0, typeorm_1.JoinColumn)({ name: 'storeTypeId', referencedColumnName: 'storeTypeId' }),
    __metadata("design:type", storeType_1.StoreTypeModel)
], StoreModel.prototype, "storeType", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => storeItems_1.StoreItemModel, (storeInventory) => storeInventory.store),
    __metadata("design:type", Array)
], StoreModel.prototype, "storeItems", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuote_1.ProformaQuoteModel, service => service.store),
    __metadata("design:type", Array)
], StoreModel.prototype, "proformaQuotes", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], StoreModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], StoreModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], StoreModel.prototype, "deletedAt", void 0);
exports.StoreModel = StoreModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'inventory', name: 'store' })
], StoreModel);
//# sourceMappingURL=store.js.map