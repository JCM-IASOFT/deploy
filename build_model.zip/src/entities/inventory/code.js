"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CodeModel = void 0;
const typeorm_1 = require("typeorm");
const product_1 = require("./product");
const barcodeType_1 = require("../../core/barcodeType");
/**
 * * CODIGO DE PRODUCTO
 * - un producto puede tener varios codigos de barra
 */
let CodeModel = class CodeModel extends typeorm_1.BaseEntity {
};
exports.CodeModel = CodeModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CodeModel.prototype, "codeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", default: '', length: 200 }),
    __metadata("design:type", String)
], CodeModel.prototype, "code", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "enum", enum: barcodeType_1.BarcodeType, default: barcodeType_1.BarcodeType.CODE_128 }),
    __metadata("design:type", String)
], CodeModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "int" }),
    __metadata("design:type", Number)
], CodeModel.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_1.ProductModel, product => product.codes),
    (0, typeorm_1.JoinColumn)({ name: 'productId', referencedColumnName: 'productId' }),
    __metadata("design:type", product_1.ProductModel)
], CodeModel.prototype, "product", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CodeModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CodeModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], CodeModel.prototype, "deletedAt", void 0);
exports.CodeModel = CodeModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'inventory', name: 'code' })
], CodeModel);
//# sourceMappingURL=code.js.map