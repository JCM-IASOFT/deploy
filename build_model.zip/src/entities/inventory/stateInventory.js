"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateInventoryModel = void 0;
const typeorm_1 = require("typeorm");
const inventory_1 = require("./inventory");
const movement_1 = require("./movement");
/**
 * Entidad que representa un estado de inventario en el sistema.
 */
let StateInventoryModel = class StateInventoryModel {
};
exports.StateInventoryModel = StateInventoryModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], StateInventoryModel.prototype, "stateInventoryId", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", Number)
], StateInventoryModel.prototype, "code", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], StateInventoryModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], StateInventoryModel.prototype, "confirmed", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], StateInventoryModel.prototype, "cancelled", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => "'0'",
    }),
    __metadata("design:type", String)
], StateInventoryModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], StateInventoryModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], StateInventoryModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => inventory_1.InventoryModel, (inventory) => inventory.stateInventory),
    __metadata("design:type", Array)
], StateInventoryModel.prototype, "inventorys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => movement_1.MovementModel, (movement) => movement.stateInventory),
    __metadata("design:type", Array)
], StateInventoryModel.prototype, "movements", void 0);
exports.StateInventoryModel = StateInventoryModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'inventory', name: 'state_inventory', })
], StateInventoryModel);
//# sourceMappingURL=stateInventory.js.map