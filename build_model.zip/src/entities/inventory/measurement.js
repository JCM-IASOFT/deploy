"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MeasurementModel = void 0;
const typeorm_1 = require("typeorm");
const presentation_1 = require("./presentation");
const company_1 = require("../company/company");
/**
 * * MEDIDA
 */
let MeasurementModel = class MeasurementModel extends typeorm_1.BaseEntity {
};
exports.MeasurementModel = MeasurementModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], MeasurementModel.prototype, "measurementId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 100
    }),
    __metadata("design:type", String)
], MeasurementModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'timestamp',
        nullable: true
    }),
    __metadata("design:type", Date)
], MeasurementModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 100
    }),
    __metadata("design:type", String)
], MeasurementModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 100
    }),
    __metadata("design:type", String)
], MeasurementModel.prototype, "abbreviation", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
    }),
    __metadata("design:type", Number)
], MeasurementModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.measurements),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], MeasurementModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => presentation_1.PresentationModel, presentation => presentation.measurement),
    __metadata("design:type", Array)
], MeasurementModel.prototype, "presentation", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], MeasurementModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], MeasurementModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], MeasurementModel.prototype, "deletedAt", void 0);
exports.MeasurementModel = MeasurementModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'inventory', name: 'measurement' })
], MeasurementModel);
//# sourceMappingURL=measurement.js.map