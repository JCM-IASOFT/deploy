"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceDeviceModel = void 0;
const typeorm_1 = require("typeorm");
const externalComponent_1 = require("./externalComponent");
const deviceProduct_1 = require("./deviceProduct");
const serviceTypeDevice_1 = require("./serviceTypeDevice");
const service_1 = require("./service");
const device_1 = require("./device");
const serviceDeviceHistory_1 = require("./serviceDeviceHistory");
const deviceBrand_1 = require("./deviceBrand");
const difference_1 = require("./difference");
/**
 * * serviceDevice = Equipo
 */
let ServiceDeviceModel = class ServiceDeviceModel extends typeorm_1.BaseEntity {
};
exports.ServiceDeviceModel = ServiceDeviceModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ServiceDeviceModel.prototype, "serviceDeviceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100 }),
    __metadata("design:type", String)
], ServiceDeviceModel.prototype, "accessories", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 280, default: '' }),
    __metadata("design:type", String)
], ServiceDeviceModel.prototype, "reason", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], ServiceDeviceModel.prototype, "estimatedAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', nullable: true }),
    __metadata("design:type", Boolean)
], ServiceDeviceModel.prototype, "inWarranty", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], ServiceDeviceModel.prototype, "model", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], ServiceDeviceModel.prototype, "serial", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 250, nullable: true }),
    __metadata("design:type", String)
], ServiceDeviceModel.prototype, "observations", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 250, nullable: true }),
    __metadata("design:type", String)
], ServiceDeviceModel.prototype, "observationsInternal", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 250, nullable: true }),
    __metadata("design:type", String)
], ServiceDeviceModel.prototype, "workCycle", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServiceDeviceModel.prototype, "serviceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServiceDeviceModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ServiceDeviceModel.prototype, "deviceBrandId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ServiceDeviceModel.prototype, "deviceId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => device_1.DeviceModel, device => device.serviceDevices, { eager: true }),
    (0, typeorm_1.JoinColumn)({ name: 'deviceId', referencedColumnName: 'deviceId' }),
    __metadata("design:type", device_1.DeviceModel)
], ServiceDeviceModel.prototype, "device", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => deviceBrand_1.DeviceBrandModel, deviceBrand => deviceBrand.serviceDevices, { eager: true }),
    (0, typeorm_1.JoinColumn)({ name: 'deviceBrandId', referencedColumnName: 'deviceBrandId' }),
    __metadata("design:type", deviceBrand_1.DeviceBrandModel)
], ServiceDeviceModel.prototype, "deviceBrand", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => externalComponent_1.ExternalComponentModel, externalcomponent => externalcomponent.serviceDevice, { eager: true }),
    __metadata("design:type", Array)
], ServiceDeviceModel.prototype, "externalComponents", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => difference_1.DifferenceModel, difference => difference.serviceDevice, { eager: true }),
    __metadata("design:type", Array)
], ServiceDeviceModel.prototype, "differences", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => deviceProduct_1.DeviceProductModel, deviceproduct => deviceproduct.serviceDevice, { eager: true }),
    __metadata("design:type", Array)
], ServiceDeviceModel.prototype, "deviceProducts", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => serviceTypeDevice_1.ServiceTypeDeviceModel, servicetypedevice => servicetypedevice.serviceDevice, { eager: true }),
    __metadata("design:type", Array)
], ServiceDeviceModel.prototype, "serviceTypeDevices", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => serviceDeviceHistory_1.ServiceDeviceHistoryModel, servicedevicehistory => servicedevicehistory.serviceDevice, { eager: true }),
    __metadata("design:type", Array)
], ServiceDeviceModel.prototype, "serviceDeviceHistorys", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => service_1.ServiceModel, service => service.serviceDevices),
    (0, typeorm_1.JoinColumn)({ name: 'serviceId', referencedColumnName: 'serviceId' }),
    __metadata("design:type", service_1.ServiceModel)
], ServiceDeviceModel.prototype, "service", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ServiceDeviceModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServiceDeviceModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServiceDeviceModel.prototype, "updatedBy", void 0);
exports.ServiceDeviceModel = ServiceDeviceModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'support', name: "service_device" })
], ServiceDeviceModel);
//# sourceMappingURL=serviceDevice.js.map