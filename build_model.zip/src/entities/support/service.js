"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceModel = void 0;
const typeorm_1 = require("typeorm");
const difference_1 = require("./difference");
const payment_1 = require("./payment");
const serviceStatusHistory_1 = require("./serviceStatusHistory");
const serviceDevice_1 = require("./serviceDevice");
const cashBoxDetail_1 = require("../accounting/cashBoxDetail");
const service_1 = require("../../core/service");
const servicePauseHistory_1 = require("./servicePauseHistory");
const campus_1 = require("../company/campus");
const serviceTechnicalHistory_1 = require("./serviceTechnicalHistory");
const credit_1 = require("../credit/credit");
const user_1 = require("../system/user");
const client_1 = require("../sales/client");
/**
 * * service = Servicio
 */
let ServiceModel = class ServiceModel extends typeorm_1.BaseEntity {
};
exports.ServiceModel = ServiceModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ServiceModel.prototype, "serviceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp' }),
    __metadata("design:type", Date)
], ServiceModel.prototype, "registrationDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], ServiceModel.prototype, "endDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], ServiceModel.prototype, "deliverDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], ServiceModel.prototype, "totalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 1 }),
    __metadata("design:type", String)
], ServiceModel.prototype, "state", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], ServiceModel.prototype, "pause", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], ServiceModel.prototype, "detailedReception", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ServiceModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: service_1.ServiceLocation, default: service_1.ServiceLocation.workshop }),
    __metadata("design:type", String)
], ServiceModel.prototype, "serviceLocation", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], ServiceModel.prototype, "comment", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], ServiceModel.prototype, "priority", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ServiceModel.prototype, "clientId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServiceModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ServiceModel.prototype, "cashBoxDetailId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ServiceModel.prototype, "userReceptionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ServiceModel.prototype, "userTechnicalId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ServiceModel.prototype, "userDeliveryId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(type => user_1.UserModel, usertype => usertype.servicesReception, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'userReceptionId' }),
    __metadata("design:type", user_1.UserModel)
], ServiceModel.prototype, "userReception", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(type => user_1.UserModel, usertype => usertype.servicesDeliverys, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'userDeliveryId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], ServiceModel.prototype, "userDelivery", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(type => user_1.UserModel, usertype => usertype.servicesTechnical),
    (0, typeorm_1.JoinColumn)({ name: 'userTechnicalId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], ServiceModel.prototype, "userTechnical", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => client_1.ClientModel, clienttype => clienttype.services),
    (0, typeorm_1.JoinColumn)({ name: 'clientId', referencedColumnName: 'clientId' }),
    __metadata("design:type", client_1.ClientModel)
], ServiceModel.prototype, "client", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.services),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], ServiceModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => difference_1.DifferenceModel, difference => difference.service),
    __metadata("design:type", Array)
], ServiceModel.prototype, "differences", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => payment_1.PaymentModel, payment => payment.service),
    __metadata("design:type", Array)
], ServiceModel.prototype, "payments", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => serviceStatusHistory_1.ServiceStatusHistoryModel, servicestatushistory => servicestatushistory.service),
    __metadata("design:type", Array)
], ServiceModel.prototype, "serviceStatusHistorys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => servicePauseHistory_1.ServicePauseHistoryModel, servicepausehistory => servicepausehistory.service),
    __metadata("design:type", Array)
], ServiceModel.prototype, "servicePauseHistorys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => serviceDevice_1.ServiceDeviceModel, serviceDevice => serviceDevice.service),
    __metadata("design:type", Array)
], ServiceModel.prototype, "serviceDevices", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => serviceTechnicalHistory_1.ServiceTechnicalHistoryModel, serviceTechnicalHistory => serviceTechnicalHistory.service),
    __metadata("design:type", Array)
], ServiceModel.prototype, "serviceTechnicalHistorys", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => cashBoxDetail_1.CashBoxDetailModel, cashBoxDetail => cashBoxDetail.services),
    (0, typeorm_1.JoinColumn)({ name: 'cashBoxDetailId', referencedColumnName: 'cashBoxDetailId' }),
    __metadata("design:type", cashBoxDetail_1.CashBoxDetailModel
    // **credit
    )
], ServiceModel.prototype, "cashBoxDetail", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => credit_1.CreditModel, (credit) => credit.service, { nullable: true }),
    __metadata("design:type", credit_1.CreditModel)
], ServiceModel.prototype, "credit", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ServiceModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServiceModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServiceModel.prototype, "updatedBy", void 0);
exports.ServiceModel = ServiceModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'support', name: "service" })
], ServiceModel);
//# sourceMappingURL=service.js.map