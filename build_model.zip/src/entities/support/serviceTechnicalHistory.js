"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceTechnicalHistoryModel = void 0;
const typeorm_1 = require("typeorm");
const service_1 = require("./service");
const user_1 = require("../system/user");
let ServiceTechnicalHistoryModel = class ServiceTechnicalHistoryModel extends typeorm_1.BaseEntity {
};
exports.ServiceTechnicalHistoryModel = ServiceTechnicalHistoryModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ServiceTechnicalHistoryModel.prototype, "serviceTechnicalHistoryId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int'
    }),
    __metadata("design:type", Number)
], ServiceTechnicalHistoryModel.prototype, "userTechnicalId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 255,
    }),
    __metadata("design:type", String)
], ServiceTechnicalHistoryModel.prototype, "reason", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp' }),
    __metadata("design:type", Date)
], ServiceTechnicalHistoryModel.prototype, "registrationDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServiceTechnicalHistoryModel.prototype, "serviceId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(type => service_1.ServiceModel, service => service.serviceTechnicalHistorys),
    (0, typeorm_1.JoinColumn)({ name: 'serviceId', referencedColumnName: 'serviceId' }),
    __metadata("design:type", service_1.ServiceModel)
], ServiceTechnicalHistoryModel.prototype, "service", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(type => user_1.UserModel, user => user.serviceTechnicalHistorys),
    (0, typeorm_1.JoinColumn)({ name: 'userTechnicalId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], ServiceTechnicalHistoryModel.prototype, "userTechnical", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ServiceTechnicalHistoryModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServiceTechnicalHistoryModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServiceTechnicalHistoryModel.prototype, "updatedBy", void 0);
exports.ServiceTechnicalHistoryModel = ServiceTechnicalHistoryModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'service_technical_history', schema: 'support' })
], ServiceTechnicalHistoryModel);
//# sourceMappingURL=serviceTechnicalHistory.js.map