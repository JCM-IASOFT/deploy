"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServicePauseHistoryModel = void 0;
const typeorm_1 = require("typeorm");
const service_1 = require("./service");
const user_1 = require("../system/user");
/**
 * * Historial de pausa de servicio
 */
let ServicePauseHistoryModel = class ServicePauseHistoryModel extends typeorm_1.BaseEntity {
};
exports.ServicePauseHistoryModel = ServicePauseHistoryModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ServicePauseHistoryModel.prototype, "servicePauseHistoryId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], ServicePauseHistoryModel.prototype, "dossier", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServicePauseHistoryModel.prototype, "serviceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServicePauseHistoryModel.prototype, "userTechnicalId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp' }),
    __metadata("design:type", Date)
], ServicePauseHistoryModel.prototype, "registrationDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date
    // ** Servicio
    )
], ServicePauseHistoryModel.prototype, "endDate", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(type => service_1.ServiceModel, service => service.servicePauseHistorys),
    (0, typeorm_1.JoinColumn)({ name: 'serviceId', referencedColumnName: 'serviceId' }),
    __metadata("design:type", service_1.ServiceModel)
], ServicePauseHistoryModel.prototype, "service", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(type => user_1.UserModel, user => user.servicePauseHistorys),
    (0, typeorm_1.JoinColumn)({ name: 'userTechnicalId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], ServicePauseHistoryModel.prototype, "userTechnical", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ServicePauseHistoryModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServicePauseHistoryModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServicePauseHistoryModel.prototype, "updatedBy", void 0);
exports.ServicePauseHistoryModel = ServicePauseHistoryModel = __decorate([
    (0, typeorm_1.Entity)({ schema: "support", name: "service_pause_history" })
], ServicePauseHistoryModel);
//# sourceMappingURL=servicePauseHistory.js.map