"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampusModel = void 0;
const typeorm_1 = require("typeorm");
const company_1 = require("./company");
const sales_1 = require("../sales/sales");
const verification_1 = require("../support/verification");
const proformaQuote_1 = require("../sales/proformaQuote");
const survey_1 = require("../support/survey");
const service_1 = require("../support/service");
const cashWithdrawals_1 = require("../accounting/cashWithdrawals");
const district_1 = require("./district");
const typeCampus_1 = require("../system/typeCampus");
const permissionCampus_1 = require("../system/permissionCampus");
const priceGroup_1 = require("../sales/priceGroup");
const store_1 = require("../inventory/store");
const employe_1 = require("../humanResource/employe");
const fixedExpenses_1 = require("../accounting/fixedExpenses");
const fixedExpensesHistory_1 = require("../accounting/fixedExpensesHistory");
const fixedExpensesType_1 = require("../accounting/fixedExpensesType");
const colorSettingsState_1 = require("../support/colorSettingsState");
let CampusModel = class CampusModel extends typeorm_1.BaseEntity {
};
exports.CampusModel = CampusModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CampusModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 60, default: '' }),
    __metadata("design:type", String)
], CampusModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '', }),
    __metadata("design:type", String)
], CampusModel.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20, default: '0' }),
    __metadata("design:type", String)
], CampusModel.prototype, "phone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', default: () => 'gen_random_uuid()' }),
    __metadata("design:type", String)
], CampusModel.prototype, "tokenAccess", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], CampusModel.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CampusModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], CampusModel.prototype, "districtId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], CampusModel.prototype, "typeCampusId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => district_1.DistrictModel, district => district.campus),
    (0, typeorm_1.JoinColumn)({ name: 'districtId', referencedColumnName: 'districtId' }),
    __metadata("design:type", district_1.DistrictModel)
], CampusModel.prototype, "district", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => typeCampus_1.TypeCampusModel, typeCampus => typeCampus.campus),
    (0, typeorm_1.JoinColumn)({ name: 'typeCampusId', referencedColumnName: 'typeCampusId' }),
    __metadata("design:type", typeCampus_1.TypeCampusModel)
], CampusModel.prototype, "typeCampus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => verification_1.VerificationModel, verification => verification.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "verifications", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.campus, { eager: true, onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], CampusModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sales_1.SalesModel, sales => sales.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => survey_1.SurveyModel, (survey) => survey.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "survey", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permissionCampus_1.PermissionCampusModel, permissionCampus => permissionCampus.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "permissionCampus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => priceGroup_1.PriceGroupModel, (priceGroup) => priceGroup.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "priceGroups", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => store_1.StoreModel, (store) => store.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "stores", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => employe_1.EmployeModel, (store) => store.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "employes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuote_1.ProformaQuoteModel, service => service.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "proformaQuotes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => service_1.ServiceModel, service => service.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "services", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => cashWithdrawals_1.CashWithdrawalsModel, cashWithdrawals => cashWithdrawals.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "cashWithdrawals", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => fixedExpenses_1.FixedExpensesModel, fixedExpenses => fixedExpenses.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "fixedExpenses", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => fixedExpensesHistory_1.FixedExpensesHistoryModel, fixedExpensesHistory => fixedExpensesHistory.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "fixedExpensesHistorys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => fixedExpensesType_1.FixedExpensesTypeModel, fixedExpensesType => fixedExpensesType.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "fixedExpensesTypes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => colorSettingsState_1.ColorSettingsStateModel, colorSettingsState => colorSettingsState.campus),
    __metadata("design:type", Array)
], CampusModel.prototype, "colorSettingsState", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], CampusModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CampusModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CampusModel.prototype, "createdAt", void 0);
exports.CampusModel = CampusModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: 'campus' })
], CampusModel);
//# sourceMappingURL=campus.js.map