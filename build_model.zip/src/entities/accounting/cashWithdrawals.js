"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CashWithdrawalsModel = void 0;
const typeorm_1 = require("typeorm");
const cashBox_1 = require("./cashBox");
const campus_1 = require("../company/campus");
const user_1 = require("../system/user");
/**
 * - retiro en efectivo
 */
let CashWithdrawalsModel = class CashWithdrawalsModel extends typeorm_1.BaseEntity {
};
exports.CashWithdrawalsModel = CashWithdrawalsModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CashWithdrawalsModel.prototype, "cashWithdrawalsId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 15,
        scale: 2,
        default: 0
    }),
    __metadata("design:type", Number)
], CashWithdrawalsModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "varchar",
        length: 150,
        default: ''
    }),
    __metadata("design:type", String)
], CashWithdrawalsModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        nullable: true
    }),
    __metadata("design:type", Number)
], CashWithdrawalsModel.prototype, "authorizationManagerId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        nullable: true
    }),
    __metadata("design:type", Number)
], CashWithdrawalsModel.prototype, "exitManagerId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "timestamp",
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashWithdrawalsModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        default: 0
    }),
    __metadata("design:type", Number)
], CashWithdrawalsModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        default: 0
    }),
    __metadata("design:type", Number)
], CashWithdrawalsModel.prototype, "cashBoxId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, authorizationManager => authorizationManager.cashWithdrawalsAuthorizations),
    (0, typeorm_1.JoinColumn)({ name: 'authorizationManagerId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel
    /**
     * encargado de salida o entrega
     */
    )
], CashWithdrawalsModel.prototype, "authorizationManager", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, exitManager => exitManager.cashWithdrawalsExits),
    (0, typeorm_1.JoinColumn)({ name: 'exitManagerId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], CashWithdrawalsModel.prototype, "exitManager", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.cashWithdrawals),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], CashWithdrawalsModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => cashBox_1.CashBoxModel, cashBox => cashBox.cashWithdrawals),
    (0, typeorm_1.JoinColumn)({ name: 'cashBoxId', referencedColumnName: 'cashBoxId' }),
    __metadata("design:type", cashBox_1.CashBoxModel)
], CashWithdrawalsModel.prototype, "cashBox", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], CashWithdrawalsModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashWithdrawalsModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashWithdrawalsModel.prototype, "createdAt", void 0);
exports.CashWithdrawalsModel = CashWithdrawalsModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'cash_withdrawals' })
], CashWithdrawalsModel);
//# sourceMappingURL=cashWithdrawals.js.map