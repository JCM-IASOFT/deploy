"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FixedExpensesHistoryModel = void 0;
const typeorm_1 = require("typeorm");
const fixedExpenses_1 = require("./fixedExpenses");
const campus_1 = require("../company/campus");
let FixedExpensesHistoryModel = class FixedExpensesHistoryModel extends typeorm_1.BaseEntity {
};
exports.FixedExpensesHistoryModel = FixedExpensesHistoryModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], FixedExpensesHistoryModel.prototype, "fixedExpensesHistoryId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 15,
        scale: 2,
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesHistoryModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 15,
        scale: 2,
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesHistoryModel.prototype, "dailyPayment", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesHistoryModel.prototype, "fixedExpensesId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        name: 'date',
        type: "timestamp",
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesHistoryModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "int",
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesHistoryModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => fixedExpenses_1.FixedExpensesModel, fixedExpenses => fixedExpenses.fixedExpensesHistory),
    (0, typeorm_1.JoinColumn)({ name: 'fixedExpensesId', referencedColumnName: 'fixedExpensesId' }),
    __metadata("design:type", fixedExpenses_1.FixedExpensesModel)
], FixedExpensesHistoryModel.prototype, "fixedExpenses", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.fixedExpensesHistorys),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], FixedExpensesHistoryModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], FixedExpensesHistoryModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesHistoryModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesHistoryModel.prototype, "createdAt", void 0);
exports.FixedExpensesHistoryModel = FixedExpensesHistoryModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'fixed_expenses_history' })
], FixedExpensesHistoryModel);
//# sourceMappingURL=fixedExpensesHistory.js.map