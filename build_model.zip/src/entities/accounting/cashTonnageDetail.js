"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CashTonnageDetailModel = void 0;
const typeorm_1 = require("typeorm");
const cashTonnage_1 = require("./cashTonnage");
const monetaryUnit_1 = require("./monetaryUnit");
/**
 * * Detalle de Arqueo de Caja
 */
let CashTonnageDetailModel = class CashTonnageDetailModel extends typeorm_1.BaseEntity {
};
exports.CashTonnageDetailModel = CashTonnageDetailModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CashTonnageDetailModel.prototype, "cashTonnageDetailId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashTonnageDetailModel.prototype, "monetaryUnitId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashTonnageDetailModel.prototype, "cashTonnageId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashTonnageDetailModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => monetaryUnit_1.MonetaryUnitModel, monetaryunit => monetaryunit.cashTonnageDetails),
    (0, typeorm_1.JoinColumn)({ name: 'monetaryUnitId', referencedColumnName: 'monetaryUnitId' }),
    __metadata("design:type", monetaryUnit_1.MonetaryUnitModel)
], CashTonnageDetailModel.prototype, "monetaryUnit", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => cashTonnage_1.CashTonnageModel, cashtonnage => cashtonnage.cashBoxDetail),
    (0, typeorm_1.JoinColumn)({ name: 'cashTonnageId', referencedColumnName: 'cashTonnageId' }),
    __metadata("design:type", cashTonnage_1.CashTonnageModel)
], CashTonnageDetailModel.prototype, "cashTonnage", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], CashTonnageDetailModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashTonnageDetailModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashTonnageDetailModel.prototype, "createdAt", void 0);
exports.CashTonnageDetailModel = CashTonnageDetailModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'cash_tonnage_detail' })
], CashTonnageDetailModel);
//# sourceMappingURL=cashTonnageDetail.js.map