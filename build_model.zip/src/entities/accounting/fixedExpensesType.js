"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FixedExpensesTypeModel = void 0;
const typeorm_1 = require("typeorm");
const fixedExpenses_1 = require("./fixedExpenses");
const campus_1 = require("../company/campus");
/**
 * tipos de gastos fijos
 */
let FixedExpensesTypeModel = class FixedExpensesTypeModel extends typeorm_1.BaseEntity {
};
exports.FixedExpensesTypeModel = FixedExpensesTypeModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], FixedExpensesTypeModel.prototype, "fixedExpensesTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "varchar",
        length: 200,
        default: ''
    }),
    __metadata("design:type", String)
], FixedExpensesTypeModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "timestamp",
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesTypeModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "int",
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesTypeModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => fixedExpenses_1.FixedExpensesModel, fixedExpenses => fixedExpenses.fixedType),
    __metadata("design:type", Array)
], FixedExpensesTypeModel.prototype, "fixedExpenses", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.fixedExpensesTypes),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], FixedExpensesTypeModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], FixedExpensesTypeModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesTypeModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesTypeModel.prototype, "createdAt", void 0);
exports.FixedExpensesTypeModel = FixedExpensesTypeModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'fixed_expenses_type' })
], FixedExpensesTypeModel);
//# sourceMappingURL=fixedExpensesType.js.map