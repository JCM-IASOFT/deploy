"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditPaymentModel = void 0;
const typeorm_1 = require("typeorm");
const creditSchedule_1 = require("./creditSchedule");
const paymentType_1 = require("../company/paymentType");
/**
 * Modelo de entidad para representar los pagos de crédito.
 * Esta clase mapea a la tabla 'credit_payment' en el esquema 'finance'.
 */
let CreditPaymentModel = class CreditPaymentModel extends typeorm_1.BaseEntity {
};
exports.CreditPaymentModel = CreditPaymentModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CreditPaymentModel.prototype, "creditPaymentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], CreditPaymentModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditPaymentModel.prototype, "creditScheduleId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CreditPaymentModel.prototype, "paymentTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], CreditPaymentModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], CreditPaymentModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => creditSchedule_1.CreditScheduleModel, creditSchedule => creditSchedule.creditPayments),
    (0, typeorm_1.JoinColumn)({ name: 'creditScheduleId', referencedColumnName: 'creditScheduleId' }),
    __metadata("design:type", creditSchedule_1.CreditScheduleModel)
], CreditPaymentModel.prototype, "creditSchedule", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => paymentType_1.PaymentTypeModel, paymentType => paymentType.creditPayments),
    (0, typeorm_1.JoinColumn)({ name: 'paymentTypeId', referencedColumnName: 'paymentTypeId' }),
    __metadata("design:type", paymentType_1.PaymentTypeModel)
], CreditPaymentModel.prototype, "paymentType", void 0);
exports.CreditPaymentModel = CreditPaymentModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'credit', name: 'credit_payment' })
], CreditPaymentModel);
//# sourceMappingURL=creditPayment.js.map