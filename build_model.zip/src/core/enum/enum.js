"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.colorSettingsType = exports.RegisterProductType = exports.SaleType = exports.TypeOperationPaymentService = exports.TypeOperationDeviceHistory = void 0;
/**
 * Enumeración que representa los tipos de operaciones en el historial de dispositivos.
 *
 * Tipos de Operaciones:
 * - **Initialization (Inicialización)**: Utilizado cuando se inicializa un dispositivo por primera vez en el sistema.
 * - **Increase (Incremento)**: Utilizado cuando se incrementa la cantidad o el valor de un dispositivo.
 * - **Discount (Descuento)**: Utilizado cuando se aplica un descuento en la cantidad o el valor de un dispositivo.
 * - **Repayment (Reembolso)**: Utilizado cuando se realiza un reembolso relacionado con un dispositivo.
 */
var TypeOperationDeviceHistory;
(function (TypeOperationDeviceHistory) {
    TypeOperationDeviceHistory["Initialization"] = "initialization";
    TypeOperationDeviceHistory["Increase"] = "increase";
    TypeOperationDeviceHistory["Discount"] = "discount";
    TypeOperationDeviceHistory["Repayment"] = "repayment";
})(TypeOperationDeviceHistory || (exports.TypeOperationDeviceHistory = TypeOperationDeviceHistory = {}));
/**
 * Enumeración que representa el tipo de pago de un servicio.
 *
 * Tipos de Pago:
 * - **Advance (Anticipo)**: Utilizado cuando se realiza un pago parcial o un adelanto para el servicio.
 * - **Completion (Completado)**: Utilizado cuando el servicio se completa totalmente y se realiza el pago total.
 */
var TypeOperationPaymentService;
(function (TypeOperationPaymentService) {
    TypeOperationPaymentService["Advance"] = "advance";
    TypeOperationPaymentService["completion"] = "completion";
})(TypeOperationPaymentService || (exports.TypeOperationPaymentService = TypeOperationPaymentService = {}));
/**
 * Enumeración que representa el tipo de venta.
 *
 * Tipos de Venta:
 * - **Paid (Pagado)**: Utilizado cuando la venta ha sido pagada en su totalidad al momento de la transacción.
 * - **Credit (Crédito)**: Utilizado cuando la venta se realiza a crédito y el pago se diferirá en el tiempo.
 */
var SaleType;
(function (SaleType) {
    SaleType["Paid"] = "Paid";
    SaleType["Credit"] = "Credit";
})(SaleType || (exports.SaleType = SaleType = {}));
/**
 * Enumeración que representa los tipos de registro de productos.
 *
 * Tipos de Registro:
 * - **Detailed (Detallado)**: Utilizado cuando se registra un producto con información completa y detallada.
 * - **Basic (Básico)**: Utilizado cuando se registra un producto con la información mínima necesaria.
 */
var RegisterProductType;
(function (RegisterProductType) {
    RegisterProductType["Detailed"] = "detailed";
    RegisterProductType["Basic"] = "basic";
})(RegisterProductType || (exports.RegisterProductType = RegisterProductType = {}));
var colorSettingsType;
(function (colorSettingsType) {
    colorSettingsType["service"] = "service";
    colorSettingsType["proforma"] = "proforma";
})(colorSettingsType || (exports.colorSettingsType = colorSettingsType = {}));
//# sourceMappingURL=enum.js.map