"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.documentTypeController = exports.DocumentTypeController = void 0;
const documentType_service_1 = require("../service/documentType.service");
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../../common/constant/message.api");
const request_handler_1 = require("../../../common/handler/request.handler");
const transacction_handler_1 = require("../../../common/handler/transacction.handler");
class DocumentTypeController {
    static getInstance() {
        if (!this.instance)
            this.instance = new DocumentTypeController();
        return this.instance;
    }
    findDocumentTypeDataTable(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId } = request.query;
                const findResponse = yield documentType_service_1.documentTypeService.findDocumentType(Number(companyId));
                response.status(http_status_codes_1.StatusCodes.OK).json({
                    data: findResponse,
                    draw: Math.random(),
                    recordsFiltered: findResponse.length,
                    recordsTotal: findResponse.length,
                });
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    findDocumentType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { companyId } = request.query;
                const findResponse = yield documentType_service_1.documentTypeService.findDocumentType(Number(companyId));
                response.status(http_status_codes_1.StatusCodes.OK).json(findResponse);
            }
            catch (error) {
                response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: message_api_1.MessageCustomApi.ERROR_SERVER,
                    data: error
                });
            }
        });
    }
    createDocumentType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { documentType } = request.body;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const createResponse = yield documentType_service_1.documentTypeService.createDocumentType(documentType, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.CREATED_SUCCESS_DOCUMENT_TYPE, data: createResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    updateDocumentType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { documentType } = request.body;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const updateResponse = yield documentType_service_1.documentTypeService.updateDocumentType(documentType, queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.UPDATED_SUCCESS_DOCUMENT_TYPE, data: updateResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
    deleteDocumentType(request, response) {
        return __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(response, () => __awaiter(this, void 0, void 0, function* () {
                try {
                    const { id } = request.params;
                    const result = (0, transacction_handler_1.handleTransaction)((queryRunner) => __awaiter(this, void 0, void 0, function* () {
                        const updateResponse = yield documentType_service_1.documentTypeService.deleteDocumentType(parseInt(id), queryRunner);
                        return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.DELETED_SUCCESS_DOCUMENT_TYPE, data: updateResponse };
                    }));
                    return result;
                }
                catch (error) {
                    return {
                        code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                        success: false,
                        message: message_api_1.MessageCustomApi.ERROR_SERVER,
                        data: error
                    };
                }
            }));
        });
    }
}
exports.DocumentTypeController = DocumentTypeController;
exports.documentTypeController = DocumentTypeController.getInstance();
//# sourceMappingURL=documentType.js.map