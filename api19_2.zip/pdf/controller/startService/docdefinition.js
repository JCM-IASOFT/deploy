"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docStartServiceDefinition = void 0;
const content_1 = require("./content");
const docStartServiceDefinition = (service, campus, company) => __awaiter(void 0, void 0, void 0, function* () {
    const content = yield (0, content_1.ContentPdf)(service, campus, company);
    let namePdf = 'servicio_' + service.serviceId.toString().padStart(5, '0') + campus.name;
    const data = {
        pageSize: {
            width: 226.77,
            height: 'auto'
        },
        pageMargins: [
            5.66, 5.66, 5.66, 5.66
        ],
        info: {
            title: `${namePdf}`,
            author: 'maclode',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        content: content,
        styles: {
            header: {
                fontSize: 9,
                bold: true,
                alignment: 'center',
            },
            titleTable: {
                fontSize: 8,
                color: '#000000',
                alignment: 'left',
            },
            textGaranty: {
                fontSize: 8,
                color: '#000000',
                bold: true,
                alignment: 'left',
            },
            tHeaderLabel: {
                fontSize: 8,
                alignment: 'left',
            },
            tHeaderValue: {
                fontSize: 8,
                bold: true,
            },
            tProductsHeader: {
                fontSize: 8.5,
                bold: true,
            },
            tProductsBody: {
                fontSize: 8,
            },
            tTotals: {
                fontSize: 9,
                bold: true,
                alignment: 'right',
            },
            tClientLabel: {
                fontSize: 8,
                alignment: 'right',
            },
            tClientValue: {
                fontSize: 8,
                bold: true,
            },
            text: {
                fontSize: 8,
                alignment: 'center',
            },
            important: {
                fontSize: 9,
                bold: true,
                alignment: 'center',
            },
            message: {
                fontSize: 8.4,
                alignment: 'left',
            },
            link: {
                fontSize: 8,
                bold: true,
                margin: [0, 0, 0, 4],
                alignment: 'center',
            },
            icon: {
                font: 'Fontello',
                fontSize: 10
            }
        },
    };
    return data;
});
exports.docStartServiceDefinition = docStartServiceDefinition;
//# sourceMappingURL=docdefinition.js.map