"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteDeviceProduct = exports.validateUpdateDeviceProduct = exports.validateCreateDeviceProduct = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateCreateDeviceProduct = [
    (0, express_validator_1.check)('deviceProducts.*.deviceProductId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('deviceProducts.*.serviceDeviceId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('deviceProducts.*.productId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('deviceProducts.*.amount').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('deviceProducts.*.price').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('externalComponents.*.description').exists().isString().notEmpty(),
    (0, express_validator_1.check)('externalComponents.*.price').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('externalComponents.*.amount').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('externalComponents.*.serviceDeviceId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('externalComponents.*.voucher').exists(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateDeviceProduct = [
    (0, express_validator_1.check)('deviceProducts.*.deviceProductId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('deviceProducts.*.serviceDeviceId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('deviceProducts.*.productId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('deviceProducts.*.amount').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('deviceProducts.*.price').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('externalComponents.*.description').exists().isString().notEmpty(),
    (0, express_validator_1.check)('externalComponents.*.price').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('externalComponents.*.amount').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('externalComponents.*.serviceDeviceId').exists().isNumeric().not().isEmpty(),
    (0, express_validator_1.check)('externalComponents.*.voucher').exists(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteDeviceProduct = [
    (0, express_validator_1.check)('deviceProductId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=deviceproduct.validator.js.map