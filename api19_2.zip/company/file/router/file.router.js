"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileRoute = void 0;
const express_1 = require("express");
const file_controller_1 = require("../controller/file.controller");
const file_validator_1 = require("../validator/file.validator");
exports.fileRoute = (0, express_1.Router)();
exports.fileRoute.get('/', file_controller_1.fileController.findFile);
exports.fileRoute.post('/', file_validator_1.validateCreateFile, file_controller_1.fileController.createFiles);
exports.fileRoute.delete('/:fileId', file_validator_1.validateDeleteFile, file_controller_1.fileController.deleteFile);
//# sourceMappingURL=file.router.js.map