"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.zoneService = exports.ZoneService = void 0;
const errormessage_handler_1 = require("../../../common/handler/errormessage.handler");
const save_error_1 = require("../../../common/handler/save.error");
const modelslibrary_1 = require("modelslibrary");
class ZoneService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ZoneService();
        return this.instance;
    }
    findZone() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const zoneFind = yield modelslibrary_1.ZoneModel.find({
                    where: {
                        deletedAt: '0'
                    },
                    relations: {
                        district: {
                            province: {
                                departament: {
                                    country: true
                                }
                            }
                        }
                    }
                });
                return zoneFind;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    createZone(zone) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const zoneCreate = modelslibrary_1.ZoneModel.create(zone);
                return yield modelslibrary_1.ZoneModel.save(zoneCreate);
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    updateZone(zone) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const zoneUpdate = yield modelslibrary_1.ZoneModel.update({ zoneId: zone.zoneId }, {
                    description: zone.description,
                    districtId: zone.districtId,
                });
                return zoneUpdate;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
    deleteZone(zoneId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const zoneDelete = yield modelslibrary_1.ZoneModel.update({ zoneId: zoneId }, {
                    deletedAt: '1'
                });
                return zoneDelete;
            }
            catch (error) {
                save_error_1.logger.error((0, errormessage_handler_1.getErrorMessage)(error));
                throw error;
            }
        });
    }
}
exports.ZoneService = ZoneService;
exports.zoneService = ZoneService.getInstance();
//# sourceMappingURL=zone.service.js.map