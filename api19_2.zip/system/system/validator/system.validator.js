"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteServiceType = exports.validateUpdateServiceType = exports.validateCreateServiceType = exports.validateFindServiceType = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../../common/handler/validate.result");
exports.validateFindServiceType = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateCreateServiceType = [
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('typeTime').exists().not().isEmpty(),
    (0, express_validator_1.check)('time').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateUpdateServiceType = [
    (0, express_validator_1.check)('serviceTypeId').exists().not().isEmpty(),
    (0, express_validator_1.check)('description').exists().not().isEmpty(),
    (0, express_validator_1.check)('typeTime').exists().not().isEmpty(),
    (0, express_validator_1.check)('time').exists().not().isEmpty(),
    (0, express_validator_1.check)('campusId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
exports.validateDeleteServiceType = [
    (0, express_validator_1.check)('serviceTypeId').exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=system.validator.js.map