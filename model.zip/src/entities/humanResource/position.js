"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PositionModel = void 0;
const typeorm_1 = require("typeorm");
const company_1 = require("../company/company");
const employe_1 = require("./employe");
/**
 * * CARGOS
 */
let PositionModel = class PositionModel extends typeorm_1.BaseEntity {
};
exports.PositionModel = PositionModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], PositionModel.prototype, "positionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 150, default: '' }),
    __metadata("design:type", String)
], PositionModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, default: null }),
    __metadata("design:type", Number)
], PositionModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.positions),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], PositionModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => employe_1.EmployeModel, (store) => store.position),
    __metadata("design:type", Array)
], PositionModel.prototype, "employes", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PositionModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PositionModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PositionModel.prototype, "createdAt", void 0);
exports.PositionModel = PositionModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'human_resource', name: 'position' })
], PositionModel);
//# sourceMappingURL=position.js.map