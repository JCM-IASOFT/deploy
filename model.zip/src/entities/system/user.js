"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserModel = void 0;
const typeorm_1 = require("typeorm");
const serviceStatusHistory_1 = require("../support/serviceStatusHistory");
const service_1 = require("../support/service");
const sales_1 = require("../sales/sales");
const verification_1 = require("../support/verification");
const rolUser_1 = require("../system/rolUser");
const permissionUser_1 = require("../system/permissionUser");
const proformaQuote_1 = require("../sales/proformaQuote");
const servicePauseHistory_1 = require("../support/servicePauseHistory");
const cashWithdrawals_1 = require("../accounting/cashWithdrawals");
const permissionCampus_1 = require("../system/permissionCampus");
const membershipPayment_1 = require("../membership/membershipPayment");
const permissionCompany_1 = require("../system/permissionCompany");
const serviceTechnicalHistory_1 = require("../support/serviceTechnicalHistory");
const store_1 = require("../inventory/store");
const finance_model_1 = require("../accounting/finance.model");
const employe_1 = require("../humanResource/employe");
const client_1 = require("../sales/client");
let UserModel = class UserModel extends typeorm_1.BaseEntity {
};
exports.UserModel = UserModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], UserModel.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '' }),
    __metadata("design:type", String)
], UserModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '' }),
    __metadata("design:type", String)
], UserModel.prototype, "fullname", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 120, default: '' }),
    __metadata("design:type", String)
], UserModel.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 225, default: '' }),
    __metadata("design:type", String)
], UserModel.prototype, "password", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 225, default: '', nullable: true }),
    __metadata("design:type", String)
], UserModel.prototype, "salt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '', nullable: true }),
    __metadata("design:type", String)
], UserModel.prototype, "phone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', default: null, nullable: true, unique: true }),
    __metadata("design:type", String)
], UserModel.prototype, "documentNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], UserModel.prototype, "isAdmin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], UserModel.prototype, "employeId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => employe_1.EmployeModel, employe => employe.users),
    (0, typeorm_1.JoinColumn)({ name: 'employeId', referencedColumnName: 'employeId' }),
    __metadata("design:type", employe_1.EmployeModel)
], UserModel.prototype, "employe", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => rolUser_1.RoleUserModel, roleuser => roleuser.user),
    __metadata("design:type", Array)
], UserModel.prototype, "roleUsers", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permissionUser_1.PermissionUserModel, permissionUser => permissionUser.user),
    __metadata("design:type", Array)
], UserModel.prototype, "permissionUsers", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permissionCampus_1.PermissionCampusModel, permissionCampus => permissionCampus.user),
    __metadata("design:type", Array)
], UserModel.prototype, "permissionCampus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permissionCompany_1.PermissionCompanyModel, permissionCampus => permissionCampus.user),
    __metadata("design:type", Array)
], UserModel.prototype, "permissionCompanys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => serviceStatusHistory_1.ServiceStatusHistoryModel, servicestatushistory => servicestatushistory.user),
    __metadata("design:type", Array)
], UserModel.prototype, "serviceStatusHistorys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuote_1.ProformaQuoteModel, service => service.employe),
    __metadata("design:type", Array)
], UserModel.prototype, "proformaQuotes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sales_1.SalesModel, sales => sales.seller),
    __metadata("design:type", Array)
], UserModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => verification_1.VerificationModel, verification => verification.user),
    __metadata("design:type", Array)
], UserModel.prototype, "verifications", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => service_1.ServiceModel, service => service.userTechnical),
    __metadata("design:type", Array)
], UserModel.prototype, "servicesTechnical", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => service_1.ServiceModel, service => service.userDelivery),
    __metadata("design:type", Array)
], UserModel.prototype, "servicesDeliverys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => service_1.ServiceModel, service => service.userReception),
    __metadata("design:type", Array)
], UserModel.prototype, "servicesReception", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => store_1.StoreModel, store => store.userInCharge),
    __metadata("design:type", Array)
], UserModel.prototype, "store", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => servicePauseHistory_1.ServicePauseHistoryModel, servicepausehistory => servicepausehistory.userTechnical),
    __metadata("design:type", Array)
], UserModel.prototype, "servicePauseHistorys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => serviceTechnicalHistory_1.ServiceTechnicalHistoryModel, serviceTechnicalHistory => serviceTechnicalHistory.userTechnical),
    __metadata("design:type", Array)
], UserModel.prototype, "serviceTechnicalHistorys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => finance_model_1.FinanceModel, finance => finance.user),
    __metadata("design:type", Array)
], UserModel.prototype, "finances", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => cashWithdrawals_1.CashWithdrawalsModel, cashWithdrawals => cashWithdrawals.exitManager),
    __metadata("design:type", Array)
], UserModel.prototype, "cashWithdrawalsExits", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => cashWithdrawals_1.CashWithdrawalsModel, cashWithdrawals => cashWithdrawals.authorizationManager),
    __metadata("design:type", Array)
], UserModel.prototype, "cashWithdrawalsAuthorizations", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => membershipPayment_1.MembershipPaymentModel, membershipPayment => membershipPayment.user),
    __metadata("design:type", Array)
], UserModel.prototype, "membershipPayments", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => client_1.ClientModel, client => client.user, { nullable: true }),
    __metadata("design:type", client_1.ClientModel)
], UserModel.prototype, "client", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], UserModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], UserModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], UserModel.prototype, "createdAt", void 0);
exports.UserModel = UserModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'system', name: 'user' })
], UserModel);
//# sourceMappingURL=user.js.map