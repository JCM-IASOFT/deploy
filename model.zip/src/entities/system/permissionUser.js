"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermissionUserModel = void 0;
const typeorm_1 = require("typeorm");
const system_1 = require("./system");
const user_1 = require("./user");
let PermissionUserModel = class PermissionUserModel extends typeorm_1.BaseEntity {
};
exports.PermissionUserModel = PermissionUserModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], PermissionUserModel.prototype, "permissionUserId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PermissionUserModel.prototype, "actionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PermissionUserModel.prototype, "subjectId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PermissionUserModel.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PermissionUserModel.prototype, "systemId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, user => user.permissionUsers),
    (0, typeorm_1.JoinColumn)({ name: 'userId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], PermissionUserModel.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => system_1.SystemModel, system => system.permissionUsers),
    (0, typeorm_1.JoinColumn)({ name: 'systemId', referencedColumnName: 'systemId' }),
    __metadata("design:type", system_1.SystemModel)
], PermissionUserModel.prototype, "system", void 0);
exports.PermissionUserModel = PermissionUserModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'system', name: 'permission_user' })
], PermissionUserModel);
//# sourceMappingURL=permissionUser.js.map