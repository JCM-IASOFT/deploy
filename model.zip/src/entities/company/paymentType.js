"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentTypeModel = void 0;
const typeorm_1 = require("typeorm");
const payment_1 = require("../support/payment");
const paymentSales_1 = require("../sales/paymentSales");
const company_1 = require("./company");
const common_1 = require("../../core/common");
const proformaQuote_1 = require("../sales/proformaQuote");
const differencePayment_1 = require("../support/differencePayment");
const creditPayment_1 = require("../credit/creditPayment");
const paymentTransaction_1 = require("../accounting/paymentTransaction");
/**
 * * paymentType = Tipo de pagos
 */
let PaymentTypeModel = class PaymentTypeModel extends typeorm_1.BaseEntity {
};
exports.PaymentTypeModel = PaymentTypeModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], PaymentTypeModel.prototype, "paymentTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], PaymentTypeModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], PaymentTypeModel.prototype, "isFeatured", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: common_1.PaymentType,
        default: common_1.PaymentType.cash,
    }),
    __metadata("design:type", String)
], PaymentTypeModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentTypeModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => payment_1.PaymentModel, payment => payment.paymentType),
    __metadata("design:type", Array)
], PaymentTypeModel.prototype, "payments", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => differencePayment_1.DifferencePaymentModel, differencePayment => differencePayment.paymentType),
    __metadata("design:type", Array)
], PaymentTypeModel.prototype, "differencePayments", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.paymentTypes),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], PaymentTypeModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => paymentSales_1.PaymentSalesModel, paymentSales => paymentSales.paymentType),
    __metadata("design:type", Array)
], PaymentTypeModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => paymentTransaction_1.PaymentTransactionModel, payment => payment.paymentType),
    __metadata("design:type", Array)
], PaymentTypeModel.prototype, "paymentsTransaction", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuote_1.ProformaQuoteModel, service => service.paymentType),
    __metadata("design:type", Array)
], PaymentTypeModel.prototype, "proformaQuotes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => creditPayment_1.CreditPaymentModel, creditPayment => creditPayment.paymentType),
    __metadata("design:type", Array)
], PaymentTypeModel.prototype, "creditPayments", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PaymentTypeModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentTypeModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentTypeModel.prototype, "updatedBy", void 0);
exports.PaymentTypeModel = PaymentTypeModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: "payment_type" })
], PaymentTypeModel);
//# sourceMappingURL=paymentType.js.map