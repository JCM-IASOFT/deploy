"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceTypeModel = void 0;
const typeorm_1 = require("typeorm");
const serviceTypeDevice_1 = require("./serviceTypeDevice");
const device_1 = require("./device");
/**
 * * serviceType = Tipo de Servicio
 */
let ServiceTypeModel = class ServiceTypeModel extends typeorm_1.BaseEntity {
};
exports.ServiceTypeModel = ServiceTypeModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ServiceTypeModel.prototype, "serviceTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], ServiceTypeModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServiceTypeModel.prototype, "typeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServiceTypeModel.prototype, "time", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServiceTypeModel.prototype, "deviceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ServiceTypeModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => serviceTypeDevice_1.ServiceTypeDeviceModel, servicetypedevice => servicetypedevice.serviceType),
    __metadata("design:type", Array)
], ServiceTypeModel.prototype, "serviceTypeDevices", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => device_1.DeviceModel, device => device.serviceType),
    (0, typeorm_1.JoinColumn)({ name: 'deviceId', referencedColumnName: 'deviceId' }),
    __metadata("design:type", device_1.DeviceModel)
], ServiceTypeModel.prototype, "device", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ServiceTypeModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServiceTypeModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ServiceTypeModel.prototype, "updatedBy", void 0);
exports.ServiceTypeModel = ServiceTypeModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'support', name: "service_type" })
], ServiceTypeModel);
//# sourceMappingURL=serviceType.js.map