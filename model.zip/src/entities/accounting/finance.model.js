"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinanceModel = exports.typeOperation = void 0;
const typeorm_1 = require("typeorm");
const paymentTransaction_1 = require("./paymentTransaction");
const typeTransaction_1 = require("./typeTransaction");
const user_1 = require("../system/user");
const cashClosing_1 = require("./cashClosing");
var typeOperation;
(function (typeOperation) {
    typeOperation["ingreso"] = "ingreso";
    typeOperation["egreso"] = "egreso";
})(typeOperation || (exports.typeOperation = typeOperation = {}));
let FinanceModel = class FinanceModel extends typeorm_1.BaseEntity {
};
exports.FinanceModel = FinanceModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)("increment"),
    __metadata("design:type", Number)
], FinanceModel.prototype, "financeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, default: '' }),
    __metadata("design:type", String)
], FinanceModel.prototype, "details", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: typeOperation, default: typeOperation.egreso }),
    __metadata("design:type", String)
], FinanceModel.prototype, "typeOperation", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], FinanceModel.prototype, "attendant", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP', }),
    __metadata("design:type", Date
    // @Column({type: 'int', nullable: true})
    // serviceId: number
    )
], FinanceModel.prototype, "deliverDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], FinanceModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], FinanceModel.prototype, "typeTransactionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], FinanceModel.prototype, "cashClosingId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => paymentTransaction_1.PaymentTransactionModel, paymentTransaction => paymentTransaction.finance, { cascade: true, eager: true }),
    __metadata("design:type", Array)
], FinanceModel.prototype, "paymentTransaction", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => typeTransaction_1.TypeTransactionModel, typeTransaction => typeTransaction.finance, { eager: true }),
    (0, typeorm_1.JoinColumn)({ name: 'typeTransactionId', referencedColumnName: 'typeTransactionId' }),
    __metadata("design:type", typeTransaction_1.TypeTransactionModel)
], FinanceModel.prototype, "typeTransaction", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, user => user.finances),
    (0, typeorm_1.JoinColumn)({ name: 'attendant', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], FinanceModel.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => cashClosing_1.CashClosingModel, cashClosing => cashClosing.finances),
    (0, typeorm_1.JoinColumn)({ name: 'cashClosingId', referencedColumnName: 'cashClosingId' }),
    __metadata("design:type", cashClosing_1.CashClosingModel)
], FinanceModel.prototype, "cashClosing", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], FinanceModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FinanceModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FinanceModel.prototype, "updatedBy", void 0);
exports.FinanceModel = FinanceModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'finance' })
], FinanceModel);
//# sourceMappingURL=finance.model.js.map