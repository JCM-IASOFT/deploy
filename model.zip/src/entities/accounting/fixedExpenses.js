"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FixedExpensesModel = void 0;
const typeorm_1 = require("typeorm");
const fixedExpensesType_1 = require("./fixedExpensesType");
const fixedExpensesHistory_1 = require("./fixedExpensesHistory");
const campus_1 = require("../company/campus");
/**
 * Gastos fijos
 */
let FixedExpensesModel = class FixedExpensesModel extends typeorm_1.BaseEntity {
};
exports.FixedExpensesModel = FixedExpensesModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], FixedExpensesModel.prototype, "fixedExpensesId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 15,
        scale: 2,
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 15,
        scale: 2,
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesModel.prototype, "dailyPayment", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 150
    }),
    __metadata("design:type", String)
], FixedExpensesModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesModel.prototype, "fixedExpensesTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "timestamptz",
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "int",
        default: 0
    }),
    __metadata("design:type", Number)
], FixedExpensesModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => fixedExpensesType_1.FixedExpensesTypeModel, fixedType => fixedType.fixedExpenses),
    (0, typeorm_1.JoinColumn)({ name: 'fixedExpensesTypeId', referencedColumnName: 'fixedExpensesTypeId' }),
    __metadata("design:type", fixedExpensesType_1.FixedExpensesTypeModel)
], FixedExpensesModel.prototype, "fixedType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.fixedExpenses),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], FixedExpensesModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => fixedExpensesHistory_1.FixedExpensesHistoryModel, fixedExpensesHistory => fixedExpensesHistory.fixedExpenses),
    __metadata("design:type", Array)
], FixedExpensesModel.prototype, "fixedExpensesHistory", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], FixedExpensesModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], FixedExpensesModel.prototype, "createdAt", void 0);
exports.FixedExpensesModel = FixedExpensesModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'fixed_expenses' })
], FixedExpensesModel);
//# sourceMappingURL=fixedExpenses.js.map