"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProformaQuoteModel = void 0;
const typeorm_1 = require("typeorm");
const currency_1 = require("../company/currency");
const proformaQuoteType_1 = require("./proformaQuoteType");
const proformaQuoteDetail_1 = require("./proformaQuoteDetail");
const sales_1 = require("./sales");
const campus_1 = require("../company/campus");
const paymentType_1 = require("../company/paymentType");
const client_1 = require("./client");
const store_1 = require("../inventory/store");
const user_1 = require("../system/user");
const priceGroup_1 = require("./priceGroup");
let ProformaQuoteModel = class ProformaQuoteModel extends typeorm_1.BaseEntity {
};
exports.ProformaQuoteModel = ProformaQuoteModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "proformaQuoteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "clientId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "storeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, default: '' }),
    __metadata("design:type", String)
], ProformaQuoteModel.prototype, "observation", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "proformaQuoteTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "employeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "currencyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "paymentTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "priceGroupId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "timestamptz" }),
    __metadata("design:type", Date)
], ProformaQuoteModel.prototype, "registrationDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "timestamptz" }),
    __metadata("design:type", Date)
], ProformaQuoteModel.prototype, "expirationDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 1 }),
    __metadata("design:type", String)
], ProformaQuoteModel.prototype, "state", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'correlative', type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], ProformaQuoteModel.prototype, "correlative", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "totalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], ProformaQuoteModel.prototype, "totalPrice", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => client_1.ClientModel, client => client.proformaQuotes),
    (0, typeorm_1.JoinColumn)({ name: 'clientId', referencedColumnName: 'clientId' }),
    __metadata("design:type", client_1.ClientModel)
], ProformaQuoteModel.prototype, "client", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.proformaQuotes),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], ProformaQuoteModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => store_1.StoreModel, store => store.proformaQuotes),
    (0, typeorm_1.JoinColumn)({ name: 'storeId', referencedColumnName: 'storeId' }),
    __metadata("design:type", store_1.StoreModel)
], ProformaQuoteModel.prototype, "store", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => proformaQuoteType_1.ProformaQuoteTypeModel, proformaquotetype => proformaquotetype.proformaQuotes),
    (0, typeorm_1.JoinColumn)({ name: 'proformaQuoteTypeId', referencedColumnName: 'proformaQuoteTypeId' }),
    __metadata("design:type", proformaQuoteType_1.ProformaQuoteTypeModel)
], ProformaQuoteModel.prototype, "proformaQuoteType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, user => user.proformaQuotes),
    (0, typeorm_1.JoinColumn)({ name: 'employeId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], ProformaQuoteModel.prototype, "employe", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => currency_1.CurrencyModel, currency => currency.proformaQuotes),
    (0, typeorm_1.JoinColumn)({ name: 'currencyId', referencedColumnName: 'currencyId' }),
    __metadata("design:type", currency_1.CurrencyModel)
], ProformaQuoteModel.prototype, "currency", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => paymentType_1.PaymentTypeModel, paymentType => paymentType.proformaQuotes),
    (0, typeorm_1.JoinColumn)({ name: 'paymentTypeId', referencedColumnName: 'paymentTypeId' }),
    __metadata("design:type", paymentType_1.PaymentTypeModel)
], ProformaQuoteModel.prototype, "paymentType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => priceGroup_1.PriceGroupModel, pricegroup => pricegroup.proformaQuotes),
    (0, typeorm_1.JoinColumn)({ name: 'priceGroupId', referencedColumnName: 'priceGroupId' }),
    __metadata("design:type", priceGroup_1.PriceGroupModel)
], ProformaQuoteModel.prototype, "priceGroup", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuoteDetail_1.ProformaQuoteDetailModel, proformaquotedetail => proformaquotedetail.proformaQuote),
    __metadata("design:type", Array)
], ProformaQuoteModel.prototype, "proformaQuoteDetails", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sales_1.SalesModel, service => service.proformaQuote),
    __metadata("design:type", Array)
], ProformaQuoteModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ProformaQuoteModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ProformaQuoteModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ProformaQuoteModel.prototype, "deletedAt", void 0);
exports.ProformaQuoteModel = ProformaQuoteModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'proforma_quote' })
], ProformaQuoteModel);
//# sourceMappingURL=proformaQuote.js.map