"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientModel = void 0;
const typeorm_1 = require("typeorm");
const company_1 = require("../company/company");
const service_1 = require("../support/service");
const sales_1 = require("../sales/sales");
const survey_1 = require("../support/survey");
const proformaQuote_1 = require("../sales/proformaQuote");
const district_1 = require("../company/district");
const credit_1 = require("../credit/credit");
const clientType_1 = require("../company/clientType");
const documentType_1 = require("../humanResource/documentType");
let ClientModel = class ClientModel extends typeorm_1.BaseEntity {
};
exports.ClientModel = ClientModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ClientModel.prototype, "clientId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 150, default: '' }),
    __metadata("design:type", String)
], ClientModel.prototype, "fullname", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', default: null, nullable: true }),
    __metadata("design:type", String)
], ClientModel.prototype, "documentNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 120, default: '' }),
    __metadata("design:type", String)
], ClientModel.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 225, default: '' }),
    __metadata("design:type", String)
], ClientModel.prototype, "password", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 225, default: '' }),
    __metadata("design:type", String)
], ClientModel.prototype, "salt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], ClientModel.prototype, "coins", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '' }),
    __metadata("design:type", String)
], ClientModel.prototype, "phone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '' }),
    __metadata("design:type", String)
], ClientModel.prototype, "referencePhone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 225, default: '' }),
    __metadata("design:type", String)
], ClientModel.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ClientModel.prototype, "clientTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], ClientModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: null, nullable: true }),
    __metadata("design:type", Number)
], ClientModel.prototype, "districtId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: null, nullable: true }),
    __metadata("design:type", Number)
], ClientModel.prototype, "documentTypeId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.clients),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], ClientModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => clientType_1.ClientTypeModel, clientType => clientType.clients),
    (0, typeorm_1.JoinColumn)({ name: 'clientTypeId', referencedColumnName: 'clientTypeId' }),
    __metadata("design:type", clientType_1.ClientTypeModel)
], ClientModel.prototype, "clientType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => district_1.DistrictModel, district => district.clients),
    (0, typeorm_1.JoinColumn)({ name: 'districtId', referencedColumnName: 'districtId' }),
    __metadata("design:type", district_1.DistrictModel)
], ClientModel.prototype, "district", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => documentType_1.DocumentTypeModel, documentType => documentType.clients),
    (0, typeorm_1.JoinColumn)({ name: 'documentTypeId', referencedColumnName: 'documentTypeId' }),
    __metadata("design:type", documentType_1.DocumentTypeModel)
], ClientModel.prototype, "documentType", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => service_1.ServiceModel, service => service.client),
    __metadata("design:type", Array)
], ClientModel.prototype, "services", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sales_1.SalesModel, service => service.client),
    __metadata("design:type", Array)
], ClientModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => survey_1.SurveyModel, survey => survey.client),
    __metadata("design:type", Array)
], ClientModel.prototype, "survey", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => proformaQuote_1.ProformaQuoteModel, service => service.client),
    __metadata("design:type", Array)
], ClientModel.prototype, "proformaQuotes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => credit_1.CreditModel, credit => credit.client),
    __metadata("design:type", Array)
], ClientModel.prototype, "credit", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], ClientModel.prototype, "receiveWhatsapp", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ClientModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ClientModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ClientModel.prototype, "createdAt", void 0);
exports.ClientModel = ClientModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'clients' })
], ClientModel);
//# sourceMappingURL=client.js.map