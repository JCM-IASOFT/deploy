"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesModel = void 0;
const typeorm_1 = require("typeorm");
const paymentSales_1 = require("./paymentSales");
const salesDetail_1 = require("./salesDetail");
const currency_1 = require("../company/currency");
const proformaQuote_1 = require("./proformaQuote");
const campus_1 = require("../company/campus");
const credit_1 = require("../credit/credit");
const client_1 = require("./client");
const user_1 = require("../system/user");
const invoice_1 = require("../logistics/invoice");
const sales_enum_1 = require("../../core/enum/sales.enum");
const salesFree_1 = require("./salesFree");
const cashBoxDetail_1 = require("../accounting/cashBoxDetail");
let SalesModel = class SalesModel extends typeorm_1.BaseEntity {
};
exports.SalesModel = SalesModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], SalesModel.prototype, "salesId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], SalesModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 250, type: "varchar", default: '' }),
    __metadata("design:type", String)
], SalesModel.prototype, "observations", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], SalesModel.prototype, "clientId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], SalesModel.prototype, "proformaQuoteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesModel.prototype, "sellerId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], SalesModel.prototype, "totalPayment", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SalesModel.prototype, "invoiceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], SalesModel.prototype, "currencyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, default: '' }),
    __metadata("design:type", String)
], SalesModel.prototype, "correlative", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], SalesModel.prototype, "change", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "int", default: 0 }),
    __metadata("design:type", Number)
], SalesModel.prototype, "state", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: sales_enum_1.SaleType, default: sales_enum_1.SaleType.Paid }),
    __metadata("design:type", String)
], SalesModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: sales_enum_1.SaleModality, default: sales_enum_1.SaleModality.Product }),
    __metadata("design:type", String)
], SalesModel.prototype, "modality", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], SalesModel.prototype, "cashBoxDetailId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => currency_1.CurrencyModel, currency => currency.sales),
    (0, typeorm_1.JoinColumn)({ name: 'currencyId', referencedColumnName: 'currencyId' }),
    __metadata("design:type", currency_1.CurrencyModel)
], SalesModel.prototype, "currency", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => client_1.ClientModel, client => client.sales),
    (0, typeorm_1.JoinColumn)({ name: 'clientId', referencedColumnName: 'clientId' }),
    __metadata("design:type", client_1.ClientModel)
], SalesModel.prototype, "client", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => proformaQuote_1.ProformaQuoteModel, client => client.sales),
    (0, typeorm_1.JoinColumn)({ name: 'proformaQuoteId', referencedColumnName: 'proformaQuoteId' }),
    __metadata("design:type", proformaQuote_1.ProformaQuoteModel)
], SalesModel.prototype, "proformaQuote", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.sales),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], SalesModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, user => user.sales),
    (0, typeorm_1.JoinColumn)({ name: 'sellerId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], SalesModel.prototype, "seller", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => invoice_1.InvoiceModel, invoice => invoice.sales),
    (0, typeorm_1.JoinColumn)({ name: 'invoiceId', referencedColumnName: 'invoiceId' }),
    __metadata("design:type", invoice_1.InvoiceModel)
], SalesModel.prototype, "invoice", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => cashBoxDetail_1.CashBoxDetailModel, cashBoxDetail => cashBoxDetail.sales),
    (0, typeorm_1.JoinColumn)({ name: 'cashBoxDetailId', referencedColumnName: 'cashBoxDetailId' }),
    __metadata("design:type", cashBoxDetail_1.CashBoxDetailModel
    /**
     * Relación uno a muchos con PaymentSalesModel.
     */
    )
], SalesModel.prototype, "cashBoxDetail", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => paymentSales_1.PaymentSalesModel, paymentSales => paymentSales.sales),
    __metadata("design:type", Array)
], SalesModel.prototype, "paymentSales", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => salesDetail_1.SalesDetailModel, salesdetail => salesdetail.sales),
    __metadata("design:type", Array)
], SalesModel.prototype, "salesDetails", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => salesFree_1.SalesFreeModel, salesFree => salesFree.sales),
    __metadata("design:type", Array)
], SalesModel.prototype, "salesFrees", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => credit_1.CreditModel, (credit) => credit.sales, { nullable: true }),
    __metadata("design:type", credit_1.CreditModel)
], SalesModel.prototype, "credit", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], SalesModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], SalesModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], SalesModel.prototype, "updatedBy", void 0);
exports.SalesModel = SalesModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'sales' })
], SalesModel);
//# sourceMappingURL=sales.js.map