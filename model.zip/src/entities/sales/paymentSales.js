"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentSalesModel = void 0;
const typeorm_1 = require("typeorm");
const sales_1 = require("./sales");
const paymentType_1 = require("../company/paymentType");
/**
 * * payment = Pagos
 */
let PaymentSalesModel = class PaymentSalesModel extends typeorm_1.BaseEntity {
};
exports.PaymentSalesModel = PaymentSalesModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], PaymentSalesModel.prototype, "paymentSalesId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentSalesModel.prototype, "paymentTypeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2 }),
    __metadata("design:type", Number)
], PaymentSalesModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentSalesModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PaymentSalesModel.prototype, "salesId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => paymentType_1.PaymentTypeModel, paymentType => paymentType.sales, { eager: true }),
    (0, typeorm_1.JoinColumn)({ name: 'paymentTypeId', referencedColumnName: 'paymentTypeId' }),
    __metadata("design:type", paymentType_1.PaymentTypeModel)
], PaymentSalesModel.prototype, "paymentType", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sales_1.SalesModel, service => service.paymentSales),
    (0, typeorm_1.JoinColumn)({ name: 'salesId', referencedColumnName: 'salesId' }),
    __metadata("design:type", sales_1.SalesModel)
], PaymentSalesModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PaymentSalesModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentSalesModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PaymentSalesModel.prototype, "updatedBy", void 0);
exports.PaymentSalesModel = PaymentSalesModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'payment_sales' })
], PaymentSalesModel);
//# sourceMappingURL=paymentSales.js.map