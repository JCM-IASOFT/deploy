"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductFileModel = void 0;
const typeorm_1 = require("typeorm");
const product_1 = require("../inventory/product");
const file_1 = require("../company/file");
let ProductFileModel = class ProductFileModel extends typeorm_1.BaseEntity {
};
exports.ProductFileModel = ProductFileModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ProductFileModel.prototype, "productFileId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProductFileModel.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProductFileModel.prototype, "fileId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_1.ProductModel, (product) => product.productFiles),
    (0, typeorm_1.JoinColumn)({ name: 'productId', referencedColumnName: 'productId' }),
    __metadata("design:type", product_1.ProductModel)
], ProductFileModel.prototype, "product", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => file_1.FileModel, (file) => file.productFiles),
    (0, typeorm_1.JoinColumn)({ name: 'fileId', referencedColumnName: 'fileId' }),
    __metadata("design:type", file_1.FileModel)
], ProductFileModel.prototype, "file", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ProductFileModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ProductFileModel.prototype, "createdAt", void 0);
exports.ProductFileModel = ProductFileModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'inventory', name: 'product_file' })
], ProductFileModel);
//# sourceMappingURL=productFile.js.map