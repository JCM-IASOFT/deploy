"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PresentationModel = void 0;
const typeorm_1 = require("typeorm");
const measurement_1 = require("./measurement");
const product_1 = require("./product");
const company_1 = require("../company/company");
let PresentationModel = class PresentationModel extends typeorm_1.BaseEntity {
};
exports.PresentationModel = PresentationModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], PresentationModel.prototype, "presentationId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 100
    }),
    __metadata("design:type", String)
], PresentationModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 100
    }),
    __metadata("design:type", String)
], PresentationModel.prototype, "factor", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 100
    }),
    __metadata("design:type", String)
], PresentationModel.prototype, "tara", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'timestamptz',
        nullable: true
    }),
    __metadata("design:type", Date)
], PresentationModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        default: 0,
    }),
    __metadata("design:type", Number)
], PresentationModel.prototype, "measurementId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
    }),
    __metadata("design:type", Number)
], PresentationModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, (company) => company.presentations),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], PresentationModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => measurement_1.MeasurementModel, measurement => measurement.presentation),
    (0, typeorm_1.JoinColumn)({ name: 'measurementId', referencedColumnName: 'measurementId' }),
    __metadata("design:type", measurement_1.MeasurementModel)
], PresentationModel.prototype, "measurement", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_1.ProductModel, (product) => product.presentation),
    __metadata("design:type", product_1.ProductModel)
], PresentationModel.prototype, "products", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PresentationModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamptz',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PresentationModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], PresentationModel.prototype, "deletedAt", void 0);
exports.PresentationModel = PresentationModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'inventory', name: 'presentation' })
], PresentationModel);
//# sourceMappingURL=presentation.js.map