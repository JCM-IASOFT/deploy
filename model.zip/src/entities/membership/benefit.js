"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BenefitModel = void 0;
const typeorm_1 = require("typeorm");
const membership_1 = require("./membership");
/**
 * * BENEFICIOS DE LA MEMBRESIA
 */
let BenefitModel = class BenefitModel extends typeorm_1.BaseEntity {
};
exports.BenefitModel = BenefitModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)(),
    __metadata("design:type", Number)
], BenefitModel.prototype, "benefitId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", default: '', length: 200 }),
    __metadata("design:type", String)
], BenefitModel.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.ManyToMany)(() => membership_1.MembershipModel, membership => membership.benefits),
    __metadata("design:type", Array)
], BenefitModel.prototype, "memberships", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP', }),
    __metadata("design:type", Date)
], BenefitModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP', }),
    __metadata("design:type", Date)
], BenefitModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 1, default: () => '0' }),
    __metadata("design:type", String)
], BenefitModel.prototype, "deletedAt", void 0);
exports.BenefitModel = BenefitModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'membership', name: 'benefit' })
], BenefitModel);
//# sourceMappingURL=benefit.js.map