"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MembershipPaymentModel = void 0;
const typeorm_1 = require("typeorm");
const membership_1 = require("./membership");
const company_1 = require("../company/company");
const user_1 = require("../system/user");
/*
 * PAGO DE MENBRESIA
 */
let MembershipPaymentModel = class MembershipPaymentModel extends typeorm_1.BaseEntity {
};
exports.MembershipPaymentModel = MembershipPaymentModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], MembershipPaymentModel.prototype, "membershipPaymentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", default: '', length: 200 }),
    __metadata("design:type", String)
], MembershipPaymentModel.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], MembershipPaymentModel.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], MembershipPaymentModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], MembershipPaymentModel.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], MembershipPaymentModel.prototype, "membershipId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => company_1.CompanyModel, company => company.membershipPayments),
    (0, typeorm_1.JoinColumn)({ name: 'companyId', referencedColumnName: 'companyId' }),
    __metadata("design:type", company_1.CompanyModel)
], MembershipPaymentModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_1.UserModel, user => user.membershipPayments),
    (0, typeorm_1.JoinColumn)({ name: 'userId', referencedColumnName: 'userId' }),
    __metadata("design:type", user_1.UserModel)
], MembershipPaymentModel.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => membership_1.MembershipModel, (membership) => membership.membershipPayments),
    (0, typeorm_1.JoinColumn)({ name: 'membershipId', referencedColumnName: 'membershipId' }),
    __metadata("design:type", membership_1.MembershipModel)
], MembershipPaymentModel.prototype, "membership", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP', }),
    __metadata("design:type", Date)
], MembershipPaymentModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP', }),
    __metadata("design:type", Date)
], MembershipPaymentModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 1, default: () => '0' }),
    __metadata("design:type", String)
], MembershipPaymentModel.prototype, "deletedAt", void 0);
exports.MembershipPaymentModel = MembershipPaymentModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'membership', name: 'membership_payment' })
], MembershipPaymentModel);
//# sourceMappingURL=membershipPayment.js.map