"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeMovementStore = exports.typeMovement = exports.stateBox = exports.TypeTokenAuthenticate = exports.SystemTokenAuthenticate = exports.TypeTemplateHTML = exports.PaymentType = exports.TypeCampus = exports.Cash_Register_Type_Movement = exports.TypeProductMovement = exports.RoleUser = void 0;
var RoleUser;
(function (RoleUser) {
    RoleUser[RoleUser["user"] = 0] = "user";
    RoleUser[RoleUser["administrator"] = 1] = "administrator";
    RoleUser[RoleUser["super_user"] = 2] = "super_user";
    RoleUser[RoleUser["technical"] = 3] = "technical";
})(RoleUser || (exports.RoleUser = RoleUser = {}));
var TypeProductMovement;
(function (TypeProductMovement) {
    TypeProductMovement["transfer"] = "transfer";
    TypeProductMovement["income"] = "income";
    TypeProductMovement["outcome"] = "outcome";
    TypeProductMovement["incomeLocal"] = "incomeLocal";
    TypeProductMovement["outcomeLocal"] = "outcomeLocal";
    TypeProductMovement["outSale"] = "outSale";
})(TypeProductMovement || (exports.TypeProductMovement = TypeProductMovement = {}));
var Cash_Register_Type_Movement;
(function (Cash_Register_Type_Movement) {
    Cash_Register_Type_Movement["Income"] = "income";
    Cash_Register_Type_Movement["Outcome"] = "outcome";
})(Cash_Register_Type_Movement || (exports.Cash_Register_Type_Movement = Cash_Register_Type_Movement = {}));
var TypeCampus;
(function (TypeCampus) {
    TypeCampus["system_suport"] = "system_suport";
    TypeCampus["system_sales"] = "system_sales";
})(TypeCampus || (exports.TypeCampus = TypeCampus = {}));
var PaymentType;
(function (PaymentType) {
    PaymentType["cash"] = "cash";
    PaymentType["transfer"] = "transfer";
})(PaymentType || (exports.PaymentType = PaymentType = {}));
var TypeTemplateHTML;
(function (TypeTemplateHTML) {
    TypeTemplateHTML[TypeTemplateHTML["user_recoverPassword"] = 0] = "user_recoverPassword";
    TypeTemplateHTML[TypeTemplateHTML["client_newPassword"] = 1] = "client_newPassword";
    TypeTemplateHTML[TypeTemplateHTML["client_recoverPassword"] = 2] = "client_recoverPassword";
})(TypeTemplateHTML || (exports.TypeTemplateHTML = TypeTemplateHTML = {}));
var SystemTokenAuthenticate;
(function (SystemTokenAuthenticate) {
    SystemTokenAuthenticate["dashboard"] = "dashboard";
    SystemTokenAuthenticate["systemSales"] = "systemSales";
    SystemTokenAuthenticate["ecommerce"] = "ecommerce";
    SystemTokenAuthenticate["manager"] = "manger";
})(SystemTokenAuthenticate || (exports.SystemTokenAuthenticate = SystemTokenAuthenticate = {}));
var TypeTokenAuthenticate;
(function (TypeTokenAuthenticate) {
    TypeTokenAuthenticate["session"] = "session";
    TypeTokenAuthenticate["recover_password"] = "recover_password";
})(TypeTokenAuthenticate || (exports.TypeTokenAuthenticate = TypeTokenAuthenticate = {}));
var stateBox;
(function (stateBox) {
    stateBox["open"] = "open";
    stateBox["closed"] = "closed";
})(stateBox || (exports.stateBox = stateBox = {}));
var typeMovement;
(function (typeMovement) {
    typeMovement["income"] = "income";
    typeMovement["expense"] = "expense";
})(typeMovement || (exports.typeMovement = typeMovement = {}));
var typeMovementStore;
(function (typeMovementStore) {
    typeMovementStore["income"] = "income";
    typeMovementStore["exit"] = "exit";
})(typeMovementStore || (exports.typeMovementStore = typeMovementStore = {}));
//# sourceMappingURL=common.js.map