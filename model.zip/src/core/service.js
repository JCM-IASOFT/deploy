"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceLocation = void 0;
var ServiceLocation;
(function (ServiceLocation) {
    ServiceLocation["workshop"] = "Taller";
    ServiceLocation["home"] = "Domicilio";
})(ServiceLocation || (exports.ServiceLocation = ServiceLocation = {}));
//# sourceMappingURL=service.js.map