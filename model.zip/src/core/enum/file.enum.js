"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileType = void 0;
var FileType;
(function (FileType) {
    FileType["TEXT"] = "text/plain";
    FileType["PDF"] = "application/pdf";
    FileType["IMAGE_JPEG"] = "image/jpeg";
    FileType["IMAGE_PNG"] = "image/png";
    FileType["IMAGE_GIF"] = "image/gif";
    FileType["IMAGE_BMP"] = "image/bmp";
    FileType["AUDIO_MPEG"] = "audio/mpeg";
    FileType["AUDIO_WAV"] = "audio/wav";
    FileType["AUDIO_OGG"] = "audio/ogg";
    FileType["VIDEO_MP4"] = "video/mp4";
    FileType["VIDEO_AVI"] = "video/avi";
    FileType["VIDEO_MOV"] = "video/quicktime";
    FileType["ARCHIVE_ZIP"] = "application/zip";
    FileType["ARCHIVE_RAR"] = "application/x-rar-compressed";
    FileType["ARCHIVE_7Z"] = "application/x-7z-compressed";
    FileType["EXECUTABLE"] = "application/x-msdownload";
})(FileType || (exports.FileType = FileType = {}));
//# sourceMappingURL=file.enum.js.map