"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SaleModality = exports.SaleType = void 0;
/**
 * Enumeración que representa el tipo de venta.
 *
 * Tipos de Venta:
 * - **Paid (Pagado)**: Utilizado cuando la venta ha sido pagada en su totalidad al momento de la transacción.
 * - **Credit (Crédito)**: Utilizado cuando la venta se realiza a crédito y el pago se diferirá en el tiempo.
 */
var SaleType;
(function (SaleType) {
    SaleType["Paid"] = "Paid";
    SaleType["Credit"] = "Credit";
})(SaleType || (exports.SaleType = SaleType = {}));
/**
 * Enumeración que define las diferentes modalidades de ventas.
 * - `Libre`: Representa una venta sin productos asociados (venta libre).
 * - `Producto`: Representa una venta que involucra productos específicos (venta con producto).
 */
var SaleModality;
(function (SaleModality) {
    SaleModality["Free"] = "Free";
    SaleModality["Product"] = "Product"; // Venta con producto
})(SaleModality || (exports.SaleModality = SaleModality = {}));
//# sourceMappingURL=sales.enum.js.map