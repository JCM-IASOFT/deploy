"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypeService = exports.ServiceLocation = void 0;
var ServiceLocation;
(function (ServiceLocation) {
    ServiceLocation["Workshop"] = "Taller";
    ServiceLocation["Home"] = "Domicilio";
})(ServiceLocation || (exports.ServiceLocation = ServiceLocation = {}));
var TypeService;
(function (TypeService) {
    TypeService["Detail"] = "detail";
    TypeService["Fast"] = "fast";
})(TypeService || (exports.TypeService = TypeService = {}));
//# sourceMappingURL=service.enum.js.map