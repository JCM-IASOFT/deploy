"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WaitingTicketModel = void 0;
const typeorm_1 = require("typeorm");
const sector_1 = require("../company/sector");
/**
 * TICKET DE ESPERA
    - Permite genera ticket por orden de espera
 */
let WaitingTicketModel = class WaitingTicketModel extends typeorm_1.BaseEntity {
};
exports.WaitingTicketModel = WaitingTicketModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], WaitingTicketModel.prototype, "waitingTicketId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 150 }),
    __metadata("design:type", String)
], WaitingTicketModel.prototype, "correlative", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], WaitingTicketModel.prototype, "order", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp' }),
    __metadata("design:type", Date)
], WaitingTicketModel.prototype, "registrationDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], WaitingTicketModel.prototype, "state", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], WaitingTicketModel.prototype, "detail", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], WaitingTicketModel.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], WaitingTicketModel.prototype, "sectorId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], WaitingTicketModel.prototype, "clientId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sector_1.SectorModel, role => role.waitingtickets),
    (0, typeorm_1.JoinColumn)({ name: 'sectorId', referencedColumnName: 'sectorId' }),
    __metadata("design:type", sector_1.SectorModel)
], WaitingTicketModel.prototype, "sector", void 0);
exports.WaitingTicketModel = WaitingTicketModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'support', name: 'waiting_ticket' })
], WaitingTicketModel);
//# sourceMappingURL=waitingTicket.js.map