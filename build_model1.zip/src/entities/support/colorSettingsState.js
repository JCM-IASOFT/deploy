"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ColorSettingsStateModel = void 0;
const typeorm_1 = require("typeorm");
const enum_1 = require("../../core/enum/enum");
const campus_1 = require("../company/campus");
let ColorSettingsStateModel = class ColorSettingsStateModel extends typeorm_1.BaseEntity {
};
exports.ColorSettingsStateModel = ColorSettingsStateModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ColorSettingsStateModel.prototype, "colorSettingsStateId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 100,
        default: ''
    }),
    __metadata("design:type", String)
], ColorSettingsStateModel.prototype, "color", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 100,
        default: ''
    }),
    __metadata("design:type", String)
], ColorSettingsStateModel.prototype, "baseColor", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        default: '',
        length: 150,
    }),
    __metadata("design:type", String)
], ColorSettingsStateModel.prototype, "statusColor", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 150,
        default: ''
    }),
    __metadata("design:type", String)
], ColorSettingsStateModel.prototype, "statusText", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'boolean',
        default: true
    }),
    __metadata("design:type", Boolean)
], ColorSettingsStateModel.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        default: enum_1.colorSettingsType.service,
        enum: enum_1.colorSettingsType
    }),
    __metadata("design:type", String)
], ColorSettingsStateModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        default: enum_1.colorEffectType.static,
        enum: enum_1.colorEffectType
    }),
    __metadata("design:type", String)
], ColorSettingsStateModel.prototype, "colorEffect", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        nullable: true
    }),
    __metadata("design:type", Number)
], ColorSettingsStateModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => campus_1.CampusModel, campus => campus.colorSettingsState),
    (0, typeorm_1.JoinColumn)({ name: 'campusId', referencedColumnName: 'campusId' }),
    __metadata("design:type", campus_1.CampusModel)
], ColorSettingsStateModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], ColorSettingsStateModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ColorSettingsStateModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], ColorSettingsStateModel.prototype, "updatedBy", void 0);
exports.ColorSettingsStateModel = ColorSettingsStateModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'color_settings_state', schema: 'support' })
], ColorSettingsStateModel);
//# sourceMappingURL=colorSettingsState.js.map