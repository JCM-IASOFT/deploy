"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompanyModel = void 0;
const typeorm_1 = require("typeorm");
const campus_1 = require("./campus");
const product_1 = require("../inventory/product");
const category_1 = require("../inventory/category");
const brand_1 = require("../inventory/brand");
const currency_1 = require("./currency");
const presentation_1 = require("../inventory/presentation");
const group_1 = require("../inventory/group");
const measurement_1 = require("../inventory/measurement");
const unitMeasurement_1 = require("../inventory/unitMeasurement");
const district_1 = require("./district");
const paymentType_1 = require("./paymentType");
const sunat_1 = require("./sunat");
const membershipPayment_1 = require("../membership/membershipPayment");
const position_1 = require("../humanResource/position");
const permissionCompany_1 = require("../system/permissionCompany");
const credit_1 = require("../credit/credit");
const client_1 = require("../sales/client");
const supplier_1 = require("../logistics/supplier");
const typeMovement_1 = require("../inventory/typeMovement");
const clientType_1 = require("./clientType");
const documentType_1 = require("../humanResource/documentType");
const bank_1 = require("./bank");
const bankAccount_1 = require("./bankAccount");
const bankAccountType_1 = require("./bankAccountType");
const terminal_1 = require("../sales/terminal");
let CompanyModel = class CompanyModel extends typeorm_1.BaseEntity {
};
exports.CompanyModel = CompanyModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CompanyModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, default: '' }),
    __metadata("design:type", String)
], CompanyModel.prototype, "uuid", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bigint', default: 0 }),
    __metadata("design:type", Number)
], CompanyModel.prototype, "ruc", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '' }),
    __metadata("design:type", String)
], CompanyModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '' }),
    __metadata("design:type", String)
], CompanyModel.prototype, "alias", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '' }),
    __metadata("design:type", String)
], CompanyModel.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 10 }),
    __metadata("design:type", String)
], CompanyModel.prototype, "countryId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 10 }),
    __metadata("design:type", String)
], CompanyModel.prototype, "districtId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '' }),
    __metadata("design:type", String)
], CompanyModel.prototype, "web", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 125, default: '' }),
    __metadata("design:type", String)
], CompanyModel.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: '0' }),
    __metadata("design:type", String)
], CompanyModel.prototype, "phone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 250, default: '' }),
    __metadata("design:type", String)
], CompanyModel.prototype, "image", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => campus_1.CampusModel, (campus) => campus.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => product_1.ProductModel, (product) => product.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "products", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => client_1.ClientModel, (client) => client.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "clients", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => supplier_1.SupplierModel, (supplier) => supplier.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "suppliers", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => category_1.CategoryModel, (category) => category.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "categorys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => typeMovement_1.TypeMovementModel, (typeIncome) => typeIncome.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "typeMovements", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => paymentType_1.PaymentTypeModel, (paymentType) => paymentType.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "paymentTypes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => brand_1.BrandModel, (brand) => brand.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "brands", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => membershipPayment_1.MembershipPaymentModel, membershipPayment => membershipPayment.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "membershipPayments", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => position_1.PositionModel, (positions) => positions.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "positions", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permissionCompany_1.PermissionCompanyModel, permissionCampus => permissionCampus.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "permissionCompanys", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => clientType_1.ClientTypeModel, (clientTypes) => clientTypes.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "clientTypes", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => sunat_1.SunatModel, sunat => sunat.company, {
        nullable: true,
        onDelete: 'SET NULL',
    }),
    __metadata("design:type", sunat_1.SunatModel)
], CompanyModel.prototype, "sunat", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => district_1.DistrictModel, district => district.company),
    (0, typeorm_1.JoinColumn)({ name: 'districtId', referencedColumnName: 'districtId' }),
    __metadata("design:type", district_1.DistrictModel)
], CompanyModel.prototype, "district", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => documentType_1.DocumentTypeModel, (document) => document.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "documentTypes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => currency_1.CurrencyModel, (currency) => currency.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "currencies", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => bank_1.BankModel, (bank) => bank.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "banks", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => bankAccount_1.BankAccountModel, (bankAccount) => bankAccount.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "bankAccounts", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => bankAccountType_1.BankAccountTypeModel, (bankAccountType) => bankAccountType.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "bankAccountTypes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => unitMeasurement_1.UnitMeasurementModel, (unitMeasurement) => unitMeasurement.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "unitMeasurements", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => measurement_1.MeasurementModel, (measurement) => measurement.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "measurements", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => group_1.GroupModel, (group) => group.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "groups", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => presentation_1.PresentationModel, (presentation) => presentation.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "presentations", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => credit_1.CreditModel, (credit) => credit.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "credit", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => terminal_1.TerminalModel, (terminal) => terminal.company),
    __metadata("design:type", Array)
], CompanyModel.prototype, "terminals", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], CompanyModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CompanyModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CompanyModel.prototype, "createdAt", void 0);
exports.CompanyModel = CompanyModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: 'company' })
], CompanyModel);
//# sourceMappingURL=company.js.map