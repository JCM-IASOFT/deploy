"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DistrictModel = void 0;
const typeorm_1 = require("typeorm");
const departament_1 = require("./departament");
const province_1 = require("./province");
const company_1 = require("./company");
const campus_1 = require("./campus");
const zone_1 = require("./zone");
const client_1 = require("../sales/client");
let DistrictModel = class DistrictModel extends typeorm_1.BaseEntity {
};
exports.DistrictModel = DistrictModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({
        type: 'varchar',
        length: 10
    }),
    __metadata("design:type", String)
], DistrictModel.prototype, "districtId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "varchar",
        length: 150,
        default: ''
    }),
    __metadata("design:type", String)
], DistrictModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar'
    }),
    __metadata("design:type", String)
], DistrictModel.prototype, "provinceId", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar'
    }),
    __metadata("design:type", String)
], DistrictModel.prototype, "departamentId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => province_1.ProvinceModel, province => province.districts),
    (0, typeorm_1.JoinColumn)({ name: 'provinceId', referencedColumnName: 'provinceId' }),
    __metadata("design:type", province_1.ProvinceModel)
], DistrictModel.prototype, "province", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => departament_1.DepartamentModel, departament => departament.districts),
    (0, typeorm_1.JoinColumn)({ name: 'departamentId', referencedColumnName: 'departamentId' }),
    __metadata("design:type", departament_1.DepartamentModel)
], DistrictModel.prototype, "departament", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => company_1.CompanyModel, company => company.district),
    __metadata("design:type", Array)
], DistrictModel.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => zone_1.ZoneModel, zone => zone.district),
    __metadata("design:type", Array)
], DistrictModel.prototype, "zones", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => campus_1.CampusModel, campus => campus.district),
    __metadata("design:type", Array)
], DistrictModel.prototype, "campus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => client_1.ClientModel, client => client.district),
    __metadata("design:type", Array)
], DistrictModel.prototype, "clients", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], DistrictModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], DistrictModel.prototype, "updatedBy", void 0);
exports.DistrictModel = DistrictModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'company', name: 'district' })
], DistrictModel);
//# sourceMappingURL=district.js.map