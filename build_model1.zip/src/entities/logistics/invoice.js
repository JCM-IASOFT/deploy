"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvoiceModel = void 0;
const typeorm_1 = require("typeorm");
const invoiceCampus_1 = require("./invoiceCampus");
const sales_1 = require("../sales/sales");
const invoice_enum_1 = require("../../core/enum/invoice.enum");
const correlatives_1 = require("../system/correlatives");
const invoiceSerie_1 = require("./invoiceSerie");
/**
 * * DOCUMENTOS DE FACTURAS
 */
let InvoiceModel = class InvoiceModel extends typeorm_1.BaseEntity {
};
exports.InvoiceModel = InvoiceModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], InvoiceModel.prototype, "invoiceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 10 }),
    __metadata("design:type", String)
], InvoiceModel.prototype, "code", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 80 }),
    __metadata("design:type", String)
], InvoiceModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: invoice_enum_1.TypeInvoice, default: invoice_enum_1.TypeInvoice.sales }),
    __metadata("design:type", String)
], InvoiceModel.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], InvoiceModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], InvoiceModel.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date
    // ** invoicecampus []
    )
], InvoiceModel.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => invoiceCampus_1.InvoiceCampusModel, payment => payment.invoice),
    __metadata("design:type", Array)
], InvoiceModel.prototype, "invoicescampus", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => invoiceSerie_1.InvoiceSerieModel, invoiceSerie => invoiceSerie.invoice),
    __metadata("design:type", Array)
], InvoiceModel.prototype, "invoiceSeries", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sales_1.SalesModel, sales => sales.invoice),
    __metadata("design:type", Array)
], InvoiceModel.prototype, "sales", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => correlatives_1.CorrelativeModel, sales => sales.invoice),
    __metadata("design:type", Array)
], InvoiceModel.prototype, "correlatives", void 0);
exports.InvoiceModel = InvoiceModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'logistics', name: 'invoice' })
], InvoiceModel);
//# sourceMappingURL=invoice.js.map