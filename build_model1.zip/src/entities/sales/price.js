"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PriceModel = void 0;
const typeorm_1 = require("typeorm");
const priceGroup_1 = require("./priceGroup");
const product_1 = require("../inventory/product");
/**
 * * LISTA DE PRECIOS
 * - Cada producto puede tener su varios lista de precios
 */
let PriceModel = class PriceModel extends typeorm_1.BaseEntity {
};
exports.PriceModel = PriceModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], PriceModel.prototype, "priceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PriceModel.prototype, "priceGroupId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], PriceModel.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => priceGroup_1.PriceGroupModel, (priceGroup) => priceGroup.prices),
    (0, typeorm_1.JoinColumn)({ name: 'priceGroupId', referencedColumnName: 'priceGroupId' }),
    __metadata("design:type", priceGroup_1.PriceGroupModel)
], PriceModel.prototype, "priceGroup", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_1.ProductModel, (product) => product.prices, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'productId', referencedColumnName: 'productId' }),
    __metadata("design:type", product_1.ProductModel)
], PriceModel.prototype, "product", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], PriceModel.prototype, "price", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], PriceModel.prototype, "priceMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, }),
    __metadata("design:type", Number)
], PriceModel.prototype, "marginGain", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PriceModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], PriceModel.prototype, "createdAt", void 0);
exports.PriceModel = PriceModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sales', name: 'prices' })
], PriceModel);
//# sourceMappingURL=price.js.map