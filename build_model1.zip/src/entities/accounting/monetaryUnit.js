"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MonetaryUnitModel = void 0;
const typeorm_1 = require("typeorm");
const accounting_1 = require("../../core/accounting");
const cashTonnageDetail_1 = require("../accounting/cashTonnageDetail");
/**
 * * Unidad Monetario
 */
let MonetaryUnitModel = class MonetaryUnitModel extends typeorm_1.BaseEntity {
};
exports.MonetaryUnitModel = MonetaryUnitModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], MonetaryUnitModel.prototype, "monetaryUnitId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: accounting_1.MonetaryUnit }),
    __metadata("design:type", String)
], MonetaryUnitModel.prototype, "monetaryUnit", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 15, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], MonetaryUnitModel.prototype, "denomination", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], MonetaryUnitModel.prototype, "companyId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => cashTonnageDetail_1.CashTonnageDetailModel, cashtonnage => cashtonnage.monetaryUnit),
    __metadata("design:type", Array)
], MonetaryUnitModel.prototype, "cashTonnageDetails", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], MonetaryUnitModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], MonetaryUnitModel.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], MonetaryUnitModel.prototype, "updatedAt", void 0);
exports.MonetaryUnitModel = MonetaryUnitModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'monetary_unit' })
], MonetaryUnitModel);
//# sourceMappingURL=monetaryUnit.js.map