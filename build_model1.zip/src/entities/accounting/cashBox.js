"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CashBoxModel = void 0;
const typeorm_1 = require("typeorm");
const cashBoxDetail_1 = require("./cashBoxDetail");
const cashWithdrawals_1 = require("./cashWithdrawals");
/**
 * * Caja
 */
let CashBoxModel = class CashBoxModel extends typeorm_1.BaseEntity {
};
exports.CashBoxModel = CashBoxModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CashBoxModel.prototype, "cashBoxId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CashBoxModel.prototype, "campusId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", default: '' }),
    __metadata("design:type", String)
], CashBoxModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => cashBoxDetail_1.CashBoxDetailModel, details => details.cashBox),
    __metadata("design:type", Array)
], CashBoxModel.prototype, "cashBoxDetails", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => cashWithdrawals_1.CashWithdrawalsModel, cashWithdrawals => cashWithdrawals.cashBox),
    __metadata("design:type", Array)
], CashBoxModel.prototype, "cashWithdrawals", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'char', length: 1,
        default: () => '0',
    }),
    __metadata("design:type", String)
], CashBoxModel.prototype, "deletedAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashBoxModel.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        type: 'timestamp',
        default: () => 'CURRENT_TIMESTAMP',
    }),
    __metadata("design:type", Date)
], CashBoxModel.prototype, "createdAt", void 0);
exports.CashBoxModel = CashBoxModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'accounting', name: 'cash_box', comment: 'Caja' })
], CashBoxModel);
//# sourceMappingURL=cashBox.js.map