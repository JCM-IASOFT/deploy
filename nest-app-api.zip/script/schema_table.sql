SELECT 
    UPPER(table_schema || '_' || table_name) || ': "' || table_schema || '.' || table_name || '"' AS json_constant
FROM information_schema.tables
WHERE table_type = 'BASE TABLE'
ORDER BY table_schema, table_name;
